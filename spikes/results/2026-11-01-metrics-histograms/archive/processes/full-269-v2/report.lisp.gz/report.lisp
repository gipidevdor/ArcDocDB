(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "13ff9cf16754f4088482c23ca00c616f1f6a5247")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "5296ffb7a602a50cd9ad1ab7c778f1b1715a5db8")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c9ecda2372aa0df71d990e0a34b06b0f339a2e7f")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/0083-explicit-unix-write-groups.md" :GIT-BLOB
   "fbca2463c1168aabadea5dcaae48fd1dbaeffcfe")
  (:PATH "docs/adr/0084-explicit-unix-read-groups.md" :GIT-BLOB
   "d5882e72757a731cd02d71f7ae97208b2cdffce0")
  (:PATH "docs/adr/0085-conditional-current-writes.md" :GIT-BLOB
   "9ccb72269093a95c3be1a665a9809c8130096f2d")
  (:PATH "docs/adr/0086-conditional-same-turn-group-commit.md" :GIT-BLOB
   "f3aad4767ed3f071173c4b9622c92fc27aaa8e7a")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "4cba1cdd6543ac3270de9b5a3aaba9bc050f27a8")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "c009a8ff3b30cc1eccf6c2e0026ee3b31ad319b6")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/istogrammi-latenza-metodo.md" :GIT-BLOB
   "135ed8079d19debda9889ef22a5d1a4174a3772b")
  (:PATH "docs/implementazione/istogrammi-latenza.md" :GIT-BLOB
   "12a49cd06238f3c7c2f892f960dee64d8f5b834a")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "89f3084e99573598937a4441056a5f4b4de9daba")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "0b04bca9cb16e03de10f6c2a049b54499209bf71")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "9dec3fa5710113d8bd90f7e3428b82fee531d445")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "d4346b4c6b8d09d503af55d8607102f95e795368")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "d0f6545bbe38571f10a705c84888af6c998ee82a")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/conditional-group-types.lisp" :GIT-BLOB
   "f018f3b3512695c2fd5cc35f88e0e04ca90aef19")
  (:PATH "src/engine/conditional-group.lisp" :GIT-BLOB
   "f502618dc0a4c33aa5024408baccb116ed943c94")
  (:PATH "src/engine/conditional.lisp" :GIT-BLOB
   "e31cf1694c34220247c84e57022561e3757aa796")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b67b3b15539954ba4d3c92fcb3f4ccfafebca4c1")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a1737e9c70b317464520811512a42d4ae059bbdd")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "9a3c91e2a88056e611555fad3f5bd90c3ec1cbdd")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client-group.lisp" :GIT-BLOB
   "a55657c6d0e22e5dedf411fe33aa6c2f1c153503")
  (:PATH "src/local/client-read-group.lisp" :GIT-BLOB
   "3ca89d062de82fec20c9410c7149e53a4741755b")
  (:PATH "src/local/client-version.lisp" :GIT-BLOB
   "9880ac8380a3db16e8eb22f70ae63d3d8d7943f2")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "47492d1a5fa77ae0e2d8b800fab22c9de5731d0e")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "a91b682e33a379df493117b289ce9fcd7257512c")
  (:PATH "src/local/group-build.lisp" :GIT-BLOB
   "428ad39cb77c5e6e5e9328a1ac9e86e27646174a")
  (:PATH "src/local/group-dispatch.lisp" :GIT-BLOB
   "302d9e8be91d13b7602e9102eb4a1022e437e0da")
  (:PATH "src/local/group-read.lisp" :GIT-BLOB
   "ba4b57f80dec489589233d4d62d6d87084600026")
  (:PATH "src/local/group-types.lisp" :GIT-BLOB
   "3e800ffbe26f8336a5205c5a4fda66bbbb05223d")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "7c4e8b761092905a3f2bb87c584e80ccf242e2fb")
  (:PATH "src/local/read-group-dispatch.lisp" :GIT-BLOB
   "36e54c6bc2f11c73dfc9dec62a32f3975ad5edee")
  (:PATH "src/local/read-group-wire.lisp" :GIT-BLOB
   "e959bfb13b654e27f5420bf6abcb9f48197960c3")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "7ed8bb00adfb30a554c872738f45dfa14ffc816f")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "3b255168238b40516b2fb39f617b70382e672224")
  (:PATH "src/local/version-dispatch.lisp" :GIT-BLOB
   "861ebbf4facb1fcdde20fea1d5a28ed4ed03faf4")
  (:PATH "src/local/version-wire.lisp" :GIT-BLOB
   "bf2032d91087f0eeb1f947128a005b446b8f6c4c")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "8ac136524ef6e80af8a0b883d15423cb3731d5ef")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "0261a301e8fef9d9dab6cd12a5f7da04633e4a24")
  (:PATH "src/local/write-queue.lisp" :GIT-BLOB
   "739d7a6ba109c153afe9534a98dbe04f21efb844")
  (:PATH "src/metrics/build.lisp" :GIT-BLOB
   "50cd7cc335a8f3016c4e1ba041f639c3ff86a72a")
  (:PATH "src/metrics/geometry.lisp" :GIT-BLOB
   "0296b72a27584238cb5364c2454a573e8533d5f2")
  (:PATH "src/metrics/package.lisp" :GIT-BLOB
   "32a6b72af6c82c058f06a9ffc5c6bc706df48aee")
  (:PATH "src/metrics/quantile.lisp" :GIT-BLOB
   "8e45b9613f63129f611a95155b10a27d2982c257")
  (:PATH "src/metrics/record.lisp" :GIT-BLOB
   "5da0431c37b0a7d0cff27c7e117de27277797487")
  (:PATH "src/metrics/snapshot.lisp" :GIT-BLOB
   "d2f483b6b7c1ff5cf78552cc0b5da020e22613b1")
  (:PATH "src/metrics/types.lisp" :GIT-BLOB
   "c75da0ff4fbeabb78c2d281879320d96b4674e43")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "ac09f6481b8be9e120531facce2735881cb815c5")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/conditional-group.lisp" :GIT-BLOB
   "bb7b7ee3e52c0b3c0ae69c2bdc48de594f0bd945")
  (:PATH "tests/engine/conditional.lisp" :GIT-BLOB
   "dc0a709ca6f298ccb870dc2e57504831c01d4285")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/client-group.lisp" :GIT-BLOB
   "910301588c9d671c2b67950d393d6dabc759adc8")
  (:PATH "tests/local/conditional-group-processes.lisp" :GIT-BLOB
   "3fbda41b85d7b3ea69b36b4b9165be82bdbeda00")
  (:PATH "tests/local/conditional-group.lisp" :GIT-BLOB
   "67c45820cbaead998fad90500f697c52d241884b")
  (:PATH "tests/local/explicit-group.lisp" :GIT-BLOB
   "d2ab3e8180c6c27791ea29458526fd2e6be732ff")
  (:PATH "tests/local/group-processes.lisp" :GIT-BLOB
   "8a1d7078a5b37124cfa30867860e47f56ed77f00")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/read-group-processes.lisp" :GIT-BLOB
   "818db6481b2d9e2cc1dce4703bba1516a4b88542")
  (:PATH "tests/local/read-group.lisp" :GIT-BLOB
   "31871cfd92a2cd26de0c486ba497e5d547cae864")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/version-processes.lisp" :GIT-BLOB
   "33a51023abe1a9a5e7b08926caf8fd2ff2f1e9bc")
  (:PATH "tests/local/version.lisp" :GIT-BLOB
   "52a44805faa6d6356ca17258885a986001231b76")
  (:PATH "tests/local/wire-group.lisp" :GIT-BLOB
   "f1caba660e45e35c58ecf27219d934f5277ccf4c")
  (:PATH "tests/local/wire-read-group.lisp" :GIT-BLOB
   "0cd9467362f5ea82e57ba40f837b1f0475500d29")
  (:PATH "tests/local/wire-version.lisp" :GIT-BLOB
   "c2c31b1ada9ed7ffa54caa8f6a0253cccab66bf1")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/metrics/allocation.lisp" :GIT-BLOB
   "cfaf35cc4a712fe6568d6e030be6ed0b462785ed")
  (:PATH "tests/metrics/geometry.lisp" :GIT-BLOB
   "94ff658183fff2de005470a05cf2ac1c4e7355ca")
  (:PATH "tests/metrics/isolation.lisp" :GIT-BLOB
   "725d8c2a130afc70f0e43c573d58d90154a82762")
  (:PATH "tests/metrics/limits.lisp" :GIT-BLOB
   "06b0b497c5ebb4781986b9f591ec98ffdc692ddf")
  (:PATH "tests/metrics/quantiles.lisp" :GIT-BLOB
   "90c6ebfd2b8d3ef6b9c3df37794b8af334011f06")
  (:PATH "tests/metrics/support.lisp" :GIT-BLOB
   "d57b8c0d7be06b771c572baf410339b73564d32b")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "7f53d379a5106a4184a96e3b2f27b2258df5f1b6")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "f9df56890db8231bb26fba808eabebd2cab3e22a")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-conditional-group-server.lisp" :GIT-BLOB
   "92145f31ddb22c4e6c205413ad31fdb24fc0dc17")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-read-loss-server.lisp" :GIT-BLOB
   "56f7401d185564c0bfe9c834742812fc42a4a6a7")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/local-version-loss-server.lisp" :GIT-BLOB
   "89f4ed52dd4f7de5b0b4ac2420f3aaef78618a41")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/metrics-histogram-bench.lisp" :GIT-BLOB
   "8655bbb485abb7bf1adfacd1b9361aaa472682a5")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 866.952618d0 :FINISHED-AT-UNIVERSAL-TIME 4002524884
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.2.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 3.19 4.01 5.54 }" :COMMIT
  "46d254e8025c70861adc397be4a559eb4b07a543" :WORKING-TREE "" :CWD
  #A((72) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4002524018)
 :COMMAND
 (#A((40) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/bin/sbcl")
  #A((10) BASE-CHAR . "--noinform") #A((13) BASE-CHAR . "--no-userinit")
  #A((12) BASE-CHAR . "--no-sysinit") #A((8) BASE-CHAR . "--script")
  #A((58) BASE-CHAR
     . "spikes/out/metrics-histograms-20261101/verify-product.lisp")
  #A((4) BASE-CHAR . "full") #A((6) BASE-CHAR . "269-v2"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4002524018 :SOURCE-BLOBS-BEFORE
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "13ff9cf16754f4088482c23ca00c616f1f6a5247")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "5296ffb7a602a50cd9ad1ab7c778f1b1715a5db8")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c9ecda2372aa0df71d990e0a34b06b0f339a2e7f")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/0083-explicit-unix-write-groups.md" :GIT-BLOB
   "fbca2463c1168aabadea5dcaae48fd1dbaeffcfe")
  (:PATH "docs/adr/0084-explicit-unix-read-groups.md" :GIT-BLOB
   "d5882e72757a731cd02d71f7ae97208b2cdffce0")
  (:PATH "docs/adr/0085-conditional-current-writes.md" :GIT-BLOB
   "9ccb72269093a95c3be1a665a9809c8130096f2d")
  (:PATH "docs/adr/0086-conditional-same-turn-group-commit.md" :GIT-BLOB
   "f3aad4767ed3f071173c4b9622c92fc27aaa8e7a")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "4cba1cdd6543ac3270de9b5a3aaba9bc050f27a8")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "c009a8ff3b30cc1eccf6c2e0026ee3b31ad319b6")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/istogrammi-latenza-metodo.md" :GIT-BLOB
   "135ed8079d19debda9889ef22a5d1a4174a3772b")
  (:PATH "docs/implementazione/istogrammi-latenza.md" :GIT-BLOB
   "12a49cd06238f3c7c2f892f960dee64d8f5b834a")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "89f3084e99573598937a4441056a5f4b4de9daba")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "0b04bca9cb16e03de10f6c2a049b54499209bf71")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "9dec3fa5710113d8bd90f7e3428b82fee531d445")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "d4346b4c6b8d09d503af55d8607102f95e795368")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "d0f6545bbe38571f10a705c84888af6c998ee82a")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/conditional-group-types.lisp" :GIT-BLOB
   "f018f3b3512695c2fd5cc35f88e0e04ca90aef19")
  (:PATH "src/engine/conditional-group.lisp" :GIT-BLOB
   "f502618dc0a4c33aa5024408baccb116ed943c94")
  (:PATH "src/engine/conditional.lisp" :GIT-BLOB
   "e31cf1694c34220247c84e57022561e3757aa796")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b67b3b15539954ba4d3c92fcb3f4ccfafebca4c1")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a1737e9c70b317464520811512a42d4ae059bbdd")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "9a3c91e2a88056e611555fad3f5bd90c3ec1cbdd")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client-group.lisp" :GIT-BLOB
   "a55657c6d0e22e5dedf411fe33aa6c2f1c153503")
  (:PATH "src/local/client-read-group.lisp" :GIT-BLOB
   "3ca89d062de82fec20c9410c7149e53a4741755b")
  (:PATH "src/local/client-version.lisp" :GIT-BLOB
   "9880ac8380a3db16e8eb22f70ae63d3d8d7943f2")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "47492d1a5fa77ae0e2d8b800fab22c9de5731d0e")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "a91b682e33a379df493117b289ce9fcd7257512c")
  (:PATH "src/local/group-build.lisp" :GIT-BLOB
   "428ad39cb77c5e6e5e9328a1ac9e86e27646174a")
  (:PATH "src/local/group-dispatch.lisp" :GIT-BLOB
   "302d9e8be91d13b7602e9102eb4a1022e437e0da")
  (:PATH "src/local/group-read.lisp" :GIT-BLOB
   "ba4b57f80dec489589233d4d62d6d87084600026")
  (:PATH "src/local/group-types.lisp" :GIT-BLOB
   "3e800ffbe26f8336a5205c5a4fda66bbbb05223d")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "7c4e8b761092905a3f2bb87c584e80ccf242e2fb")
  (:PATH "src/local/read-group-dispatch.lisp" :GIT-BLOB
   "36e54c6bc2f11c73dfc9dec62a32f3975ad5edee")
  (:PATH "src/local/read-group-wire.lisp" :GIT-BLOB
   "e959bfb13b654e27f5420bf6abcb9f48197960c3")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "7ed8bb00adfb30a554c872738f45dfa14ffc816f")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "3b255168238b40516b2fb39f617b70382e672224")
  (:PATH "src/local/version-dispatch.lisp" :GIT-BLOB
   "861ebbf4facb1fcdde20fea1d5a28ed4ed03faf4")
  (:PATH "src/local/version-wire.lisp" :GIT-BLOB
   "bf2032d91087f0eeb1f947128a005b446b8f6c4c")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "8ac136524ef6e80af8a0b883d15423cb3731d5ef")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "0261a301e8fef9d9dab6cd12a5f7da04633e4a24")
  (:PATH "src/local/write-queue.lisp" :GIT-BLOB
   "739d7a6ba109c153afe9534a98dbe04f21efb844")
  (:PATH "src/metrics/build.lisp" :GIT-BLOB
   "50cd7cc335a8f3016c4e1ba041f639c3ff86a72a")
  (:PATH "src/metrics/geometry.lisp" :GIT-BLOB
   "0296b72a27584238cb5364c2454a573e8533d5f2")
  (:PATH "src/metrics/package.lisp" :GIT-BLOB
   "32a6b72af6c82c058f06a9ffc5c6bc706df48aee")
  (:PATH "src/metrics/quantile.lisp" :GIT-BLOB
   "8e45b9613f63129f611a95155b10a27d2982c257")
  (:PATH "src/metrics/record.lisp" :GIT-BLOB
   "5da0431c37b0a7d0cff27c7e117de27277797487")
  (:PATH "src/metrics/snapshot.lisp" :GIT-BLOB
   "d2f483b6b7c1ff5cf78552cc0b5da020e22613b1")
  (:PATH "src/metrics/types.lisp" :GIT-BLOB
   "c75da0ff4fbeabb78c2d281879320d96b4674e43")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "ac09f6481b8be9e120531facce2735881cb815c5")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/conditional-group.lisp" :GIT-BLOB
   "bb7b7ee3e52c0b3c0ae69c2bdc48de594f0bd945")
  (:PATH "tests/engine/conditional.lisp" :GIT-BLOB
   "dc0a709ca6f298ccb870dc2e57504831c01d4285")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/client-group.lisp" :GIT-BLOB
   "910301588c9d671c2b67950d393d6dabc759adc8")
  (:PATH "tests/local/conditional-group-processes.lisp" :GIT-BLOB
   "3fbda41b85d7b3ea69b36b4b9165be82bdbeda00")
  (:PATH "tests/local/conditional-group.lisp" :GIT-BLOB
   "67c45820cbaead998fad90500f697c52d241884b")
  (:PATH "tests/local/explicit-group.lisp" :GIT-BLOB
   "d2ab3e8180c6c27791ea29458526fd2e6be732ff")
  (:PATH "tests/local/group-processes.lisp" :GIT-BLOB
   "8a1d7078a5b37124cfa30867860e47f56ed77f00")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/read-group-processes.lisp" :GIT-BLOB
   "818db6481b2d9e2cc1dce4703bba1516a4b88542")
  (:PATH "tests/local/read-group.lisp" :GIT-BLOB
   "31871cfd92a2cd26de0c486ba497e5d547cae864")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/version-processes.lisp" :GIT-BLOB
   "33a51023abe1a9a5e7b08926caf8fd2ff2f1e9bc")
  (:PATH "tests/local/version.lisp" :GIT-BLOB
   "52a44805faa6d6356ca17258885a986001231b76")
  (:PATH "tests/local/wire-group.lisp" :GIT-BLOB
   "f1caba660e45e35c58ecf27219d934f5277ccf4c")
  (:PATH "tests/local/wire-read-group.lisp" :GIT-BLOB
   "0cd9467362f5ea82e57ba40f837b1f0475500d29")
  (:PATH "tests/local/wire-version.lisp" :GIT-BLOB
   "c2c31b1ada9ed7ffa54caa8f6a0253cccab66bf1")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/metrics/allocation.lisp" :GIT-BLOB
   "cfaf35cc4a712fe6568d6e030be6ed0b462785ed")
  (:PATH "tests/metrics/geometry.lisp" :GIT-BLOB
   "94ff658183fff2de005470a05cf2ac1c4e7355ca")
  (:PATH "tests/metrics/isolation.lisp" :GIT-BLOB
   "725d8c2a130afc70f0e43c573d58d90154a82762")
  (:PATH "tests/metrics/limits.lisp" :GIT-BLOB
   "06b0b497c5ebb4781986b9f591ec98ffdc692ddf")
  (:PATH "tests/metrics/quantiles.lisp" :GIT-BLOB
   "90c6ebfd2b8d3ef6b9c3df37794b8af334011f06")
  (:PATH "tests/metrics/support.lisp" :GIT-BLOB
   "d57b8c0d7be06b771c572baf410339b73564d32b")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "7f53d379a5106a4184a96e3b2f27b2258df5f1b6")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "f9df56890db8231bb26fba808eabebd2cab3e22a")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-conditional-group-server.lisp" :GIT-BLOB
   "92145f31ddb22c4e6c205413ad31fdb24fc0dc17")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-read-loss-server.lisp" :GIT-BLOB
   "56f7401d185564c0bfe9c834742812fc42a4a6a7")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/local-version-loss-server.lisp" :GIT-BLOB
   "89f4ed52dd4f7de5b0b4ac2420f3aaef78618a41")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/metrics-histogram-bench.lisp" :GIT-BLOB
   "8655bbb485abb7bf1adfacd1b9361aaa472682a5")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "ok    package ARCDOCDB presente
ok    ARCDOCDB:*VERSION* è una stringa
ok    TEST-REQ-IDX-001-HASH-ORACLE-UPSTREAM-ANCHORS
ok    TEST-REQ-IDX-001-HASH-VECTORS
ok    TEST-REQ-IDX-001-HASH-SEED-HIGH
ok    TEST-REQ-IDX-001-HASH-LENGTH
ok    TEST-REQ-IDX-001-HASH-TAIL
ok    TEST-REQ-IDX-001-HASH-BLOCKS
ok    TEST-REQ-IDX-001-HASH-EMPTY-SPANS-AT-BUFFER-EDGES
ok    TEST-REQ-IDX-001-HASH-ALL-TAILS-AT-SPAN-CEILING
ok    TEST-REQ-IDX-001-HASH-BOUNDARIES-32-8-4-THROUGH-65K
ok    TEST-REQ-IDX-001-HASH-ALL-256-SINGLE-OCTETS
ok    TEST-REQ-IDX-001-HASH-ZERO-FF-ORDERED-AND-ASYMMETRIC-LANES
ok    TEST-REQ-IDX-001-HASH-OUTSIDE-SPAN-DIFFERS-AND-ALL-BYTES-STAY-UNCHANGED
ok    TEST-REQ-IDX-001-HASH-SEED-AND-CALL-HISTORY-HAVE-NO-STATE
  XXH64 corpus: seed 6483BEEF, 256 span finiti di 0..65535 byte.
ok    TEST-REQ-IDX-001-HASH-FINITE-CORPUS-FIXED-SEED-6483BEEF
ok    TEST-REQ-IDX-001-HASH-EVERY-BYTE-IN-SELECTED-SPANS-PARTICIPATES
ok    TEST-REQ-IDX-001-HASH-NAMED-PUBLIC-CALLER-WITH-T-ARGUMENTS
ok    TEST-REQ-IDX-001-HASH-INVALID-BUFFERS-AND-NONSIMPLE-ARRAYS
ok    TEST-REQ-IDX-001-HASH-INVALID-INDEX-TYPES-AND-NEGATIVE-INDICES
ok    TEST-REQ-IDX-001-HASH-INVALID-SEEDS-IN-EACH-HALF
ok    TEST-REQ-IDX-001-HASH-VALID-INDEX-TYPES-BUT-INVALID-BUFFER-RANGE
ok    TEST-REQ-IDX-001-HASH-SPAN-65536-AND-LARGER-REJECTED-WITHOUT-MUTATION
ok    TEST-REQ-IDX-001-HASH-VALIDATION-ARGUMENTS-RANGE-SPAN-PRECEDENCE
ok    TEST-REQ-IDX-001-HASH-ABSOLUTE-INDICES-MAY-EXCEED-SPAN-LIMIT
ok    TEST-REQ-IDX-001-HASH-U32-SIGN-BITS-AND-ASYMMETRIC-WORD-ORDER
  XXH64 heap: 64 finestre seriali, 16448 chiamate misurate, atteso 0 byte.
ok    TEST-REQ-IDX-001-HASH-ZERO-HEAP-IN-SERIAL-CALL-WINDOWS
ok    TEST-REQ-IDX-001-HASH-BLOCK-RELATIONAL-GUARDS
ok    TEST-REQ-IDX-001-HASH-TAIL-RELATIONAL-GUARDS
  XXH64 thread: quattro worker privati, 1220 risultati, ready/join limitati.
ok    TEST-REQ-IDX-001-HASH-FOUR-REAL-WORKERS-WITH-PRIVATE-INPUT-AND-BOUNDED-CLEANUP
28 test XXH64 superati.
ok    TEST-REQ-AFF-004-TYPED-ERRORS-RENDERING
ok    TEST-REQ-FOR-003-OUT-OF-LINE-READERS
ok    TEST-REQ-FOR-003-LITTLE-ENDIAN
ok    TEST-REQ-FOR-003-RANGES
ok    TEST-REQ-FOR-003-CRC-KNOWN-VECTORS
ok    TEST-REQ-FOR-003-CRC-DIFFERENTIAL-INCREMENTAL
ok    TEST-REQ-FOR-003-CRC-BACKENDS-BOUNDARIES
ok    TEST-REQ-FOR-003-CRC-ALL-SMALL-SPLITS
ok    TEST-REQ-FOR-003-CRC-SOFTWARE-DISPATCH-AND-GUARDS
ok    TEST-REQ-FOR-003-CRC-COMPILER-PLATFORM-MATRIX
ok    TEST-REQ-FOR-003-CRC-OS-REPORT-AND-SELECTION
ok    TEST-REQ-FOR-003-CRC-STARTUP-FALLBACK
ok    TEST-REQ-FOR-003-CRC-NATIVE-QUALIFICATION-SPANS-SEEDS-AND-SPLITS
ok    TEST-REQ-FOR-003-WORD-ENCODING-INDEPENDENT-ORACLE
ok    TEST-REQ-LIM-001-WORD-ENCODING-PREFLIGHT
ok    TEST-REQ-FOR-003-INDEPENDENT-ENCODING-ORACLE
ok    TEST-REQ-LIM-001-ROUNDTRIP-VERSIONS
ok    TEST-REQ-LIM-003-KEY-BOUNDARIES
ok    TEST-REQ-LIM-001-DOCUMENT-BOUNDARIES
ok    TEST-REQ-FOR-003-EVERY-BYTE-CORRUPTION
ok    TEST-REQ-FOR-003-EVERY-TRUNCATION
ok    TEST-REQ-FOR-003-VALID-CRC-INVALID-FIELDS
ok    TEST-REQ-LIM-001-PREFLIGHT-NO-PARTIAL-WRITE
ok    TEST-REQ-AFF-002-INDEX-IDENTITY
ok    TEST-REQ-FOR-004-PREPARED-OUTCOME
ok    TEST-REQ-FOR-003-CONTROL-RECORD-SHAPES
ok    TEST-REQ-LIM-001-SEMANTIC-BOUNDARIES
ok    TEST-REQ-FOR-004-OUTCOME-PROVENANCE-FIELDS
ok    TEST-REQ-FOR-004-U64-BOTH-WORDS
ok    TEST-REQ-FOR-003-SEALED-BATCHES
ok    TEST-REQ-FOR-003-BATCH-ALL-TRUNCATIONS
ok    TEST-REQ-FOR-003-BATCH-SEAL-SEMANTIC-CORRUPTION
ok    TEST-REQ-FOR-003-BATCH-STAMP-AND-TYPE
ok    TEST-REQ-LIM-003-BATCH-BUDGETS
ok    TEST-REQ-FOR-004-BATCH-TXID-INDEPENDENT-OF-SEAL-CSN
35 test delle fondazioni superati.
ok    REQ-OBS-001-EXACT-LOW-BINS
ok    REQ-OBS-001-EVERY-POWER-AND-PRECISION-BOUNDARY
ok    REQ-OBS-001-CONFIGURED-AND-OBSERVED-MAXIMUM-CLIPPING
ok    REQ-OBS-001-EMPTY-AND-ZERO-PERCENTILES
ok    REQ-OBS-001-RATIONAL-NEAREST-RANK-AT-COUNT-LIMITS
ok    REQ-OBS-001-P50-P95-P99-P999-SORTED-REFERENCE
ok    REQ-OBS-001-PUBLIC-RANK-WITH-SYNTHETIC-FULL-POPULATION
ok    REQ-OBS-001-INVALID-PERCENTILE-ARGUMENTS
ok    REQ-OBS-001-CONFIGURATION-DEFAULTS-AND-STORAGE
ok    REQ-OBS-001-INVALID-CONFIGURATION-TYPES-AND-LIMITS
ok    REQ-OBS-001-OUT-OF-DOMAIN-SAMPLES-NEVER-MUTATE
ok    REQ-OBS-001-CAP-STICKY-COMPLETENESS-AND-OVERFLOW
ok    REQ-OBS-001-FULL-CAP-COUNTER-BOUNDARY-SYNTHETIC
ok    REQ-OBS-001-SNAPSHOT-COPY-AND-RESET-ISOLATION
ok    REQ-OBS-001-MUTATION-MACRO-EXPANSION-AND-VALUES
ok    REQ-OBS-001-REENTRY-PRESERVES-OUTER-BUSY-STATE
ok    REQ-OBS-001-MUTATION-MACRO-LITERAL-MODES
ok    REQ-OBS-001-READ-ABORT-RELEASES-BUSY-PRESERVES-FAULT
ok    REQ-OBS-001-ABNORMAL-MUTATION-FAULTS-UNTIL-RESET
ok    REQ-OBS-001-WRONG-OWNER-ERRORS-BEFORE-CHANGE
ok    REQ-OBS-001-TWO-OWNER-SERIES-ISOLATION
ok    REQ-OBS-001-THREAD-LOCAL-GUARD-AND-INHERITED-PARENT-IDENTITY
ok    REQ-OBS-001-HOT-ALLOCATION
23 test degli istogrammi di latenza superati.
ok    REQ-SEC-008-WIRE-INDEPENDENT
  Cornice full text: 3168 alterazioni singole rilevate.
ok    REQ-SEC-008-EVERY-SINGLE-BIT
ok    REQ-SEC-008-EVERY-TRUNCATION
ok    REQ-SEC-008-EMPTY-SECTIONS
ok    REQ-SEC-008-NO-SEMANTIC-PROMOTION
ok    REQ-SEC-008-META-BUDGET-EDGE
ok    REQ-SEC-008-CRC-VALID-HEADER-ERRORS
ok    REQ-SEC-008-CRC-VALID-DIRECTORY-ERRORS
ok    REQ-SEC-010-PREFLIGHT-PRESERVES-DESTINATION
ok    REQ-SEC-010-READER-INPUT-AND-BUDGET
ok    REQ-SEC-008-PARALLEL-INDEPENDENT-BUFFERS
11 test della cornice full text superati.
Unicode 18 NFC: 20171 righe, 100855 confronti.
ok    REQ-SEC-007-NORMALIZATION-CONFORMANCE
Unicode 18 Word_Break: 1944 righe, 8487 confini.
ok    REQ-SEC-007-WORD-BREAK-CONFORMANCE
Unicode 18 case fold C/F: 1606 mapping.
ok    REQ-SEC-007-FULL-CASE-FOLD-CONFORMANCE
ok    REQ-SEC-007-SCALAR-READER-EXHAUSTIVE
ok    REQ-SEC-007-PROFILE-EXAMPLES
ok    REQ-SEC-007-STATE-AND-UTF8-GUARDS
ok    REQ-SEC-010-ANALYSIS-BUDGETS
ok    REQ-SEC-004-POSITIONAL-PHRASES-AND-VERSIONS
Run posizionale: 115200 confronti con scansione indipendente.
ok    REQ-SEC-004-INDEX-DIFFERENTIAL
ok    REQ-SEC-010-INDEX-CAPACITY-AND-STATE
Cornice: 0 byte consed per 1000 scritture + verifiche.
ok    REQ-SEC-008-FRAMING-ALLOCATION
Analisi + query: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-HOT-PATH-ALLOCATION
ok    REQ-SEC-007-ANALYSIS-CONCURRENT-READERS
13 test dell'analisi full text superati.
ok    REQ-SEC-008-CODEC-GOLDEN-INDEPENDENT
ok    REQ-SEC-008-PERSISTED-QUERY-SEMANTICS
ok    REQ-SEC-008-EMPTY-AND-MULTIPLE-FIELDS
Codec: 3744 bit e 468 troncamenti rifiutati.
ok    REQ-SEC-008-EVERY-BIT-AND-TRUNCATION
ok    REQ-SEC-008-CODEC-CRC-VALID-BODY-ERRORS
ok    REQ-SEC-008-CODEC-TERM-PROFILE-CORRUPTION
ok    REQ-SEC-008-META-AUTHORITY-AND-PROFILE
ok    REQ-SEC-010-CODEC-PREFLIGHT-PRESERVES-DESTINATION
ok    REQ-SEC-010-CODEC-SCRATCH-AND-WORK
ok    REQ-SEC-008-DESCRIPTOR-OWNS-CONFIGURATION
ok    REQ-SEC-008-CANDIDATE-CONTRACT-BEFORE-WRITE
Codec/query, ID 1: 0 byte consed per 1000 operazioni.
Codec/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-CODEC-HOT-ALLOCATION
Indice serializzato: 43200 confronti con scansione indipendente.
ok    REQ-SEC-008-PERSISTED-INDEX-DIFFERENTIAL
Fuzz CRC valido: 1020 rifiuti tipizzati, 4 varianti valide.
ok    REQ-SEC-008-CODEC-CRC-VALID-FUZZ
ok    REQ-SEC-008-PERSISTED-PARALLEL-READERS
15 test del codec completo full text superati.
ok    REQ-SEC-003-CBOR-NNTP-INDEPENDENT-WIRE
ok    REQ-SEC-010-DOCUMENT-BOUND-DISTINCT-AND-EMPTY
ok    REQ-SEC-007-DOCUMENT-NESTED-AND-UNICODE
ok    REQ-SEC-003-DOCUMENT-TAGGED-AND-COMPLEX-KEYS
ok    REQ-SEC-003-DOCUMENT-CONFIG-OWNED-AND-FIXED-IDS
ok    REQ-SEC-003-DOCUMENT-SELECTED-TYPES-AND-DUPLICATES
ok    REQ-SEC-003-DOCUMENT-ENTIRE-CBOR-IS-VALIDATED
ok    REQ-SEC-010-DOCUMENT-AGGREGATE-LIMITS
ok    REQ-SEC-010-DOCUMENT-WORK-NODES-AND-FILE-BUDGET
ok    REQ-SEC-010-DOCUMENT-CANCEL-AND-REUSE-AT-EVERY-PHASE
ok    REQ-SEC-010-DOCUMENT-PREFLIGHT-KEEPS-PRIOR-RESULT
ok    REQ-SEC-003-DOCUMENT-CONFIG-GUARDS
ok    REQ-SEC-003-DOCUMENT-DEPTH-AND-SIBLING-FRAMES
Documenti CBOR: 115200 confronti indipendenti su run e file, 128 bound verificati.
ok    REQ-SEC-003-DOCUMENT-INDEPENDENT-DIFFERENTIAL
ok    REQ-SEC-003-DOCUMENT-ALL-SIXTEEN-FIELDS
Preparazione CBOR, ID 1: 0 byte consed per 1000 operazioni.
Preparazione CBOR, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-DOCUMENT-HOT-ALLOCATION
ok    REQ-SEC-006-DOCUMENT-PARALLEL-WORKERS
17 test della preparazione documentale full text superati.
ok    REQ-SEC-003-RESERVATION-OWNED-NNTP-RUNS
Ledger indipendente: 256 confronti di bound su 128 operazioni.
ok    REQ-SEC-010-RESERVATION-INDEPENDENT-LEDGER
ok    REQ-SEC-003-RESERVATION-ALL-SIXTEEN-GENERATIONS
ok    REQ-SEC-003-RESERVATION-ATOMIC-CONTRACT-AND-ROW
ok    REQ-SEC-006-RESERVATION-BORROW-AND-GENERATION
ok    REQ-SEC-010-RESERVATION-PUBLIC-INPUT-GUARDS
ok    REQ-SEC-010-RESERVATION-COLD-GUARDS-AND-OWNED-CONFIG-VECTOR
ok    REQ-SEC-010-RESERVATION-LAST-INDEX-REFUSAL
ok    REQ-SEC-010-RESERVATION-FILE-BOUNDS-AND-ROTATION
ok    REQ-SEC-010-RESERVATION-CUMULATIVE-MEMORY-BUDGETS
ok    REQ-SEC-010-RESERVATION-RUN-AND-SLOT-BUDGETS
ok    REQ-SEC-006-RESERVATION-EMPTY-DOCUMENT-HOLDS-SLOT
ok    REQ-SEC-006-RESERVATION-CANCELLATION-AT-EVERY-COPY-STAGE
ok    REQ-SEC-010-RESERVATION-TRANSFER-RETAINS-HISTORICAL-COST
ok    REQ-SEC-006-RESERVATION-STALE-LEASE-AND-FOREIGN-TOKEN
ok    REQ-SEC-006-RESERVATION-LOST-SOURCE-FAIL-STOP
ok    REQ-SEC-006-RESERVATION-INTERRUPTED-ADOPTION-FAIL-STOP
ok    REQ-SEC-003-ROW-DIRECTORY-INDEPENDENT-MODEL
ok    REQ-SEC-010-ROW-DIRECTORY-CAPACITY-AND-COLD-MEMORY
ok    REQ-SEC-006-ROW-DIRECTORY-CANCEL-REUSE-AND-PRIVATE-PENDING
ok    REQ-SEC-010-ROW-DIRECTORY-REJECTIONS-WITHOUT-EFFECTS
ok    REQ-SEC-006-ROW-DIRECTORY-INTERRUPTED-INSERT
ok    REQ-SEC-006-ROW-DIRECTORY-INTERRUPTED-REMOVE
ok    REQ-SEC-006-ROW-DIRECTORY-CORRUPTION-FAIL-STOP
Riserve/copia/query, ID 1: 0 byte consed per 1000 operazioni.
Riserve/copia/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-RESERVATION-HOT-ALLOCATION
ok    REQ-SEC-006-RESERVATION-FOUR-INDEPENDENT-WRITERS
26 test delle riserve full text superati.
ok    REQ-SEC-003-PUT-OWNED-RECORD-INDEPENDENT-WIRE
ok    REQ-SEC-003-PUT-RECORD-NUMBER-IS-NOT-HINT-ROW
ok    REQ-WAL-005-FRAME-APPEND-RANGES-AND-CAPACITY
ok    REQ-SEC-010-PUT-CUMULATIVE-WORK-AND-MEMORY
ok    REQ-WAL-005-PUT-WRITER-DOES-NOT-SCAN-BODY
ok    REQ-WAL-005-FRAME-PREFLIGHT-NO-PARTIAL-EFFECT
ok    REQ-SEC-006-PUT-START-REJECTIONS-PRESERVE-PREVIOUS
ok    REQ-SEC-003-PUT-INVALID-DOCUMENT-NEVER-RESERVED
ok    REQ-SEC-010-PUT-RESERVATION-REFUSAL-PRESERVES-COHORT
ok    REQ-SEC-003-PUT-APPEND-PREFLIGHT-RETAINS-RESERVATION
ok    REQ-WAL-005-PUT-WORKER-ATTESTS-FRAME-BEFORE-RESERVATION
ok    REQ-WAL-005-PUT-STALE-BATCH-INCARNATION
ok    REQ-SEC-006-PUT-CANCEL-AND-REUSE-STAGES
ok    REQ-SEC-006-PUT-WRONG-LEASE-AND-GENERATION
ok    REQ-SEC-006-PUT-INTERRUPTED-APPEND-FAIL-STOP
ok    REQ-SEC-003-PUT-ALL-SIXTEEN-GENERATIONS
PUT/analisi/riserva/WAL/query, ID 1: 0 byte consed per 1000 operazioni.
PUT/analisi/riserva/WAL/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-PUT-HOT-ALLOCATION
ok    REQ-SEC-006-PUT-FOUR-INDEPENDENT-WORKERS
ok    REQ-SEC-004-REFERENCE-V1-V2-ORDINARY-PREPARED-BOUNDARIES
ok    REQ-SEC-004-REFERENCE-SURVIVES-REAL-BATCH-RETIREMENT
ok    REQ-WAL-005-REFERENCE-HEADER-ONLY-CRC
ok    REQ-SEC-006-REFERENCE-INTERRUPTED-CAPTURE-FAIL-STOP
ok    REQ-SEC-006-REFERENCE-FOUR-INDEPENDENT-WRITERS
ok    REQ-SEC-006-REFERENCE-REJECTIONS-PRESERVE-STATE
ok    REQ-WAL-005-REFERENCE-REJECTS-MANUAL-AND-LATE-SEALS
ok    REQ-WAL-005-REFERENCE-HEADER-CORRUPTION-FAIL-STOP
ok    REQ-SEC-004-REFERENCE-NATIVE-FILE-INDEPENDENT-RECORD
ok    REQ-SEC-004-ROW-REFERENCE-STAGES-AND-STAMPS
ok    REQ-SEC-004-ROW-REFERENCE-SURVIVES-WAL-REUSE
ok    REQ-SEC-006-ROW-REFERENCE-CANCEL-GENERIC-AND-INPUTS
ok    REQ-SEC-006-ROW-REFERENCE-INCONSISTENT-PHYSICAL-FAIL-STOP
31 test del legame PUT full text superati.
ok    TEST-REQ-AFF-004-UTF8-REFERENCE-IS-STRICT
ok    TEST-REQ-AFF-004-UTF8-EMPTY-ASCII-AND-DEFAULT-BUDGET
ok    TEST-REQ-AFF-004-UTF8-INVALID-RANGE-AND-BUFFER
ok    TEST-REQ-AFF-008-UTF8-INVALID-BUDGET
ok    TEST-REQ-AFF-008-UTF8-BYTE-BUDGET-PRECEDES-CONTENT
ok    TEST-REQ-AFF-004-UTF8-ALL-256-SINGLE-BYTE-INPUTS
  UTF-8 esaustivo: 65536 coppie, 18304 valide, 47232 rifiutate.
ok    TEST-REQ-AFF-004-UTF8-ALL-65536-TWO-BYTE-INPUTS
ok    TEST-REQ-AFF-004-UTF8-MANUAL-SCALAR-BOUNDARIES
ok    TEST-REQ-AFF-004-UTF8-NUL-BOM-NONCHARACTERS-AND-NO-NORMALIZATION
ok    TEST-REQ-AFF-004-UTF8-ILLEGAL-LEADING-OFFSET
ok    TEST-REQ-AFF-004-UTF8-TRUNCATION-BEFORE-CONTENT
ok    TEST-REQ-AFF-004-UTF8-CONTINUATION-OFFSET-AND-PRIORITY
ok    TEST-REQ-AFF-004-UTF8-SCALAR-RESTRICTIONS-AFTER-CONTINUATIONS
ok    TEST-REQ-AFF-004-UTF8-SEEDED-SCALAR-STREAM-AND-SLICES
  UTF-8 fuzz: seed 3629A11F, 4096 input di 3..8 byte, 234 validi, 3862 rifiutati.
ok    TEST-REQ-AFF-004-UTF8-DIFFERENTIAL-FUZZ-4096-INPUTS
ok    TEST-REQ-LIM-001-UTF8-EXACT-SIXTEEN-MIB-AND-OVER-BUDGET
  UTF-8: 2 worker, 128 verifiche, 83886080 byte; WALL fixture con controlli/rendezvous: worker 0 start/first/end 9294958/9299544/9562983, sink 16777216; worker 1 start/first/end 9295040/9299629/9563103, sink 16777216; overlap 267943 tick (1000000 tick/s); nessuna inferenza su tempo puro primitiva, CPU o scaling.
ok    TEST-REQ-CON-005-UTF8-TWO-PRIVATE-BUFFERS-AND-REAL-CPU-OVERLAP
17 test UTF-8 superati.
ok    TEST-REQ-AFF-004-CBOR-ALL-256-COMPLETE-LEADING-BYTES
ok    TEST-REQ-AFF-004-CBOR-ALL-256-ONE-BYTE-SPANS
ok    TEST-REQ-AFF-004-CBOR-ALL-256-EXTENDED-SIMPLE-VALUES
  CBOR BE: 65536 argomenti a 16 bit, compresi quelli non minimi.
ok    TEST-REQ-AFF-004-CBOR-ALL-65536-BIG-ENDIAN-TWO-BYTE-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-IMMEDIATE-VALUES-WITHOUT-BODY-OR-TAG-CHILD
ok    TEST-REQ-AFF-004-CBOR-RAW-WIDTHS-PRESERVE-NONMINIMAL-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-U64-EXTREMES-AND-ASYMMETRIC-WORDS
ok    TEST-REQ-AFF-004-CBOR-FLOATING-BITS-ZERO-SIGN-INFINITY-AND-NAN
ok    TEST-REQ-AFF-004-CBOR-INDEFINITE-AND-BREAK-ARE-CONTEXT-FREE-MARKERS
ok    TEST-REQ-AFF-004-CBOR-RESERVED-AND-ILLEGAL-INDEFINITE-PRECEDE-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-EVERY-ARGUMENT-TRUNCATION-AND-DECLARED-END
ok    TEST-REQ-AFF-004-CBOR-SIMPLE-CHECK-FOLLOWS-COMPLETE-HEAD
ok    TEST-REQ-AFF-004-CBOR-INVALID-BUFFER-AND-RANGE-BEFORE-CONTENT
ok    TEST-REQ-AFF-004-CBOR-EMPTY-VALID-SPANS-HAVE-END-OFFSET
ok    TEST-REQ-AFF-004-CBOR-MISALIGNED-HEADS-IGNORE-TRAILING-BYTES
  CBOR fuzz: seed 8949A11F, 4096 span di 1..9 byte, 3437 validi, 659 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-DIFFERENTIAL-FUZZ-4096-BOUNDED-SPANS
  CBOR header read: 2 worker, 2097152 header, 18874368 byte; WALL fixture con controlli/rendezvous: worker 0 start/first/end 9590817/9591198/9630408, sink 2401919800705024; worker 1 start/first/end 9590836/9591216/9629464, sink 2231683637051392; overlap 38628 tick (1000000 tick/s); nessuna inferenza su tempo puro primitiva, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-TWO-PRIVATE-BUFFERS-AND-REAL-CPU-OVERLAP
17 test degli header CBOR superati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-LEADING-BYTES-AND-SHORT-SPANS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-MAJOR-ZERO-TO-SIX-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-EXTENDED-SIMPLE-VALUES
  CBOR minimo: 65536 half e 131072 espansioni esatte, inclusi NaN e segni.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-HALF-AND-EXACT-EXPANSIONS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-IEEE-ORACLE-KNOWN-VALUES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-RFC-NUMERIC-VECTORS-AND-ADJACENT-VALUES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-FINITE-NORMAL-SUBNORMAL-BOUNDARIES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SIGN-ZERO-INFINITY-AND-NAN-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-EVERY-TRUNCATED-HEAD-BEFORE-PREFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SYNTAX-BEFORE-NONMINIMAL
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-INVALID-BUFFER-RANGE-AND-EMPTY-SPAN
ok    TEST-REQ-LIM-002-CBOR-MINIMAL-HEADER-ONLY-AND-MISALIGNED-SENTINELS
  CBOR minimo fuzz: seed4D494E43, 4096word32+4096word64+4096span0..9, 11223 accettati/1065 rifiutati/84 nonminimi.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-FINITE-DIFFERENTIAL-FUZZ-SEED-4D494E43
  CBOR minimo: 2 worker, 524288 header, 4718592 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 9861413/9861416/9874913, sink 1406013828104192; worker 1 start/first/end 9861442/9861442/9876280, sink 5628138478764032; overlap 13471 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-MINIMAL-TWO-PRIVATE-WORKERS-REAL-WORK-INTERVALS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-PUBLIC-SUBNORMAL-ALIGNMENT-PAIRS
15 test delle testate CBOR minime superati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-RFC-DEFINITE-VECTORS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-RFC-INDEFINITE-VECTORS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-GENERIC-PROFILE-PERMISSIONS
  CBOR structure AST: seed 7394B21D, 256 casi generati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-GENERATED-AST-CORPUS
  CBOR structure lead: 512 span, 41 validi/471 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-ALL-LEADS-TWO-BYTE-SPANS
  CBOR structure fuzz: seed 49CBA017, 30 validi/4066 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-SEEDED-FINITE-DIFFERENTIAL
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-TRUNCATION-AT-EVERY-BOUNDARY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-EXACT-ROOT-AND-TRAILING-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-BREAK-CONTEXT-AND-TAG-PRIORITY
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-TAGS-CHARGE-PARENT-ONCE
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-CHUNKS-SAME-TYPE-AND-HEADER-FIRST
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-VALID-UNICODE-AND-CHUNK-LOCALITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-INVALID-UNICODE-EXACT-OFFSETS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-PAYLOAD-WIDTH-AND-HUGE-UNSIGNED-LENGTHS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-CONTAINER-MINIMUM-REMAINING-BYTES
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-DEPTH-100-AND-MAP-KEYS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-NODE-BOUNDARIES-CHUNKS-AND-BREAKS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-HEADER-ERRORS-BEFORE-NODE-BUDGET
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-INVALID-RANGE-AND-TYPE-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-WORKSPACE-ALIAS-AND-PREFLIGHT-IMMUTABILITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-LIMIT-CONFIGURATION-AND-ORDER
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-BYTE-BUDGET-AND-EXACT-16-MIB
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-REUSE-AFTER-RUNTIME-FAILURES
  CBOR structure: 2 worker, 48 scansioni, 2359344 nodi, 5505168 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 9946289/9949762/10029737, sink 4718784; worker 1 start/first/end 9946314/9949749/10028525, sink 3145920; overlap 82211 tick (1000000 tick/s); nessuna inferenza su tempo puro scanner, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-STRUCTURE-TWO-PRIVATE-WORKSPACES-REAL-CPU-OVERLAP
24 test della struttura CBOR superati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-ALL-MAJOR-TYPES-AND-GENERIC-PERMISSIONS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-INTEGER-AND-TAG-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-STRING-AND-CONTAINER-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-NONMINIMAL-WIDTHS-AT-EVERY-MAJOR
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-FLOATS-IN-ROOT-KEYS-VALUES-AND-TAGS
  CBOR struttura minima: 768 casi lead, 84 accettati/684 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-ALL-LEADING-BYTES-COLD-REFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-HEADER-SYNTAX-BEFORE-LOCAL-PREFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-PREFERENCE-BEFORE-BUDGETS-AND-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-NESTED-PREFERENCE-NOT-ONLY-ROOT
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-OPAQUE-BYTES-AND-CONTROL-TEXT-ARE-NOT-HEADERS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-UTF8-ABSOLUTE-OFFSETS-AND-WHOLE-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-COMPLETED-ROOT-PRECEDES-TRAILING-CONTENT
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-TAGS-COUNT-ONCE-IN-PARENT-AND-NODE-BOUNDS
ok    TEST-REQ-LIM-002-CBOR-MINIMAL-SCAN-DEPTH-100-101-AND-MAP-KEYS
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-HUGE-LENGTHS-AND-PARENT-ARITY-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-INVALID-INPUT-PRIORITY-AND-COLD-IMMUTABILITY
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-WORKSPACE-ALIAS-AND-LIMIT-ORDER
ok    TEST-REQ-LIM-001-CBOR-MINIMAL-SCAN-EXACT-SIXTEEN-MIB-AND-OVER-BUDGET
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-RESET-AFTER-ERRORS-AND-ALTERNATING-MODES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-MISALIGNMENT-DECLARED-SPAN-AND-TRUNCATIONS
  CBOR struttura minima: 512 AST e fuzz4096 seed53434d31, 41 validi/4055 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-SEEDED-ASTS-AND-FINITE-DIFFERENTIAL-FUZZ
  CBOR minimal scan: 2 worker, 48 scansioni, 2359344 nodi, 11796624 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 10351515/10355615/10451075, sink 4718784; worker 1 start/first/end 10351644/10357170/10483377, sink 9437376; overlap 99431 tick (1000000 tick/s); nessuna inferenza su tempo puro scanner, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-MINIMAL-SCAN-TWO-PRIVATE-WORKSPACES-REAL-TIME-OVERLAP
22 test della struttura CBOR minima superati.
ok    TEST-REQ-CBR-001-CBOR-WRITE-LITERAL-VECTORS-ALL-SEVEN-MAJOR-TYPES
ok    TEST-REQ-CBR-001-CBOR-WRITE-DIRECT-ARGUMENTS-ZERO-THROUGH-TWENTY-THREE
ok    TEST-REQ-CBR-001-CBOR-WRITE-ADJACENT-WIDTH-BOUNDARIES-AND-SPLIT-U64
  CBOR write: 65536 argomenti u16 x 7 major, 458752 confronti aritmetici freddi.
ok    TEST-REQ-CBR-001-CBOR-WRITE-ALL-U16-ARGUMENTS-FOR-EACH-MAJOR
ok    TEST-REQ-CBR-001-CBOR-WRITE-EVERY-INSUFFICIENT-CAPACITY-BEFORE-ANY-BYTE
ok    TEST-REQ-CBR-001-CBOR-WRITE-INVALID-RANGES-DOMINATE-ALL-OTHER-ERRORS
ok    TEST-REQ-CBR-001-CBOR-WRITE-REJECTS-NON-SIMPLE-OCTET-DESTINATIONS
ok    TEST-REQ-CBR-001-CBOR-WRITE-MAJOR-PRECEDES-HIGH-LOW-AND-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-HIGH-PRECEDES-LOW-AND-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-LOW-PRECEDES-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-EMPTY-VALID-SPANS-ARE-CAPACITY-ERRORS
ok    TEST-REQ-CBR-001-CBOR-WRITE-EXACT-CAPACITY-MISALIGNMENT-AND-EXTRA-SPAN
ok    TEST-REQ-CBR-001-CBOR-WRITE-HEADER-HAS-NO-DOCUMENT-OR-PAYLOAD-BUDGET
ok    TEST-REQ-CBR-001-CBOR-WRITE-REUSE-AND-CONSECUTIVE-HEADERS
  CBOR write fuzz: seed57524342, 4096 casi; dimensioni1/2/3/5/9 = 560/465/511/512/2048.
ok    TEST-REQ-CBR-001-CBOR-WRITE-DIFFERENTIAL-FUZZ-SEED-57524342
  CBOR header write: 2 worker, 229376 header; WALL fixture con controlli/rendezvous dopo il primo giro completo: worker 0 start/first/end 10643397/10643400/10649617, sink 15466496; worker 1 start/first/end 10643421/10643423/10649630, sink 17006592; overlap 6196 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-001-CBOR-WRITE-TWO-EXCLUSIVE-DESTINATIONS-REAL-TIME-OVERLAP
ok    TEST-REQ-CBR-001-CBOR-WRITE-MINIMAL-READER-ROUNDTRIP-SUPPLEMENT
17 test della scrittura degli header CBOR minimi superati.
ok    TEST-REQ-CBR-002-STRING-WRITE-LITERAL-HEADERS-AND-BYTE-PAYLOADS
ok    TEST-REQ-CBR-002-STRING-WRITE-MAJOR-TWO-PRESERVES-ALL-OCTETS
ok    TEST-REQ-CBR-002-STRING-WRITE-TEXT-NUL-BOM-NONCHARACTERS-AND-NO-NORMALIZATION
ok    TEST-REQ-CBR-002-STRING-WRITE-WIDTH-BOUNDARIES-AND-ADJACENT-LENGTHS
  CBOR string write: lunghezze0..4096 x MT2/3, 8194 confronti freddi.
ok    TEST-REQ-CBR-002-STRING-WRITE-ALL-LENGTHS-ZERO-THROUGH-4096
ok    TEST-REQ-CBR-002-STRING-WRITE-EVERY-SHORT-CAPACITY-WITH-PHYSICAL-SUFFIX
ok    TEST-REQ-CBR-002-STRING-WRITE-DESTINATION-RANGE-IS-FIRST
ok    TEST-REQ-CBR-002-STRING-WRITE-INVALID-DESTINATION-AND-SOURCE-SHAPES
ok    TEST-REQ-CBR-002-STRING-WRITE-MAJOR-BEFORE-SOURCE-BUDGET-AND-CAPACITY
ok    TEST-REQ-CBR-002-STRING-WRITE-SOURCE-RANGE-BEFORE-BUDGET-AND-CAPACITY
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-ARGUMENT-BEFORE-RESOURCE-AND-UTF8
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-INCLUDES-HEADER-AND-EMPTY-ITEM
ok    TEST-REQ-CBR-002-STRING-WRITE-MAXIMUM-ITEM-AND-ONE-BYTE-OVER-LIMIT
ok    TEST-REQ-CBR-002-STRING-WRITE-SAME-ARRAY-DISJOINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-002-STRING-WRITE-OVERLAP-INCLUDES-HEADER-AND-NOT-EXTRA-SPAN
ok    TEST-REQ-CBR-002-STRING-WRITE-UTF8-MALFORMED-MANUAL-SOURCE-OFFSETS
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-CAPACITY-OVERLAP-BEFORE-UTF8
ok    TEST-REQ-CBR-002-STRING-WRITE-REUSE-AFTER-ERRORS-AND-CONCATENATION
  CBOR string write fuzz: seed53574342, 2048 casi, 1546 accettati/502 UTF-8 rifiutati.
ok    TEST-REQ-CBR-002-STRING-WRITE-DIFFERENTIAL-FUZZ-SEED-53574342
ok    TEST-REQ-CBR-002-STRING-WRITE-MINIMAL-SCAN-SUPPLEMENT-AFTER-COLD-BYTE-CHECK
  CBOR string write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 12709298/12709309/12757289, sink 9707520; worker 1 start/first/end 12709331/12709350/12827181, sink 9969664; overlap 47958 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR string write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 12757293/12757299/12875033, sink 9707520; worker 1 start/first/end 12827185/12827200/12944808, sink 9969664; overlap 47848 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-002-STRING-WRITE-TWO-REUSED-WORKERS-SHARED-IMMUTABLE-SOURCE
21 test della scrittura delle stringhe CBOR minime superati.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-LITERAL-VECTORS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-ALL-248-CODES-OFFSETS-AND-RESIDUALS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EVERY-INSUFFICIENT-CAPACITY-AND-PHYSICAL-SUFFIX
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-ALL-EIGHT-RESERVED-BEFORE-CAPACITY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-INVALID-VALUE-TYPES-AND-BOUNDS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-INVALID-RANGES-DOMINATE-VALUE-AND-CAPACITY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-NON-SIMPLE-DESTINATIONS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-DISPLACED-VIEW-AND-WHOLE-BACKING-UNCHANGED
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EMPTY-SPANS-AND-ZERO-LENGTH-ARRAY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-START-ZERO-AND-EXACT-PHYSICAL-END
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-REUSE-AFTER-ERRORS-AND-SUCCESS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-CONCATENATION-OF-ALL-CODES
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EXACT-SINGLE-RESULT-FOR-ALL-CODES
  CBOR simple write: fuzz seed 53494D43, 2048 casi: 768 successi, 512 valori, 256 capacita, 512 destinazioni/range rifiutati.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-FIXED-SEED-2048-FUZZ
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-READER-AND-SCANNER-AFTER-COLD-BYTES
  CBOR simple write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 12964959/12964966/12967070, sink 3804160; worker 1 start/first/end 12964984/12964985/12967088, sink 3836928; overlap 2086 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR simple write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 12967071/12967072/12969228, sink 3804160; worker 1 start/first/end 12967090/12967090/12969221, sink 3836928; overlap 2131 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-TWO-REUSED-WORKERS-IMMUTABLE-PLANS
16 test della scrittura dei valori semplici CBOR superati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-ORACLE-KNOWN-RATIONALS-AND-NAN-PADDING
ok    TEST-REQ-CBR-004-FLOAT-WRITE-LITERAL-ZERO-INFINITY-FINITE-AND-NAN-VECTORS
  CBOR float write: 65536 half, 131072 espansioni; 196608 successi e 196608 capacita insufficienti, otto offset e tre configurazioni ruotati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-ALL-65536-HALF-AND-EXACT-EXPANSIONS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-FINITE-NORMAL-SUBNORMAL-BOUNDARIES-AND-ADJACENCIES
ok    TEST-REQ-CBR-004-FLOAT-WRITE-BINARY64-SUBNORMAL-ALIGNMENT-ACROSS-WORDS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-NAN-SIGNALING-QUIET-PAYLOAD-ALL-ALIGNMENTS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-AI-TYPES-AND-ALL-OCTET-VALUES
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-HIGH-AND-LOW-TYPES-AND-U32-BOUNDS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INCOHERENT-WIDTH-WORDS-BEFORE-CAPACITY
ok    TEST-REQ-CBR-004-FLOAT-WRITE-PREFLIGHT-PRECEDENCE-CHAIN
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-RANGES-BEFORE-ALL-VALUE-ERRORS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-NON-SIMPLE-DESTINATIONS-AND-WHOLE-DISPLACED-BACKING
ok    TEST-REQ-CBR-004-FLOAT-WRITE-EMPTY-SPAN-AND-ZERO-LENGTH-DESTINATION
ok    TEST-REQ-CBR-004-FLOAT-WRITE-REUSE-AFTER-ERRORS-AND-SHORTER-SUCCESS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-CONCATENATION-OF-REDUCED-AND-RETAINED-FORMS
  CBOR float write: fuzz seed464C5434, 2048 casi: 768 successi, 256 capacita, 128 AI, 128 HIGH, 128 LOW, 256 parole, 384 range/destinazioni rifiutati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-FIXED-SEED-2048-FUZZ
ok    TEST-REQ-CBR-004-FLOAT-WRITE-READER-AND-SCANNER-ONLY-AFTER-COLD-COMPARISON
  CBOR float write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13239431/13239437/13242030, sink 2115584; worker 1 start/first/end 13239454/13239455/13242057, sink 2148352; overlap 2576 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR float write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13242033/13242034/13244660, sink 2115584; worker 1 start/first/end 13242059/13242060/13244684, sink 2148352; overlap 2601 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-TWO-REUSED-WORKERS-IMMUTABLE-PLANS
18 test della scrittura dei float CBOR superati.
ok    TEST-REQ-CBR-005-ARRAY-EMPTY-SCALAR-AND-FIVE-LITERAL-CHILDREN
ok    TEST-REQ-CBR-005-ARRAY-COUNT-WIDTH-BOUNDARIES-AND-MINIMAL-HEADER
ok    TEST-REQ-CBR-005-ARRAY-NESTED-TAG-MAP-TEXT-AND-RAW-FLOAT-PREFERENCE
ok    TEST-REQ-CBR-005-ARRAY-CONCATENATION-NEXT-AND-REUSED-SPACE
ok    TEST-REQ-CBR-005-ARRAY-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-005-ARRAY-SOURCE-TYPE-RANGE-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-005-ARRAY-TABLE-TYPE-AND-COUNT-DOMAINS
ok    TEST-REQ-CBR-005-ARRAY-WORKSPACE-TYPE-AND-ALL-SCRATCH-ALIASES-EVEN-EMPTY
ok    TEST-REQ-CBR-005-ARRAY-CONFIGURED-LIMITS-AND-EMPTY-ROOT-MINIMUM
ok    TEST-REQ-CBR-005-ARRAY-STRICT-ENTRY-ORDER-BOUNDS-LAST-AND-UNREAD-TAIL
ok    TEST-REQ-CBR-005-ARRAY-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-005-ARRAY-OVERLAP-ENTIRE-FOOTPRINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-005-ARRAY-FULL-BYTE-BUDGET-EXACT-16MIB-AND-ONE-OVER
ok    TEST-REQ-CBR-005-ARRAY-ROOT-TAG-NODE-ACCOUNTING-AND-EXHAUSTED-RESIDUE
ok    TEST-REQ-CBR-005-ARRAY-ROOT-DEPTH-SCALARS-TAGS-AND-99-100-CHILD-CONTAINERS
ok    TEST-REQ-CBR-005-ARRAY-CHILD-ERRORS-ABSOLUTE-OFFSETS-AND-LEFT-TO-RIGHT
ok    TEST-REQ-CBR-005-ARRAY-REUSE-AFTER-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-005-ARRAY-SCRATCH-LAST-CHILD-AND-ZERO-COUNT-NO-RESET
  CBOR array fuzz: seed41525235, 1024 casi, 512 successi e 64 ciascuno capacita/byte/entry/nodi/profondita/parse/source-range/count.
ok    TEST-REQ-CBR-005-ARRAY-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR array: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13584046/13584059/13587274, sink 52178944; worker 1 start/first/end 13584069/13584073/13587516, sink 75218944; overlap 3205 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR array: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13587279/13587282/13590813, sink 52178944; worker 1 start/first/end 13587518/13587519/13590911, sink 75218944; overlap 3295 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-005-ARRAY-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-INPUTS
20 test della composizione degli array CBOR superati.
ok    TEST-REQ-CBR-006-MAP-EMPTY-SCALAR-PAIR-AND-TWO-LITERAL-PAIRS
ok    TEST-REQ-CBR-006-MAP-PAIR-COUNT-WIDTH-BOUNDARIES-AND-MINIMAL-HEADER
ok    TEST-REQ-CBR-006-MAP-NESTED-UTF8-FLOATS-OPAQUE-BYTES-AND-PRESERVED-PAIR-ORDER
ok    TEST-REQ-CBR-006-MAP-CONCATENATION-NEXT-AND-REUSED-SPACE
ok    TEST-REQ-CBR-006-MAP-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-006-MAP-SOURCE-TYPE-RANGE-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-006-MAP-TABLE-TYPE-COUNT-DOMAINS-AND-HALF-LENGTH-BEFORE-MULTIPLICATION
ok    TEST-REQ-CBR-006-MAP-WORKSPACE-TYPE-AND-ALL-SCRATCH-ALIASES-EVEN-EMPTY
ok    TEST-REQ-CBR-006-MAP-CONFIGURED-LIMITS-AND-EMPTY-ROOT-MINIMUM
ok    TEST-REQ-CBR-006-MAP-STRICT-ACTIVE-ENDS-LAST-AND-UNREAD-EVEN-OR-ODD-TAIL
ok    TEST-REQ-CBR-006-MAP-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-006-MAP-OVERLAP-ENTIRE-FOOTPRINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-006-MAP-FULL-BYTE-BUDGET-KEY-PLUS-VALUE-EXACT-16MIB-AND-OVER
ok    TEST-REQ-CBR-006-MAP-ROOT-KEY-VALUE-TAG-NODES-AND-ZERO-RESIDUE-BEFORE-RESET
ok    TEST-REQ-CBR-006-MAP-ROOT-DEPTH-SCALARS-TAGS-AND-99-100-CHILD-CONTAINERS
ok    TEST-REQ-CBR-006-MAP-KEY-AND-VALUE-PARSER-ERRORS-ABSOLUTE-AND-LEFT-TO-RIGHT
ok    TEST-REQ-CBR-006-MAP-REUSE-AFTER-VALUE-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-006-MAP-SCRATCH-LAST-VALUE-AND-ZERO-PAIRS-NO-RESET
  CBOR map fuzz: seed4D415035, 1024 casi, 512 successi e 64 ciascuno capacita/byte/entry/nodi/profondita/parse/source-range/count.
ok    TEST-REQ-CBR-006-MAP-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR map: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13839970/13839980/13843205, sink 54677504; worker 1 start/first/end 13839989/13839993/13843665, sink 77537280; overlap 3216 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR map: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 13843208/13843209/13847491, sink 54677504; worker 1 start/first/end 13843668/13843669/13847058, sink 77537280; overlap 3390 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-006-MAP-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-INPUTS
20 test della composizione delle mappe CBOR superati.
ok    TEST-REQ-CBR-007-TAG-U32-WORD-WIDTH-BOUNDARIES-AND-ALL-WIRE-SENTINELS
ok    TEST-REQ-CBR-007-TAG-OPAQUE-SCALARS-UTF8-FLOATS-CONTAINERS-AND-PAIR-ORDER
ok    TEST-REQ-CBR-007-TAG-CONCATENATION-NEXT-AND-EXACT-RETURN-ARITY
ok    TEST-REQ-CBR-007-TAG-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-007-TAG-SOURCE-TYPE-RANGE-EMPTY-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-007-TAG-HIGH-THEN-LOW-DOMAIN-PRECEDENCE-WITHOUT-U64
ok    TEST-REQ-CBR-007-TAG-WORKSPACE-TYPE-AND-BOTH-KINDS-ALIASES
ok    TEST-REQ-CBR-007-TAG-CONFIGURED-LIMITS-AND-ROOT-TWO-NODE-MINIMUM
ok    TEST-REQ-CBR-007-TAG-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-007-TAG-CAPACITY-ACTIVE-END-AND-COMPLETE-BYTE-BUDGET
ok    TEST-REQ-CBR-007-TAG-OVERLAP-INCLUDING-ONLY-HEADER-AND-TOUCHING-BOUNDARIES
ok    TEST-REQ-CBR-007-TAG-FULL-16MIB-WITH-ONE-AND-NINE-BYTE-HEADER-AND-OVER
ok    TEST-REQ-CBR-007-TAG-ROOT-AND-CONTENT-NODE-RESIDUE-LONG-TAG-CHAINS-NO-FRAME
ok    TEST-REQ-CBR-007-TAG-DEPTH-UNCHANGED-ZERO-SCALARS-AND-100-101-CONTAINERS
ok    TEST-REQ-CBR-007-TAG-PARSER-FAILURES-ABSOLUTE-OFFSET-AND-COMPLETE-SINGLE-ITEM
ok    TEST-REQ-CBR-007-TAG-EVERY-TRUNCATION-NONZERO-SOURCE-START-AND-EXACT-END
ok    TEST-REQ-CBR-007-TAG-SCRATCH-REUSE-AFTER-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-007-TAG-SCRATCH-CONTENT-ONLY-STATISTICS-AFTER-SUCCESS
  CBOR tag fuzz: seed54414737, 1024 casi, 512 successi e 64 ciascuno capacita/byte/high/nodi/profondita/parse/source-range/empty.
ok    TEST-REQ-CBR-007-TAG-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR tag: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14324719/14324735/14327087, sink 66766848; worker 1 start/first/end 14324748/14324754/14327250, sink 97310720; overlap 2339 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR tag: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14327090/14327093/14329585, sink 66766848; worker 1 start/first/end 14327251/14327254/14329780, sink 97310720; overlap 2334 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-007-TAG-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-SOURCE
20 test della composizione dei tag CBOR superati.
ok    TEST-REQ-CBR-008-ITEM-LITERAL-ALL-MAJORS-AND-UNREAD-POISON-TAIL
ok    TEST-REQ-CBR-008-ITEM-INTEGER-TAG-AND-STRING-WIDTH-BOUNDARIES
ok    TEST-REQ-CBR-008-ITEM-CONCATENATED-FRONTIERS-AND-EXACT-SCANNERS-STILL-TRAILING
ok    TEST-REQ-CBR-008-ITEM-AUTHORIZED-END-PHYSICAL-SENTINELS-AND-NONZERO-START
ok    TEST-REQ-CBR-008-ITEM-BUFFER-TYPE-RANGE-AND-WHOLE-BACKING-ARRAY-PRESERVATION
ok    TEST-REQ-CBR-008-ITEM-WORKSPACE-TYPE-ALIAS-AND-PREFLIGHT-BEFORE-RESET
ok    TEST-REQ-CBR-008-ITEM-CONFIGURED-LIMITS-AND-ALL-PREFLIGHT-PRECEDENCES
ok    TEST-REQ-CBR-008-ITEM-BYTE-BUDGET-INCLUDES-ENTIRE-WINDOW-AND-UNREAD-TAIL
ok    TEST-REQ-CBR-008-ITEM-ROOT-AND-TAG-CHAIN-NODE-BUDGET-WITHOUT-TAIL-NODES
ok    TEST-REQ-CBR-008-ITEM-DEPTH-ZERO-AND-100-101-WITHOUT-TAIL-DEPTH
ok    TEST-REQ-CBR-008-ITEM-MALFORMED-FIRST-ITEM-ABSOLUTE-ERRORS-AND-MINIMALITY
ok    TEST-REQ-CBR-008-ITEM-EVERY-TRUNCATION-IS-BOUNDED-BY-AUTHORIZED-END
ok    TEST-REQ-CBR-008-ITEM-HEADER-PREFERENCE-BEFORE-NODES-DEPTH-AND-PAYLOAD
ok    TEST-REQ-CBR-008-ITEM-SCRATCH-REUSE-AND-CONTENT-STATISTICS-WITHOUT-TAIL
ok    TEST-REQ-CBR-008-ITEM-FULL-16MIB-WINDOW-TAIL-AND-COMPLETE-PAYLOAD-BOUNDARY
  CBOR item fuzz: seed49544538, 1024 casi, 512 successi e 64 ciascuno byte/nodi/depth/nonminimal/range/workspace/byte-limit/truncated.
ok    TEST-REQ-CBR-008-ITEM-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR item: onda 0, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14441103/14441109/14443213, sink 74129408; worker 1 start/first/end 14441136/14441140/14443245, sink 74129408; overlap 2077 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
  CBOR item: onda 1, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14443216/14443217/14445437, sink 74129408; worker 1 start/first/end 14443247/14443248/14445398, sink 74129408; overlap 2151 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CBR-008-ITEM-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-BUFFER
17 test della lettura del primo item CBOR minimo superati.
ok    TEST-REQ-CBR-009-STRING-LITERAL-EMPTY-UTF8-AND-UNREAD-TAILS
ok    TEST-REQ-CBR-009-STRING-LENGTH-WIDTH-BOUNDARIES-AND-PAYLOAD-OFFSET
ok    TEST-REQ-CBR-009-STRING-RAW-BYTES-NEVER-VALIDATED-AS-UTF8
ok    TEST-REQ-CBR-009-STRING-CONCATENATION-AND-ZERO-LENGTH-PAYLOAD-FRONTIERS
ok    TEST-REQ-CBR-009-STRING-BUFFER-TYPE-RANGE-AND-BACKING-ARRAY-PRESERVED
ok    TEST-REQ-CBR-009-STRING-BYTE-LIMIT-DOMAIN-AND-PREFLIGHT-PRECEDENCES
ok    TEST-REQ-CBR-009-STRING-BUDGET-COVERS-WHOLE-WINDOW-AND-EMPTY-SPAN
ok    TEST-REQ-CBR-009-STRING-TYPE-PRECEDES-FIT-FOR-EVERY-OTHER-MAJOR
ok    TEST-REQ-CBR-009-STRING-HEADER-SYNTAX-AND-MINIMALITY-PRECEDE-TYPE
ok    TEST-REQ-CBR-009-STRING-NONMINIMAL-LENGTHS-BEFORE-FIT-OR-UTF8
ok    TEST-REQ-CBR-009-STRING-U64-LENGTH-AND-LOW-WORD-FIT-BEFORE-PAYLOAD
ok    TEST-REQ-CBR-009-STRING-EVERY-HEADER-AND-PAYLOAD-TRUNCATION-AT-AUTHORIZED-END
ok    TEST-REQ-CBR-009-STRING-UTF8-REASONS-AND-ABSOLUTE-PAYLOAD-OFFSETS
ok    TEST-REQ-CBR-009-STRING-FIT-BEFORE-UTF8-AND-VALIDATION-STOPS-AT-PAYLOAD-END
ok    TEST-REQ-CBR-009-STRING-FULL-16MIB-WINDOW-PAYLOAD-AND-ONE-BYTE-OVER
  CBOR string read fuzz: seed53545239, 1024 casi, 512 successi e 64 ciascuno byte/type/nonminimal/truncated/utf8/range/byte-limit/empty.
ok    TEST-REQ-CBR-009-STRING-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASSES
  CBOR string read: onda 0, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14768923/14768928/14769775, sink 84649984; worker 1 start/first/end 14768950/14768952/14769866, sink 85010432; overlap 825 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
  CBOR string read: onda 1, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 14769777/14769778/14770694, sink 84649984; worker 1 start/first/end 14769867/14769868/14770796, sink 85010432; overlap 827 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CBR-009-STRING-TWO-REUSED-WORKERS-SHARE-BUFFER-WITH-DISTINCT-RAW-AND-TEXT-WINDOWS
17 test della lettura delle stringhe CBOR minime superati.
ok    TEST-REQ-MVC-008-CSN-DEFAULT-CAPACITY-AND-VALID-BOUNDARIES
ok    TEST-REQ-AFF-008-CSN-INVALID-CONFIGURATION-EACH-FIELD
ok    TEST-REQ-MVC-008-CSN-RECOVERY-BASE-AND-FIRST-SUCCESSOR
ok    TEST-REQ-MVC-008-CSN-FULL-REFUSAL-CREDIT-AND-EVERY-SLOT-REUSED
ok    TEST-REQ-MVC-008-CSN-REVERSE-COMPLETION-AND-INTERIOR-GAP
ok    TEST-REQ-MVC-008-CSN-ADR0046-MODULO-RING-COUNTEREXAMPLE
ok    TEST-REQ-MVC-008-CSN-CARRY-U32-AND-HORIZON-BORROW
ok    TEST-REQ-MVC-008-CSN-CROSSES-SBCL-FIXNUM-BOUNDARY
ok    TEST-REQ-AFF-008-CSN-LAST-U64-AND-EXHAUSTION-DOES-NOT-WRAP
ok    TEST-REQ-AFF-004-CSN-INVALID-TOKEN-SHAPES-AND-ZERO
ok    TEST-REQ-AFF-004-CSN-EXACT-SLOT-HIGH-LOW-AND-REGISTRY-BINDING
ok    TEST-REQ-AFF-004-CSN-DOUBLE-RESOLUTION-AND-STALE-REUSED-SLOT
  CSN: K=2, 6 commit, 850 prefissi, 243 storie complete.
  CSN: K=3, 6 commit, 7310 prefissi, 2403 storie complete.
ok    TEST-REQ-MVC-008-CSN-EXHAUSTIVE-CAPACITY-2-3-THROUGH-SIX-COMMITS
  CSN seed #x46C5A71B: 2993 presi, 2987 risolti, 2085 pieni, 964 letture, 971 stale.
ok    TEST-REQ-MVC-008-CSN-DETERMINISTIC-TEN-THOUSAND-ACTIONS
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-SHAPE-BEFORE-PUBLIC-MUTATION
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-FRONTIERS-BEFORE-PUBLIC-MUTATION
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-LIVE-COUNT-TOKEN-AND-RESIDUAL-SCAN
ok    TEST-REQ-CON-004-CSN-GUARD-MACRO-SINGLE-EVALUATION-VALUES-AND-CLEANUP
ok    TEST-REQ-CON-004-CSN-HELD-WORKER-GUARD-BUSY-AND-INDEPENDENT-REGISTRY
  CSN: 4 worker x 1000 assegnazioni, 6622 busy, 906 full, slot #(1275 1353 1372), H convergente.
ok    TEST-REQ-MVC-008-CSN-FOUR-REAL-WORKERS-ONE-THOUSAND-ASSIGNMENTS-EACH
20 test del registro CSN superati.
ok    TEST-REQ-AFF-008-SNAPSHOT-CONFIGURATION-BOUNDARIES
ok    TEST-REQ-AFF-008-SNAPSHOT-CONFIGURATION-TYPED-RANGE-REFUSALS
ok    TEST-REQ-MVC-005-SNAPSHOT-EMPTY-ARCHIVE-CSN-ZERO
ok    TEST-REQ-MVC-005-SNAPSHOT-CANONICAL-OUT-OF-ORDER-ACTIVATION
ok    TEST-REQ-MVC-005-SNAPSHOT-CARRY-U32-AND-BOXED-CSN
ok    TEST-REQ-MVC-007-SNAPSHOT-MAXIMUM-CSN-IS-NOT-ABSENCE
ok    TEST-REQ-MVC-007-SNAPSHOT-SAME-CSN-DISTINCT-GENERATIONS
ok    TEST-REQ-MVC-003-SNAPSHOT-MULTIPIN-RETENTION-BOUNDARIES
ok    TEST-REQ-MVC-007-SNAPSHOT-CONSERVATIVE-THRESHOLD-UNTIL-RECALCULATION
ok    TEST-REQ-AFF-008-SNAPSHOT-CAPACITY-REFUSES-BEFORE-MUTATION
ok    TEST-REQ-MVC-007-SNAPSHOT-PINNED-CONTEXT-REFUSES-BEFORE-MUTATION
ok    TEST-REQ-AFF-008-SNAPSHOT-DEADLINE-OVERFLOW-AND-EXACT-U64-BOUNDARY
ok    TEST-REQ-AFF-008-SNAPSHOT-PRIVATE-FI-GENERATION-EXHAUSTION
ok    TEST-REQ-MVC-004-SNAPSHOT-ACTIVE-READER-DEADLINE-BEFORE-EXACT-AFTER
ok    TEST-REQ-MVC-004-SNAPSHOT-ACTIVE-ACTIVATION-EXPIRY-REMOVES-PIN
ok    TEST-REQ-MVC-004-SNAPSHOT-WAIT-DEADLINE-BEFORE-EXACT-AFTER
ok    TEST-REQ-MVC-004-SNAPSHOT-LIFETIME-INCLUDES-INITIAL-WAIT
ok    TEST-REQ-AFF-008-SNAPSHOT-TIMER-BUDGET-REFUSALS-AND-EMPTY-SWEEP
ok    TEST-REQ-AFF-008-SNAPSHOT-TIMER-CIRCULAR-FAIRNESS-AND-MIXED-DEADLINES
ok    TEST-REQ-MVC-004-SNAPSHOT-TIMER-DISTINGUISHES-WAIT-AND-AGE
ok    TEST-REQ-MVC-007-SNAPSHOT-TERMINATION-IDEMPOTENT-ACTIVE-AND-WAITING
ok    TEST-REQ-MVC-007-SNAPSHOT-STALE-GENERATION-AFTER-CONTEXT-REUSE
ok    TEST-REQ-MVC-007-SNAPSHOT-STALE-CONTEXT-AFTER-SLOT-REUSE
ok    TEST-REQ-MVC-005-SNAPSHOT-PRIVATE-BUFFER-RANGE-AND-UNBOUND-IDENTITY
ok    TEST-REQ-AFF-004-SNAPSHOT-TERMINAL-INVALIDATION-PRESERVES-PINS
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-READER-CSN-STATE-AND-RANGE
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-COUNTER-GUARDS
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-RECALCULATION-INVARIANTS
ok    TEST-REQ-MVC-007-SNAPSHOT-ANNOUNCEMENT-BEFORE-CAPTURE
ok    TEST-REQ-MVC-007-SNAPSHOT-HORIZON-REGRESSION
ok    TEST-REQ-MVC-007-SNAPSHOT-CAPTURED-CSN-BELOW-HORIZON
ok    TEST-REQ-MVC-007-SNAPSHOT-BUSY-ROLLBACK-WITHOUT-PIN
ok    TEST-REQ-MVC-007-SNAPSHOT-BUSY-ROLLBACK-WITH-PIN
ok    TEST-REQ-MVC-007-SNAPSHOT-OTHER-RESOURCE-FAIL-STOP
ok    TEST-REQ-MVC-007-SNAPSHOT-CANONICAL-CONDITION-IDENTITY
ok    TEST-REQ-MVC-007-SNAPSHOT-THROW-AFTER-ANNOUNCEMENT
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-BEFORE-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-DURING-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-AFTER-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-READY-EQUALITY-AND-PUBLISHED-IDENTITY
ok    TEST-REQ-CON-004-SNAPSHOT-HELD-MUTEX-READER-AND-OTHER-ARCHIVE
ok    TEST-REQ-CON-004-SNAPSHOT-RECURSIVE-GUARD-AND-NIL-BODY
ok    TEST-REQ-CON-004-SNAPSHOT-READER-WITH-CSN-MUTEX-HELD
43 test snapshot/CSN superati.
ok    TEST-REQ-AFF-008-EBR-VALID-CAPACITIES-AND-INITIAL-STATE
ok    TEST-REQ-AFF-008-EBR-WORKER-CAPACITY-REFUSALS
ok    TEST-REQ-AFF-008-EBR-RETIREMENT-CAPACITY-REFUSALS
ok    TEST-REQ-CMP-005-EBR-CANONICAL-CONTEXT-AND-WORKER-RANGE
ok    TEST-REQ-CMP-005-EBR-ENTER-EXIT
ok    TEST-REQ-CMP-005-EBR-NESTED-ENTRY-PRESERVES-PIN
ok    TEST-REQ-CMP-005-EBR-INACTIVE-EXIT-REFUSED
ok    TEST-REQ-CMP-005-EBR-INDEPENDENT-READERS
ok    TEST-REQ-CMP-005-EBR-OWNER-NONLOCAL-CLEANUP
ok    TEST-REQ-CMP-007-EBR-RESERVATION-RESOURCE-AND-CREDITS
ok    TEST-REQ-CMP-007-EBR-NULL-RESOURCE-PRESERVES-STATE
ok    TEST-REQ-CMP-007-EBR-DUPLICATE-RESOURCE-PRESERVES-STATE
ok    TEST-REQ-AFF-008-EBR-FULL-CAPACITY-PRESERVES-STATE
ok    TEST-REQ-CMP-007-EBR-CANCEL-IS-IDEMPOTENT
ok    TEST-REQ-CMP-007-EBR-PUBLISH-ADVANCES-ONCE
ok    TEST-REQ-CMP-007-EBR-PUBLISHED-RETIREMENT-CANNOT-CANCEL
ok    TEST-REQ-CMP-007-EBR-INVALID-TICKET-STATE-OPERATIONS
ok    TEST-REQ-CMP-007-EBR-STRICT-RECLAIM-THRESHOLD
ok    TEST-REQ-CMP-007-EBR-TWO-OLD-READERS-BLOCK-RECLAIM
ok    TEST-REQ-CMP-007-EBR-NEW-READER-DOES-NOT-BLOCK-OLD-RETIREMENT
ok    TEST-REQ-CMP-007-EBR-THRESHOLD-IS-MONOTONE
ok    TEST-REQ-CMP-007-EBR-RESOURCE-UNTIL-COMPLETION
ok    TEST-REQ-CMP-007-EBR-COMPLETION-IS-IDEMPOTENT
ok    TEST-REQ-CMP-007-EBR-STALE-GENERATION-PRESERVES-REUSE
ok    TEST-REQ-CMP-007-EBR-ZERO-AND-WRONG-GENERATION-PRESERVE-STATE
ok    TEST-REQ-AFF-008-EBR-GENERATION-MAXIMUM-WITHOUT-WRAP
ok    TEST-REQ-AFF-008-EBR-EPOCH-CREDIT-BEFORE-PUBLICATION
ok    TEST-REQ-AFF-008-EBR-CANCEL-RESTORES-EPOCH-CREDIT
ok    TEST-REQ-AFF-004-EBR-METADATA-INCOHERENCE-FAULTS
ok    TEST-REQ-AFF-004-EBR-COUNTER-INCOHERENCE-FAULTS
ok    TEST-REQ-AFF-004-EBR-FUTURE-READER-FAULTS
ok    TEST-REQ-AFF-004-EBR-READER-CLEANUP-AFTER-FAULT
ok    TEST-REQ-CMP-007-EBR-CLAIM-IS-EXCLUSIVE
ok    TEST-REQ-CMP-005-EBR-READER-FINISHES-WITH-MAINTENANCE-MUTEX-HELD
34 test epoche/reclaim superati.
ok    TEST-REQ-MVC-005-READ-CURRENT-BUFFER-UNTOUCHED
ok    TEST-REQ-MVC-005-READ-SNAPSHOT-CSN-ZERO-CARRY-BOXED
ok    TEST-REQ-MVC-004-READ-COMPLETION-KEEPS-SNAPSHOT
ok    TEST-REQ-MVC-004-READ-WAITING-REFUSAL-CLEANS-EPOCH
ok    TEST-REQ-MVC-004-READ-ENDED-BEGIN-CLEANS-EPOCH
ok    TEST-REQ-CON-004-READ-CURRENT-GENERATION-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-SNAPSHOT-ZERO-GENERATION-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-FOREIGN-SNAPSHOT-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-ALREADY-ACTIVE-READER-REFUSAL
ok    TEST-REQ-CON-004-READ-NESTED-KEEPS-EXISTING-PIN
ok    TEST-REQ-MVC-005-READ-INACTIVE-BUFFER-REFUSAL
ok    TEST-REQ-MVC-005-READ-RESULT-RANGE-PRESERVES-BUFFER
ok    TEST-REQ-MVC-004-READ-FINAL-SNAPSHOT-CHECK
ok    TEST-REQ-CMP-007-READ-LOGICAL-EXPIRY-KEEPS-LIVE-EPOCH
ok    TEST-REQ-CON-004-READ-CLOCK-REGRESSION-RELEASES-PIN
ok    TEST-REQ-CMP-007-READ-ABANDON-RELEASES-PIN
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-GENERATION
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-CSN
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-START
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-CONFIRMED
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-SNAPSHOT
ok    TEST-REQ-AFF-004-READ-ACTIVE-CURRENT-GENERATION
ok    TEST-REQ-AFF-004-READ-ACTIVE-CURRENT-CSN
ok    TEST-REQ-AFF-004-READ-ACTIVE-SNAPSHOT-ZERO-GENERATION
ok    TEST-REQ-AFF-004-READ-ACTIVE-FOREIGN-BINDING
ok    TEST-REQ-AFF-004-READ-MISSING-EPOCH-FAULT
ok    TEST-REQ-AFF-004-READ-FAULTED-CONTEXT-STAYS-FAULTED
ok    TEST-REQ-AFF-004-READ-FINAL-CSN-CHANGED-FAULT
ok    TEST-REQ-CMP-007-READ-EXTERNAL-ERROR-THROW-CLEANUP
ok    TEST-REQ-CON-004-READ-TWO-WORKER-MIGRATION
30 test dei compiti di lettura superati.
ok    TEST-REQ-AFF-008-GET-EXACT-PAYLOAD-BUDGET
ok    TEST-REQ-AFF-008-GET-DEFAULT-PAYLOAD-BUDGET
ok    TEST-REQ-AFF-008-GET-BUDGET-REFUSED-BEFORE-WORKER-LOOKUP
ok    TEST-REQ-AFF-008-GET-INVALID-WORKER-CONFIGURATION
ok    TEST-REQ-FOR-001-GET-VIEW-IDENTITY-LENGTH
ok    TEST-REQ-FOR-001-GET-VIEW-COPIES-IDENTITY
ok    TEST-REQ-CON-004-GET-SECOND-VIEW-SAME-CANONICAL-ARCHIVE
ok    TEST-REQ-CON-004-GET-EQUAL-REGISTERS-DISTINCT-ARCHIVE-REFUSED
ok    TEST-REQ-CON-004-GET-FOREIGN-ARCHIVE-REFUSED
ok    TEST-REQ-LIM-003-GET-KEY-LENGTH-BOUNDARIES
ok    TEST-REQ-CON-004-GET-PRIVATE-KEY-ALIAS-REFUSED
ok    TEST-REQ-IDX-001-GET-UNCONFIGURED-HASH-RELEASES-EPOCH
ok    TEST-REQ-CON-004-GET-NESTED-START-PRESERVES-EXISTING-PIN
ok    TEST-REQ-CON-004-GET-PREMATURE-FINISH-PRESERVES-EXISTING-PIN
ok    TEST-REQ-CMP-007-GET-ABANDON-IS-IDEMPOTENT-AND-REUSABLE
ok    TEST-REQ-AFF-004-GET-FI-FAULTED-CONTEXT-IS-TERMINAL
ok    TEST-REQ-AFF-004-GET-FI-IDLE-RESIDUE-FAULTS
ok    TEST-REQ-MVC-005-GET-CURRENT-MISS-AUTHORIZES-ABSENCE
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-MISS-REQUIRES-HISTORY
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-CANDIDATE-OLDER-THAN-LIMIT
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-CANDIDATE-EQUAL-TO-LIMIT
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-NEWER-CANDIDATE-REQUIRES-HISTORY
ok    TEST-REQ-MVC-005-GET-CURRENT-HIGH-CSN-REMAINS-CANDIDATE
ok    TEST-REQ-MVC-004-GET-COPY-IS-PRIVATE-UNTIL-FINAL-CONFIRMATION
ok    TEST-REQ-IDX-001-GET-CANDIDATE-COPY-HAS-INDEPENDENT-STORAGE
ok    TEST-REQ-CON-004-GET-CANDIDATE-ALIAS-PRESERVES-EXISTING-PIN
ok    TEST-REQ-AFF-008-GET-OUTPUT-RANGE-ERROR-RELEASES-EPOCH
ok    TEST-REQ-CON-004-GET-OUTPUT-ALIAS-ERROR-RELEASES-EPOCH
ok    TEST-REQ-MVC-004-GET-FINAL-EXPIRY-AFTER-VALUE-COPY
ok    TEST-REQ-MVC-004-GET-FINAL-TERMINATION-AFTER-VALUE-COPY
ok    TEST-REQ-CON-004-GET-CLOCK-REGRESSION-AFTER-VALUE-COPY
ok    TEST-REQ-AFF-004-GET-FI-EMPTY-VALUE-RANGE-FAULTS
ok    TEST-REQ-AFF-004-GET-FI-VALUE-OVERFLOW-FAULTS
ok    TEST-REQ-AFF-003-GET-EXTERNAL-ERROR-AFTER-COPY-CLEANS-OWNER
ok    TEST-REQ-AFF-003-GET-EXTERNAL-THROW-AFTER-COPY-CLEANS-OWNER
ok    TEST-GET-D04-NATIVE-READONLY-HEADER-AND-KNOWN-PUT
ok    TEST-GET-D08-MISS-INSERT-THEN-HIT-WITHOUT-RECORD-IO
ok    TEST-GET-D08-CACHE-DISABLED-STILL-LOADS-KNOWN-VALUE
ok    TEST-GET-D05-CACHE-MISS-PROBE-KEEPS-CANDIDATE-AND-DOES-NO-IO
ok    TEST-GET-D05-PREPARED-PROBE-REQUIRES-PROOF-WITHOUT-IO
ok    TEST-GET-D05-SMALL-PROBE-PRECEDES-PROOF-AND-CACHE
ok    TEST-GET-D05-SMALL-LOAD-DOES-NO-PROOF-OR-RECORD-IO
ok    TEST-GET-D07-PREPARED-REAL-OUTCOME-BEFORE-PUT
ok    TEST-GET-D08-PREPARED-CACHE-HIT-STILL-READS-AUTHORITATIVE-PROOF
ok    TEST-GET-D04-HEADER-REJECTS-OTHER-SEGMENT-IDENTITY
ok    TEST-GET-D04-HEADER-REJECTS-OTHER-SERIE-IDENTITY
ok    TEST-GET-D04-CORRUPT-REAL-HEADER-CANNOT-CREATE-CAPABILITY
ok    TEST-GET-D04-TARGET-OWNER-REFUSAL-RELEASES-EPOCH
ok    TEST-GET-D04-TARGET-SEGMENT-ID-DISAGREES-WITH-INDEX-LOCATION
ok    TEST-GET-D04-HIGH-SEGMENT-WORD-IS-NOT-TRUNCATED-TO-LOCATION
ok    TEST-GET-D04-COMMITTED-PREFIX-ONE-BYTE-SHORT-FOR-PUT
ok    TEST-GET-D04-RECORD-LOCATION-BEFORE-HEADER-IS-REFUSED
ok    TEST-GET-D04-INDEX-SIZE-WITH-NO-VALUE-IS-NOT-A-GET-SOURCE
ok    TEST-GET-D04-INVALID-STORAGE-FLAGS-REJECTED-BEFORE-IO
ok    TEST-GET-D04-PERMITTED-FLAG-MUST-MATCH-PERSISTENT-PUT
ok    TEST-GET-D04-V1-HEADER-SELECTS-V1-RECORD-VERIFIER
ok    TEST-GET-D04-V1-KEY-LIMIT-REFUSES-V2-SIZED-INDEX-KEY
ok    TEST-GET-D04-COMPACTED-ORIGIN-CANNOT-AUTHORIZE-PREPARED-PUT
ok    TEST-GET-D06-PREPARED-PROOF-IS-MANDATORY
ok    TEST-GET-D06-PLAIN-PUT-REJECTS-UNEXPECTED-PROOF-OFFSET
ok    TEST-GET-D06-OUTCOME-MUST-NOT-OVERLAP-PUT
ok    TEST-GET-D06-OUTCOME-BEFORE-HEADER-IS-REFUSED
ok    TEST-GET-D06-OUTCOME-ONE-BYTE-BEYOND-COMMITTED-PREFIX
ok    TEST-GET-D07-OUTCOME-HEADER-AND-BODY-CRCS-CHECKED-BEFORE-PUT
ok    TEST-GET-D07-OUTCOME-CSN-MUST-MATCH-COMMITTED-INDEX
ok    TEST-GET-D07-VALID-CRC-OTHER-RECORD-TYPE-IS-NOT-OUTCOME
ok    TEST-GET-D07-OUTCOME-TXID-MUST-MATCH-PREPARED-PUT
ok    TEST-GET-D07-PERSISTENT-PUT-BODY-CORRUPTION-IS-NOT-A-CACHE-MISS
ok    TEST-GET-D07-PLAIN-PUT-CSN-DISAGREES-WITH-INDEX
ok    TEST-GET-D08-FI-CORRUPT-CACHE-COPY-FALLS-BACK-TO-INTACT-NATIVE-PUT
70 test GET superati.
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE16
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE256
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE4096
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE16
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE256
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE4096
ok    TEST-REQ-CCH-002-PERFORMANCE-CACHE-HIT-V1
ok    TEST-REQ-CCH-002-PERFORMANCE-CACHE-HIT-V2
ok    TEST-REQ-IDX-001-PERFORMANCE-ABSENT
ok    TEST-REQ-MVC-005-PERFORMANCE-SNAPSHOT-BOXED-LATE
ok    TEST-REQ-MVC-004-PERFORMANCE-SNAPSHOT-FINAL-AUTHORIZATION
ok    TEST-REQ-AFF-002-PERFORMANCE-OUTPUT-COPY
ok    TEST-REQ-AFF-002-PERFORMANCE-PREFIX-BOUNDARY
ok    TEST-REQ-AFF-002-PERFORMANCE-MAX-U64-VERIFICATION
ok    TEST-REQ-CCH-004-PERFORMANCE-CACHE-CRC-FALLBACK
ok    TEST-REQ-AFF-002-PERFORMANCE-PERSISTENT-CRC-GUARD
ok    TEST-REQ-CMP-007-PERFORMANCE-CLEANUP
ok    TEST-REQ-CCH-004-PERFORMANCE-CACHE-REPAIR-HIT
ok    TEST-REQ-CON-004-PERFORMANCE-SHARED-READERS4
19 test del contratto GET per benchmark superati.
ok    TEST-REQ-CCH-004-CACHE-EMPTY-AND-PUBLISHED
ok    TEST-REQ-CCH-004-CACHE-ODD-SEQUENCE-IS-UNREADABLE
ok    TEST-REQ-CCH-004-CACHE-SEQUENCE-LIMIT-IS-UNREADABLE
ok    TEST-REQ-CCH-004-CACHE-DISABLED-IS-TERMINAL
ok    TEST-REQ-CCH-004-CACHE-LAST-CREDIT-THEN-DISABLED
ok    TEST-REQ-CCH-004-CACHE-ODD-SLOTS-ARE-QUARANTINED
ok    TEST-REQ-CCH-004-CACHE-CORRUPT-COPY-IS-REJECTED
ok    TEST-REQ-CCH-004-CACHE-CORRUPT-INPUT-PRECEDES-PUBLICATION
  Cache v1/16 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1177/367/504/0, hit/miss 2026/2070, espulsioni 1177, scan non riletti espulsi 2; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V1-FOUR-WORKERS-SMALL-RECORDS
  Cache v2/16 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1241/294/513/0, hit/miss 2057/2039, espulsioni 1241, scan non riletti espulsi 3; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V2-FOUR-WORKERS-SMALL-RECORDS
  Cache v1/4096 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1530/490/28/0, hit/miss 2347/1749, espulsioni 1530, scan non riletti espulsi 0; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V1-FOUR-WORKERS-MULTI-KIB-RECORDS
  Cache v2/4096 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1486/531/31/0, hit/miss 2153/1943, espulsioni 1486, scan non riletti espulsi 1; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V2-FOUR-WORKERS-MULTI-KIB-RECORDS
  Cache v1: mutex detenuto da altro worker, BUSY completato prima del rilascio; stesso worker poi INSERTED e HIT verificato.
ok    TEST-REQ-CCH-004-CACHE-V1-OTHER-THREAD-HELD-STRIPE-IS-NONBLOCKING
  Cache v2: mutex detenuto da altro worker, BUSY completato prima del rilascio; stesso worker poi INSERTED e HIT verificato.
ok    TEST-REQ-CCH-004-CACHE-V2-OTHER-THREAD-HELD-STRIPE-IS-NONBLOCKING
14 test della pubblicazione cache superati.
ok    TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START
ok    TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N
ok    TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT
ok    TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS
ok    TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED
ok    TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER
ok    TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER
ok    TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME
ok    TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17
ok    TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID
ok    TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT
ok    TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK
ok    TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT
ok    TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL
ok    TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP
ok    TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS
ok    TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH
ok    TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS
ok    TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE
ok    TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ
ok    TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS
ok    TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION
ok    TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY
ok    TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN
ok    TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION
ok    TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY
ok    TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER
ok    TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO
ok    TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-INITIALIZATION-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-INITIAL-CONTROLLER-ROOT-AND-NIL-REFUSAL
ok    TEST-REQ-IDX-001-SERIES-GET-EMPTY-ACTIVE-CLOSED-BEFORE-FIRST-BATCH-NATIVE-V1-V2
ok    TEST-REQ-AFF-004-SERIES-GET-EMPTY-ACTIVE-CANDIDATE-FAULTED-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FIRST-BATCH-PUBLISH-AND-REUSE-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-REPEATED-INITIALIZATION-REFUSED
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FOREIGN-OWNER-BEFORE-INITIALIZATION
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-DUPLICATE-BEFORE-INITIALIZATION
ok    TEST-REQ-CON-002-SERIES-GET-EMPTY-ACTIVE-LEASE-BEFORE-CHECKS
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FILE-FRONTIER-REFUSED
ok    TEST-REQ-CMP-007-SERIES-GET-EMPTY-ACTIVE-FIXTURE-CLEANUP-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-CLOSED-CAPABILITIES-REFUSED
ok    TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP
ok    TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2
ok    TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED
ok    TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT
ok    TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK
ok    TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP
ok    TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED
ok    TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED
ok    TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL
ok    TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION
ok    TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE
ok    TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION
ok    TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION
ok    TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION
ok    TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS
ok    TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES
ok    TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17
ok    TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART
ok    TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED
ok    TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE
ok    TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED
ok    TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER
ok    TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED
ok    TEST-REQ-CMP-007-SERIES-GET-OLD-CANDIDATE-NEW-ACTIVE-SUPERSET-NATIVE-V1-V2
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-SOURCE-PINNED-THROUGH-COPY-AND-RECLAIM
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-HOOK-CONDITION-RELEASES-PIN-BEFORE-RECLAIM
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-HOOK-NONLOCAL-EXIT-RELEASES-PIN-BEFORE-RECLAIM
72 test directory GET superati.
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-ALL-EIGHT-OCTETS
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-ZERO-AND-SINGLE-PROOF
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-U64-ORDER-AND-STABLE-DUPLICATES
ok    TEST-REQ-FOR-004-RESOLVER-LOOKUP-FIRST-DUPLICATE-AND-U64-BORDERS
ok    TEST-REQ-FOR-004-RESOLVER-DUPLICATE-CSN-EACH-WORD-CONFLICTS
ok    TEST-REQ-FOR-004-RESOLVER-ORDER-HIGH-LOW-AND-PHYSICAL-OFFSET
ok    TEST-REQ-FOR-004-RESOLVER-PROOF-SHAPE-BEFORE-SORT-OR-SEARCH
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-PREFLIGHT-NO-PARTIAL-EFFECTS
ok    TEST-REQ-FOR-004-RESOLVER-NATIVE-V1-V2-MULTIPLE-BATCHES-AND-PUTS
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-ZERO-OUTCOMES-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-ONE-OUTCOME-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-TWO-OUTCOMES-RADIX-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-EMPTY-PREFIX-ZERO-PAYLOAD
ok    TEST-REQ-FOR-004-RESOLVER-UNRESOLVED-PREPARED-NOT-INVENTED-COMMIT
ok    TEST-REQ-FOR-004-RESOLVER-OUTCOME-BEFORE-PUT-IS-CORRUPTION
ok    TEST-REQ-FOR-004-RESOLVER-CONFLICTING-OUTCOME-LOW-WORD
ok    TEST-REQ-FOR-004-RESOLVER-CONFLICTING-OUTCOME-HIGH-WORD
ok    TEST-REQ-CON-004-RESOLVER-SOURCE-BUFFER-REUSE-DOES-NOT-ALTER-MAP
ok    TEST-REQ-AFF-008-RESOLVER-SOURCE-BUDGET-BEFORE-IO
ok    TEST-REQ-AFF-008-RESOLVER-RECORD-AND-BATCH-BUDGETS
ok    TEST-REQ-STO-006-RESOLVER-ONE-FD-AUTHORITATIVE-PREFIX-PRESERVES-TAIL
ok    TEST-REQ-FOR-004-RESOLVER-MULTIPLE-PREPARED-TXID-AND-CSN-U64
ok    TEST-REQ-FOR-004-RESOLVER-TXID-HIGH-LOW-BOUNDARIES
ok    TEST-REQ-FOR-004-RESOLVER-IDENTICAL-DUPLICATES-SELECT-FIRST-PHYSICAL-PROOF
ok    TEST-REQ-FOR-004-RESOLVER-MIXED-ORDINARY-PREPARED-FLAGS
ok    TEST-REQ-CCH-002-RESOLVER-PREPARED-COLD-READ-PROOF-BEFORE-PUT-SAME-FD
ok    TEST-REQ-CCH-002-RESOLVER-PREPARED-CACHE-HIT-STILL-REREADS-OWN-PROOF
ok    TEST-REQ-CCH-002-RESOLVER-ORDINARY-CACHE-HIT-REQUIRES-NO-PROOF-OR-IO
ok    TEST-REQ-FOR-004-RESOLVER-UNRESOLVED-PREPARED-CANNOT-AUTHORIZE-RESPONSE
ok    TEST-REQ-FOR-004-RESOLVER-CANDIDATE-CSN-LOW-WORD-MISMATCH
ok    TEST-REQ-FOR-004-RESOLVER-CANDIDATE-CSN-HIGH-WORD-MISMATCH
ok    TEST-REQ-CMP-007-RESOLVER-FOREIGN-CANONICAL-OWNER-CLEANS-PIN
ok    TEST-REQ-CON-004-RESOLVER-PRECONDITIONS-PRESERVE-EXISTING-PIN
ok    TEST-REQ-CON-004-RESOLVER-SMALL-BUFFER-PRECEDES-PREPARED-PROOF-IO
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-HEADER-CRC
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-CSN-LOW
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-CSN-HIGH
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-TXID-LOW
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-TXID-HIGH
ok    TEST-REQ-FOR-004-RESOLVER-LATER-IDENTICAL-PROOF-CANNOT-RESCUE-CORRUPT-FIRST
ok    TEST-REQ-CON-004-RESOLVER-THROW-DURING-PROOF-RELEASES-PIN
ok    TEST-REQ-MVC-004-RESOLVER-SNAPSHOT-EXPIRES-AFTER-PRIVATE-PREPARED-COPY
42 test resolver GET superati.
ok    TEST-REQ-FOR-001-ACTIVE-SOURCE-CONFIGURATION-IDENTITY-AND-FD
ok    TEST-REQ-FOR-003-ACTIVE-NATIVE-V1-V2-PUT-AND-TOMBSTONE
ok    TEST-REQ-IDX-001-ACTIVE-TOMBSTONE-PAGE-ZERO-PUTS
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-IMMUTABLE-NO-CSN-OR-IO
ok    TEST-REQ-AFF-008-ACTIVE-FIRST-PAYLOAD-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-SECOND-PAYLOAD-PEAK-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-PAGE-BUDGET-EXACT-REFUSES-NEXT
ok    TEST-REQ-AFF-008-ACTIVE-PUT-BUDGET-EXACT-REFUSES-NEXT
ok    TEST-REQ-AFF-008-ACTIVE-RECORD-BYTE-BUDGETS-EXACT-ONE-SHORT
ok    TEST-REQ-FOR-004-ACTIVE-PREPARED-OUTCOME-REFUSED-BEFORE-CSN
ok    TEST-REQ-CON-004-ACTIVE-ROOTS-PERSIST-AFTER-PUBLIC-BATCH-REUSE
ok    TEST-REQ-AFF-001-ACTIVE-SEALED-CRC-FAULTS-ARCHIVE-PRESERVES-CAUSE
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-BATCH-FILE-ID
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-BATCH-VERSION
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-EMPTY-OPEN
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-OPEN-TOKEN-BOUND
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-SEALED-REFUSED-WITH-TOKEN-PRESERVED
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-PREVIOUS-ORDER
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-RING-FULL
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-EVENT-GENERATION-BOUND
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-CONTIGUOUS-OFFSET
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-SEGMENT-SPACE
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-RECORD-BOUNDARY
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-SEAL-BYTE-BOUNDARY
ok    TEST-REQ-AFF-001-ACTIVE-PREFLIGHT-HEADER-CORRUPTION-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-ACTIVE-PREFLIGHT-OPEN-COUNT-FAULTS-ARCHIVE
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-NIBBLE-TRANSITIONS-PERSISTENT
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-65536-FINAL-CONVERGENCE
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-MALFORMED-LOCAL-GUARDS
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-OCCUPIED-APPEND-PRESERVES-GRAPH
ok    TEST-REQ-FOR-003-ACTIVE-NATIVE-V1-V2-CSN-U64-AND-ORDINARY-FLAGS
ok    TEST-REQ-CCH-002-ACTIVE-COLD-READ-AND-WARM-PROBE-AND-READ
ok    TEST-REQ-WAL-006-ACTIVE-DURABLE-PLANNED-ROOT-CANNOT-AUTHORIZE-VALUE
ok    TEST-REQ-WAL-006-ACTIVE-OLD-PUT-USES-OWN-PAGE-END
ok    TEST-REQ-IDX-001-ACTIVE-HEADER-SEAL-TOMBSTONE-FRONTIER-AND-MISSING-ROW-FAULT
ok    TEST-REQ-IDX-001-ACTIVE-CANDIDATE-CSN-LOW-AND-HIGH-WORD-MISMATCH
ok    TEST-REQ-IDX-001-ACTIVE-CANDIDATE-WIRE-SIZE-AND-RESERVED-HIGH-WORD
ok    TEST-REQ-CMP-007-ACTIVE-FOREIGN-SOURCE-OWNER-CLEANS-BEFORE-OUTER-UNWIND
ok    TEST-REQ-CMP-007-ACTIVE-CLOSED-READONLY-FD-IS-TERMINAL-SOURCE-FAULT
ok    TEST-REQ-CON-004-ACTIVE-THROW-AT-NATIVE-PREAD-CLEANS-WITHOUT-AUTHORIZING
ok    TEST-REQ-CON-004-ACTIVE-SMALL-BUFFER-RESTARTS-AND-REACQUIRES-NEW-ROOT
ok    TEST-REQ-MVC-004-ACTIVE-SNAPSHOT-EXPIRES-AFTER-PRIVATE-COPY
ok    TEST-REQ-AFF-008-ACTIVE-APPEND-STARTUP-EXACT-BUDGET-AND-EMPTY-ROOT
ok    TEST-REQ-WAL-005-ACTIVE-APPEND-OPEN-REFUSALS-PRESERVE-ENTIRE-ARENA
ok    TEST-REQ-WAL-006-ACTIVE-APPEND-V1-V2-PAGES-AND-TOMBSTONE-BOUNDARIES
ok    TEST-REQ-WAL-006-ACTIVE-APPEND-PREPARED-TAIL-IS-NOT-A-READER-FRONTIER
ok    TEST-REQ-IDX-001-ACTIVE-APPEND-OLD-ROOT-IGNORES-ALL-UNPUBLISHED-TAIL-FIELDS
ok    TEST-REQ-AFF-002-ACTIVE-APPEND-DAMAGED-PREFIX-FAULTS-BEFORE-IO
ok    TEST-REQ-WAL-005-ACTIVE-APPEND-REUSED-TAIL-FAULTS-WITHOUT-CSN
ok    TEST-REQ-WAL-005-ACTIVE-APPEND-KNOWN-CSN-ORDER-REFUSAL-KEEPS-TAIL-UNUSED
ok    TEST-REQ-WAL-006-ACTIVE-APPEND-INCOMPLETE-COPY-AND-ADOPTION-NEVER-REUSE
ok    TEST-REQ-IDX-001-ACTIVE-APPEND-65536-PAGE-SEARCH-BOUNDARIES
52 test GET ACTIVE superati.
ok    TEST-REQ-AFF-008-WRITER-CONFIGURATION
ok    TEST-REQ-AFF-008-WRITER-DEFAULTS-AND-CONFIGURATION-BOUNDARIES
ok    TEST-REQ-CON-001-WRITER-FIFO-RING-WRAP-AND-NIL
ok    TEST-REQ-AFF-008-WRITER-FULL-REFUSAL-RETAINS-PAYLOAD
ok    TEST-REQ-CON-004-WRITER-GUARD-BUSY-DOES-NOT-MUTATE
ok    TEST-REQ-CON-001-WRITER-TARGET-SUBRANGE-AND-EMPTY
ok    TEST-REQ-AFF-004-WRITER-INVALID-TARGET-PREFLIGHT
ok    TEST-REQ-AFF-004-WRITER-PRIVATE-RING-ALIAS-REFUSED
ok    TEST-REQ-CON-001-WRITER-LEASE-LIFECYCLE
ok    TEST-REQ-CON-001-WRITER-STALE-LEASE-SAME-THREAD
ok    TEST-REQ-AFF-008-WRITER-QUANTUM-IS-CUMULATIVE-PER-LEASE
ok    TEST-REQ-AFF-008-WRITER-GENERATION-DOES-NOT-WRAP
ok    TEST-REQ-CON-001-WRITER-SEEDED-LIST-ORACLE
ok    TEST-REQ-CON-001-WRITER-FOREIGN-THREAD-CANNOT-USE-LEASE
ok    TEST-REQ-CON-001-WRITER-CAS-HAS-ONE-OWNER
  Due Serie: 128 CRC, 1048576 byte; WALL fixture con controlli/rendezvous fuori dalle lease: worker 0 start/first/end 20931604/20932073/20967523, sink 596103808; worker 1 start/first/end 20931594/20932061/20962974, sink 1698207232; overlap 31370 tick (1000000 tick/s); nessuna inferenza su tempo puro calcolo, CPU o scaling.
ok    TEST-REQ-CON-003-INDEPENDENT-SERIES-PROGRESS-AND-CPU-OVERLAP
  wave 0: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
  wave 1: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
  wave 2: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
ok    TEST-REQ-CON-001-WRITER-REAL-PRODUCERS-CONSUMERS-AND-WORKER-REUSE
ok    TEST-REQ-AFF-008-HANDOFF-CONFIGURATION-AND-LIMITS
ok    TEST-REQ-CON-005-HANDOFF-SINGLE-OBLIGATION-AND-DUPLICATE-BEGIN
ok    TEST-REQ-CON-005-HANDOFF-ENQUEUE-BEFORE-AND-AFTER-EMPTY-RELEASE
ok    TEST-REQ-CON-004-HANDOFF-CUMULATIVE-QUANTUM-AND-SUCCESSIVE-SLICES
ok    TEST-REQ-AFF-008-HANDOFF-FULL-READY-AND-RUNNING-RETAIN-STATE
ok    TEST-REQ-CON-004-HANDOFF-BUSY-IDLE-AND-READY-PRESERVE-STATE
ok    TEST-REQ-CON-005-HANDOFF-BUSY-RELEASE-RETAINS-LEASE-FOR-RETRY
ok    TEST-REQ-CON-005-HANDOFF-EARLY-RELEASE-CONSERVES-ENTIRE-BACKLOG
ok    TEST-REQ-AFF-004-HANDOFF-LEASE-VALIDATION-AND-STALE-GENERATION
ok    TEST-REQ-AFF-004-HANDOFF-TARGET-PREFLIGHT-AND-PRIVATE-ALIAS
ok    TEST-REQ-AFF-008-HANDOFF-GENERATION-EXHAUSTION-PRESERVES-READY
ok    TEST-REQ-AFF-004-HANDOFF-REJECTS-INCONSISTENT-SCHEDULING-STATES
ok    TEST-REQ-AFF-004-HANDOFF-HELPERS-REQUIRE-CURRENT-THREAD-GUARD
ok    TEST-REQ-CON-001-HANDOFF-SEEDED-LIST-AND-SCHEDULING-ORACLE
ok    TEST-REQ-CON-001-HANDOFF-FOREIGN-THREAD-CANNOT-USE-LEASE
ok    TEST-REQ-CON-002-HANDOFF-TRANSFERS-SUCCESSIVE-SLICES-BETWEEN-REUSED-THREADS
  Handoff: 4 thread riusati, 6 ondate, 36 messaggi, 2 Serie indipendenti.
ok    TEST-REQ-CON-003-HANDOFF-REUSES-FOUR-WORKERS-ACROSS-INDEPENDENT-SERIES-WAVES
ok    TEST-REQ-AFF-008-READY-CONFIGURATION-AND-LIMITS
ok    TEST-REQ-AFF-004-READY-SHARD-AND-WRITER-PREFLIGHT
ok    TEST-REQ-CON-001-READY-PER-SHARD-FIFO-WRAP-AND-PRIVATE-OPAQUE-RING
ok    TEST-REQ-CON-004-READY-CURSOR-ROTATES-FIRST-CHOICE-AND-EMPTY-SCAN
ok    TEST-REQ-CON-001-READY-SEEDED-INDEPENDENT-LISTS-AND-CURSORS
ok    TEST-REQ-CON-005-READY-FULL-PRESERVES-SCHEDULING-OBLIGATION
ok    TEST-REQ-CON-005-READY-DEQUEUED-REFERENCE-SURVIVES-BEGIN-BUSY
ok    TEST-REQ-CON-004-READY-SKIPS-BUSY-HOME-AND-PRESERVES-LOCAL-RING
ok    TEST-REQ-CON-004-READY-BUSY-OBSERVATIONS-AND-SCAN-ORDER-ORACLE
ok    TEST-REQ-CON-005-READY-BUSY-PUBLICATION-RETAINS-OBLIGATION-AND-PAYLOAD
ok    TEST-REQ-AFF-004-READY-REJECTS-INVALID-PRIVATE-RING-SHAPES
ok    TEST-REQ-AFF-004-READY-REJECTS-INVALID-PRIVATE-PARTITION-ARRAYS
ok    TEST-REQ-AFF-004-READY-REJECTS-INCONSISTENT-OCCUPIED-AND-FREE-SLOTS
ok    TEST-REQ-AFF-004-READY-HELPERS-REJECT-MISSING-AND-FOREIGN-GUARD
ok    TEST-REQ-CON-005-READY-HANDOFF-BEFORE-AFTER-RELEASE-AND-NEXT-WAVE
  Ready: 4 thread riusati, 6 ondate, 36 payload, shard fermata e stealing.
ok    TEST-REQ-CON-003-READY-REUSED-WORKERS-LIVE-PRODUCERS-AND-INDEPENDENT-SHARDS
  Ready: 2 consumer riusati, 8 ondate, un riferimento estratto per ondata.
ok    TEST-REQ-CON-002-READY-COMPETING-CONSUMERS-TAKE-ONE-REFERENCE-PER-WAVE
ok    TEST-REQ-CON-001-RECYCLE-ROOM-PUBLISHES-AND-PRESERVES-FIFO
ok    TEST-REQ-CON-005-RECYCLE-CAPACITY-ONE-TRANSFERS-OLD-AND-KEEPS-NEW
ok    TEST-REQ-CON-001-RECYCLE-FULL-WRAP-PRESERVES-INDEPENDENT-LIST-ORDER
ok    TEST-REQ-CON-001-RECYCLE-SEEDED-OBLIGATIONS-AND-PAYLOADS-EXACTLY-ONCE
ok    TEST-REQ-CON-005-RECYCLE-ALL-CONSUMERS-RESCHEDULE-AFTER-PRODUCER-REFILLS-FULL
ok    TEST-REQ-CON-005-RECYCLE-BUSY-RETAINS-OBLIGATION-AND-BOTH-RING-SHAPES
ok    TEST-REQ-AFF-004-RECYCLE-SHARD-WRITER-PREFLIGHT-BEFORE-HELD-GUARD
ok    TEST-REQ-AFF-004-RECYCLE-PRIVATE-RING-AND-PARTITION-SHAPES-PRE-MUTATION
ok    TEST-REQ-AFF-004-RECYCLE-MALFORMED-FULL-HEAD-AND-FREE-TAIL-PRE-MUTATION
ok    TEST-REQ-AFF-004-RECYCLE-HELPER-REJECTS-MISSING-AND-FOREIGN-GUARD
ok    TEST-REQ-CON-001-RECYCLE-PRIVATE-OPAQUE-DUPLICATE-IS-OUTSIDE-HANDOFF-PROTOCOL
ok    TEST-REQ-CON-005-RECYCLE-HANDOFF-BEFORE-RELEASE-AND-NEW-WAVE-WITHOUT-CLEANUP
ok    TEST-REQ-CON-005-RECYCLE-RETURNED-OBLIGATION-SURVIVES-BEGIN-BUSY
  Recycle: 3 thread riusati, 8 ondate, 48 payload, ready FULL e busy bounded.
ok    TEST-REQ-CON-002-RECYCLE-TWO-COMPETING-CONSUMERS-AND-LIVE-PRODUCER-REUSED
ok    TEST-REQ-CON-003-RECYCLE-OTHER-SHARD-PROGRESSES-WHILE-FIRST-GUARD-IS-HELD
ok    TEST-REQ-CON-004-WORKER-FACTORY-PREFLIGHT-AND-EMPTY-CURSOR-ROTATION
ok    TEST-REQ-CON-001-WORKER-CLAIM-BATCH-ACK-AND-IDLE-RELEASE
ok    TEST-REQ-CON-005-WORKER-QUANTUM-YIELD-RESCHEDULE-AND-MONOTONE-TOKENS
ok    TEST-REQ-CON-005-WORKER-BATCH-DEBT-BLOCKS-MORE-POP-FINISH-AND-TRANSFER
ok    TEST-REQ-AFF-004-WORKER-CURRENT-TOKEN-REQUIRED-AND-STALE-ACK-KEEPS-DEBT
ok    TEST-REQ-AFF-004-WORKER-BUFFER-RANGE-AND-PRIVATE-ALIAS-PREFLIGHT
ok    TEST-REQ-CON-005-WORKER-BEGIN-BUSY-RETAINS-CLAIMED-REFERENCE
ok    TEST-REQ-CON-005-WORKER-POP-BUSY-RETAINS-LEASE-BUFFER-AND-GENERATION
ok    TEST-REQ-CON-005-WORKER-END-BUSY-IS-FINISHING-AND-BLOCKS-NEW-POP
ok    TEST-REQ-CON-004-WORKER-SCANNED-HOME-AND-FULL-RECYCLE-RETAINED-ON-BUSY
ok    TEST-REQ-CON-005-WORKER-TWO-CONTEXTS-FULL-REFILL-PRESERVES-ALL-OBLIGATIONS
ok    TEST-REQ-CON-005-WORKER-EMPTY-OBSERVATION-AND-NEW-WAVE-AFTER-IDLE
ok    TEST-REQ-CON-002-WORKER-FOREIGN-THREAD-REFUSES-ALL-SIX-PHASES
ok    TEST-REQ-AFF-008-WORKER-LOCAL-GENERATION-LIMIT-CAN-CEDE-INTO-FRESH-CONTEXT
ok    TEST-REQ-CON-002-WORKER-CEDE-ADOPT-VALIDATES-HOME-AND-SINGLE-CALLER-OBLIGATION
ok    TEST-REQ-CON-001-WORKER-SEEDED-INDEPENDENT-OBLIGATIONS-PAYLOADS-AND-BATCH-DEBT
ok    TEST-REQ-AFF-004-WORKER-PRIVATE-SHAPES-AND-PENDING-COUNT-INVARIANTS
ok    TEST-REQ-AFF-004-WORKER-PRIVATE-INDEX-CORRUPTION-POISONS-BEFORE-ADOPT
ok    TEST-REQ-AFF-008-WORKER-BOUNDARY-EXPANSION-VALUES-ONCE-AND-ERROR-IDENTITY
ok    TEST-REQ-AFF-008-WORKER-STALE-NOT-READY-REFERENCE-CANNOT-STEAL-NEW-WAVE
ok    TEST-REQ-AFF-008-WORKER-GENERATION-OVERFLOW-PRECEDES-EMPTY-AND-YIELD-POP
  Worker: 4 thread riusati, 6 ondate, 36 payload CRC, contesti owner-only.
ok    TEST-REQ-CON-003-WORKER-REUSED-OWNER-CONTEXTS-LIVE-PRODUCERS-AND-INDEPENDENT-SHARDS
  Worker: 2 consumer owner riusati, 8 ondate, un solo obbligo per ondata.
ok    TEST-REQ-CON-002-WORKER-COMPETING-OWNER-CONTEXTS-CLAIM-ONE-OBLIGATION-PER-WAVE
89 test delle code writer superati.
ok    TEST-REQ-THR-001-POOL-CONSTRUCTION-DEFAULTS-AND-VALID-BOUNDS
ok    TEST-REQ-AFF-008-POOL-PRIVATE-CONSTRUCTION-DEFAULTS-AND-EXPLICIT-STATE
ok    TEST-REQ-AFF-008-POOL-GENERATED-EQUALITY-COMPARES-EACH-BOUNDED-SIGNAL
ok    TEST-REQ-AFF-008-POOL-DECLARED-INTEGER-DOMAINS-AND-DIRECTION-MEMBERS
ok    TEST-REQ-AFF-008-POOL-INVALID-CONFIGURATION-HAS-TYPED-REASONS
ok    TEST-REQ-THR-001-POOL-FIRST-SAMPLE-SEEDS-EXACT-FIXED-POINT-SIGNALS
ok    TEST-REQ-AFF-013-POOL-EWMA-INDEPENDENT-ORACLE-AND-NEGATIVE-ROUNDING
ok    TEST-REQ-AFF-008-POOL-INVALID-SAMPLES-PRESERVE-ENTIRE-PUBLIC-STATE
ok    TEST-REQ-AFF-008-POOL-SAMPLE-UPPER-BOUNDS-AND-CLOCK-EXHAUSTION
ok    TEST-REQ-THR-001-POOL-ADDITIVE-GROWTH-NEEDS-COMPLETE-DWELL
ok    TEST-REQ-THR-001-POOL-MULTIPLICATIVE-DECREASE-FLOORS-AND-CLAMPS
ok    TEST-REQ-THR-001-POOL-HYSTERESIS-THRESHOLDS-ARE-INCLUSIVE-AS-SPECIFIED
ok    TEST-REQ-THR-001-POOL-CONFIGURABLE-QUEUE-THRESHOLD-AND-CUSTOM-PERIOD
ok    TEST-REQ-THR-001-POOL-BOUNDS-DO-NOT-EMIT-ZERO-CHANGE-COMMANDS
ok    TEST-REQ-THR-001-POOL-HOLD-REGION-BREAKS-CONTINUOUS-DWELL
ok    TEST-REQ-THR-001-POOL-DIRECTION-CHANGE-RESTARTS-DWELL
ok    TEST-REQ-THR-001-POOL-LONG-GAP-RESETS-EWMA-AND-DWELL
ok    TEST-REQ-THR-001-POOL-GAP-EXACTLY-TWO-PERIODS-KEEPS-EXISTING-DWELL
ok    TEST-REQ-THR-001-POOL-PENDING-TARGET-IS-RETAINED-AND-SENSORS-ADVANCE
ok    TEST-REQ-THR-001-POOL-FIRST-PENDING-SAMPLE-AND-COMPLETED-COMMAND-DWELL
ok    TEST-REQ-CON-005-POOL-CROSS-THREAD-ACCESS-REJECTED-WITHOUT-OWNER-MUTATION
ok    TEST-REQ-AFF-008-POOL-PRIVATE-BOUND-AND-CLOCK-FAULTS-ARE-DETECTED
ok    TEST-REQ-CON-005-POOL-INDEPENDENT-CONTROLLERS-HAVE-DETERMINISTIC-PARALLEL-TRACES
ok    TEST-REQ-CON-005-POOL-PORT-OWNER-AND-REGISTRY-COORDINATOR-ARE-DISTINCT
ok    TEST-REQ-THR-001-POOL-ACTIVATION-RETIREMENT-AWAIT-REAL-WORKER-ACKS
ok    TEST-REQ-AFF-008-POOL-REGISTRY-COPIES-CALLER-VECTOR-AND-BINDS-ONCE
ok    TEST-REQ-AFF-008-POOL-REGISTRY-INVALID-SHAPE-DOES-NOT-BIND-ANY-PORT
ok    TEST-REQ-CON-001-POOL-RETIREMENT-PRESERVES-CLAIM-LEASE-BATCH-AND-FINISHING
ok    TEST-REQ-CON-002-POOL-RESCHEDULE-OBLIGATION-BLOCKS-RETIREMENT-UNTIL-TRANSFER
ok    TEST-REQ-CON-004-POOL-FAULTED-WORKER-RETAINS-COMMAND-REFERENCE-AND-DIAGNOSTIC
ok    TEST-REQ-AFF-008-POOL-PORT-STARTUP-VALIDATES-FLAGS-COORDINATOR-AND-IDLE-DEBTS
ok    TEST-REQ-AFF-008-POOL-STARTUP-REJECTS-COORDINATOR-AND-REUSED-WORKER-OWNER
ok    TEST-REQ-AFF-008-POOL-STARTUP-REJECTS-NONZERO-OR-PENDING-GENERATION-BEFORE-BINDING
ok    TEST-REQ-AFF-008-POOL-INVALID-SAMPLES-DO-NOT-MUTATE-CONTROLLER-OR-PORTS
ok    TEST-REQ-AFF-008-POOL-GENERATION-EXHAUSTION-PRECEDES-EVERY-CONTROLLER-AND-PORT-WRITE
ok    TEST-REQ-AFF-008-POOL-WORD-PROTOCOL-FAULTS-REFUSE-READER-COORDINATOR-AND-WORKER
ok    TEST-REQ-AFF-008-POOL-IDLE-DEBT-REFUSES-ACK-WITHOUT-POISONING-OR-RESET
ok    TEST-REQ-AFF-008-POOL-PRIVATE-REGISTRY-TARGET-CAPACITY-PREFIX-AND-COUNT-INVARIANTS
ok    TEST-REQ-AFF-008-POOL-CAS-CONFLICT-CANNOT-REPORT-REQUEST-OR-ACK-SUCCESS
ok    TEST-REQ-AFF-008-POOL-GENERATED-PORT-EQUALITY-COMPARES-REQUEST-ACK-AND-BINDING
ok    TEST-REQ-CON-005-POOL-TWO-RETIREMENT-ACKS-CAN-ARRIVE-WITH-A-PREFIX-HOLE
ok    TEST-REQ-CON-005-POOL-INACTIVE-CLAIM-KEEPS-REAL-READY-OBLIGATION-AND-CURSOR
ok    TEST-REQ-THR-001-POOL-REAL-GROW-ACKNOWLEDGES-BEFORE-TAKING-READY-WRITER
ok    TEST-REQ-THR-001-POOL-REAL-SHRINK-RETIRES-BEFORE-REMOVING-READY-WRITER
ok    TEST-REQ-CON-005-POOL-FOREIGN-OWNER-REJECTION-PRECEDES-PHASE-AND-WORD-CHECKS
ok    TEST-REQ-CON-004-POOL-EVERY-NONIDLE-PHASE-REFUSES-BEFORE-INACTIVE-OR-DEBT-VALIDATION
ok    TEST-REQ-AFF-008-POOL-IDLE-INCONSISTENCY-REFUSES-RETIREMENT-ACK-AND-C1-POISONING
ok    TEST-REQ-AFF-008-POOL-CORRUPT-WORD-PROTOCOL-PRESERVES-READY-AND-LOCAL-WORKER
ok    TEST-REQ-AFF-008-POOL-RETIREMENT-ACK-CAS-CONFLICT-CANNOT-TAKE-A-READY-WRITER
ok    TEST-REQ-CON-005-POOL-ACTIVE-EMPTY-AND-BUSY-PRESERVE-C1-CURSOR-ROTATION
ok    TEST-REQ-THR-001-POOL-RETIRE-AFTER-ACTIVE-SAMPLE-PERMITS-ONE-LAST-COMPLETE-TASK
ok    TEST-REQ-CON-002-POOL-PENDING-RETIRE-WAITS-FOR-BRIDGE-BATCH-AND-EXPLICIT-HANDOFF
ok    TEST-REQ-CON-002-POOL-FULL-RECYCLE-KEEPS-CLAIMED-AND-ROUTES-NEW-WRITER-BEFORE-RETIRE
ok    TEST-REQ-AFF-008-POOL-DISPATCH-FACTORY-TYPE-AND-CONTEXT-BINDING-REFUSE-WITHOUT-EFFECTS
ok    TEST-REQ-CON-005-POOL-DISPATCH-FACTORY-REQUIRES-COMPLETE-IDLE-BEFORE-CONSTRUCTION
ok    TEST-REQ-CON-005-POOL-DISPATCH-FOREIGN-OWNER-PRECEDES-TABLE-PHASE-AND-POOL-CHECKS
ok    TEST-REQ-CON-005-POOL-DISPATCH-INACTIVE-EMPTY-BUSY-NEVER-ENTER-ROUTING
ok    TEST-REQ-CON-002-POOL-DISPATCH-ROUTES-TWO-REAL-WRITERS-WITHOUT-IMPLICIT-BEGIN
ok    TEST-REQ-CON-002-POOL-DISPATCH-EXISTING-CLAIMED-ROUTES-WITHOUT-READING-CORRUPT-POOL-WORDS
ok    TEST-REQ-CON-002-POOL-DISPATCH-PENDING-RETIRE-DRAINS-EXISTING-CLAIMED-BEFORE-ACK
ok    TEST-REQ-CON-002-POOL-DISPATCH-FULL-RECYCLE-ROUTES-NEW-CLAIMED-WHILE-RETIRE-PENDING
ok    TEST-REQ-CON-004-POOL-DISPATCH-ALL-DISALLOWED-PHASES-PRESERVE-FIRST-FAULT-AND-DEBTS
ok    TEST-REQ-AFF-008-POOL-DISPATCH-ROUTING-FAULT-RETAINS-ACTIVATION-ACK-AND-ACQUIRED-OBLIGATION
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CORRUPT-TABLE-BINDING-REFUSES-BEFORE-CLAIM-OR-ROUTING
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CORRUPT-LINK-FAULTS-AFTER-CLAIM-WITHOUT-BEGIN-OR-ROLLBACK
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CONTRADICTORY-GATE-OUTPUT-REFUSES-BEFORE-ROUTING
ok    TEST-REQ-CON-002-POOL-DISPATCH-WRITER-BUSY-BEGIN-KEEPS-CLAIMED-FOR-EXPLICIT-RETRY
ok    TEST-REQ-CON-002-POOL-RECYCLE-ROOM-PUBLISHES-ONCE-WITHOUT-SECOND-CLAIM-OR-ROUTING
ok    TEST-REQ-CON-002-POOL-RECYCLE-FULL-ROUTES-NEW-WRITER-WITHOUT-BEGIN-OR-CURSOR-CHANGE
ok    TEST-REQ-CON-004-POOL-RECYCLE-READY-BUSY-PRESERVES-COMPLETE-OBLIGATION-AND-RING
ok    TEST-REQ-CON-005-POOL-RECYCLE-SIX-DISALLOWED-PHASES-PRESERVE-DEBTS-AND-FIRST-FAULT
ok    TEST-REQ-CON-002-POOL-RECYCLE-EXISTING-OBLIGATION-IGNORES-INACTIVE-AND-CORRUPT-WORDS
ok    TEST-REQ-CON-002-POOL-RECYCLE-ROOM-DOES-NOT-ACKNOWLEDGE-PENDING-RETIRE
ok    TEST-REQ-AFF-008-POOL-RECYCLE-BINDING-REFUSES-BEFORE-TRANSFER
ok    TEST-REQ-CON-005-POOL-RECYCLE-FOREIGN-OWNER-PRECEDES-BINDING-AND-POOL-DATA
ok    TEST-REQ-AFF-008-POOL-RECYCLE-ROUTING-FAULT-KEEPS-COMPLETED-FULL-TRANSFER
ok    TEST-REQ-AFF-008-POOL-RECYCLE-CONTRADICTORY-OUTPUT-REFUSES-BEFORE-ROUTING-WITHOUT-C3-FAULT
ok    TEST-REQ-AFF-008-POOL-RECYCLE-INVALID-DISPATCHER-TYPE-HAS-NO-EFFECTS
ok    TEST-REQ-CON-004-POOL-RECYCLE-READY-INVARIANT-PRESERVES-ORIGINAL-C1-FAULT
ok    TEST-REQ-CON-004-POOL-RECYCLE-UNKNOWN-STATUS-REFUSES-AT-RUNTIME-WITHOUT-EFFECTS
ok    TEST-REQ-CON-002-POOL-BEGIN-REAL-ACTIVE-FORWARDS-FOUR-VALUES-WITHOUT-POP
ok    TEST-REQ-CON-002-POOL-BEGIN-FULL-RECYCLE-STARTS-CURRENT-B-INSTEAD-OF-PREVIOUS-A
ok    TEST-REQ-CON-002-POOL-BEGIN-EXISTING-CLAIM-IGNORES-INACTIVE-CORRUPT-AND-RETIRE-WORDS
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-WRITER-BUSY-KEEPS-CLAIMED-AND-BOTH-GENERATIONS
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-SERIE-BUSY-RETURNS-CLOSING-WITH-EXPLICIT-CLOSE
ok    TEST-REQ-AFF-008-POOL-BEGIN-SERIE-GENERATION-LIMIT-RETURNS-TOKEN-AND-EXPLICIT-CLOSE
ok    TEST-REQ-AFF-008-POOL-BEGIN-LOCAL-GENERATION-LIMIT-PRECEDES-WRITER-AND-SERIE-ACQUIRE
ok    TEST-REQ-AFF-008-POOL-BEGIN-BINDING-PRECEDES-ROUTING-AND-ANY-ACQUISITION
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-FOREIGN-OWNER-PRECEDES-BINDING-AND-ACQUISITIONS
ok    TEST-REQ-CON-005-POOL-BEGIN-SIX-WRONG-PHASES-PRESERVE-CAPACITIES-AND-PRIOR-FAULT
ok    TEST-REQ-AFF-008-POOL-BEGIN-ROUTING-FAULT-PRECEDES-BEGIN-AND-PRESERVES-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-POOL-BEGIN-REAL-WRITER-NOT-READY-PROPAGATES-C1-FAULT-EQ
ok    TEST-REQ-AFF-008-POOL-BEGIN-UNEXPECTED-SERIE-ACQUIRE-KEEPS-C1-CAPACITY-AND-CONDITION-EQ
ok    TEST-REQ-AFF-008-POOL-BEGIN-INVALID-DISPATCHER-TYPE-PRESERVES-FIXTURE
ok    TEST-REQ-CON-002-POOL-STEP-IDLE-ACTIVATES-BEFORE-CLAIM-AND-FORWARDS-ORIGINAL-CURSOR
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-EMPTY-ROTATES-ONCE-WITHOUT-IMPLICIT-SECOND-ATTEMPT
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-REAL-READY-BUSY-FORWARDS-STATUS-WITHOUT-RETRY
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-INACTIVE-KEEPS-READY-AND-CURSOR-WITHOUT-SCAN
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-PENDING-RETIRE-ACKNOWLEDGES-BEFORE-READY-ACCESS
ok    TEST-REQ-CON-002-POOL-STEP-CURRENT-IGNORES-INACTIVE-CORRUPT-AND-RETIRE-WORDS
ok    TEST-REQ-CON-002-POOL-STEP-ROOM-PUBLISHES-AND-RETURNS-WITHOUT-FALL-THROUGH-OR-ACK
ok    TEST-REQ-CON-002-POOL-STEP-FULL-ROUTES-B-ONCE-AND-NEXT-STEP-IS-CURRENT
ok    TEST-REQ-CON-004-POOL-STEP-RESCHEDULE-READY-BUSY-PRESERVES-OBLIGATION-WITHOUT-RETRY
ok    TEST-REQ-CON-004-POOL-STEP-RUNNING-BATCH-FINISHING-AND-FAULTED-REFUSE-BEFORE-DELEGATION
ok    TEST-REQ-AFF-008-POOL-STEP-BINDING-PRECEDES-PHASE-AND-ANY-OPERATIONAL-ENTRY
ok    TEST-REQ-CON-005-POOL-STEP-FOREIGN-OWNER-PRECEDES-BINDING-PHASE-AND-POOL-WORDS
ok    TEST-REQ-AFF-008-POOL-STEP-FULL-ROUTING-FAULT-KEEPS-TRANSFER-AND-FIRST-CONDITION-EQ
ok    TEST-REQ-AFF-008-POOL-STEP-CLAIM-ROUTING-FAULT-KEEPS-SUCCESSFUL-ACTIVATION-ACK
ok    TEST-REQ-CON-004-POOL-STEP-GETTER-FI-OUTSIDE-TYPE-REFUSES-BEFORE-DELEGATION
ok    TEST-REQ-AFF-008-POOL-STEP-INVALID-DISPATCHER-TYPE-KEEPS-FIXTURE
  pool-chain: A :RUNNING, B 32 quantum conclusi prima della release A.
  pool-chain: A :BATCH, B 32 quantum conclusi prima della release A.
ok    TEST-REQ-CON-002-POOL-CHAIN-OTHER-SERIES-COMPLETES-BEFORE-HELD-LEASE-AND-BATCH-RELEASE
  pool-chain: capacity 1, home 0, FULL, ritiro e handoff conclusi.
  pool-chain: capacity 1, home 2, FULL, ritiro e handoff conclusi.
  pool-chain: capacity 2, home 0, ROOM, ritiro e handoff conclusi.
  pool-chain: capacity 2, home 2, ROOM, ritiro e handoff conclusi.
ok    TEST-REQ-THR-001-POOL-CHAIN-FULL-ROOM-RETIREMENT-AND-CROSS-WORKER-READY-HANDOFF
ok    TEST-REQ-CON-002-POOL-START-ACTIVATION-CLAIM-AND-ONE-BEGIN-WITH-ORIGINAL-METADATA
ok    TEST-REQ-CON-005-POOL-START-EMPTY-BUSY-INACTIVE-NEVER-ROUTE-OR-BEGIN
ok    TEST-REQ-CON-002-POOL-START-CURRENT-PRIORITIZES-OBLIGATION-OVER-INACTIVE-OR-RETIREMENT
ok    TEST-REQ-CON-002-POOL-START-FULL-BEGINS-NEW-WRITER-AND-PRESERVES-PENDING-RETIREMENT
ok    TEST-REQ-CON-002-POOL-START-ROOM-STOPS-AFTER-PUBLICATION-WITHOUT-SECOND-CLAIM-OR-ACK
ok    TEST-REQ-CON-004-POOL-START-WRITER-BUSY-PRESERVES-CLAIMED-AND-CONSUMES-NO-TOKEN
ok    TEST-REQ-CON-004-POOL-START-WRITER-BUSY-AFTER-CLAIM-KEEPS-TRANSFER-AND-ACTIVATION-ACK
ok    TEST-REQ-AFF-008-POOL-START-ROUTING-FAULT-AFTER-CLAIM-NEVER-BEGINS-OR-ROLLS-BACK-ACK
ok    TEST-REQ-CON-004-POOL-START-READY-BUSY-KEEPS-RESCHEDULE-AND-RING
ok    TEST-REQ-AFF-008-POOL-START-SERIE-BUSY-OR-GENERATION-EXHAUSTED-RETURNS-LIVE-CLOSING-TOKEN
ok    TEST-REQ-AFF-008-POOL-START-LOCAL-GENERATION-LIMIT-BEFORE-EITHER-LEASE
ok    TEST-REQ-CON-005-POOL-START-ACTIVE-BATCH-FINISHING-AND-FAULTED-REFUSE-WITHOUT-EFFECTS
ok    TEST-REQ-AFF-008-POOL-START-BINDING-BEFORE-SELECTION-OR-ACQUISITION
ok    TEST-REQ-CON-005-POOL-START-REAL-FOREIGN-OWNER-REFUSES-BEFORE-ROUTING
ok    TEST-REQ-AFF-008-POOL-START-DEFENSIVE-STATUS-AND-LINK-PAIRS-ARE-OPERATIONAL
ok    TEST-REQ-AFF-008-POOL-START-UNEXPECTED-ACQUIRE-KEEPS-FIRST-C1-CAUSE-AND-WRITER-LEASE
ok    TEST-REQ-AFF-008-POOL-START-INVALID-DISPATCHER-IS-TYPED-AND-DOES-NOT-TOUCH-FIXTURE
129 test del controllore pool superati.
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-INDEPENDENT-ORACLE
ok    TEST-REQ-FOR-001-SEGMENT-HEADER-ALL-TRUNCATIONS-AND-BIT-FLIPS
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-CRC-VALID-INVALID-FIELDS
ok    TEST-REQ-AFF-002-SEGMENT-HEADER-IDENTITY
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-PREFLIGHT-PRESERVES-BUFFER
ok    TEST-REQ-FOR-002-LOG-HEADER-INDEPENDENT-ORACLE
ok    TEST-REQ-FOR-002-LOG-HEADER-DEFAULT-VERSION-IS-TWO
ok    TEST-REQ-FOR-001-LOG-HEADER-ALL-TRUNCATIONS
ok    TEST-REQ-FOR-001-LOG-HEADER-ALL-BIT-FLIPS
ok    TEST-REQ-FOR-002-LOG-HEADER-EVERY-RESERVED-BYTE
ok    TEST-REQ-FOR-002-LOG-HEADER-EVERY-IDENTITY-BYTE
ok    TEST-REQ-FOR-002-LOG-HEADER-CRC-VALID-WRONG-MAGIC
ok    TEST-REQ-FOR-002-LOG-HEADER-UNKNOWN-VERSION-WITH-VALID-CRC
ok    TEST-REQ-FOR-001-LOG-HEADER-CRC-BEFORE-UNKNOWN-VERSION
ok    TEST-REQ-FOR-002-LOG-HEADER-ENCODER-PREFLIGHT-PRESERVES-BUFFER
ok    TEST-REQ-FOR-002-LOG-HEADER-READER-PREFLIGHT
ok    TEST-REQ-FOR-002-COMPACTION-EMPTY-HEADERS
ok    TEST-REQ-CMP-009-COMPACTION-RESOLVED-RECORDS-AND-COUNTS
ok    TEST-REQ-FOR-002-COMPACTION-VERSION-FROM-FILE
ok    TEST-REQ-FOR-003-COMPACTION-EVERY-CONTENT-TRUNCATION
ok    TEST-REQ-FOR-001-COMPACTION-EVERY-BIT-CORRUPTION
ok    TEST-REQ-FOR-002-COMPACTION-AUTHORITATIVE-IDENTITIES
ok    TEST-REQ-FOR-002-COMPACTION-HEADER-FIELDS-AND-VERSION
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-WRITER-ORIGIN
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-PREPARED-RECORDS
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-CONTROL-RECORDS
ok    TEST-REQ-FOR-003-COMPACTION-CRC-VALID-INVALID-TYPE-AND-FLAGS
ok    TEST-REQ-FOR-003-COMPACTION-CRC-VALID-INCONSISTENT-LENGTHS
ok    TEST-REQ-FOR-001-COMPACTION-IGNORES-PHYSICAL-TAIL
ok    TEST-REQ-AFF-008-COMPACTION-EXACT-AND-EXHAUSTED-BUDGETS
ok    TEST-REQ-AFF-008-COMPACTION-INVALID-ARGUMENTS
ok    TEST-REQ-FOR-003-EDIT-ENCODING-LAYOUT
ok    TEST-REQ-FOR-003-EDIT-TRUNCATION-COUNTS-AND-LENGTHS
ok    TEST-REQ-AFF-008-EDIT-BUDGET-BOUNDARIES
ok    TEST-REQ-TXM-001-DECISION-ENCODING-LAYOUT
ok    TEST-REQ-TXM-001-DECISION-TRUNCATION-AND-BUDGETS
ok    TEST-REQ-FOR-003-CONTROL-RECORD-BOTH-VERSIONS
ok    TEST-REQ-FOR-003-CONTROL-RECORD-INTEGRITY-BEFORE-COUNTS
ok    TEST-REQ-AFF-008-ENCODER-PREFLIGHT-NO-PARTIAL-WRITE
ok    TEST-REQ-AFF-008-EDIT-CUMULATIVE-BUDGET-AND-CORRUPT-HUGE-COUNTS
ok    TEST-REQ-AFF-008-ENCODER-OVERFLOW-AND-UNUSED-SECTIONS
ok    TEST-REQ-FOR-003-DECISION-RECORD-ALL-TRUNCATIONS-AND-BIT-FLIPS
ok    TEST-REQ-AFF-008-BYTE-BUDGET-BEFORE-CRC-SCAN
ok    TEST-REQ-AFF-008-INTERNAL-RANGE-GUARDS
44 test dei metadati storage superati.
ok    TEST-REQ-AFF-001-SHORT-APPEND-AND-GROUP-FLUSH
ok    TEST-REQ-STO-003-SHORT-PREAD-POSITIONAL-NO-STATE-WRITE
ok    TEST-REQ-AFF-001-WRITE-ERRORS-NEVER-RETRY
ok    TEST-REQ-AFF-001-FLUSH-ERROR-PRESERVES-DURABLE-FRONTIER
ok    TEST-REQ-AFF-002-READ-ERRORS-NO-RETRY-NO-SHARED-MUTATION
ok    TEST-REQ-AFF-008-INVALID-PROGRESS-AND-EOF
ok    TEST-REQ-AFF-008-PREFLIGHT-BUDGET-AND-ZERO-LENGTH
ok    TEST-REQ-AFF-001-CLOSE-ONCE-EVEN-EINTR
ok    TEST-REQ-AFF-001-DIRECTORY-FLUSH-DISPATCH-AND-INVALID-RETURN
ok    TEST-REQ-STO-003-OPEN-PREFLIGHT-AND-ERRORS
ok    TEST-REQ-AFF-001-DIRECTORY-FAILURE-AND-EMPTY-FILE-FLUSH
ok    TEST-REQ-AFF-001-INVALID-CLOSE-RESULT-AND-CLOSED-READER
ok    TEST-REQ-AFF-004-INVALID-PRIVATE-DESCRIPTOR-BEFORE-SYSCALL
ok    TEST-REQ-STO-003-NATIVE-APPEND-FLUSH-AND-CHECKED-RECORD
ok    TEST-REQ-STO-003-NATIVE-NO-FOLLOW-FILE-KINDS-AND-CLOEXEC
ok    TEST-REQ-STO-003-CONCURRENT-PREAD-DISTINCT-BUFFERS
ok    TEST-REQ-FOR-003-NATIVE-TWO-SEALED-BATCHES-ONE-FLUSH
ok    TEST-REQ-AFF-004-NATIVE-ERRNO-AND-CLEANUP-PROVENANCE
ok    TEST-REQ-IPC-002-READINESS-DOMAINS-AND-BORROWED-FD-ZERO
ok    TEST-REQ-IPC-002-READINESS-TIMEOUT-INTERRUPTION-AND-FAULTS
ok    TEST-REQ-IPC-002-READINESS-FLAGS-COUNTS-AND-RESET
ok    TEST-REQ-IPC-002-READINESS-REAL-PIPE-INPUT-OUTPUT-AND-HUP
ok    TEST-REQ-IPC-002-READINESS-OWNER-REENTRY-AND-NONLOCAL-CLEANUP
ok    TEST-REQ-REC-001-IO-RENAME-MINIMUM-SOURCE-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MINIMUM-DESTINATION-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MAXIMUM-SOURCE-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MAXIMUM-DESTINATION-NAME
ok    TEST-REQ-REC-001-IO-RENAME-BOTH-NAME-BOUNDARIES
ok    TEST-REQ-REC-001-IO-RENAME-ALL-PERMITTED-ASCII
ok    TEST-REQ-REC-001-IO-RENAME-NAMES-WITH-DOTS-AND-BACKSLASH
ok    TEST-REQ-REC-001-IO-RENAME-CASE-SENSITIVE-NAMES
ok    TEST-REQ-REC-001-IO-RENAME-STRING-FILL-POINTER
ok    TEST-REQ-REC-001-IO-RENAME-ADJUSTABLE-STRINGS-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-DISPLACED-STRINGS-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-DISPLACED-ADJUSTABLE-FILL-POINTER-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-PRIVATE-COPIES-BEFORE-CALLBACK-EFFECT
ok    TEST-REQ-AFF-004-IO-RENAME-NON-STRING-NAMES
ok    TEST-REQ-REC-001-IO-RENAME-EMPTY-NAME
ok    TEST-REQ-REC-001-IO-RENAME-NAME-OVER-MAXIMUM
ok    TEST-REQ-REC-001-IO-RENAME-NUL-NAME
ok    TEST-REQ-REC-001-IO-RENAME-SLASH-NAME
ok    TEST-REQ-REC-001-IO-RENAME-DOT-NAME
ok    TEST-REQ-REC-001-IO-RENAME-DOTDOT-NAME
ok    TEST-REQ-REC-001-IO-RENAME-NON-ASCII-NAME
ok    TEST-REQ-REC-001-IO-RENAME-FORBIDDEN-LAST-CHARACTER-AT-MAXIMUM-LENGTH
ok    TEST-REQ-REC-001-IO-RENAME-SAME-NAME-SAME-STRING
ok    TEST-REQ-REC-001-IO-RENAME-SAME-NAME-DISTINCT-STRINGS
ok    TEST-REQ-AFF-004-IO-RENAME-INPUT-CAPABILITY
ok    TEST-REQ-AFF-004-IO-RENAME-APPEND-CAPABILITY
ok    TEST-REQ-AFF-004-IO-RENAME-CLOSED-DIRECTORY
ok    TEST-REQ-AFF-004-IO-RENAME-FAULTED-DIRECTORY
ok    TEST-REQ-AFF-004-IO-RENAME-INVALID-PRIVATE-DESCRIPTOR
ok    TEST-REQ-AFF-004-IO-RENAME-BACKEND-KEYWORD-OMITTED
ok    TEST-REQ-AFF-004-IO-RENAME-BACKEND-CALLBACK-NIL
ok    TEST-REQ-REC-001-IO-RENAME-BACKEND-CALLBACK-PRESENT-SINGLE-CALL
ok    TEST-REQ-REC-001-IO-RENAME-DIRECTORY-DESCRIPTOR-BOUNDARIES
ok    TEST-REQ-AFF-001-IO-RENAME-FLUSH-IS-SEPARATE
ok    TEST-REQ-AFF-001-IO-RENAME-ENOENT-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-EIO-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-EINTR-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-NIL-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-POSITIVE-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-NEGATIVE-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-NON-INTEGER-ZERO-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-RETURN-ONE-KEEPS-CLOSED
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-EIO-KEEPS-CLOSED
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-ZERO-KEEPS-CLOSED
ok    TEST-REQ-AFF-004-IO-RENAME-ORIGINAL-TYPED-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-IO-RENAME-ORIGINAL-FOREIGN-CONDITION-PRESERVED
ok    TEST-REQ-AFF-001-IO-RENAME-CONDITION-DURING-CALLBACK-RETURN
ok    TEST-REQ-AFF-001-IO-RENAME-SYSCALL-ERROR-DURING-CALLBACK-RETURN
ok    TEST-REQ-AFF-001-IO-RENAME-NONLOCAL-EXIT-CLEANUP-FAULTS-BEFORE-CALLER-CLEANUP
ok    TEST-REQ-AFF-001-IO-RENAME-HANDLER-NONLOCAL-EXIT-CLEANUP-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-LOCAL-INTERRUPT-PROBE-CLEANUP-BOUNDARIES
ok    TEST-REQ-AFF-001-IO-RENAME-LOCAL-INTERRUPT-PROBE-FAILURE-SIGNAL
ok    TEST-REQ-AFF-004-IO-RENAME-RESULT-HANDLER-CONDITION-PRESERVED
ok    TEST-REQ-REC-001-IO-RENAME-POSTCHECKER-NIL-SUCCESS
ok    TEST-REQ-AFF-001-IO-RENAME-POSTCHECKER-NON-NIL-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-POSTCHECKER-INCOMPLETE-EXIT-FAULTS
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-REPLACEMENT-KEEPS-OLD-INODE-AND-APPEND
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-FSYNC-DIRECTORY-IS-EXPLICIT
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-PARENT-MOVE-KEEPS-FD-NAMESPACE-AND-CWD
ok    TEST-REQ-AFF-004-IO-RENAME-NATIVE-MISSING-SOURCE-PRESERVES-TARGET-AND-FAULTS
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-INVALID-NAMES-PRECEDE-SYSCALL
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-NAME-LENGTH-BOUNDARIES
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-ADJUSTABLE-DISPLACED-FILLPOINTER-NAMES
ok    TEST-REQ-CON-004-IO-RENAME-NATIVE-FOUR-INDEPENDENT-WORKERS-BOUNDED-ROUNDS
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-VERIFIED-DISTINCT-INODES-AND-SEPARATE-FSYNC
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-VERIFIED-FD-NAME-MISMATCHES-BEFORE-RENAME
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-VERIFIED-HARDLINK-ALIAS-BEFORE-RENAME
ok    TEST-REQ-AFF-004-IO-RENAME-NATIVE-VERIFIED-EXIT-AFTER-EFFECT-FAULTS-WITHOUT-ROLLBACK
ok    TEST-REQ-AFF-001-FLUSH-GUARD-SUCCESS
ok    TEST-REQ-AFF-004-FLUSH-GUARD-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-004-FLUSH-GUARD-NONLOCAL-EXIT
ok    TEST-REQ-AFF-008-FLUSH-GUARD-INVALID-RESULTS
ok    TEST-REQ-AFF-001-FLUSH-GUARD-ERRNO-NO-RETRY
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-SUCCESS-REJECTED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-ERRNO-PRESERVED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-INVALID-RESULT-PRESERVED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-FLUSH-GUARD-WRITTEN-MUTATED
ok    TEST-REQ-AFF-008-FLUSH-GUARD-PREFLIGHT-CLOSED
ok    TEST-REQ-AFF-008-FLUSH-GUARD-PREFLIGHT-INPUT
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-ORIGINAL-WRITE-CONDITION
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-NONLOCAL-WRITE
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-PROGRESS
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-ERRNO
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-INVALID-RESULT
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-TRANSFER-GUARD-WRITTEN-MUTATED
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-READ-PROGRESS
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-NONLOCAL-READ-REMAINS-READONLY
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-OWNED-INPUT-EOF-AND-EXACT-IDENTITIES
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ZERO-AND-INDEX-EOF-BOUNDARIES
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ALL-CALLBACKS-REQUIRED-NO-LEGACY-FALLBACK
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-INVALID-BUDGETS-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ASCII-NAME-BOUNDS-AND-PRIVATE-COPY
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-PARENT-MODE-AND-LIFECYCLE-PREFLIGHT
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-INVALID-CHILD-FD-AND-PARENT-ALIAS-NOT-CLOSED
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-METADATA-SHAPE-AND-SIZE-BUDGET
ok    TEST-REQ-FOR-001-IO-OPEN-RELATIVE-ENTRY-IDENTITY-MISMATCH-AND-INVALID-RESULT
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-PARENT-CLOSED-IN-EACH-CALLBACK
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-CALLBACK-CONDITIONS-AND-SYSCALL-PROVENANCE
ok    TEST-REQ-AFF-004-IO-OPEN-RELATIVE-CLEANUP-FAILURE-KEEPS-PRIMARY-FIELDS-NO-RETRY
ok    TEST-REQ-AFF-004-IO-OPEN-RELATIVE-NONLOCAL-EXIT-CLEANS-CHILD-BEFORE-CALLER
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-READ-EOF-FLAGS-AND-PRESERVED-WRITER
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-EMPTY-FILE-ZERO-BUDGET
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-SPARSE-U64-EOF-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-NO-FOLLOW-FILE-KINDS-AND-MISSING
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-PARENT-MOVE-IGNORES-REPLACEMENT-DECOY
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-REPEAT-CLOSE-OWNS-ONLY-CHILD
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-OWNED-APPEND-FD-ZERO-AND-EXACT-IDENTITIES
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-POSITIVE-BUDGET-BOUNDS-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-ALL-CALLBACKS-REQUIRED-NO-LEGACY-FALLBACK
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-TMP-LEAF-BOUNDS-AND-PRIVATE-COPY
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-PARENT-MODE-AND-LIFECYCLE-PREFLIGHT
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-INVALID-CHILD-FD-AND-PARENT-ALIAS-NOT-CLOSED
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-METADATA-SHAPE-EMPTY-AND-SIZE-BUDGET
ok    TEST-REQ-FOR-001-IO-CREATE-RELATIVE-ENTRY-IDENTITY-MISMATCH-AND-INVALID-RESULT
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-PARENT-CLOSED-IN-EACH-CALLBACK
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-CALLBACK-CONDITIONS-PRESERVE-PRIMARY
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-SYSCALL-PROVENANCE-AT-EACH-STAGE
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-CLEANUP-FAILURE-KEEPS-PRIMARY-FIELDS-NO-RETRY
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-NONLOCAL-EXIT-CLEANS-CHILD-BEFORE-CALLER
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-APPEND-FLAGS-PERMISSIONS-AND-READONLY-IDENTITY
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-NATIVE-COLLISIONS-PRESERVE-FILE-FIFO-DIRECTORY-AND-SYMLINK
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-PARENT-MOVE-IGNORES-REPLACEMENT-DECOY
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-REPEATED-CLOSE-AND-DESCRIPTOR-REUSE
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-NATIVE-POSTCREATE-VALIDATION-FAILURE-KEEPS-ORPHAN
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-SUCCESS-EXACT-FD-AND-CLOSE-ONCE
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-BUSY-PRESERVES-PARENT-NO-RETRY
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-ERRNO-PROVENANCE-WITHOUT-RETRY
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-REJECTS-EVERY-NONZERO-OR-NONINTEGER-RESULT
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-MISSING-CALLBACK-NO-NATIVE-FALLBACK
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-WRONG-MODE-BEFORE-CALLBACK-OR-SUPPORT-CHECK
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-CLOSED-OR-FAULTED-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-INVALID-FD-BEFORE-CALLBACK
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-CALLBACK-INVALIDATES-PARENT-NO-SUCCESS
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-PRESERVES-TYPED-CALLBACK-CONDITION
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-NATIVE-TWO-OPENS-BUSY-CLOSE-REACQUIRE
160 test I/O superati.
ok    TEST-REQ-FOR-001-CONTROL-CANONICAL-ACTIVE-AND-CHECKPOINT-V1-V2
ok    TEST-REQ-REC-001-CONTROL-MANIFEST-COMPLETE-STATE
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-COPIES-CALLER-PAYLOAD
ok    TEST-REQ-REC-001-CONTROL-PREPARE-CHUNKS-ORDER-AND-SHORT-LAST-BLOCK
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-ONE-BYTE-AND-OVERSIZED-CHUNKS
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-POSITIVE-SHORT-IO
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-SUCCESS-ACCESSORS-AND-RETRY
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-PAYLOAD-AND-BUDGET-PREFLIGHT
ok    TEST-REQ-REC-001-CONTROL-BUILDER-REJECTS-OTHER-ACTIVE
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-MANIFEST-CUMULATIVE-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-SHORT-SCRATCH
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-THREE-SCRATCH-ALIASES
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-READ-TRANSFER-BUDGET
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-WRITE-TRANSFER-AND-TOTAL-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-STARTED-APPEND
ok    TEST-REQ-REC-001-CONTROL-PREPARE-REJECTS-PHYSICAL-ACTIVE-ALIAS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-BACKEND-MISMATCH
ok    TEST-REQ-AFF-002-CONTROL-PREPARE-READBACK-FIRST-MIDDLE-LAST-AND-BOUNDARY
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-FILE-FLUSH-FAILURE
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-TYPED-ERROR-AFTER-BYTE
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-NONLOCAL-AFTER-BYTE
ok    TEST-REQ-AFF-008-CONTROL-PUBLICATION-MISSING-ENTRY-AND-RENAME-CALLBACKS
ok    TEST-REQ-AFF-008-CONTROL-REPLACEMENT-PREFLIGHT-MISSING-IDENTITY
ok    TEST-REQ-AFF-008-CONTROL-PUBLICATION-PREVIOUS-MODE-AND-BACKEND
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CLOSED-CAPABILITIES
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-LOG-HEALTH-PREFLIGHT
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CHECKPOINT-WRITTEN-AND-DURABLE-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-ACTIVE-WRITTEN-AND-DURABLE-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-REAL-ACTIVE-ADVANCE-BEFORE-CLAIM
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ORIGINAL-ERROR-AT-EACH-FD-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ORIGINAL-ERROR-AT-EACH-ENTRY-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ERRNO-OPERATION-AND-NO-RETRY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-INVALID-FD-IDENTITY-COMPONENTS
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-INVALID-ENTRY-IDENTITY-COMPONENTS
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-ENTRY-DEVICE-OR-INODE-MISMATCH-AT-EACH-STEP
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-SOURCE-TARGET-PHYSICAL-ALIAS
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-IDENTITIES-DISTINCT-IN-EITHER-COMPONENT
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-RENAME-NONZERO-OR-INVALID-RESULT
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-RENAME-ORIGINAL-TYPED-AND-FOREIGN-ERRORS
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-NONLOCAL-IDENTITY-ENTRY-AND-RENAME
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FLUSH-NONZERO
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-DIRECTORY-FLUSH-ORIGINAL-TYPED-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FLUSH-NONLOCAL
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-CALLBACK-CLOSES-AND-RETURNS-ZERO
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-RENAME-CALLBACK-CLOSES-AND-RETURNS-ZERO
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-CLOSE-THEN-ORIGINAL-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-ADVANCES-ACTIVE-POSTCONDITION
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-ADVANCES-CHECKPOINT-POSTCONDITION
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-CLOSES-PREVIOUS-POSTCONDITION
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-UNCAUGHT-REENTRANCY-PRESERVES-ORIGINAL
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-HANDLED-REENTRANCY-WINNER-PRESERVED
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FRONTIER-MUTATED-IN-CALLBACK
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CLOSED-CHECKPOINT-AFTER-FLUSH
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-MISSING-SOURCE-OR-TARGET-ENTRY
ok    TEST-REQ-AFF-004-CONTROL-PREPARE-DIRECTORY-FLUSH-ORIGINAL-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-DIRECTORY-FLUSH-NONLOCAL
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-CLOSE-STOPS-SHORT-IO
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-CAS-LOSER-DOES-NOT-FAULT-WINNER
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-ERROR-PRESERVES-KNOWN-SHORT-PROGRESS
ok    TEST-REQ-AFF-004-CONTROL-PREPARE-ORIGINAL-ERROR-AT-EACH-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-ACTIVE-PREPARATION-ORIGINAL-ERROR-AT-EACH-IDENTITY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-SUCCESS-V1-REAL-RECOVERY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-SUCCESS-V2-REAL-RECOVERY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-MOVED-PARENT-FD-ANCHORED-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-SOURCE-SYMLINK-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-TARGET-SYMLINK-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-SOURCE-NAME-MISMATCH-IDENTICAL-BYTES
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-WRONG-PREVIOUS-OTHER-INODE-IDENTICAL-BYTES
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-HARDLINK-ALIAS-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-BACKEND-MISMATCH-PREFLIGHT-KEEPS-PREPARED
ok    TEST-REQ-AFF-004-CONTROL-NATIVE-FSYNC-FAILURE-AFTER-RENAME-NO-WRAPPER-READABLE-FILE
ok    TEST-REQ-CON-004-CONTROL-NATIVE-FOUR-WORKERS-FOUR-ROUNDS-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-TIMEOUT-IS-TYPED-SEPARATE-FROM-ASSERT
ok    TEST-REQ-FOR-001-CONTROL-RECOVERY-BITWISE-FIXTURE-ORACLE
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-V1-PUBLIC-DEFAULTS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-V2-PUBLIC-DEFAULTS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-CHUNKS-SHORTREADS-ALL-OFFSETS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-OWNED-MANIFEST-SCRATCH-REUSED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-SIZE-BELOW-HEADER
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-BUDGET-BELOW-HEADER
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-CRV-D01-EXACT-HEADER-NO-SNAPSHOT
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-ALIAS-BEFORE-BUFFER-RANGE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-SHORT-SCRATCH-NO-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-TRANSFER-BUDGET-MIN-SIZE-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-WRONG-CAPABILITY-MODE
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSED-INPUT-PREFLIGHT
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-INVALID-SCANNER-BUDGETS-BEFORE-READ
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-OUT-OF-TYPE-BUDGETS-BEFORE-READ
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-EXACT-BYTE-BUDGET-AND-EXHAUSTION
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-BATCH-BUDGET-NOT-CONVERTED-TO-TAIL
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-RECORD-BUDGET-EXACT-AND-EXHAUSTED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-EDIT-BUDGET-EXACT-AND-EXHAUSTED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-SEGMENT-OCCURRENCES-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-OUTCOME-OCCURRENCES-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PER-EDIT-CLOSED-REMOVED-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-ZERO-OUTCOMES-VALID-ZERO-SEGMENTS-EXHAUSTED
ok    TEST-REQ-AFF-009-CONTROL-RECOVERY-DURABLE-WITNESS-BEYOND-FIRST-BAD-RECORD
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-GENUINE-TAIL-EVERY-CUT-AFTER-VALID-PREFIX
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-SEALED-SEMANTIC-ERRORS-NEVER-TAIL
ok    TEST-REQ-FOR-001-CONTROL-RECOVERY-HEADER-CRC-AND-VALIDATION-ORDER
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-INVALID-MAGIC-VALID-CRC
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-EVERY-UUID-BYTE-VALID-CRC
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-EVERY-RESERVED-BYTE-VALID-CRC
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-UNSUPPORTED-HEADER-FORMAT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-PHYSICAL-EOF-EVERY-SHORTREAD-CUT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-ORIGINAL-IO-CONDITION-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-ORIGINAL-FOREIGN-CONDITION-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-NONLOCAL-VALUES-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-SYSCALL-ERROR-PROGRESS-NO-RETRY
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-INVALID-READER-PROGRESS
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSE-DURING-READ-NO-RESULT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-PREFIX-BEFORE-HEADER-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-PREFIX-BEYOND-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-COMPLETE-BEFORE-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-TAIL-AT-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-PREFLIGHT-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-READ-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-HEADER-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSE-AFTER-REPLAY-OUTSIDE-CONTRACT
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-PUBLICATION-SUCCESS-V1-REAL-INODES-FRONTIERS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-PUBLICATION-SUCCESS-V2-REAL-INODES-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-READONLY-CAPABILITY-EXACT-NO-APPEND-SUBSTITUTION
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-SAME-UUID-DIFFERENT-VIEW-PRECLAIM-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-DIFFERENT-UUID-VIEW-PRECLAIM-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-INVALID-TRANSITION-NO-EFFECTS-TOKEN-USABLE
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-CLOSED-EXACT-OLD-INPUT-PRECLAIM-ALIAS-VALID-RETRY
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-FAULTED-EXACT-OLD-INPUT-PRECLAIM-ALIAS-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-FALSE-ASSOCIATION-RENAME-BINDING-STILL-GUARDS
ok    TEST-REQ-AFF-017-CONTROL-RECOVERY-PUBLICATION-OLD-TAIL-AUTHORITATIVE-STABLE-EOF-ALLOWED
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-DIRECTORY-SYSCALL-FAULT-NO-WRAPPER
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-ORIGINAL-DIRECTORY-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-NONLOCAL-VALUES-PRESERVED
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-RECOVERY-RESULT-USED-TWICE-TOKEN-CONSUMED
ok    TEST-REQ-CON-004-CONTROL-RECOVERY-PUBLICATION-INDEPENDENT-FOUR-WORKERS-TWO-ROUNDS-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PRIVATE-READ-REJECTS-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PRIVATE-CONSTRUCTOR-REJECTS-EACH-INVALID-FIELD
138 test CONTROL superati.
ok    TEST-REQ-FOR-003-VALID-LOG-ORACLE-AND-DETERMINISM
ok    TEST-REQ-FOR-003-EMPTY-LOG-AND-EMPTY-BATCHES
ok    TEST-REQ-AFF-009-EVERY-LOG-TRUNCATION
ok    TEST-REQ-AFF-009-FRONTIER-BOUNDARY-AND-FAILED-BATCH-START
ok    TEST-REQ-AFF-009-DAMAGED-WITNESS-BATCH-REMAINS-EVIDENCE
ok    TEST-REQ-AFF-009-INVALID-WITNESSES-ARE-IGNORED
ok    TEST-REQ-AFF-009-CORRUPT-LENGTH-CANNOT-HIDE-WITNESS
ok    TEST-REQ-AFF-009-BROKEN-HEADER-DOES-NOT-END-SEARCH
ok    TEST-REQ-AFF-009-WITNESS-AT-EVERY-ALIGNMENT
ok    TEST-REQ-AFF-009-NESTED-SEAL-AT-LAST-SEARCH-POSITION
ok    TEST-REQ-AFF-008-LOG-AND-BATCH-BUDGETS
ok    TEST-REQ-AFF-008-BATCH-BUDGET-CANNOT-CLASSIFY-UNCHECKED-TAIL
ok    TEST-REQ-AFF-008-SEARCH-BUDGET-COUNTS-POSITIONS
ok    TEST-REQ-AFF-008-EOF-IS-EXPLICIT-AND-COMPLETE
ok    TEST-REQ-AFF-008-INVALID-CONFIGURATION-IS-NEVER-TAIL
ok    TEST-REQ-AFF-009-U64-OFFSETS-AND-OVERFLOW
13504 mutazioni bit prima del testimone durevole verificate.
ok    TEST-REQ-AFF-009-EVERY-BIT-BEFORE-DURABLE-WITNESS
6752 mutazioni bit nel lotto finale senza testimone verificate.
ok    TEST-REQ-AFF-017-EVERY-BIT-IN-FINAL-UNWITNESSED-BATCH
ok    TEST-REQ-AFF-009-OVERLAPPING-SEAL-AFTER-NONCOVERING-FRONTIER
ok    TEST-REQ-TXM-005-DECISION-TABLE-ORDERED-UNORDERED-ORACLE
ok    TEST-REQ-TXM-005-SEEDED-HISTORIES-AND-PERMUTED-DUPLICATES
ok    TEST-REQ-TXM-001-ZERO-MAXIMUM-U64-AND-SHARED-CSN
ok    TEST-REQ-TXM-005-TABLE-OWNS-PARTICIPANT-COPIES
ok    TEST-REQ-TXM-001-PARTICIPANT-EXACT-BYTES-AND-QUERY-RANGES
ok    TEST-REQ-TXM-005-CONFLICTING-CSN-SET-OR-COUNT
ok    TEST-REQ-TXM-005-DUPLICATE-PARTICIPANTS-WITHIN-RECORD
ok    TEST-REQ-TXM-005-EVERY-CUT-KEEPS-ONLY-SEALED-DECISIONS
ok    TEST-REQ-TXM-005-PRESUMED-ABORT-AFTER-COMPLETE-TAIL-SEARCH
ok    TEST-REQ-TXM-005-SCANS-LATER-CORRUPTION-BEFORE-PAYLOAD-OR-BUDGET
ok    TEST-REQ-FOR-003-SEALED-INVALID-DECISION-PAYLOAD-IS-NOT-TAIL
ok    TEST-REQ-AFF-008-EMPTY-DECISIONS-ZERO-AND-LARGE-BUDGETS
ok    TEST-REQ-AFF-008-PHYSICAL-DUPLICATE-RECORD-BUDGETS
ok    TEST-REQ-AFF-008-INVALID-DECISION-BUDGETS-EVEN-EMPTY
ok    TEST-REQ-AFF-008-DECISION-SCANNER-BUDGETS-PROPAGATE
ok    TEST-REQ-AFF-008-DECISION-EOF-AND-VERSION-ERRORS
ok    TEST-REQ-TXM-005-HIGH-FILE-OFFSET-AND-CONFLICT-PROVENANCE
ok    TEST-REQ-TXM-005-FIRST-PHYSICAL-DECISION-CONFLICT-ACROSS-TXID-GROUPS
ok    TEST-REQ-TXM-001-PARTICIPANT-EVERY-BYTE-AND-EVERY-BIT
ok    TEST-REQ-FOR-003-SEALED-TRAILING-DECISION-PAYLOAD
ok    TEST-REQ-FOR-003-SHORT-DECISION-FRAME-REQUIRES-COVERING-WITNESS
ok    TEST-REQ-TXM-005-UNSEALED-SEMANTIC-ERRORS-AND-COVERING-WITNESS
ok    TEST-REQ-AFF-008-DECISION-BUDGET-OFFSETS-BEFORE-COALESCENCE
ok    TEST-REQ-TXM-005-PUBLIC-DEFAULT-BUDGETS-AND-EXPLICIT-VERSION
ok    TEST-REQ-TXM-001-MAXIMUM-U16-PARTICIPANT-COUNT
ok    TEST-REQ-TXM-005-RADIX-PARTICIPANT-CARDINALITIES-AND-PATTERNS
ok    TEST-REQ-TXM-001-RADIX-PARTICIPANT-EVERY-BYTE-AND-BIT
ok    TEST-REQ-TXM-005-RADIX-DUPLICATE-PARTICIPANT-OFFSET
ok    TEST-REQ-TXM-005-RADIX-PARTICIPANT-SHAPE-BEFORE-SORT
ok    TEST-REQ-TXM-005-RADIX-ENTRY-CARDINALITIES-PATTERNS-AND-STABILITY
ok    TEST-REQ-AFF-008-RADIX-ENTRY-65536-BUCKET-COUNTS
ok    TEST-REQ-TXM-001-RADIX-ENTRY-EVERY-TXID-BIT
ok    TEST-REQ-TXM-005-RADIX-ENTRY-SHAPE-BEFORE-SORT
ok    TEST-REQ-TXM-005-CONCURRENT-IMMUTABLE-TABLE-QUERIES
ok    TEST-REQ-AFF-008-RADIX-PREFIX-INVALID-TOTAL
ok    TEST-REQ-AFF-008-RADIX-ENTRY-INVALID-OBJECT-BEFORE-SLOT-ACCESS
ok    TEST-REQ-AFF-008-RADIX-INVALID-DIGIT-BEFORE-ACCESS
ok    TEST-REQ-AFF-008-RADIX-SCATTER-INVALID-ARRAYS
ok    TEST-REQ-AFF-008-RADIX-INVALID-FINAL-CURSORS
ok    TEST-REQ-AFF-008-RADIX-SCATTER-INVALID-CURSORS
ok    TEST-REQ-TXM-005-PUBLIC-PARTICIPANT-SORT-THRESHOLD-BOUNDARIES
ok    TEST-REQ-TXM-005-PUBLIC-ENTRY-SORT-THRESHOLD-BOUNDARIES
ok    TEST-REQ-TXM-005-PUBLIC-RADIX-FIRST-PHYSICAL-CONFLICT-ACROSS-GROUPS
ok    TEST-REQ-AFF-017-MANIFEST-HISTORIES-V1-V2-AND-BATCH-LAYOUTS
ok    TEST-REQ-FOR-003-MANIFEST-SNAPSHOT-SIZES-AND-PERMUTED-SECTIONS
ok    TEST-REQ-AFF-018-MANIFEST-IDEMPOTENT-CLOSURES-REMOVALS-AND-OUTCOMES
ok    TEST-REQ-FOR-003-MANIFEST-CONFLICTING-OUTCOME-AND-CLOSED-PROOF
ok    TEST-REQ-AFF-018-MANIFEST-SECTION-OVERLAP-IS-INVALID
ok    TEST-REQ-AFF-018-MANIFEST-INVALID-TRANSITIONS-NEVER-REACTIVATE
ok    TEST-REQ-FOR-003-MANIFEST-SNAPSHOT-REQUIRED-AND-VALID
ok    TEST-REQ-AFF-017-MANIFEST-EVERY-CUT-KEEPS-WHOLE-SEALED-PREFIX
ok    TEST-REQ-AFF-017-MANIFEST-OWNS-CLOSURE-AND-OUTCOME-COPIES
ok    TEST-REQ-FOR-003-MANIFEST-U64-BOUNDARIES-AND-ID-EXHAUSTION
ok    TEST-REQ-FOR-003-MANIFEST-DIRECT-API-DEFAULTS-AND-REQUIRED-OPTIONS
ok    TEST-REQ-AFF-018-MANIFEST-RESERVED-OLD-IDS-AND-UNCHANGED-ACTIVE
ok    TEST-REQ-AFF-008-MANIFEST-PHYSICAL-DUPLICATE-BUDGETS
ok    TEST-REQ-AFF-008-MANIFEST-ZERO-EMPTY-SECTIONS-AND-INVALID-BUDGETS
ok    TEST-REQ-FOR-003-MANIFEST-SEMANTIC-CORRUPTION-IN-SEALED-PREFIX
ok    TEST-REQ-AFF-009-MANIFEST-WITNESS-PRECEDES-SEMANTIC-ERRORS-AND-BUDGETS
ok    TEST-REQ-AFF-017-MANIFEST-UNSEALED-INVALID-TRANSITION-IS-EXCLUDED
ok    TEST-REQ-AFF-008-MANIFEST-SCANNER-AND-EOF-CONTRACTS
ok    TEST-REQ-AFF-018-MANIFEST-HIGH-FILE-OFFSET-AND-ERROR-PROVENANCE
ok    TEST-REQ-AFF-017-MANIFEST-FOUR-INDEPENDENT-SERIES-IN-PARALLEL
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-ALL-TRUE-V1-V2
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-EMPTY-SETS-AUTHORITATIVE-ACTIVE-CLOSURE
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-HIGHWATER-EQUALITY-JUMP-AND-FULL-U64
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-ACTIVE-REUSED-BELOW-HIGHWATER
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-LAST-ID-THEN-EXHAUSTION
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-OLD-ACTIVE-MISSING-OR-REMOVED
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-OLD-ACTIVE-STILL-ACTIVE-AND-SELF
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-LENGTH-ONLY-FALSE
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-CLOSED-OUTCOME-COUNT-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-STATE-AND-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-ZERO-CSN-PRESENT-VERSUS-ABSENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-CSN-ONLY-FALSE-FULL-U64
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-TXID-FULL-U64-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-OUTCOME-ORDER-AND-IDENTICAL-DUPLICATES
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-CARDINALITY-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-REMOVED-CARDINALITY-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-REMOVED-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-PUBLIC-QUERIES-IMMUTABLE-ON-REPEATED-RESULTS
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-BOUNDED-GENERATIVE-MATRIX
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-PRIVATE-FI-CLOSED-STATE-ONLY-FALSE
ok    TEST-REQ-AFF-004-MANIFEST-TRANSITION-PRIVATE-FI-ORIGINAL-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-MANIFEST-TRANSITION-PRIVATE-FI-NONLOCAL-PRESERVED
ok    TEST-REQ-REC-001-INVENTORY-ADR-ACTION-TABLE
ok    TEST-REQ-REC-001-INVENTORY-ZERO-CLOSED-AND-REMOVED
ok    TEST-REQ-REC-002-INVENTORY-MISSING-LIVE-AND-HEALTH-PRIORITY
ok    TEST-REQ-REC-002-INVENTORY-BOTH-NAMES-ALWAYS-CONSERVATIVE
ok    TEST-REQ-REC-001-INVENTORY-EXHAUSTIVE-SMALL-MODEL-AND-INPUT-ORDERS
ok    TEST-REQ-AFF-008-INVENTORY-DUPLICATES-AND-INVALID-ENTRIES
ok    TEST-REQ-AFF-008-INVENTORY-PHYSICAL-AND-LIVE-BUDGETS
ok    TEST-REQ-AFF-008-INVENTORY-BUDGET-COUNTS-LIVE-NOT-OUTPUT-ROWS
ok    TEST-REQ-AFF-008-INVENTORY-INVALID-ARGUMENTS-AND-QUERY-RANGE
ok    TEST-REQ-REC-001-INVENTORY-UNSIGNED-U64-ORDER-AND-EXACT-IDENTITIES
ok    TEST-REQ-REC-001-INVENTORY-MAXIMUM-U64-ACTIVE
ok    TEST-REQ-AFF-017-INVENTORY-PLAN-OWNS-DATA-AFTER-INPUT-REUSE
ok    TEST-REQ-AFF-017-INVENTORY-FOUR-PRIVATE-SERIES-AND-SHARED-PLAN
ok    TEST-REQ-REC-001-RECOVERY-ID-FINITE-MODEL
ok    TEST-REQ-REC-001-RECOVERY-ID-HIGH-WATER-AND-ORPHANS
ok    TEST-REQ-REC-001-RECOVERY-ID-U64-FRONTIERS
ok    TEST-REQ-AFF-008-RECOVERY-ID-ORIGINAL-ERRORS-AND-BUDGETS
ok    TEST-REQ-AFF-018-RECOVERY-ID-INDEPENDENT-DECISIONS
ok    TEST-REQ-AFF-018-RECOVERY-ID-EMPTY-PLAN-INJECTION
ok    TEST-REQ-AFF-017-RECOVERY-ID-OWNED-PLAN-NO-RESERVATION
ok    TEST-REQ-AFF-017-RECOVERY-ID-FOUR-PRIVATE-SERIES
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-ADR-TABLE-V1-V2
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-FULL-U64-AND-MORE-THAN-EIGHT-FILES
ok    TEST-REQ-REC-002-INVENTORY-DIRECTORY-ABSENT-AND-CONFLICTING-LIVE-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-THREE-IO-BUDGETS-EXACT-ONE-UNDER
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-IGNORED-NAMES-COUNT-BEFORE-FILTERING
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-INVALID-BUDGETS-BEFORE-ENUMERATION
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-REJECTS-INCOMPLETE-AND-INVALID-BACKEND-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-CAPABILITY-AND-CALLBACK-PREFLIGHT
ok    TEST-REQ-AFF-017-INVENTORY-DIRECTORY-OWNED-LATIN1-NAMES-AND-PLAN-SURVIVE-REUSE
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-MALFORMED-SEGMENTLIKE-NAMES-REJECTED
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-PHYSICAL-ALIAS-AND-DUPLICATE-NAME
ok    TEST-REQ-AFF-001-INVENTORY-DIRECTORY-ORIGINAL-FAULT-AND-CALLBACK-CLOSE
ok    TEST-REQ-AFF-004-INVENTORY-DIRECTORY-NATIVE-OUTCOME-DATA-POLICY-ONLY
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-REPEAT-AND-INDEPENDENT-CURSOR-V1-V2
ok    TEST-REQ-REC-002-INVENTORY-DIRECTORY-NATIVE-MISSING-AND-CONFLICTING-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-NATIVE-BUDGET-FAILURE-KEEPS-PARENT-REUSABLE
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-HARDLINK-ALIAS-UNCHANGED
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-NATIVE-SYMLINK-FIFO-DIRECTORY-REJECTED
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-PARENT-RENAME-ANCHORS-ORIGINAL-FD
ok    TEST-REQ-REC-001-DIRECTORY-ID-FINITE-MODEL-ONE-ENUMERATION
ok    TEST-REQ-REC-001-DIRECTORY-ID-HIGH-WATER-ORPHANS-AND-HEALTH
ok    TEST-REQ-REC-001-DIRECTORY-ID-U64-FRONTIERS-AND-ERROR-ORDER
ok    TEST-REQ-AFF-008-DIRECTORY-ID-FIVE-BUDGETS-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-DIRECTORY-ID-INVALID-BEFORE-ENUMERATION
ok    TEST-REQ-AFF-001-DIRECTORY-ID-ORIGINAL-ERRORS-NO-PARTIAL-RESULT
ok    TEST-REQ-AFF-017-DIRECTORY-ID-OWNED-PLAN-AND-NO-RESERVATION
ok    TEST-REQ-AFF-017-DIRECTORY-ID-FOUR-PRIVATE-SERIES
ok    TEST-REQ-REC-001-DIRECTORY-ID-NATIVE-REPEAT-BYTE-PRESERVATION-V1-V2
ok    TEST-REQ-REC-001-DIRECTORY-ID-NATIVE-PARENT-RENAME-AND-EXHAUSTION
ok    TEST-REQ-REC-001-SOURCES-ONLY-LIVE-ORDERED-OWNED-V1-V2
ok    TEST-REQ-REC-002-SOURCES-NONREADY-BEFORE-ANY-OPEN
ok    TEST-REQ-REC-001-SOURCES-U64-AND-INPUT-REUSE
ok    TEST-REQ-AFF-008-SOURCES-BUDGETS-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-SOURCES-TOTAL-HIGH-BITS-NO-OVERFLOW
ok    TEST-REQ-AFF-008-SOURCES-INVALID-PREFLIGHT-AND-MISSING-CALLBACKS
ok    TEST-REQ-AFF-004-SOURCES-EACH-OPEN-METADATA-AND-ENTRY-FAILURE
ok    TEST-REQ-AFF-004-SOURCES-CLEANUP-PRIMARY-AND-ALL-CLOSE-FAILURES
ok    TEST-REQ-AFF-008-SOURCES-QUERY-AND-DEFENSIVE-PLAN-GUARDS
ok    TEST-REQ-AFF-004-SOURCES-INCOMPLETE-PARENT-AND-NONLOCAL-CLEANUP
ok    TEST-REQ-AFF-004-SOURCES-CURRENT-CHILD-CLEANUP-AND-PRIOR-CLEANUP-PRESERVED
ok    TEST-REQ-AFF-008-SOURCES-TOTAL-FIXNUM-OVERFLOW-REFUSED-BEFORE-ADDITION
ok    TEST-REQ-REC-001-SOURCES-NATIVE-READONLY-REPEAT-AND-BUDGET-CLEANUP
ok    TEST-REQ-REC-001-SOURCES-NATIVE-PARENT-RENAME-KEEPS-ORIGINAL-FD
ok    TEST-REQ-REC-001-SOURCES-FOUR-PRIVATE-SERIES-CONCURRENT
ok    TEST-REQ-REC-001-SOURCES-NATIVE-SYMLINK-AND-HARDLINK-REFUSED
170 test recovery superati.
ok    TEST-REQ-REC-001-ACTIVE-READ-ARV-D01-D06-D11-HEADER-ONLY
ok    TEST-REQ-REC-001-ACTIVE-READ-EXACT-CHUNKS-SHORTS-NO-HEADER-REREAD
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D01-TRUNCATED-HEADER-PREFLIGHT
ok    TEST-REQ-AFF-002-ACTIVE-READ-EARLY-PHYSICAL-EOF-HEADER-AND-BODY
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D01-INVALID-CHUNK-AND-HEADER-BUDGET
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D02-CALLER-AND-FORMAT-BYTE-LIMITS
ok    TEST-REQ-AFF-008-ACTIVE-READ-SCRATCH-ALIAS-BEFORE-RANGE-AND-ONE-BYTE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-READ-HEADER-AND-BODY-TRANSFER-CAPACITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-INVALID-SCANNER-BUDGETS-BEFORE-IDENTITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-OUT-OF-TYPE-BUDGETS-BEFORE-IDENTITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-EXACT-SCANNER-BUDGETS-NEVER-BECOME-TAIL
ok    TEST-REQ-AFF-002-ACTIVE-READ-BACKEND-MISMATCH-BEFORE-IDENTITY
ok    TEST-REQ-AFF-002-ACTIVE-READ-ARV-D02-PHYSICAL-ALIAS-AND-FULL-IDENTITIES
ok    TEST-REQ-FOR-001-ACTIVE-READ-HEADER-CRC-BEFORE-OTHER-FIELDS-AND-BODY
ok    TEST-REQ-FOR-001-ACTIVE-READ-ENTIRE-UUID-AND-U64-ID-BEFORE-BODY
ok    TEST-REQ-FOR-002-ACTIVE-READ-MAGIC-RESERVED-VERSION-ORIGIN-BEFORE-BODY
ok    TEST-REQ-AFF-009-ACTIVE-READ-ARV-D06-D11-UNSEALED-TAIL-BOUNDARIES
ok    TEST-REQ-AFF-009-ACTIVE-READ-DURABLE-WITNESS-PRECEDES-SEMANTIC-CONFLICT
ok    TEST-REQ-AFF-009-ACTIVE-READ-WITNESS-SEARCH-AND-EXACT-DURABLE-BOUNDARY
ok    TEST-REQ-AFF-002-ACTIVE-READ-EITHER-CAPABILITY-CLOSED-BEFORE-PREFLIGHT
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-PREPARED-SAME-BATCH-ZERO-MAX-U64
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-PREPARED-DIFFERENT-BATCHES-OFFSET
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-OUTCOME-BEFORE-PREPARED-SAME-OTHER-BATCH
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D04-PREPARED-BUDGET-DISTINCT-NOT-PHYSICAL
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D05-IDENTICAL-OUTCOMES-COALESCE
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D05-CONFLICTING-OUTCOMES-ZERO-HIGH-BITS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D05-OUTCOME-BUDGET-PHYSICAL-INCLUDING-ORPHANS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D04-D05-ZERO-BUDGETS-ORDINARY-AND-EMPTY
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D07-D08-RESOLUTION-TABLE-ALL-FOUR-CASES
ok    TEST-REQ-TXM-005-ACTIVE-ARV-D07-DECISION-NONPARTICIPANT-WITH-WITHOUT-OUTCOME
ok    TEST-REQ-TXM-005-ACTIVE-ARV-D08-DECISION-CSN-CONFLICTS-LOW-HIGH-ZERO
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D08-ORPHAN-OUTCOMES-IGNORE-UNRELATED-DECISIONS
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D09-MIXED-STATISTICS-EXACT-PARTITION
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D09-UNSEALED-OUTCOME-AND-PREPARED-NOT-COUNTED
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-ORDERED-OUTCOMES-BINARY-SEARCH-ALL-GAPS
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-U64-ORDER-ALL-BITS-NO-CSN-ORDER-ASSUMPTION
ok    TEST-REQ-FOR-003-ACTIVE-ARV-D12-CLOSURE-LITERAL-BYTES-HIGH-ID-AND-CSN
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-SHORT-RANGE-BEFORE-ANY-WRITE
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-SERIES-IDENTITY-ALIAS-PRECEDES-RANGE
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-D12-RESULT-INDEPENDENT-OF-SCRATCH-AND-DECISION-INTERNALS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D07-FI-DECISION-PARTICIPANT-COUNT-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D09-FI-EACH-INITIAL-RESOLUTION-COUNTER
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D09-FI-FINAL-RESOLUTION-PARTITION-MISMATCH
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D10-FI-PACK-CSN-TYPE-INVALID
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-FI-CLOSURE-AND-QUERY-SHAPE-BEFORE-WRITE
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-NATIVE-V1-DERIVED-ZERO-HIGH-U64-LOCAL-ABORT-TAIL
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-NATIVE-V2-DERIVED-ZERO-HIGH-U64-LOCAL-ABORT-TAIL
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-COMPLETE-FILE-LOCAL-OUTCOME-MATCHES-AUTHORITATIVE-DECISION
ok    TEST-REQ-FOR-003-ACTIVE-PUBLICATION-CLOSURE-SERIALIZED-SORTED-INDEPENDENT-CANARIES
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-MISSING-OR-REMOVED-OLD-CLOSED-PRECLAIM
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-SHORT-LONG-AND-PHYSICAL-EOF-PREFIX-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-FEWER-OR-EXTRA-OUTCOME-COUNT-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-ZERO-OR-TRUNCATED-HIGH-CSN-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-MISSING-ZERO-OUTCOME-EQUAL-COUNT-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-REPLACED-OUTCOME-LOCAL-ABORTED-TAIL-NOT-AUTHORITY
ok    TEST-REQ-AFF-008-ACTIVE-PUBLICATION-CLOSED-ACTIVE-OR-CANONICAL-CONTROL-FD-TOKEN-REUSABLE
ok    TEST-REQ-AFF-018-ACTIVE-PUBLICATION-HISTORICAL-CLOSED-OUTCOMES-AND-REMOVED-PRESERVED
ok    TEST-REQ-AFF-004-ACTIVE-PUBLICATION-NATIVE-DIRECTORY-FSYNC-FAULT-AFTER-RENAME
ok    TEST-REQ-AFF-004-ACTIVE-PUBLICATION-ORIGINAL-CONDITION-AFTER-RENAME-PRESERVED
59 test recovery ACTIVE superati.
ok    TEST-REQ-REC-001-ARCHIVE-READ-HEADER-ONLY-AND-EMPTY-SEALED-BATCHES
ok    TEST-REQ-AFF-002-ARCHIVE-READ-CHUNKS-SHORTS-SAME-FD-AND-LAST-SHORT-CHUNK
ok    TEST-REQ-FOR-001-ARCHIVE-READ-TRUNCATED-HEADER-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-INVALID-OPTIONS-AND-WHOLE-FILE-BYTE-BUDGET
ok    TEST-REQ-AFF-008-ARCHIVE-READ-SCALAR-TYPES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-SCRATCH-ALIAS-AND-SHORT-RANGE-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-TRANSFER-CAPACITY-EXACT-THRESHOLDS
ok    TEST-REQ-AFF-002-ARCHIVE-READ-CLOSED-CAPABILITY-BEFORE-PREFLIGHT
ok    TEST-REQ-AFF-002-ARCHIVE-READ-REJECTS-APPEND-AND-DIRECTORY-CAPABILITIES
ok    TEST-REQ-AFF-002-ARCHIVE-READ-EARLY-EOF-IS-NOT-A-LOG-TAIL
ok    TEST-REQ-AFF-002-ARCHIVE-READ-BACKEND-ERRORS-AND-IMPOSSIBLE-PROGRESS-NO-RETRY
ok    TEST-REQ-AFF-002-ARCHIVE-READ-REVOCATION-AFTER-PROGRESS-NEVER-RETURNS-RESULT
ok    TEST-REQ-FOR-001-ARCHIVE-READ-HEADER-CRC-PRECEDES-FIELDS-AND-BODY
ok    TEST-REQ-FOR-002-ARCHIVE-READ-MAGIC-ALL-RESERVED-BYTES-AND-UNKNOWN-VERSION
ok    TEST-REQ-FOR-001-ARCHIVE-READ-ENTIRE-ARCHIVE-UUID-DISTINCT-FROM-SERIE
ok    TEST-REQ-TXM-005-ARCHIVE-READ-IDENTICAL-DUPLICATES-CANONICAL-PARTICIPANTS
ok    TEST-REQ-TXM-005-ARCHIVE-READ-FIRST-PHYSICAL-CONFLICT-CSN-OR-PARTICIPANT
ok    TEST-REQ-FOR-003-ARCHIVE-READ-SEALED-SEMANTIC-ERRORS-NEVER-BECOME-TAIL
ok    TEST-REQ-AFF-008-ARCHIVE-READ-PHYSICAL-BUDGETS-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-009-ARCHIVE-READ-UNSEALED-TAIL-AND-CONFLICT-PRESUMED-ABORT
ok    TEST-REQ-AFF-009-ARCHIVE-READ-WITNESS-SEARCH-IGNORES-CORRUPT-LENGTH-AND-EXACT-BOUNDARY
ok    TEST-REQ-AFF-009-ARCHIVE-READ-DURABLE-WITNESS-BEFORE-SEMANTIC-CONFLICT-OR-BUDGET
ok    TEST-REQ-AFF-008-ARCHIVE-TYPES-CONSTRUCTOR-REJECTS-INVALID-IDENTITY-AND-SCOPE
ok    TEST-REQ-AFF-017-ARCHIVE-TYPES-OWNS-CALLER-UUID-WITH-SEPARATE-SERIE-SCOPE
ok    TEST-REQ-TXM-001-ARCHIVE-QUERY-U64-ZERO-HIGH-MAXIMUM-AND-MISSING
ok    TEST-REQ-AFF-017-ARCHIVE-QUERY-OWNS-RESULT-AFTER-SCRATCH-AND-CALLER-REUSE
ok    TEST-REQ-TXM-001-ARCHIVE-QUERY-PARTICIPANT-ALL-BITS-AND-NONZERO-SLICE
ok    TEST-REQ-AFF-008-ARCHIVE-QUERY-INVALID-RANGES-EVEN-FOR-ABSENT-TXID
ok    TEST-REQ-AFF-008-ARCHIVE-QUERY-INVALID-TYPES-HAVE-NO-IO
ok    TEST-REQ-AFF-017-ARCHIVE-QUERY-TWO-ARCHIVES-KEEP-INDEPENDENT-DECISIONS
ok    TEST-REQ-REC-001-ARCHIVE-ACTIVE-SAME-SCOPE-DISTINCT-UUID-V1-V2
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-FOREIGN-SCOPE-SAME-UUID-BEFORE-IO
ok    TEST-REQ-AFF-002-ARCHIVE-ACTIVE-CLOSED-DECISION-BEFORE-IO
ok    TEST-REQ-AFF-002-ARCHIVE-ACTIVE-DECISION-REVOKED-DURING-HEADER-OR-BODY
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-SCRATCH-ALIAS-ARCHIVE-BEFORE-RANGE
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-NIL-OR-BARE-TABLE-TYPE-ERROR
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-ALL-EIGHT-BUDGET-TYPES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-INVALID-BUDGET-VALUES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-ALL-POSITIVE-EXACT-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-BYTE-BUDGET-FORWARDED-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-SCANNER-BUDGETS-PRESERVE-CANONICAL-ERRORS
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-PREPARED-BUDGET-ZERO-AND-ONE
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-OUTCOME-BUDGET-COUNTS-PHYSICAL-DUPLICATES
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-DERIVED-LOCAL-ABORT-CANONICAL-ZERO-MAX-U64
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-UNSEALED-DECISION-DOES-NOT-COMMIT
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-UNSEALED-ACTIVE-OUTCOME-IGNORED
ok    TEST-REQ-REC-001-ARCHIVE-NATIVE-V1-V2-COMPLETE-THROUGH-PUBLISHED-CHECKPOINT
ok    TEST-REQ-TXM-007-ARCHIVE-NATIVE-V1-V2-TAIL-EXCLUDED-THROUGH-PUBLISHED-CHECKPOINT
ok    TEST-REQ-AFF-008-ARCHIVE-GUARDS-BODY-COMPOUND-CONDITIONS-AND-EMPTY-BODY
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-PREFLIGHT-INCONSISTENT-END-BEFORE-IO
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-IO-RETURN-HEADER-AND-BODY-BEFORE-RESULT
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-HEADER-DECODER-INCONSISTENT-END
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-PREFIX-RANGE-AND-COMPLETE-TAIL-COHERENCE
ok    TEST-REQ-AFF-008-ARCHIVE-GUARDS-PRIVATE-CONSTRUCTORS-STILL-ENFORCE-TYPES
54 test recovery Archivio superati.
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-HEADER-ONLY-NATIVE-V1-V2
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-ORDINARY-PUT-TOMBSTONE-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-LOCAL-OUTCOME-NATIVE-V1-V2
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-DERIVED-ZERO-HIGH-U64-NATIVE-V1-V2
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-PRESUMED-ABORT-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-ORPHAN-OUTCOME-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-IDENTICAL-OUTCOMES-NATIVE-V1-V2
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-SERIALIZER-RANGE-AND-IDENTITY-ALIAS-NO-WRITE
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PREPARED-ACROSS-BATCHES-REJECTED
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PREPARED-AFTER-OUTCOME-REJECTED
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-CONFLICTING-OUTCOMES-REJECTED
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-DECISION-MUST-NAME-THIS-SERIES
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-DECISION-CSN-MUST-MATCH-LOCAL-OUTCOME
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-BYTE-BUDGET-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-RECORD-BUDGET-EXCLUDES-SEAL
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-PREPARED-BUDGET-COUNTS-DISTINCT-TXIDS
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-OUTCOME-BUDGET-COUNTS-PHYSICAL-DUPLICATES
ok    TEST-REQ-AFF-009-ACTIVE-RECOVERY-TAIL-KEPT-AFTER-LAST-COMPLETE-BATCH
ok    TEST-REQ-AFF-009-ACTIVE-RECOVERY-DURABLE-WITNESS-REJECTS-DAMAGED-MIDDLE-BATCH
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-IDENTITY-SCRATCH-ALIAS-REJECTED-BEFORE-RANGE
ok    TEST-REQ-FOR-001-ACTIVE-RECOVERY-HEADER-ID-MUST-MATCH-CONTROL-ACTIVE
ok    TEST-REQ-FOR-001-ACTIVE-RECOVERY-COMPACTION-ORIGIN-IS-NOT-ACTIVE
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-NATIVE-REOPEN-COMPLETE-AND-TAIL
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-REJECTS-WRONG-PREFIX-BEFORE-CLAIM
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PUBLICATION-REJECTS-OMITTED-EXTRA-OR-CHANGED-OUTCOME
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-REJECTS-CLOSED-OLD-SEGMENT-BEFORE-CLAIM
ok    TEST-REQ-AFF-002-ACTIVE-RECOVERY-PUBLICATION-ORIGINAL-FSYNC-FAULT-AFTER-RENAME
27 test RECOVERY ACTIVE superati.
ok    TEST-REQ-REC-001-CLOSED-READ-CDR-D01-HEADER-ONLY-ALL-TRUE
ok    TEST-REQ-AFF-008-CLOSED-READ-CDR-D01-EACH-FALSE-AND-BYTE-BOUNDS
ok    TEST-REQ-FOR-001-CLOSED-READ-HEADER-CRC-PRECEDES-FIELDS-AND-BODY
ok    TEST-REQ-AFF-008-CLOSED-READ-TYPED-ARGUMENTS-BEFORE-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-BACKEND-MISMATCH-BEFORE-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-MODE-BEFORE-BACKEND-AND-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-EITHER-CAPABILITY-CLOSED-BEFORE-IO
ok    TEST-REQ-REC-001-CLOSED-READ-MEMBERSHIP-BEFORE-HEADER
ok    TEST-REQ-AFF-008-CLOSED-READ-SCRATCH-ALIAS-RANGE-AND-CANARIES
ok    TEST-REQ-AFF-008-CLOSED-READ-PREFIX-AND-CLOSURE-BUDGETS-BEFORE-IO
ok    TEST-REQ-AFF-008-CLOSED-READ-TRANSFER-BUDGET-EXACT-AND-MINUS-ONE
ok    TEST-REQ-FOR-001-CLOSED-READ-ENTIRE-UUID-AND-FULL-U64-ID
ok    TEST-REQ-FOR-002-CLOSED-READ-MAGIC-AND-ALL-RESERVED-BYTES-BEFORE-BODY
ok    TEST-REQ-FOR-002-CLOSED-READ-UNKNOWN-VERSION-AND-ORIGIN-BEFORE-BODY
ok    TEST-REQ-FOR-002-CLOSED-READ-VERSION-COMES-FROM-SEGMENT-HEADER
ok    TEST-REQ-AFF-002-CLOSED-READ-CHUNKS-SHORTS-AND-LAST-SHORT
ok    TEST-REQ-STO-006-CLOSED-READ-HEADER-ONLY-PREFIX-IGNORES-PHYSICAL-TAIL
ok    TEST-REQ-STO-006-CLOSED-READ-PREFIX-IS-AUTHORITATIVE-OVER-COMPLETE-OR-BROKEN-TAIL
ok    TEST-REQ-AFF-002-CLOSED-READ-PHYSICAL-EOF-BEFORE-AUTHORITATIVE-PREFIX
ok    TEST-REQ-AFF-002-CLOSED-READ-ORIGINAL-CONDITIONS-PRESERVED-EVEN-AFTER-REVOCATION
ok    TEST-REQ-AFF-002-CLOSED-READ-SYSCALL-AND-INVALID-PROGRESS-STOP-AT-FIRST-ERROR
ok    TEST-REQ-AFF-002-CLOSED-READ-REVOCATION-DURING-HEADER-BODY-AND-FINAL-TRANSFER
ok    TEST-REQ-FOR-003-CLOSED-READ-CORRUPTION-BEFORE-PREFIX-IS-NEVER-TAIL
ok    TEST-REQ-STO-006-CLOSED-READ-INCOMPLETE-PREFIX-IS-REJECTED-WITHOUT-READING-TAIL
ok    TEST-REQ-AFF-008-CLOSED-READ-CDR-D03-BODY-RANGE-EACH-FALSE-AND-EXACT
ok    TEST-REQ-TXM-007-CLOSED-WRITER-OUTCOME-EDIT-TUTTE-LE-PRESENZE
ok    TEST-REQ-TXM-007-CLOSED-WRITER-OUTCOME-EDIT-CONFLITTI-ZERO-BIT-ALTI
ok    TEST-REQ-CMP-009-CLOSED-COMPACTION-PUT-TOMBSTONE-SENZA-SEAL
ok    TEST-REQ-STO-006-CLOSED-INSIEME-VUOTO-SOLO-MANIFEST-VUOTO
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-DUPLICATI-IDENTICI-UNA-CLASSIFICAZIONE
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-DUPLICATI-DISCORDI-ANCHE-ORFANI
ok    TEST-REQ-TXM-007-CLOSED-ORDINE-PREPARED-OUTCOME-E-CONFINE-LOTTI
ok    TEST-REQ-TXM-007-CLOSED-CONTEGGI-MISTI-E-METADATI-ORFANI
ok    TEST-REQ-CMP-009-CLOSED-COMPACTION-RIFIUTA-PREPARED-OUTCOME-SEAL
ok    TEST-REQ-STO-006-CLOSED-INSIEME-COMPLETO-ID-U64-ORDINE-LIBERO
ok    TEST-REQ-STO-006-CLOSED-INSIEME-MANCANTE-EXTRA-DUPLICATO
ok    TEST-REQ-STO-006-CLOSED-INSIEME-ALTRO-CONTROL-REALE
ok    TEST-REQ-STO-006-CLOSED-INSIEME-FD-CLOSED-O-CONTROL-CHIUSO
ok    TEST-REQ-AFF-008-CLOSED-INSIEME-BUDGET-ESATTO-E-PRIMA-DEL-COUNT
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-ORFANO-EDIT-OMONIMO-ACCORDO-E-CONFLITTO
ok    TEST-REQ-MVC-005-CLOSED-CSN-VUOTO-CONTRO-ZERO-PRESENTE
ok    TEST-REQ-MVC-005-CLOSED-SEAL-PREPARED-ONLY-NON-CONFONDE-TXID
ok    TEST-REQ-MVC-005-CLOSED-EDIT-ORFANI-WRITER-COMPACTION-ANCHE-VUOTI
ok    TEST-REQ-MVC-005-CLOSED-WRITER-MASSIMO-ORDINARI-OUTCOME-SEAL-EDIT
ok    TEST-REQ-MVC-005-CLOSED-COMPACTION-MASSIMO-PUT-O-TOMBSTONE-U64
ok    TEST-REQ-MVC-005-CLOSED-MASSIMO-ESCLUDE-TUTTO-OLTRE-P-ANCHE-P64
ok    TEST-REQ-MVC-005-SERIE-INSIEME-VUOTO-E-ZERO-PRESENTE
ok    TEST-REQ-MVC-005-SERIE-MASSIMO-COMPLETO-FONTI-MISTE-ORDINE-LIBERO
ok    TEST-REQ-MVC-005-SERIE-RIFIUTA-MANCANTI-EXTRA-DUPLICATI-ALTRO-CONTROL-BUDGET
ok    TEST-REQ-MVC-005-SERIE-RIFIUTA-ACTIVE-CLOSED-CONTROL-CHIUSI
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-NATIVE-V1-WRITER-COMPACTION-TAIL-READONLY
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-NATIVE-V2-COMPLETE-SET-UNORDERED
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-EMPTY-SET-AND-HEADER-PREFIX-V1-V2
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-MISSING-EXTRA-BEFORE-CLAIM-TOKEN-REUSABLE
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-DUPLICATE-ID-SAME-RESULT-OR-DISTINCT-READONLY-ALIAS
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-DIFFERENT-CONTROL-SAME-BYTES-SAME-OR-ALIAS-FD
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-CLOSED-WRITER-OR-COMPACTION-FD-PRECLAIM-REREAD-ALIAS
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-CLOSED-CONTROL-OR-ACTIVE-FD-PRECLAIM-RECOVERY
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-SET-BUDGET-BEFORE-COUNT-AND-EXACT-BOUNDARY
ok    TEST-REQ-AFF-004-CLOSED-PUBLICATION-PRIVATE-DIRECTORY-FSYNC-ORIGINAL-FAULT-AFTER-RENAME
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-IO-HEADER-BODY-RETURNS
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-HEADER-EACH-CONJUNCT
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-MANIFEST-IMPOSSIBLE-PREFIX
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-BATCH-PROGRESS-AND-FRONTIERS
ok    TEST-REQ-AFF-008-CLOSED-GUARDS-BATCHES-AND-RECORD-BUDGETS
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-COMPACTION-EACH-CONJUNCT
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-LOCAL-STATE-AND-EDIT-VALUE
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-COMPACTION-CSN-COUNT-KIND-CONSUMPTION
ok    TEST-REQ-AFF-008-CLOSED-GUARDS-PRIVATE-RESULT-TYPES-AND-SET-PREFIX
69 test recovery CLOSED superati.
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D01-D02-EXACT-SERIES-AND-EIGHT-N
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D02-EMPTY-BEFORE-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D02-EACH-BUDGET-FALSE-INDEPENDENTLY
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D01-COPY-GUARD-EACH-CONDITION
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-BUDGETS-PRECEDE-INVALID-ELEMENTS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-TYPED-ARGUMENTS-AND-ELEMENTS
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-OTHER-SCOPE-IN-EACH-POSITION
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D04-EACH-OUTER-CARDINALITY
ok    TEST-REQ-REC-002-ARCHIVE-CSN-PREFLIGHT-ACR-D04-EXACT-ARCHIVE-OBJECT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-TYPED-ARGUMENTS-AND-NESTED-VECTORS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-ZERO-CLOSED-AND-ACTIVE-INCLUSIVE-TOTAL
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-INDEPENDENT-LOCAL-AND-GLOBAL-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-CARDINALITY-BEFORE-SEGMENT-BUDGETS
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-EQ-UUID-DUPLICATES
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-OWNED-CATALOG-ORDER
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-PLAN-RETAINS-ONLY-ARCHIVE-AND-SCALARS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-FOUR-SERIES-FOUR-CLOSED-EXACT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-COUNT-AND-BUDGETS-BEFORE-CAPACITY-GATES
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-DISTINCT-VIEWS-SAME-UUID
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-REGISTRI-IN-EVERY-POSITION
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-REGISTRI-ABSENT-OR-CLONED
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-OWNED-COPY-SURVIVES-CALLER-MUTATION
ok    TEST-REQ-MVC-006-ACR-D09-ASSENZA-CONTRO-ZERO-IN-OGNI-FONTE
ok    TEST-REQ-MVC-006-ACR-D08-MASSIMO-LOG-E-SERIE-MAGGIORE-MINORE-UGUALE
ok    TEST-REQ-MVC-006-ACR-D09-TXID-ALTI-NON-DIVENTANO-CSN
ok    TEST-REQ-MVC-006-ACR-D08-DECISIONI-ORFANE-ORDINE-TXID-CSN-INDIPENDENTE
ok    TEST-REQ-MVC-006-ACR-D08-CODE-DECISION-ACTIVE-CLOSED-ESCLUSE
ok    TEST-REQ-MVC-006-ACR-D09-SEAL-ED-EDIT-ORFANI-CON-BIT-ALTI
ok    TEST-REQ-TXM-005-ACR-D06-REPLAY-DISTINTO-STESSI-BYTE-ACTIVE-VUOTO-O-PREPARED
ok    TEST-REQ-TXM-005-ACR-D06-VISTA-CLONE-STESSO-UUID-STESSO-AMBITO
ok    TEST-REQ-STO-006-ACR-D07-CLOSED-MANCANTI-EXTRA-DUPLICATI-IN-SERIE-SUCCESSIVA
ok    TEST-REQ-STO-006-ACR-D07-CLOSED-ALTRO-CONTROL-STESSI-BYTE-E-P
ok    TEST-REQ-AFF-008-ACR-D07-FD-DECISION-ACTIVE-CONTROL-CLOSED-CHIUSI
ok    TEST-REQ-MVC-006-ACR-D09-PIANO-CONSEGNATO-INTERROGABILE-DOPO-CHIUSURA-FONTI
ok    TEST-REQ-TXM-005-ACR-D06-ACTIVE-SCAMBIATI-O-RIPETUTI
ok    TEST-REQ-TXM-005-ACR-D06-ALTRO-ARCHIVIO-STESSO-UUID-REPLAY-REALE
ok    TEST-REQ-MVC-006-ACR-D09-CODE-SOLE-NON-CREANO-PRESENZA-CSN
ok    TEST-REQ-TXM-005-ACR-D06-TABELLA-INDIPENDENTE-LOW-LEVEL-ACTIVE-VUOTO
ok    TEST-REQ-TXM-005-ACR-D06-ALTRO-ARCHIVIO-AMBITO-DIVERSO
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-V1-REGISTRI-LAST-ALL-SERIES-TAIL-EXCLUDED
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-V2-REGISTRI-NONFIXED-UNREFERENCED-DECISION-WINS
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-ABSENCE-VERSUS-PRESENT-ZERO-BASE-FIRST-ONE
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-EACH-SOURCE-BASE-U32-CARRY-FIRST-M-PLUS-ONE
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-U64-LIMIT-EMITS-LAST-ONCE-THEN-EXHAUSTED-NO-WRAP
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-CALLER-VECTORS-UUID-SCRATCH-PLAN-REMAIN-INDEPENDENT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-GATES-COUNT-CLOSED-DUPLICATES-BUDGETS-REGISTRI-SCOPE
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-CLOSED-DECISION-CONTROL-ACTIVE-WRITER-COMPACTION-FD
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-REPLAY-MARKER-ARCHIVE-OWNER-CANONICAL-VIEW-GATES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-RESULT-CONSUMPTION
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-RESULT-ABSENCE-REQUIRES-ZERO
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-DECISION-LIFETIME-RECHECKED-AFTER-SERIES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-DECISION-SHAPE-BEFORE-MAXIMUM
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-GUARDS-PRIVATE-CONSTRUCTORS-AND-QUERY-TYPES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-CLOSED-STATE-AND-PREFIX-DELEGATED
54 test piano CSN Archivio superati.
ok    TEST-REQ-MVC-006-RUNTIME-ASSENZA-E-ZERO-OSSERVATO-PRIMO-CSN-UNO
ok    TEST-REQ-MVC-006-RUNTIME-PIU-SERIE-DECISION-O-CLOSED-DOMINANTI
ok    TEST-REQ-MVC-006-RUNTIME-RIPORTO-U32-E-BIT-ALTI
ok    TEST-REQ-MVC-008-RUNTIME-LIMITE-U64-NESSUN-WRAP-O-MUTAZIONE-SU-ESAURIMENTO
ok    TEST-REQ-MVC-005-RUNTIME-DOPPIO-AVVIO-STESSO-PIANO-O-PIANO-DISTINTO-RIFIUTATO
ok    TEST-REQ-MVC-005-RUNTIME-ARCHIVI-DISTINTI-STESSO-UUID-INDIPENDENTI
ok    TEST-REQ-AFF-008-RUNTIME-CAPACITA-INVALIDE-PRIMA-DEL-BINDING-POI-SUCCESSO
ok    TEST-REQ-AFF-008-RUNTIME-TICK-INVALIDI-PRIMA-DEL-BINDING-POI-SUCCESSO
ok    TEST-REQ-AFF-008-RUNTIME-QUATTRO-CAPACITA-MASSIME-SIMULTANEE
ok    TEST-REQ-AFF-008-RUNTIME-TIPI-PIANO-E-GETTER-ERRATI-SENZA-BINDING-PARZIALE
ok    TEST-REQ-MVC-007-RUNTIME-DURATE-MASSIME-U64-VALIDE
ok    TEST-REQ-REC-001-RUNTIME-PIANO-CHIUSO-FONTI-CHIUSE-NESSUNA-RILETTURA
ok    TEST-REQ-MVC-007-RUNTIME-SNAPSHOT-CATTURA-CSN-CANONICO-ATTENDE-ORIZZONTE
ok    TEST-REQ-MVC-005-RUNTIME-GET-CORRENTE-E-SNAPSHOT-LEGAMI-E-BYTE-COERENTI
ok    TEST-REQ-MVC-005-RUNTIME-GET-RIFIUTA-VISTA-E-SNAPSHOT-DEL-BOOTSTRAP-SENZA-PIN
ok    TEST-REQ-MVC-006-RUNTIME-TWO-PLANS-ONE-CANONICAL-PUBLICATION
ok    TEST-REQ-MVC-007-RUNTIME-SHARED-CSN-OUT-OF-ORDER-RESOLUTION-AND-SNAPSHOT
ok    TEST-REQ-MVC-006-RUNTIME-NATIVE-COMPLETE-PLAN-FACTORY-FIRST-M-PLUS-ONE
ok    TEST-REQ-MVC-007-RUNTIME-NATIVE-CONFIGURED-CAPACITIES-ISOLATED-FROM-RECOVERY-SCOPE
ok    TEST-REQ-MVC-006-RUNTIME-NATIVE-BINDING-AND-GETTERS-AFTER-SOURCE-FDS-CLOSED
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-SLOT-ESTRANEO-RIPRISTINATO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-PIANO-CONTEGGI-INCOERENTI
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-PIANO-ASSENZA-RICHIEDE-ZERO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-SNAPSHOT-ALTRO-CSN-BASE-IDENTICA
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-VECCHIO-AMBITO-CON-LINK-CSN-CORRETTO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-BASE-HIGH-LOW-INDIPENDENTI
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-ULTIMO-CORRETTO-ORIZZONTE-DIVERSO
ok    TEST-REQ-MVC-006-RUNTIME-ADOPTION-NATIVE-V1-V2-DEFAULT-SINGLETON-NOEFFECTS
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-CAPACITY-PREFLIGHT-NO-PARTIAL-BINDING
ok    TEST-REQ-MVC-005-RUNTIME-ADOPTION-EXACT-SCOPE-EVEN-SAME-CSN-AND-EPOCHS
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-CLOSED-READONLY-OR-APPEND-NO-BINDING
ok    TEST-REQ-MVC-008-RUNTIME-ADOPTION-ADVANCED-WRITTEN-AND-DURABLE-REFUSED
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-EXACT-FILE-CAPABILITIES-NOT-INODE-ONLY
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-LOG-ID-VERSION-AND-KIND-PREFLIGHT
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-REAL-COMPACTION-HEADER-IS-NOT-WRITER
ok    TEST-REQ-AFF-001-RUNTIME-ADOPTION-FAULTED-LOG-NO-PARTIAL-BINDING
ok    TEST-REQ-CON-002-RUNTIME-ADOPTION-REFUSES-LOG-ALREADY-BOUND-BY-GENERIC-FACTORY
ok    TEST-REQ-MVC-008-RUNTIME-ADOPTION-NATIVE-FIRST-COMMIT-AND-COMMON-SNAPSHOT-TWO-SERIES
38 test bootstrap runtime superati.
ok    TEST-REQ-WAL-005-CODEC-V1-V2-AND-HIGH-U64
ok    TEST-REQ-WAL-005-PRESERVE-PREPARED-OUTCOME-DECISION-TXID
ok    TEST-REQ-WAL-005-EMPTY-AND-SEAL-EXACT-CAPACITY
ok    TEST-REQ-AFF-008-BUILDER-PREFLIGHT-AND-SEALED-IMMUTABILITY
ok    TEST-REQ-WAL-002-TWO-LOTS-ONE-FLUSH-AND-REUSE
ok    TEST-REQ-AFF-008-GROUP-BUDGET-IDENTITY-AND-ORDER
ok    TEST-REQ-AFF-008-FILE-BUDGET-BEFORE-ANY-WRITE
ok    TEST-REQ-WAL-005-OFFSET-AND-DURABLE-WITNESS-BEFORE-WRITE
ok    TEST-REQ-WAL-003-CONTROL-LOG-NEVER-ASYNC
ok    TEST-REQ-AFF-008-CANCEL-UNSENT-GROUP-RELEASES-CAPACITY
ok    TEST-REQ-WAL-002-BUFFERED-IDENTICAL-MIXED-SEALS-ONE-WRITE-AND-REUSE
ok    TEST-REQ-AFF-008-BUFFERED-FALLBACK-AND-EXACT-64KIB-CAPACITY
ok    TEST-REQ-AFF-008-BUFFER-TYPE-ALIAS-AND-FILE-REFUSAL-BEFORE-ACQUISITION
ok    TEST-REQ-WAL-006-BUFFERED-EVERY-BYTE-CUT-AND-SHORT-WRITE-PREFIX-MODEL
ok    TEST-REQ-AFF-001-BUFFERED-HARD-ERRORS-NO-FALLBACK-OR-FLUSH
ok    TEST-REQ-AFF-004-ALL-APPEND-EXITS-FAULT-AND-PRESERVE-PRIMARY-CONTROL
ok    TEST-REQ-AFF-001-BUFFERED-FLUSH-FAILURE-PRESERVES-WRITTEN-FRONTIER
ok    TEST-REQ-AFF-004-ACQUISITION-EXIT-FAULTS-ONLY-OWNED-GROUP
ok    TEST-REQ-AFF-001-BUFFERED-SHAPE-AND-RETURN-INVARIANTS-FAULT-BEFORE-CONFIRMATION
ok    TEST-REQ-AFF-001-WRITE-FAILURE-STOPS-LOG-AND-ALL-BATCHES
ok    TEST-REQ-AFF-001-FLUSH-FAILURE-NEVER-ADVANCES-DURABILITY
ok    TEST-REQ-WAL-005-CRASH-AT-EVERY-WRITTEN-BYTE-V1-V2
ok    TEST-REQ-AFF-001-PRIVATE-OWNERSHIP-VIOLATION-STOPS-BEFORE-FLUSH
ok    TEST-REQ-WAL-002-SECOND-GROUP-REJECTED-UNTIL-FLUSH
ok    TEST-REQ-WAL-002-CONCURRENT-GROUPS-AT-MOST-ONE-WRITE
ok    TEST-REQ-WAL-002-CONCURRENT-FLUSH-AT-MOST-ONE-SYSCALL
ok    TEST-REQ-WAL-002-NATIVE-GROUP-AND-DURABLE-WITNESS-V1-V2
ok    TEST-REQ-AFF-009-SUBSEQUENT-BATCH-WITNESS-DETECTS-OLD-CORRUPTION
ok    TEST-REQ-MVC-008-WAL-CSN-FREE-ASSOCIATION-REJECTIONS
ok    TEST-REQ-MVC-008-WAL-CSN-LIMB-BOUNDARIES-V1-V2
ok    TEST-REQ-WAL-005-WAL-CSN-PREPARED-AND-ORDINARY-STAMPS
ok    TEST-REQ-WAL-005-WAL-CSN-MANUAL-API-REMAINS-UNBOUND
ok    TEST-REQ-MVC-008-WAL-CSN-EMPTY-AND-CONTROL-CONTENT-BEFORE-ASSIGNMENT
ok    TEST-REQ-MVC-008-WAL-CSN-LOG-LAYOUT-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-008-WAL-CSN-OFFSETS-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-004-WAL-CSN-PRIVATE-SHAPE-AND-SEAL-BUDGET-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-001-WAL-CSN-FAULTED-LOG-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-008-WAL-CSN-FULL-BUSY-AND-EXHAUSTED-BEFORE-ASSIGNMENT
ok    TEST-REQ-MVC-008-WAL-CSN-REPEAT-SEAL-BEFORE-ASSIGNMENT
ok    TEST-REQ-WAL-006-WAL-CSN-FULL-WRITE-AND-PUBLICATION-LEVELS
ok    TEST-REQ-WAL-006-WAL-CSN-ASYNC-BEFORE-FLUSH-CANNOT-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-DURABLE-BEFORE-PUBLICATION-AND-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-HORIZON-GAP-ACROSS-INDEPENDENT-LOGS
ok    TEST-REQ-MVC-008-WAL-CSN-BUSY-PUBLICATION-KEEPS-TOKEN
ok    TEST-REQ-MVC-008-WAL-CSN-DOUBLE-RESOLVER-AND-OWNED-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-STALE-EVENT-AFTER-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-WRONG-REGISTRY-AND-TOKEN-IDENTITY
ok    TEST-REQ-MVC-008-WAL-CSN-NONLIVE-REGISTRY-TOKEN
ok    TEST-REQ-WAL-006-WAL-CSN-HEALTHY-ANNULMENT-ALWAYS-REFUSED
ok    TEST-REQ-AFF-001-WAL-CSN-PARTIAL-WRITE-FAULT-ANNULMENT
ok    TEST-REQ-AFF-001-WAL-CSN-FLUSH-FAULT-BUSY-ANNULMENT
ok    TEST-REQ-AFF-001-WAL-CSN-LATER-LOG-FAULT-REJECTS-OLD-PUBLICATION
ok    TEST-REQ-MVC-008-WAL-CSN-BOUND-LOG-IDENTITY-BEFORE-OWNERSHIP
ok    TEST-REQ-AFF-004-WAL-CSN-INCOMPLETE-ASSOCIATION-BEFORE-RESOLUTION
ok    TEST-REQ-AFF-008-WAL-CSN-FILE-BUDGET-AND-AVAILABILITY-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-004-WAL-CSN-INVALID-RECORD-OFFSET-RETAINS-OBLIGATION
  WAL/CSN: 4 Serie x 500 cicli, 2229 busy, 378 full, H convergente.
ok    TEST-REQ-MVC-008-FOUR-SERIES-SHARED-CSN-WAL-LIFECYCLE
57 test WAL superati.
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-CAPACITY-OFFSET-CSN-AND-EFFECT-BOUNDARIES
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-ACCEPTS-OPAQUE-NON-NIL-VALUES
ok    TEST-REQ-AFF-004-SERIES-BOOTSTRAP-NIL-STALE-AND-REPEATED-BEFORE-EFFECT
ok    TEST-REQ-AFF-004-SERIES-BOOTSTRAP-VIRGIN-GUARDS-AND-EXISTING-READER-ROOT
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-REFUSES-USED-EMPTY-RING-WITH-NIL-ROOT
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-FIRST-COMMIT-REQUIRES-INITIAL-ROOT-IDENTITY
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-HEALTH-AND-RING-PRECEDE-EFFECT
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-ACQUIRED-EFFECT-EXIT-PRESERVES-CAUSE-AND-ROOTS
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-PREEXISTING-EFFECT-KEEPS-OUTER-OWNERSHIP
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-CAS-CORRUPTION-KEEPS-FIRST-CONDITION-AND-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-INCOMPLETE-END-PRESERVES-ERROR-AND-NONLOCAL-EXIT
ok    TEST-REQ-AFF-008-SERIES-DEFAULT-AND-CAPACITY-BOUNDARIES
ok    TEST-REQ-AFF-008-SERIES-INVALID-CONFIGURATION-PRESERVES-WAL
ok    TEST-REQ-CON-001-SERIES-LEASE-BUSY-STALE-AND-SINGLE-RELEASE
ok    TEST-REQ-WAL-005-SERIES-ADOPTS-SEALED-BEFORE-IO-AND-CAPTURES-TOKEN
ok    TEST-REQ-WAL-005-SERIES-REFUSES-OPEN-UNBOUND-AND-POST-DISPATCH-LOTS
ok    TEST-REQ-AFF-004-SERIES-REGISTRY-AND-LOG-BINDING-BEFORE-ADOPTION
ok    TEST-REQ-WAL-005-SERIES-OFFSET-GAP-AND-DUPLICATE-PRESERVE-OBLIGATION
ok    TEST-REQ-MVC-008-SERIES-CSN-STRICT-ORDER-EVEN-AT-CONTIGUOUS-OFFSETS
ok    TEST-REQ-WAL-006-SERIES-PLANNED-ROOT-EQ-AND-NIL-ARE-DISTINCT-PRECONDITIONS
ok    TEST-REQ-AFF-008-SERIES-FULL-KEEPS-SEALED-TOKEN-FOR-LATER-ADOPTION
ok    TEST-REQ-WAL-006-SERIES-PUBLICATION-FIFO-UNRESOLVED-AND-RETURNED-H
ok    TEST-REQ-WAL-006-SERIES-GROUP-STRONG-COVERAGE-BEFORE-ROOT-CAS
ok    TEST-REQ-WAL-006-SERIES-ASYNC-SEPARATE-PUBLICATION-AND-RETIREMENT-CURSORS
ok    TEST-REQ-AFF-004-SERIES-IO-BEGIN-ONCE-AND-WRITTEN-IS-NOT-COMPLETION
ok    TEST-REQ-WAL-005-SERIES-RETIREMENT-FIFO-RESOLVED-DURABLE-UNOWNED
ok    TEST-REQ-AFF-004-SERIES-FREE-AND-STALE-PREALLOCATED-EVENT-AFTER-WRAP
ok    TEST-REQ-AFF-004-SERIES-FOREIGN-EVENT-SAME-GENERATION-AND-CSN
ok    TEST-REQ-AFF-004-SERIES-FALSE-EVENT-AND-INVALID-GENERATION-BEFORE-MUTATION
ok    TEST-REQ-MVC-008-SERIES-BUSY-AFTER-CAS-KEEPS-ROOT-ONCE-AND-CAPTURED-TOKEN
ok    TEST-REQ-MVC-008-SERIES-HIGH-CSN-CARRY-AND-DELAYED-GLOBAL-HORIZON
ok    TEST-REQ-AFF-001-SERIES-KNOWN-WRITE-AND-FLUSH-FAULT-DRAIN-AND-ANNUL
ok    TEST-REQ-AFF-001-SERIES-TERMINAL-FAULT-AND-SCOPE-ONLY-UPGRADES
ok    TEST-REQ-AFF-001-SERIES-ANNUL-REQUIRES-LOCAL-FAULT-AND-GLOBAL-QUIESCENCE
ok    TEST-REQ-MVC-008-SERIES-ANNUL-FIFO-BUSY-PRESERVES-CAPTURED-OBLIGATION
ok    TEST-REQ-AFF-001-SERIES-ARCHIVE-FAULT-REFUSES-AUTOMATIC-ANNUL
ok    TEST-REQ-AFF-004-SERIES-CAPTURED-TOKEN-NEVER-RECONSTRUCTED-FROM-MUTATED-LOT
ok    TEST-REQ-AFF-004-SERIES-REGISTRY-INVARIANT-AFTER-ROOT-CAS-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-SERIES-UNEXPECTED-ROOT-CAS-AND-NONLOCAL-EXIT-FAULT-ARCHIVE
ok    TEST-REQ-AFF-008-SERIES-LEASE-AND-EVENT-GENERATIONS-EXHAUST-WITHOUT-WRAP
ok    TEST-REQ-WAL-006-SERIES-INVALID-LEVEL-AND-PUBLICATION-REPLAY-PRESERVE-STATE
ok    TEST-REQ-WAL-006-SERIES-REJECTED-DISPATCH-WITHDRAWS-WITHOUT-IO-AND-H-CONVERGES
ok    TEST-REQ-AFF-004-SERIES-WITHDRAW-REFUSES-HEALTHY-OWNED-WRITTEN-STALE-AND-DOUBLE
ok    TEST-REQ-AFF-004-SERIES-WAL-PREFLIGHT-INVARIANTS-FAULT-BEFORE-ADOPTION-OR-RELEASE
ok    TEST-REQ-AFF-004-SERIES-UNCERTAIN-GETTER-FAULTS-ARCHIVE-BEFORE-AND-AFTER-CAS
ok    TEST-REQ-AFF-008-SERIES-RING-INVALID-CAPACITY-BEFORE-INDEXING
ok    TEST-REQ-CON-002-SERIES-RING-CURSORS-FAIL-SEPARATELY
ok    TEST-REQ-CON-002-SERIES-RING-COUNTS-FAIL-SEPARATELY
ok    TEST-REQ-MVC-008-SERIES-CSN-AFTER-EXPLICIT-TRUTH-PAIRS
ok    TEST-REQ-CON-002-SERIES-BOOTSTRAP-READERS-SEE-ONLY-NIL-OR-COMPLETE-ROOT
ok    TEST-REQ-CON-001-SERIES-BOOTSTRAP-FOREIGN-THREAD-CANNOT-USE-OWNER-LEASE
ok    TEST-REQ-CON-001-SERIES-FOREIGN-THREAD-LEASE-AND-RELEASE-REACQUIRE-TRANSFER
ok    TEST-REQ-CON-002-SERIES-CAS-EIGHT-CONTENDERS-ONE-OWNER
  Serie: 4 controller x 64 lotti, K=3, 5 busy, 16 full, H convergente.
ok    TEST-REQ-CON-004-SERIES-FOUR-CONTROLLERS-SHARED-BOUNDED-CSN
ok    TEST-REQ-CON-002-SERIES-IMMUTABLE-ROOT-PARALLEL-READER-AFTER-HANDOFF
ok    TEST-REQ-WAL-006-SERIES-IO-FINISH-JOINED-BEFORE-DRAIN-AND-ANNUL
ok    TEST-REQ-CON-004-SERIES-HELD-CSN-GUARD-PUBLISH-NEVER-WAITS
ok    TEST-REQ-CON-001-WORKER-SERIE-DOUBLE-LEASE-FIFO-ACK-AND-IDLE
ok    TEST-REQ-CON-005-WORKER-SERIE-QUANTUM-ROTATION-MONOTONE-TRACT-AND-BATCH
ok    TEST-REQ-CON-005-WORKER-SERIE-FIRST-LEASE-BUSY-DOES-NOT-TOUCH-SERIE
ok    TEST-REQ-CON-005-WORKER-SERIE-SECOND-LEASE-BUSY-CLOSES-WITHOUT-POP
ok    TEST-REQ-CON-005-WORKER-SERIE-SECOND-LEASE-BUSY-AND-END-BUSY-KEEP-OBLIGATION
ok    TEST-REQ-CON-005-WORKER-SERIE-RELEASES-SERIE-BEFORE-BUSY-WRITER-END
ok    TEST-REQ-AFF-004-WORKER-SERIE-BATCH-DEBT-AND-STALE-ACK-RETAIN-BOTH-LEASES
ok    TEST-REQ-AFF-004-WORKER-SERIE-TRACT-TOKEN-REFUSED-BEFORE-POP-ACK-OR-CLOSE
ok    TEST-REQ-AFF-004-WORKER-SERIE-TARGET-SPAN-AND-ALIAS-REFUSALS-BEFORE-POP
ok    TEST-REQ-AFF-004-WORKER-SERIE-STATIC-BINDING-REFUSES-OTHER-CLAIMED-WRITER
ok    TEST-REQ-AFF-008-WORKER-SERIE-LOCAL-GENERATION-EXHAUSTION-PRECEDES-WRITER-BEGIN
ok    TEST-REQ-AFF-008-WORKER-SERIE-CONTROLLER-GENERATION-LIMIT-REQUIRES-EXPLICIT-CLOSE
ok    TEST-REQ-CON-002-WORKER-SERIE-FOREIGN-OWNER-IN-IDLE-ACTIVE-BATCH-AND-CLOSING
ok    TEST-REQ-AFF-008-WORKER-SERIE-RELEASE-FAULT-RETAINS-TWO-LEASES-AND-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-WORKER-SERIE-ERROR-BETWEEN-RELEASES-PRESERVES-CONDITION-AND-WRITER
ok    TEST-REQ-AFF-004-WORKER-SERIE-STALE-CONTROLLER-LEASE-NEVER-POISONS-NEW-OWNER
ok    TEST-REQ-AFF-004-WORKER-SERIE-OWNED-FAULT-THREE-INDEPENDENT-TRUTH-PAIRS
ok    TEST-REQ-AFF-008-WORKER-SERIE-BOUNDARY-ONCE-VALUES-AND-EXACT-CONDITION
ok    TEST-REQ-AFF-008-WORKER-SERIE-PRESERVES-EARLIER-WORKER-FAULT-ON-RAW-BEGIN
ok    TEST-REQ-AFF-008-WORKER-SERIE-ACQUIRE-BOUNDARY-UNKNOWN-REASONS-NEVER-REMAIN-RECOVERABLE
ok    TEST-REQ-AFF-008-WORKER-SERIE-RELEASE-BOUNDARY-UNKNOWN-REASONS-RETAIN-BOTH-LEASES
ok    TEST-REQ-AFF-008-WORKER-SERIE-LOWER-WORKER-FAULT-CANNOT-MATCH-BENIGN-OUTER-TOKEN-REASON
ok    TEST-REQ-AFF-008-WORKER-SERIE-ZERO-ACTIVE-GENERATION-FAULTS-ONLY-OWNED-CONTROLLER
ok    TEST-REQ-WAL-006-WORKER-SERIE-FAULTED-CONTROLLER-STILL-DRAINS-FINISHED-IO
ok    TEST-REQ-CON-002-WORKER-SERIE-TWO-WRITERS-ONE-CONTROLLER-HAVE-ONE-ACTIVE-LEASE
ok    TEST-REQ-CON-002-WORKER-SERIE-INDEPENDENT-CONTROLLERS-ACTIVE-CONCURRENTLY
ok    TEST-REQ-CON-005-ROUTING-WRITER-ORDINAL-AND-LEGACY-DEFAULT
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-MAXIMUM-SHAPE-REACHES-ENTRY-VALIDATION
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-REJECTS-SHAPE-AND-BUDGET-WITHOUT-EFFECTS
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-OVERSIZE-REFUSAL-HAS-ITERATIVE-PREIMAGE
ok    TEST-REQ-AFF-008-ROUTING-CORRUPT-PRIVATE-SHAPE-REJECTS-BEFORE-LEASE
ok    TEST-REQ-AFF-001-ROUTING-SELECTS-FAULTED-SERIE-FOR-EXPLICIT-DRAIN
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-ENTRY-TYPES-AND-EXACT-ORDINALS
ok    TEST-REQ-CON-002-ROUTING-REGISTRY-REFUSES-CONTROLLER-ALIAS-BEFORE-ANY-LEASE
ok    TEST-REQ-CON-002-ROUTING-REGISTRY-COPIES-INPUT-VECTORS-AND-PRESERVES-IDENTITIES
ok    TEST-REQ-CON-005-ROUTING-TABLE-CONSTRUCTION-REQUIRES-IDLE-OWNER
ok    TEST-REQ-CON-005-ROUTING-READY-FULL-RECYCLE-SWITCHES-SERIES-AND-PRESERVES-FIFO
ok    TEST-REQ-AFF-008-ROUTING-UNKNOWN-UNROUTED-AND-OUT-OF-RANGE-RETAIN-OBLIGATION
ok    TEST-REQ-AFF-008-ROUTING-CORRUPT-LINK-IS-DETECTED-BEFORE-LEASE-OR-POP
ok    TEST-REQ-CON-005-ROUTING-LOOKUP-REJECTS-RUNNING-BATCH-AND-RESCHEDULE
ok    TEST-REQ-CON-005-ROUTING-LOOKUP-REJECTS-FINISHING-WITHOUT-CHANGING-DEBT
ok    TEST-REQ-CON-002-ROUTING-FOREIGN-OWNER-FACTORY-AND-LOOKUP-PRESERVE-ALL-FIELDS
ok    TEST-REQ-CON-002-ROUTING-SHARED-REGISTRY-READY-TWO-SERIES-ACTIVE-IN-PARALLEL
ok    TEST-REQ-AFF-008-ROUTING-LOOKUP-REASON-CANNOT-BYPASS-TERMINAL-BOUNDARY
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-FRESH-GETTER-AND-DEFAULT-FACTORY
ok    TEST-REQ-AFF-008-SERIES-LOG-BINDING-PRESERVES-CAPACITY-GENERAL-ROOT-AND-OFFSET
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-DUPLICATE-FACTORY-EVEN-OTHER-REGISTRY
ok    TEST-REQ-AFF-008-SERIES-LOG-BINDING-INVALID-CONFIG-PRECEDES-BINDING
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-REJECTS-NONSEGMENT-BEFORE-BINDING
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-NEW-CANONICAL-LOG-INDEPENDENT
ok    TEST-REQ-AFF-009-SERIES-LOG-BINDING-FOREIGN-SLOT-FI-RESTORED
ok    TEST-REQ-CON-004-SERIES-LOG-BINDING-TWO-FOUR-WORKERS-ONE-PUBLICATION-AND-OBSERVER
109 test del controller Serie superati.
ok    TEST-REQ-AFF-003-SLOT-DEFTEST-EXPANSION-REGISTERS-WITHOUT-RUNNING
ok    TEST-REQ-LIM-001-SLOT-V2-FORMAT-LIMITS-MATCH-ADR-0048
ok    TEST-REQ-IDX-001-SLOT-DEFAULT-BANK-ZEROED-FIXED-U64-LAYOUT
ok    TEST-REQ-AFF-008-SLOT-MAXIMUM-CAPACITY-AND-LAST-INDEX
ok    TEST-REQ-AFF-008-SLOT-NEGATIVE-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-ZERO-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-OVER-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-NEGATIVE-BUDGET-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-ZERO-BUDGET-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-PAYLOAD-BUDGET-EXACT-AND-ONE-BYTE-SHORT
ok    TEST-REQ-AFF-008-SLOT-RANGE-REFUSED-BY-EVERY-INDEXED-API
ok    TEST-REQ-IDX-001-SLOT-CSN-FULL-U64-BEYOND-FIXNUM
ok    TEST-REQ-IDX-003-SLOT-REPUBLISH-REMOVE-AND-REUSE-ISOLATES-NEIGHBORS
ok    TEST-REQ-IDX-006-SLOT-REMOVAL-CLEARS-EVERY-RETAINED-WORD
ok    TEST-REQ-LIM-001-SLOT-KEY-LENGTH-BOUNDARIES-1-255-256-65535
ok    TEST-REQ-LIM-001-SLOT-ZERO-KEY-LENGTH-REFUSED
ok    TEST-REQ-LIM-001-SLOT-KEY-RESERVED-BITS-REFUSED
ok    TEST-REQ-IDX-001-SLOT-KEY-LIVE-FLAG-REQUIRED
ok    TEST-REQ-LIM-001-SLOT-KEY-ARENA-END-AT-U32-EXCLUSIVE-LIMIT
ok    TEST-REQ-LIM-001-SLOT-KEY-ARENA-OVERFLOW-BY-ONE-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-RESERVED-BITS-REFUSED
ok    TEST-REQ-LIM-001-SLOT-MINIMUM-RECORD-HEADER-PLUS-KEY-ACCEPTED
ok    TEST-REQ-LIM-001-SLOT-RECORD-SHORTER-THAN-HEADER-PLUS-KEY-REFUSED
ok    TEST-REQ-LIM-001-SLOT-EXACT-DOCUMENT-AND-RECORD-MAXIMA-ACCEPTED
ok    TEST-REQ-LIM-003-SLOT-DOCUMENT-OVERFLOW-BELOW-RECORD-MAXIMUM-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-MAXIMUM-PLUS-ONE-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-END-EXACT-SEGMENT-LIMIT-ACCEPTED
ok    TEST-REQ-LIM-001-SLOT-RECORD-END-OVERFLOW-BY-ONE-REFUSED
ok    TEST-REQ-IDX-003-SLOT-ZERO-CSN-LIVE-PAYLOAD-REFUSED
ok    TEST-REQ-IDX-003-SLOT-PRIMARY-END-MUST-BE-ZERO
ok    TEST-REQ-IDX-003-SLOT-RETAINED-EXCLUSIVE-INTERVAL-FULL-U64
ok    TEST-REQ-IDX-003-SLOT-RETAINED-ZERO-EQUAL-AND-EARLIER-END-REFUSED
ok    TEST-REQ-IDX-003-SLOT-RETAINED-U64-MAX-START-HAS-NO-VALID-END
ok    TEST-REQ-IDX-003-SLOT-EMPTY-PREDICATE-CHECKS-ALL-FIVE-FIELDS
ok    TEST-REQ-IDX-003-SLOT-INTERNAL-VALIDATION-EMPTY-LIVE-AND-MALFORMED
ok    TEST-REQ-IDX-005-SLOT-FREEZE-IDEMPOTENT-READABLE-AND-ALL-WRITERS-REFUSED
ok    TEST-REQ-AFF-004-SLOT-INVALIDATION-IDEMPOTENT-TERMINAL-AND-PRESERVES-DATA
ok    TEST-REQ-AFF-004-SLOT-FAULT-AFTER-FREEZE-KEEPS-BOTH-TERMINAL-STATES
ok    TEST-REQ-CON-004-SLOT-ODD-RETRY-LIMIT-PRESERVES-OUTPUT-AND-SKIPS-TRANSIENT-VALIDATION
ok    TEST-REQ-AFF-004-SLOT-READER-CORRUPT-SEQUENCE-THRESHOLD-AND-U64-MAX
ok    TEST-REQ-AFF-004-SLOT-WRITER-ODD-AND-THRESHOLD-SEQUENCES-FAULT
ok    TEST-REQ-AFF-008-SLOT-INITIAL-CREDIT-AND-ONE-PER-MUTATION
ok    TEST-REQ-AFF-008-SLOT-LAST-CREDIT-CONSUMED-WITHOUT-WRAP
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-LIVE-PUBLISH-REMOVE-AND-RELOCATE-REFUSED
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-EMPTY-REMOVAL-IS-IDEMPOTENT
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-RELOCATION-NOOPS-NEED-NO-CREDIT
ok    TEST-REQ-AFF-004-SLOT-STABLE-CORRUPT-FIELDS-FAULT-READER-BEFORE-COPY
ok    TEST-REQ-AFF-004-SLOT-PARTIAL-EMPTY-FAULTS-READER-AND-WRITER
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-PRIMARY-AND-RETAINED-CHANGES-ONLY-LOCATION
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-CSN-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-LOCATION-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-KEY-METADATA-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-RECORD-LENGTH-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-RETAINED-END-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-CSN-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-KEY-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-RECORD-LENGTH-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-RETAINED-END-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-INVALID-EXPECTED-AND-REPLACEMENT-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-EMPTY-IS-A-NOOP
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-EQUAL-LOCATION-NEVER-CONSUMES-CREDIT
ok    TEST-REQ-IDX-003-SLOT-PRIMARY-WRITER-THREE-READERS-CORRELATED-U64-SNAPSHOTS
ok    TEST-REQ-IDX-003-SLOT-RETAINED-WRITER-THREE-READERS-CORRELATED-FIVE-WORD-SNAPSHOTS
ok    TEST-REQ-IDX-006-SLOT-RETAINED-CONCURRENT-REMOVE-REPUBLISH-PRESERVES-EMPTY-OUTPUT
64 test degli slot indice v2 superati.
ok    TEST-REQ-AFF-003-PRIMARY-HARNESS-AND-EMPTY-ROOT
ok    TEST-REQ-IDX-001-PRIMARY-BINARY-COLLISIONS-AND-SPAN
ok    TEST-REQ-IDX-001-PRIMARY-FULL-GROUP-WRAP-AND-DELETED-NOT-EMPTY
ok    TEST-REQ-IDX-006-PRIMARY-DELETE-IDEMPOTENCE-AND-REUSE-NEW-FINGERPRINT
ok    TEST-REQ-IDX-001-PRIMARY-UPSERT-CSN-INCREASING-AND-KEY-STABLE
ok    TEST-REQ-IDX-005-PRIMARY-PREFIX-REFUSALS-BEFORE-MUTATION
ok    TEST-REQ-IDX-005-PRIMARY-OWNER-REFUSALS-PRESERVE-BOTH-DOMAINS
ok    TEST-REQ-IDX-005-PRIMARY-FROZEN-FRAGMENT-READABLE-NEVER-WRITABLE
ok    TEST-REQ-IDX-005-PRIMARY-ARENA-GROWTH-BUDGET-AND-OFFSETS
ok    TEST-REQ-LIM-003-PRIMARY-KEY-65535-AND-INVALID-LENGTHS
ok    TEST-REQ-IDX-001-PRIMARY-U64-CSN-THROUGH-MAXIMUM
ok    TEST-REQ-IDX-003-PRIMARY-EIGHT-COLLISION-SAMPLES-ONE-BUDGET
ok    TEST-REQ-IDX-003-PRIMARY-COLLISIONS-AND-ODD-RETRIES-SHARE-EIGHT
ok    TEST-REQ-CON-004-PRIMARY-OUTPUT-PRESERVED-MISS-AND-CONTEXT-REFUSALS
ok    TEST-REQ-IDX-005-PRIMARY-LOAD-SLOT-CREDIT-AND-REVISION-PREFLIGHT
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-SPAN-PROBE-AND-NO-RESERVATION
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-LOAD-AND-UPDATE
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-ARENA-AND-DELETED-KEY
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-CREDIT-AND-ABSENT-DELETE
ok    TEST-REQ-IDX-007-PRIMARY-MUTATION-PREFLIGHT-REVISION-AND-ABSENT-DELETE
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-DOMAIN-SPAN-AND-CONTEXT-GUARDS
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-CANONICAL-FAULT-AND-CLEANUP
ok    TEST-REQ-IDX-005-PRIMARY-MANUAL-REBUILD-COMPACTS-AND-PUBLISHES-CURRENT-ROOT
ok    TEST-REQ-IDX-005-PRIMARY-MANUAL-SPLIT-ROUTES-MSB-PREFIXES
ok    TEST-REQ-IDX-005-PRIMARY-SHALLOW-SPLIT-NO-DOUBLING-AND-UNRELATED-MUTABLE
ok    TEST-REQ-IDX-007-PRIMARY-STALE-PLAN-AFTER-SOURCE-UPDATE-NO-FREEZE
ok    TEST-REQ-IDX-007-PRIMARY-STALE-PLAN-AFTER-CANDIDATE-UPDATE-AND-ARENA-GROWTH
ok    TEST-REQ-IDX-007-PRIMARY-TWO-PLANS-OLD-ROOT-AND-CONSUMED-PLAN-REFUSED
ok    TEST-REQ-IDX-007-PRIMARY-DIRECTORY-CANDIDATES-AND-EXACT-BUDGET
ok    TEST-REQ-IDX-004-PRIMARY-RELOCATION-MESSAGE-SURVIVES-REBUILD-NOT-NEW-VERSION
ok    TEST-REQ-IDX-007-PRIMARY-ROOT-CHANGES-HIT-MISS-AND-COMMON-BUDGET
ok    TEST-REQ-IDX-007-PRIMARY-FINAL-CONFIRMATION-EXHAUSTED-NO-RESTART
ok    TEST-REQ-IDX-003-PRIMARY-WRITER-UPDATES-THREE-READERS-NO-TORN-PAYLOAD
ok    TEST-REQ-IDX-007-PRIMARY-MANUAL-REBUILDS-AND-ARENA-GROWTH-WITH-READERS
ok    TEST-REQ-IDX-005-REBUILD-ORIGINAL-SLOTS-AND-COMPACTED-OFFSETS
ok    TEST-REQ-IDX-005-REBUILD-SPLIT-VERIFIED
ok    TEST-REQ-IDX-005-REBUILD-U64-MAX-KEY-AND-RESET-SEQUENCE
ok    TEST-REQ-IDX-005-REBUILD-DELETION-COMPACTS-LIVE-BYTES
ok    TEST-REQ-IDX-005-REBUILD-EMPTY-FRAGMENT
ok    TEST-REQ-IDX-005-REBUILD-EMPTY-SPLIT
ok    TEST-REQ-IDX-005-REBUILD-SPLIT-ONE-EMPTY-CHILD
ok    TEST-REQ-AFF-008-REBUILD-TRANSIENT-BUDGET
ok    TEST-REQ-AFF-008-REBUILD-DIRECTORY-BUDGET-BEFORE-CANDIDATES
ok    TEST-REQ-AFF-008-REBUILD-FRAGMENT-BUDGET-CONDITIONS
ok    TEST-REQ-AFF-008-REBUILD-INVALID-SHAPE-AND-BUDGET
ok    TEST-REQ-AFF-008-REBUILD-DEPTH-EXHAUSTED-ONLY-FOR-SPLIT
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-FINGERPRINT
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-LOOKUP-GROUP
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-SOURCE-PREFIX
ok    TEST-REQ-IDX-005-REBUILD-PLAN-STALE-AFTER-SOURCE-UPDATE
ok    TEST-REQ-IDX-005-REBUILD-SECOND-CONSTRUCTION-STALES-FIRST-PLAN
ok    TEST-REQ-AFF-008-REBUILD-REVISION-EXHAUSTION-BEFORE-CANDIDATES
ok    TEST-REQ-AFF-008-REBUILD-GENERATION-EXHAUSTION-BEFORE-CANDIDATES
ok    TEST-REQ-IDX-005-REBUILD-CORRUPTED-COPY-LOCATION
ok    TEST-REQ-IDX-005-REBUILD-COPY-COMPARISON
ok    TEST-REQ-IDX-005-REBUILD-DUPLICATE-SOURCE-KEY
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-CONTROL-CORRUPTION
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-BANK-CORRUPTION-PROPAGATES
ok    TEST-REQ-IDX-005-REBUILD-PROBE-BANK-CORRUPTION-BEFORE-SLOT-SCAN
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-ARENA-AND-LIVE-COUNT-CORRUPTION
ok    TEST-REQ-IDX-005-REBUILD-COPY-LOOKUP-FALSE-IS-TERMINAL
ok    TEST-REQ-IDX-005-REBUILD-COLD-ABORT-PRESERVES-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-PHYSICAL-SLOTS
ok    TEST-REQ-IDX-005-HASH-MAP-NONLIVE-SENTINELS-AND-EXACT-COUNTS
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-ARITY-EMPTY-AND-UNCONFIGURED
ok    TEST-REQ-IDX-005-HASH-MAP-SEED-CONSTRUCTOR-AND-IMMUTABILITY
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-TYPES-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-LENGTHS-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-ALIAS-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-INVALID-SEED-TYPES-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-SEED-MISMATCH
ok    TEST-REQ-IDX-005-HASH-MAP-STALE-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-BUILDING-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-FOREIGN-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-CANONICAL-ROOT-AND-BANK-GUARDS
ok    TEST-REQ-IDX-005-HASH-MAP-CORRUPT-BANK-FAULTS-IMMEDIATELY
ok    TEST-REQ-IDX-005-HASH-MAP-CORRUPT-ARENA-AND-LIVE-COUNT
ok    TEST-REQ-IDX-005-HASH-MAP-MISSING-ROOT-FAULTS
ok    TEST-REQ-IDX-005-HASH-MAP-INTERNAL-DIGEST-FAULTS
ok    TEST-REQ-IDX-001-HASH-KERNEL-FAULT-PROPAGATES-OWNER
80 test dell'indice primario superati.
ok    REQ-IDX-008-AVVIO-RESIDENTE-SENZA-PAGINAZIONE-FORZATA
ok    REQ-IDX-008-CRESCITA-PRIMA-DEL-PROSSIMO-LAVORO
ok    REQ-IDX-008-RIENTRO-E-BANDA-STABILE
ok    REQ-IDX-008-QUOTE-DINAMICHE-E-SERIE-INDIPENDENTI
ok    REQ-IDX-008-ARROTONDAMENTO-E-LIMITI-ARITMETICI
ok    REQ-IDX-008-RIFIUTI-PRIMA-DEGLI-EFFETTI
ok    REQ-IDX-008-PREFLIGHT-DELLA-SOLA-TRANSIZIONE
  Modo indice: 10000 decisioni, 0 byte Lisp osservati.
ok    REQ-IDX-008-FINESTRA-SENZA-ALLOCAZIONE
8 test del modo automatico superati.
ok    REQ-IDX-009-FIXTURE-INDIPENDENTI-TRE-TAGLIE-E-TIPI
ok    REQ-IDX-009-COLLISIONI-OVERFLOW-E-SATURAZIONE
ok    REQ-IDX-009-DIRECTORY-RADIX-E-MASSIMI
ok    REQ-IDX-009-IDENTITA-COPIATA-E-RIFERIMENTI-ATTESI
ok    REQ-IDX-009-PREFLIGHT-SENZA-EFFETTI
ok    REQ-IDX-009-DOMINI-DESCRITTORE
ok    REQ-IDX-009-INTERI-GRANDI-E-GEOMETRIA-ALLINEATA
ok    REQ-IDX-009-RECORD-AI-LIMITI-V2
ok    REQ-IDX-009-CORRUZIONE-OGNI-BYTE-PAGINA-4K
ok    REQ-IDX-009-HEADER-E-CRC-VALIDI-NON-BASTANO
ok    REQ-IDX-009-SLOT-E-CHIAVI-SEMANTICAMENTE-INCOERENTI
ok    REQ-IDX-009-RIFERIMENTI-DIRECTORY-NON-CANONICI
ok    REQ-IDX-009-TRONCAMENTI-E-GUARDIE
ok    REQ-IDX-009-CHIAVE-MASSIMA-FRAMMENTATA
ok    REQ-IDX-009-CHIAVI-INLINE-ESTERNE-E-ARENA-ESATTA
ok    REQ-IDX-009-CODA-CHIAVE-E-CATENA-INVALIDE
ok    REQ-IDX-009-SPLIT-DIRECTORY-E-BUCKET-IMMUTABILI
ok    REQ-IDX-009-RIFERIMENTI-ESTERNI-E-IDENTITA-ALLINEATA
ok    REQ-IDX-009-CACHE-HIT-COPIE-PRIVATE-E-RIUSO-LIMITATO
ok    REQ-IDX-009-CACHE-IDENTITA-COMPLETA-E-FALLIMENTO-NON-PUBBLICATO
ok    REQ-IDX-009-CACHE-CORRUZIONE-SHORT-READ-E-RIPRESA
ok    REQ-IDX-009-CACHE-PREFLIGHT-OWNER-RIENTRO-E-NONLOCAL
ok    REQ-IDX-009-CACHE-DOMINI-E-BUDGET
ok    REQ-IDX-009-CACHE-FILE-PREAD-CORTO-E-LIFETIME
ok    REQ-IDX-009-CACHE-FIFO-DUE-FRAME
ok    REQ-IDX-009-LOOKUP-INLINE-TRE-TAGLIE-COLLISIONI-E-ASSENZA
ok    REQ-IDX-009-LOOKUP-DIRECTORY-MULTILIVELLO-E-OVERFLOW
ok    REQ-IDX-009-LOOKUP-RADIX-CONFINI-U32
ok    REQ-IDX-009-LOOKUP-CHIAVE-MASSIMA-ESTERNA-CACHE-UN-FRAME
ok    REQ-IDX-009-LOOKUP-BUDGET-PAGINE-BYTE-E-RIPRISTINO
ok    REQ-IDX-009-CACHE-CURSORE-PRIVATO-NON-ALTERA-IDENTITA-FRAME
ok    REQ-IDX-001-LOOKUP-DIFFERENZIALE-PRIMARIO-RESIDENTE
ok    REQ-IDX-009-LOOKUP-CORRUZIONI-TRAPAGINE-E-OUTPUT-INTATTO
ok    REQ-IDX-009-LOOKUP-IO-CRC-E-NONLOCAL-SENZA-RISULTATO
ok    REQ-IDX-009-LOOKUP-PREFLIGHT-OWNER-RIENTRO-E-BUDGET-FACTORY
ok    REQ-IDX-009-LOOKUP-EMPTY-PRIMA-CANDIDATO-NELLO-STESSO-GRUPPO
ok    REQ-IDX-009-LOOKUP-BUDGET-ESATTO-E-FACTORY-MASSIMA
ok    REQ-IDX-009-LOOKUP-DIGEST-COMPLETO-ALIAS-E-CSN-PAROLE
ok    REQ-IDX-009-LOOKUP-TOTALE-CHIAVE-ESTERNO-INCOERENTE
ok    REQ-IDX-009-COSTRUZIONE-SPAN-COPIA-RANGE-E-METADATI
ok    REQ-IDX-009-COSTRUZIONE-BUCKET-ROUNDTRIP-TRE-TAGLIE
ok    REQ-IDX-009-COSTRUZIONE-CHIAVI-MASSIME-MISTE-E-OVERFLOW
ok    REQ-IDX-009-COSTRUZIONE-DIRECTORY-ROUTING-MULTILIVELLO
ok    REQ-IDX-009-COSTRUZIONE-PREFLIGHT-DUPLICATI-CAPIENZA-E-BUDGET
ok    REQ-IDX-009-COSTRUZIONE-FAIL-STOP-SHORT-WRITE-E-NONLOCAL
ok    REQ-IDX-009-COSTRUZIONE-DIRECTORY-PREFLIGHT-OWNER-ROUTING-ORDINE
ok    REQ-IDX-009-COSTRUZIONE-CONFINI-PREFLIGHT-OWNER-E-RIENTRO
ok    REQ-IDX-009-COSTRUZIONE-INTERRUZIONE-OGNI-FRONTIERA-CHIAVE
ok    REQ-IDX-009-COSTRUZIONE-FILE-APPEND-FLUSH-RIAPERTURA-READONLY
ok    REQ-IDX-009-COSTRUZIONE-CONFIGURAZIONE-E-CANDIDATI-INCOERENTI
ok    REQ-IDX-009-COSTRUZIONE-BUCKET-PIENO-COLLISIONI-GRUPPI
ok    REQ-IDX-009-COSTRUZIONE-DIRECTORY-CAMPO-A-CAVALLO-U32
ok    REQ-IDX-009-COSTRUZIONE-QUOTA-FILE-E-IDENTITA-SENZA-WRAP
ok    REQ-IDX-010-CONTAINER-TRE-TAGLIE-CHIAVI-MASSIME-E-PUBBLICAZIONE
ok    REQ-IDX-010-FOOTER-ORACOLO-INDIPENDENTE
ok    REQ-IDX-010-FOOTER-FONTE-SEME-VERSIONE-E-RISERVATI
ok    REQ-IDX-010-DUPLICATI-GLOBALI-PAYLOAD-IDENTICO-RIFIUTATI
ok    REQ-IDX-010-AUTORITA-CONTEGGIO-E-BUDGET-CUMULATIVO
ok    REQ-IDX-010-INTERRUZIONI-SIGILLO-E-RIAPERTURA-SENZA-ACK
ok    REQ-IDX-010-ADOZIONE-PRESERVA-ROOT-E-INVALIDAZIONE-FONTE
ok    REQ-IDX-010-ENTRY-IRRAGGIUNGIBILI-E-COPERTURA-MANCANTE
ok    REQ-IDX-010-PAGINA-VALIDA-DIGEST-FALSO
ok    REQ-IDX-010-FONTE-VUOTA-E-TIPO-ROOT-ERRATO
ok    REQ-IDX-010-ARCHI-VUOTI-VERIFICATI-SENZA-QUERY-ENTRY
ok    REQ-IDX-010-FOOTER-CRC-VERSIONE-PREFISSO-E-FILE-INCOMPLETO
ok    REQ-IDX-010-SIGILLO-FILE-ESATTO-VECCHIA-ROOT-E-OSSERVATORE
ok    REQ-IDX-010-RECOVERY-DIRECTORY-MULTILIVELLO-E-OVERFLOW
ok    REQ-IDX-010-FLUSH-FALLITO-E-NESSUNA-PROVA-ADOTTABILE
ok    REQ-IDX-010-CONFIGURAZIONE-FONTE-RECOVERY-E-LIFETIME
IMAGE-CRASH-READY :BEFORE-FOOTER
IMAGE-CHILD write before-footer status=:SIGNALED code=9
IMAGE-RESTART-VERIFIED :BEFORE-FOOTER
IMAGE-CHILD verify before-footer status=:EXITED code=0
IMAGE-CRASH-READY :AFTER-FOOTER
IMAGE-CHILD write after-footer status=:SIGNALED code=9
IMAGE-RESTART-VERIFIED :AFTER-FOOTER
IMAGE-CHILD verify after-footer status=:EXITED code=0
IMAGE-CRASH-READY :AFTER-FLUSH
IMAGE-CHILD write after-flush status=:SIGNALED code=9
IMAGE-RESTART-VERIFIED :AFTER-FLUSH
IMAGE-CHILD verify after-flush status=:EXITED code=0
ok    REQ-IDX-010-SIGKILL-PRIMA-DOPO-FOOTER-FLUSH-E-RECOVERY-READONLY
70 test delle pagine indice superati.
CHILD v1 write-COMMITTED status=:SIGNALED code=9
CRASH-READY :COMMITTED pid=85760
CHILD v1 recover-COMMITTED status=:EXITED code=0
VERIFIED v1 :COMMITTED recovery=T closed=1 originals-unchanged=1
CHILD v1 verify-COMMITTED status=:EXITED code=0
VERIFIED v1 :COMMITTED recovery=NIL closed=1 originals-unchanged=2
VERTICAL v1 :COMMITTED PASS
CHILD v1 write-TAIL status=:SIGNALED code=9
CRASH-READY :TAIL pid=85781
CHILD v1 recover-TAIL status=:EXITED code=0
VERIFIED v1 :TAIL recovery=T closed=1 originals-unchanged=1
CHILD v1 verify-TAIL status=:EXITED code=0
VERIFIED v1 :TAIL recovery=NIL closed=1 originals-unchanged=2
VERTICAL v1 :TAIL PASS
CHILD v1 write-PREPARED status=:SIGNALED code=9
CRASH-READY :CHECKPOINT-PREPARED pid=85817
CHILD v1 recover-PREPARED status=:EXITED code=0
VERIFIED v1 :PREPARED recovery=T closed=1 originals-unchanged=2
CHILD v1 verify-PREPARED status=:EXITED code=0
VERIFIED v1 :PREPARED recovery=NIL closed=1 originals-unchanged=3
VERTICAL v1 :PREPARED PASS
CHILD v1 write-ROTATED status=:SIGNALED code=9
CRASH-READY :ROTATED pid=85824
CHILD v1 recover-ROTATED status=:EXITED code=0
VERIFIED v1 :ROTATED recovery=T closed=2 originals-unchanged=2
CHILD v1 verify-ROTATED status=:EXITED code=0
VERIFIED v1 :ROTATED recovery=NIL closed=2 originals-unchanged=3
VERTICAL v1 :ROTATED PASS
CHILD v2 write-COMMITTED status=:SIGNALED code=9
CRASH-READY :COMMITTED pid=85830
CHILD v2 recover-COMMITTED status=:EXITED code=0
VERIFIED v2 :COMMITTED recovery=T closed=1 originals-unchanged=1
CHILD v2 verify-COMMITTED status=:EXITED code=0
VERIFIED v2 :COMMITTED recovery=NIL closed=1 originals-unchanged=2
VERTICAL v2 :COMMITTED PASS
CHILD v2 write-TAIL status=:SIGNALED code=9
CRASH-READY :TAIL pid=85837
CHILD v2 recover-TAIL status=:EXITED code=0
VERIFIED v2 :TAIL recovery=T closed=1 originals-unchanged=1
CHILD v2 verify-TAIL status=:EXITED code=0
VERIFIED v2 :TAIL recovery=NIL closed=1 originals-unchanged=2
VERTICAL v2 :TAIL PASS
CHILD v2 write-PREPARED status=:SIGNALED code=9
CRASH-READY :CHECKPOINT-PREPARED pid=85855
CHILD v2 recover-PREPARED status=:EXITED code=0
VERIFIED v2 :PREPARED recovery=T closed=1 originals-unchanged=2
CHILD v2 verify-PREPARED status=:EXITED code=0
VERIFIED v2 :PREPARED recovery=NIL closed=1 originals-unchanged=3
VERTICAL v2 :PREPARED PASS
CHILD v2 write-ROTATED status=:SIGNALED code=9
CRASH-READY :ROTATED pid=85896
CHILD v2 recover-ROTATED status=:EXITED code=0
VERIFIED v2 :ROTATED recovery=T closed=2 originals-unchanged=2
CHILD v2 verify-ROTATED status=:EXITED code=0
VERIFIED v2 :ROTATED recovery=NIL closed=2 originals-unchanged=3
VERTICAL v2 :ROTATED PASS
ok    test-REQ-REC-001-vertical-native-SIGKILL-reopen-v1-v2
CHILD v2 write-COMMITTED status=:SIGNALED code=9
CRASH-READY :COMMITTED pid=85925
CHILD v2 recover-COMMITTED status=:EXITED code=0
VERIFIED v2 :COMMITTED recovery=T closed=1 originals-unchanged=1
CHILD v2 verify-COMMITTED status=:EXITED code=0
VERIFIED v2 :COMMITTED recovery=NIL closed=1 originals-unchanged=2
CHILD v2 verify-wrong-COMMITTED status=:EXITED code=1
VERTICAL-FAIL ORACLE-VALUE-MISMATCH: VERTICAL-ORACLE-MISMATCH: valore diverso dall'atteso indipendente.
ok    test-REQ-VAL-001-vertical-oracle-rejects-wrong-value
CHILD v1 write-COMMITTED status=:SIGNALED code=9
CRASH-READY :COMMITTED pid=85960
CHILD v1 recover-COMMITTED status=:EXITED code=0
VERIFIED v1 :COMMITTED recovery=T closed=1 originals-unchanged=1
CHILD v1 resume-COMMITTED status=:SIGNALED code=9
RESUMED v1 :COMMITTED base=5 last=9 H=9
CRASH-READY :RESUMED pid=85982
CHILD v1 recover-resumed-COMMITTED status=:EXITED code=0
REVERIFIED v1 :COMMITTED recovery=T last=9 originals-unchanged=3
CHILD v1 verify-resumed-COMMITTED status=:EXITED code=0
REVERIFIED v1 :COMMITTED recovery=NIL last=9 originals-unchanged=4
VERTICAL-RESUME v1 :COMMITTED PASS
CHILD v1 write-TAIL status=:SIGNALED code=9
CRASH-READY :TAIL pid=86018
CHILD v1 recover-TAIL status=:EXITED code=0
VERIFIED v1 :TAIL recovery=T closed=1 originals-unchanged=1
CHILD v1 resume-TAIL status=:SIGNALED code=9
RESUMED v1 :TAIL base=5 last=9 H=9
CRASH-READY :RESUMED pid=86045
CHILD v1 recover-resumed-TAIL status=:EXITED code=0
REVERIFIED v1 :TAIL recovery=T last=9 originals-unchanged=3
CHILD v1 verify-resumed-TAIL status=:EXITED code=0
REVERIFIED v1 :TAIL recovery=NIL last=9 originals-unchanged=4
VERTICAL-RESUME v1 :TAIL PASS
CHILD v1 write-PREPARED status=:SIGNALED code=9
CRASH-READY :CHECKPOINT-PREPARED pid=86082
CHILD v1 recover-PREPARED status=:EXITED code=0
VERIFIED v1 :PREPARED recovery=T closed=1 originals-unchanged=2
CHILD v1 resume-PREPARED status=:SIGNALED code=9
RESUMED v1 :PREPARED base=5 last=9 H=9
CRASH-READY :RESUMED pid=86116
CHILD v1 recover-resumed-PREPARED status=:EXITED code=0
REVERIFIED v1 :PREPARED recovery=T last=9 originals-unchanged=4
CHILD v1 verify-resumed-PREPARED status=:EXITED code=0
REVERIFIED v1 :PREPARED recovery=NIL last=9 originals-unchanged=5
VERTICAL-RESUME v1 :PREPARED PASS
CHILD v1 write-ROTATED status=:SIGNALED code=9
CRASH-READY :ROTATED pid=86159
CHILD v1 recover-ROTATED status=:EXITED code=0
VERIFIED v1 :ROTATED recovery=T closed=2 originals-unchanged=2
CHILD v1 resume-ROTATED status=:SIGNALED code=9
RESUMED v1 :ROTATED base=8 last=12 H=12
CRASH-READY :RESUMED pid=86199
CHILD v1 recover-resumed-ROTATED status=:EXITED code=0
REVERIFIED v1 :ROTATED recovery=T last=12 originals-unchanged=4
CHILD v1 verify-resumed-ROTATED status=:EXITED code=0
REVERIFIED v1 :ROTATED recovery=NIL last=12 originals-unchanged=5
VERTICAL-RESUME v1 :ROTATED PASS
CHILD v2 write-COMMITTED status=:SIGNALED code=9
CRASH-READY :COMMITTED pid=86231
CHILD v2 recover-COMMITTED status=:EXITED code=0
VERIFIED v2 :COMMITTED recovery=T closed=1 originals-unchanged=1
CHILD v2 resume-COMMITTED status=:SIGNALED code=9
RESUMED v2 :COMMITTED base=5 last=9 H=9
CRASH-READY :RESUMED pid=86255
CHILD v2 recover-resumed-COMMITTED status=:EXITED code=0
REVERIFIED v2 :COMMITTED recovery=T last=9 originals-unchanged=3
CHILD v2 verify-resumed-COMMITTED status=:EXITED code=0
REVERIFIED v2 :COMMITTED recovery=NIL last=9 originals-unchanged=4
VERTICAL-RESUME v2 :COMMITTED PASS
CHILD v2 write-TAIL status=:SIGNALED code=9
CRASH-READY :TAIL pid=86305
CHILD v2 recover-TAIL status=:EXITED code=0
VERIFIED v2 :TAIL recovery=T closed=1 originals-unchanged=1
CHILD v2 resume-TAIL status=:SIGNALED code=9
RESUMED v2 :TAIL base=5 last=9 H=9
CRASH-READY :RESUMED pid=86343
CHILD v2 recover-resumed-TAIL status=:EXITED code=0
REVERIFIED v2 :TAIL recovery=T last=9 originals-unchanged=3
CHILD v2 verify-resumed-TAIL status=:EXITED code=0
REVERIFIED v2 :TAIL recovery=NIL last=9 originals-unchanged=4
VERTICAL-RESUME v2 :TAIL PASS
CHILD v2 write-PREPARED status=:SIGNALED code=9
CRASH-READY :CHECKPOINT-PREPARED pid=86399
CHILD v2 recover-PREPARED status=:EXITED code=0
VERIFIED v2 :PREPARED recovery=T closed=1 originals-unchanged=2
CHILD v2 resume-PREPARED status=:SIGNALED code=9
RESUMED v2 :PREPARED base=5 last=9 H=9
CRASH-READY :RESUMED pid=86439
CHILD v2 recover-resumed-PREPARED status=:EXITED code=0
REVERIFIED v2 :PREPARED recovery=T last=9 originals-unchanged=4
CHILD v2 verify-resumed-PREPARED status=:EXITED code=0
REVERIFIED v2 :PREPARED recovery=NIL last=9 originals-unchanged=5
VERTICAL-RESUME v2 :PREPARED PASS
CHILD v2 write-ROTATED status=:SIGNALED code=9
CRASH-READY :ROTATED pid=86496
CHILD v2 recover-ROTATED status=:EXITED code=0
VERIFIED v2 :ROTATED recovery=T closed=2 originals-unchanged=2
CHILD v2 resume-ROTATED status=:SIGNALED code=9
RESUMED v2 :ROTATED base=8 last=12 H=12
CRASH-READY :RESUMED pid=86526
CHILD v2 recover-resumed-ROTATED status=:EXITED code=0
REVERIFIED v2 :ROTATED recovery=T last=12 originals-unchanged=4
CHILD v2 verify-resumed-ROTATED status=:EXITED code=0
REVERIFIED v2 :ROTATED recovery=NIL last=12 originals-unchanged=5
VERTICAL-RESUME v2 :ROTATED PASS
ok    test-REQ-REC-001-vertical-resume-writes-second-SIGKILL-v1-v2
CHILD v2 write-ROTATED status=:SIGNALED code=9
CRASH-READY :ROTATED pid=86598
CHILD v2 recover-ROTATED status=:EXITED code=0
VERIFIED v2 :ROTATED recovery=T closed=2 originals-unchanged=2
CHILD v2 resume-wrong-csn-ROTATED status=:EXITED code=1
REJECTED-CSN-BEFORE-APPEND
VERTICAL-FAIL ORACLE-CSN-MISMATCH: VERTICAL-CSN-MISMATCH: atteso 9, osservato 1.
ok    test-REQ-VAL-001-vertical-oracle-rejects-reused-CSN
4 test verticali superati; 16 scenari positivi e 2 controlli negativi.
ok    TEST-REQ-AFF-001-PRODUCTION-PREFLIGHT-INDEX-FAULT-CLOSES-ADMISSION
ok    TEST-REQ-LIM-003-PRODUCTION-INDEX-LOAD-REJECTS-BEFORE-COMMIT
ok    TEST-REQ-LIM-003-PRODUCTION-KEY-ARENA-REJECTS-BEFORE-COMMIT
ok    TEST-REQ-VAL-001-PRODUCTION-IMAGE-ORACLE-PERMITS-ONLY-EXACT-FINAL-RENAME
ok    TEST-REQ-REC-001-PRODUCTION-STARTUP-RECOVERY-ADMISSION-V1-V2
ok    TEST-REQ-AFF-001-PRODUCTION-EXCLUSIVE-OWNER-AND-CLOSE
ok    TEST-REQ-REC-001-PRODUCTION-INIT-EXPLICIT-AND-EXISTING-DATA-PRESERVED
ok    TEST-REQ-REC-001-PRODUCTION-STARTUP-FAULT-RELEASES-LOCK-AND-PRESERVES-CAUSE
ok    TEST-REQ-WAL-006-PRODUCTION-WRITE-FAULT-TERMINAL-NO-CONFIRMATION
ok    TEST-REQ-FOR-004-PRODUCTION-CORRUPTION-NO-ADMISSION-NO-REWRITE
ok    TEST-REQ-MVC-005-PRODUCTION-DECREASING-CSN-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-REC-001-PRODUCTION-ORPHAN-CONFLICT-BEFORE-EFFECTS
ok    TEST-REQ-AFF-004-PRODUCTION-CLEANUP-PRESERVES-PRIMARY-AND-ATTEMPTS-ALL
ok    TEST-REQ-IDX-010-STARTUP-PAGINATO-GET-E-RITIRO-PUT-DELETE
ok    TEST-REQ-IDX-010-FONTE-VUOTA-TOMBSTONE-CHECKPOINT-STABILE
ok    TEST-REQ-IDX-010-CANDIDATO-OBSOLETO-RIFIUTATO-SENZA-FALLBACK
ok    TEST-REQ-IDX-010-CANDIDATO-FALSO-CON-FONTE-ESATTA
ok    TEST-REQ-IDX-010-CONFIGURAZIONE-E-BUDGET-IMMAGINE
ok    TEST-REQ-IDX-010-PREFLIGHT-CAPIENZA-CONSERVA-PAGINATO
ok    TEST-REQ-IDX-010-GET-USA-PAGINATO-E-NON-RESIDENTE
ok    TEST-REQ-IDX-010-FALLIMENTO-STARTUP-DOPO-ADOZIONE-RILASCIA-RISORSE
ok    TEST-REQ-IDX-010-FILE-CHIUSO-ANCHE-CON-CACHE-CALDA-NESSUN-FALLBACK
ok    TEST-REQ-IDX-010-DECISIONI-FONTE-VALIDATORE-E-FASE
ENGINE-CRASH-READY :BEFORE-INDEX-IMAGE
(:KIND :ENGINE-CHILD :MODE \"image-startup\" :FORMAT 1 :STAGE
 \"before-index-image\" :STATUS :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v1 image-verify before-index-image
(:KIND :ENGINE-CHILD :MODE \"image-verify\" :FORMAT 1 :STAGE \"before-index-image\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-READY
(:KIND :ENGINE-CHILD :MODE \"image-startup\" :FORMAT 1 :STAGE \"index-image-ready\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v1 image-verify index-image-ready
(:KIND :ENGINE-CHILD :MODE \"image-verify\" :FORMAT 1 :STAGE \"index-image-ready\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"image-write\" :FORMAT 1 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v1 image-reject after-flush
(:KIND :ENGINE-CHILD :MODE \"image-reject\" :FORMAT 1 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-INDEX-IMAGE
(:KIND :ENGINE-CHILD :MODE \"image-startup\" :FORMAT 2 :STAGE
 \"before-index-image\" :STATUS :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v2 image-verify before-index-image
(:KIND :ENGINE-CHILD :MODE \"image-verify\" :FORMAT 2 :STAGE \"before-index-image\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-READY
(:KIND :ENGINE-CHILD :MODE \"image-startup\" :FORMAT 2 :STAGE \"index-image-ready\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v2 image-verify index-image-ready
(:KIND :ENGINE-CHILD :MODE \"image-verify\" :FORMAT 2 :STAGE \"index-image-ready\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"image-write\" :FORMAT 2 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
ENGINE-IMAGE-VERIFIED v2 image-reject after-flush
(:KIND :ENGINE-CHILD :MODE \"image-reject\" :FORMAT 2 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-SIGKILL-ADOZIONE-E-PRIMA-SCRITTURA-V1-V2
ok    TEST-REQ-IDX-010-BUILD-END-TO-END-V1-V2-TRE-TAGLIE
ok    TEST-REQ-IDX-010-BUILD-VUOTO-TOMBSTONE-E-CHIAVE-MASSIMA
ok    TEST-REQ-IDX-010-BUILD-600-CHIAVI-DIRECTORY-TRE-TAGLIE
ok    TEST-REQ-IDX-010-BUILD-PREFISSO-COMUNE-E-DIRECTORY-MULTILIVELLO
ok    TEST-REQ-IDX-010-BUILD-PREFLIGHT-BUDGET-NOME-E-OWNERSHIP
ok    TEST-REQ-IDX-010-BUILD-QUOTA-FILE-PAGINE-E-VERIFICA-FALLITA
ok    TEST-REQ-IDX-010-BUILD-USCITA-NON-LOCALE-E-RIENTRO
ok    TEST-REQ-IDX-010-BUILD-RADIX-U64-DUPLICATI-E-OVERFLOW-FORZATO
ok    TEST-REQ-IDX-010-BUILD-RILEVA-MUTAZIONE-FONTE-E-CONTEGGIO
ok    TEST-REQ-IDX-010-BUILD-CLEANUP-TENTA-ENTRAMBI-I-CLOSE
ok    TEST-REQ-IDX-010-BUILD-CAUSA-IO-PRESERVATA-DAL-CONFINE
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 1 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-created v1
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 1 :STAGE
 \"image-build-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-PAGES
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 1 :STAGE \"image-build-pages\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-pages v1
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 1 :STAGE \"image-build-pages\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 1 :STAGE
 \"image-build-after-flush\" :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-after-flush v1
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 1 :STAGE
 \"image-build-after-flush\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 2 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-created v2
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 2 :STAGE
 \"image-build-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-PAGES
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 2 :STAGE \"image-build-pages\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-pages v2
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 2 :STAGE \"image-build-pages\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"build-image\" :FORMAT 2 :STAGE
 \"image-build-after-flush\" :STATUS :SIGNALED :CODE 9)
ENGINE-BUILD-VERIFIED build-verify image-build-after-flush v2
(:KIND :ENGINE-CHILD :MODE \"build-verify\" :FORMAT 2 :STAGE
 \"image-build-after-flush\" :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-BUILD-SIGKILL-V1-V2-CREAZIONE-PAGINE-FLUSH
ok    TEST-REQ-IDX-010-ACTIVATE-V1-V2-TRE-TAGLIE-SOSTITUZIONE-E-RITIRO
ok    TEST-REQ-IDX-010-ACTIVATE-STARTUP-OWNERSHIP-E-PREFLIGHT-SCRITTURA
ok    TEST-REQ-IDX-010-ACTIVATE-QUOTA-TRANSITORIA-E-THREAD
ok    TEST-REQ-IDX-010-ACTIVATE-CANDIDATO-RIFIUTATO-CONSERVA-ROOT-E-CHIUDE-LOCALE
ok    TEST-REQ-IDX-010-ACTIVATE-NONLOCAL-PRIMA-DOPO-SWAP-E-RIENTRO
ok    TEST-REQ-IDX-010-ACTIVATE-FONTE-MUTATA-E-CAUSA-IO-DOPO-SWAP
ok    TEST-REQ-IDX-010-ACTIVATE-CLOSE-FALLITO-DOPO-TRASFERIMENTO-E-RITIRO
ok    TEST-REQ-IDX-010-ACTIVATE-GUARDIE-BINDING-E-STARTUP
ok    TEST-REQ-IDX-010-ACTIVATE-CLOSE-AL-PRIMO-PUT-FALLISCE-PRIMA-DEL-WAL
ENGINE-CRASH-READY :BEFORE-IMAGE-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 1 :STAGE
 \"before-image-publication\" :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED before-image-publication v1
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 1 :STAGE
 \"before-image-publication\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED image-published v1
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 1 :STAGE \"after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED after-flush v1
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 1 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-IMAGE-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 2 :STAGE
 \"before-image-publication\" :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED before-image-publication v2
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 2 :STAGE
 \"before-image-publication\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED image-published v2
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"activate-run\" :FORMAT 2 :STAGE \"after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-ACTIVATION-VERIFIED after-flush v2
(:KIND :ENGINE-CHILD :MODE \"activate-verify\" :FORMAT 2 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-ACTIVATE-SIGKILL-SWAP-E-PRIMA-SCRITTURA-V1-V2
ok    TEST-REQ-IDX-010-DELTA-PUT-DELETE-RESURRECTION-V1-V2-TRE-TAGLIE
ok    TEST-REQ-IDX-010-DELTA-KEY-AND-BYTE-QUOTA-NO-WAL-EFFECTS
ok    TEST-REQ-IDX-010-DELTA-PREFLIGHT-CONFIGURATION-AND-DOUBLE-RESERVATION
ok    TEST-REQ-IDX-010-DELTA-COLLISION-EXACT-KEY-SPAN-AND-COPY
ok    TEST-REQ-IDX-010-DELTA-ADMITTED-FAILURE-AND-PREFLIGHT-INVARIANT
ENGINE-CRASH-READY :BEFORE-APPEND
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 1 :STAGE \"before-append\"
 :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v1 before-append
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 1 :STAGE \"before-append\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 1 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
DELTA-VERIFIED v1 after-flush
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 1 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 1 :STAGE \"after-commit\"
 :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v1 after-commit
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 1 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-APPEND
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 2 :STAGE \"before-append\"
 :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v2 before-append
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 2 :STAGE \"before-append\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 2 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
DELTA-VERIFIED v2 after-flush
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 2 :STAGE \"after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 2 :STAGE \"after-commit\"
 :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v2 after-commit
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 2 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-DELTA-SIGKILL-REPLAY-CANONICO-V1-V2
ok    TEST-REQ-IDX-010-DELTA-PUBLICATION-OWNERSHIP-AND-ADMISSION-GUARDS
ok    TEST-REQ-IDX-011-LOCATION-DELTA-EXACT-PAYLOAD-AND-LAYOUT
ok    TEST-REQ-IDX-011-LOCATION-DELTA-FULL-WIDTH-PUBLICATION-AND-GUARDS
ok    TEST-REQ-IDX-011-PAGED-GET-INDEPENDENT-OF-RESIDENT-TABLE-AND-HANDLE
ok    TEST-REQ-IDX-011-LOCATION-DELTA-INVALID-STATE-FIELDS-NO-FALLBACK
ok    TEST-REQ-IDX-011-LOCATION-DELTA-DIFFERENTIAL-RENEWAL-AND-RESTART
ENGINE-CRASH-READY :BEFORE-DELTA-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 1 :STAGE
 \"before-delta-publication\" :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v1 before-delta-publication
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 1 :STAGE
 \"before-delta-publication\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-DELTA-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 1 :STAGE
 \"after-delta-publication\" :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v1 after-delta-publication
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 1 :STAGE
 \"after-delta-publication\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-DELTA-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 2 :STAGE
 \"before-delta-publication\" :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v2 before-delta-publication
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 2 :STAGE
 \"before-delta-publication\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-DELTA-PUBLICATION
(:KIND :ENGINE-CHILD :MODE \"delta-write\" :FORMAT 2 :STAGE
 \"after-delta-publication\" :STATUS :SIGNALED :CODE 9)
DELTA-VERIFIED v2 after-delta-publication
(:KIND :ENGINE-CHILD :MODE \"delta-verify\" :FORMAT 2 :STAGE
 \"after-delta-publication\" :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-011-LOCATION-DELTA-SIGKILL-PUBLICATION-V1-V2
ok    TEST-REQ-IDX-011-LOCATION-DELTA-COMPLETE-OLD-AND-NEW-RESERVATION
ok    TEST-REQ-IDX-011-LOCATION-DELTA-PUBLICATION-FIELD-DOMAINS
ok    TEST-REQ-IDX-011-LOCATION-DELTA-CORRUPT-GEOMETRY-AND-PREFLIGHT
ok    TEST-REQ-IDX-011-LOCATION-DELTA-INJECTED-ERROR-NO-ACK-AND-RECOVERY
ok    TEST-REQ-IDX-010-RENEW-V1-V2-TRE-TAGLIE-FONTE-DELTA-E-RESTART
ok    TEST-REQ-IDX-010-RENEW-CICLI-QUOTA-E-DISABILITAZIONE
ok    TEST-REQ-IDX-010-RENEW-PREFLIGHT-INTERO-PICCO-NOME-E-OWNER
ok    TEST-REQ-IDX-010-RENEW-BUSY-CONTINUO-E-CALLBACK-NON-RIENTRANTI
ok    TEST-REQ-IDX-010-RENEW-USCITE-INCOMPLETE-OWNERSHIP-PRIMA-E-DOPO-SWAP
ok    TEST-REQ-IDX-010-RENEW-FONTE-E-REVISIONE-RICONTROLLATE-TRA-LE-FASI
ok    TEST-REQ-IDX-010-RENEW-QUOTA-PAGINE-TARDIVA-E-POSTCONDIZIONI
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 1 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v1 image-build-created
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 1 :STAGE
 \"image-build-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-RENEWAL-BUILT
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 1 :STAGE \"image-renewal-built\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v1 image-renewal-built
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 1 :STAGE
 \"image-renewal-built\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v1 image-published
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 2 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v2 image-build-created
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 2 :STAGE
 \"image-build-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-RENEWAL-BUILT
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 2 :STAGE \"image-renewal-built\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v2 image-renewal-built
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 2 :STAGE
 \"image-renewal-built\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"renew-write\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
RENEWAL-VERIFIED v2 image-published
(:KIND :ENGINE-CHILD :MODE \"renew-verify\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-RENEW-SIGKILL-PRIMA-E-DOPO-PUBBLICAZIONE-V1-V2
ok    TEST-REQ-IDX-010-RENEW-CHIAVI-LUNGHE-PREFISSO-COMUNE-V1-V2
ok    TEST-REQ-IDX-010-RENEW-CONDIZIONE-ORIGINALE-CONSERVATA
ok    TEST-REQ-IDX-010-MAINTAIN-POLICY-DOMINI-SOGLIE-ARROTONDAMENTO
ok    TEST-REQ-IDX-010-MAINTAIN-NOOP-E-RINNOVO-QUOTE-PRESERVATE-V1-V2
ok    TEST-REQ-IDX-010-MAINTAIN-SOGLIA-BYTE-PREFLIGHT-NOME-E-MEMORIA
ok    TEST-REQ-IDX-010-MAINTAIN-GUARDIE-E-CONTATORI-CORROTTI
ok    TEST-REQ-IDX-010-MAINTAIN-RINNOVO-FALLITO-E-NON-RIENTRABILE
ok    TEST-REQ-IDX-010-MAINTAIN-POLICY-CONDIVISA-DUE-MOTORI-ISOLATI
ok    TEST-REQ-IDX-012-AUTO-CONFIGURATION-DOMAINS-AND-OWNERSHIP
ok    TEST-REQ-IDX-012-AUTO-REPEATED-WRITES-INDEPENDENT-ORACLE-V1-V2-THREE-PAGE-SIZES
ok    TEST-REQ-IDX-012-AUTO-INDEPENDENT-THRESHOLD-AND-CAPACITY-TRIGGERS
ok    TEST-REQ-IDX-012-AUTO-INVALID-WRITES-PRECEDE-DERIVED-EFFECTS
ok    TEST-REQ-IDX-012-AUTO-RESERVATION-COLLISION-SEQUENCE-AND-ID-ENDPOINT
ok    TEST-REQ-IDX-012-AUTO-DISABLING-AND-INDEPENDENT-ENGINES
ok    TEST-REQ-IDX-012-AUTO-INCOMPLETE-EXITS-PRIMARY-AND-CONTINUOUS-BUSY
ok    TEST-REQ-IDX-012-AUTO-SUCCESS-ONE-ADMISSION-THROUGH-COMMIT
ok    TEST-REQ-IDX-012-AUTO-INTERNAL-ADMISSION-GUARDS-AND-SPECIFIC-CAPACITY-CONDITION
ok    TEST-REQ-IDX-012-AUTO-CORRUPTION-POSTCONDITIONS-AND-LATE-BUDGET
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 1 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v1 image-build-created
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 1 :STAGE \"image-build-created\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v1 image-published
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 1 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTOMATIC-INDEX-RENEWED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 1 :STAGE
 \"automatic-index-renewed\" :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v1 automatic-index-renewed
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 1 :STAGE
 \"automatic-index-renewed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 1 :STAGE \"after-commit\" :STATUS
 :SIGNALED :CODE 9)
AUTO-VERIFIED v1 after-commit
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 1 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-BUILD-CREATED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 2 :STAGE \"image-build-created\"
 :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v2 image-build-created
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 2 :STAGE \"image-build-created\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :IMAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v2 image-published
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 2 :STAGE \"image-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTOMATIC-INDEX-RENEWED
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 2 :STAGE
 \"automatic-index-renewed\" :STATUS :SIGNALED :CODE 9)
AUTO-VERIFIED v2 automatic-index-renewed
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 2 :STAGE
 \"automatic-index-renewed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"auto-write\" :FORMAT 2 :STAGE \"after-commit\" :STATUS
 :SIGNALED :CODE 9)
AUTO-VERIFIED v2 after-commit
(:KIND :ENGINE-CHILD :MODE \"auto-verify\" :FORMAT 2 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-012-AUTO-SIGKILL-AROUND-RENEWAL-AND-DOCUMENT-COMMIT-V1-V2
ok    TEST-REQ-IDX-010-DISCOVER-PROFILI-NOMI-DOMINI-E-QUOTA
ok    TEST-REQ-IDX-010-DISCOVER-V1-V2-TRE-TAGLIE-SCELTA-E-RITIRO
ok    TEST-REQ-IDX-010-DISCOVER-NESSUNO-INCOMPLETI-PROFILI-E-CANONICO
ok    TEST-REQ-IDX-010-DISCOVER-CANDIDATO-SELEZIONATO-VERIFICATO-INTEGRALMENTE-SENZA-RIPIEGO
ok    TEST-REQ-IDX-010-DISCOVER-LIMITI-PRIMA-DI-SCELTA-E-BUDGET-VERIFICA
ok    TEST-REQ-IDX-010-DISCOVER-SOURCE-STATO-E-REVISIONE-PRIMA-DELLA-SCELTA
ok    TEST-REQ-IDX-010-DISCOVER-NONLOCAL-CLOSE-E-SYMLINK-SENZA-FALLBACK
ENGINE-CRASH-READY :INDEX-IMAGE-CANDIDATE
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 1 :STAGE
 \"index-image-candidate\" :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v1 index-image-candidate
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 1 :STAGE
 \"index-image-candidate\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-DISCOVERED
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 1 :STAGE
 \"index-image-discovered\" :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v1 index-image-discovered
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 1 :STAGE
 \"index-image-discovered\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-READY
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 1 :STAGE \"index-image-ready\"
 :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v1 index-image-ready
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 1 :STAGE
 \"index-image-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-CANDIDATE
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 2 :STAGE
 \"index-image-candidate\" :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v2 index-image-candidate
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 2 :STAGE
 \"index-image-candidate\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-DISCOVERED
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 2 :STAGE
 \"index-image-discovered\" :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v2 index-image-discovered
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 2 :STAGE
 \"index-image-discovered\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :INDEX-IMAGE-READY
(:KIND :ENGINE-CHILD :MODE \"discover-run\" :FORMAT 2 :STAGE \"index-image-ready\"
 :STATUS :SIGNALED :CODE 9)
DISCOVERY-VERIFIED v2 index-image-ready
(:KIND :ENGINE-CHILD :MODE \"discover-verify\" :FORMAT 2 :STAGE
 \"index-image-ready\" :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-010-DISCOVER-SIGKILL-PROBE-SCELTA-E-ADOZIONE-V1-V2
ok    TEST-REQ-IDX-010-DISCOVER-FONTE-PRIMA-DEL-NOME-E-IDENTITA-CANONICA
ok    TEST-REQ-IDX-010-DISCOVER-NON-AGGIRA-IL-RECOVERY-CANONICO
ok    TEST-REQ-IDX-010-DISCOVER-GEOMETRIA-OLTRE-LIMITE-SENZA-LETTURA-DEL-PAYLOAD
ok    TEST-REQ-IDX-010-DISCOVER-FENCE-ADOZIONE-E-ADMISSION-ANCHE-ESPLICITA
ok    TEST-REQ-IDX-013-FIT-REMAINS-RESIDENT-WITH-FLAT-SPLITS-AND-NO-INDEX-IO
ok    TEST-REQ-IDX-013-TRANSITIONS-REPLAY-DELETE-AND-RETURN-V1-V2-THREE-PAGE-SIZES
ok    TEST-REQ-IDX-013-GROWTH-PAGES-AND-DELETION-RETURNS-WITHOUT-MANUAL-MODE
ok    TEST-REQ-IDX-013-QUOTA-BOUNDARIES-AND-INVALID-POLICY-PRESERVE-CANONICAL
ok    TEST-REQ-IDX-013-AUTOMATIC-COMPACTION-BOUNDED-HISTORY-AND-CANONICAL-VALUES
ok    TEST-REQ-IDX-013-MAXIMUM-KEY-EXACT-IDENTITY-AND-ABSENT-DELETE
ok    TEST-REQ-IDX-013-INDEX-FAILURE-AFTER-SEAL-NO-ACK-REPLAY-RESTORES-DOCUMENT
ok    TEST-REQ-IDX-013-DERIVED-CORRUPTION-FAILS-WITHOUT-RESIDENT-FALLBACK
ok    TEST-REQ-IDX-013-RESOLVER-METADATA-ONLY-AND-FIXED-CACHE-ACROSS-REOPENS
ok    TEST-REQ-IDX-013-REENTRY-AND-INCOMPLETE-MODE-PUBLICATION-FAIL-STOP
ENGINE-CRASH-READY :AUTO-PAGE-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-page-created\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-page-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"auto-page-created\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-PAGE-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-page-verified\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-page-verified
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"auto-page-verified\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-PAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-page-published\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-page-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"auto-page-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-compact-created\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-compact-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE
 \"auto-compact-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-COPIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-compact-copied\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-compact-copied
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"auto-compact-copied\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE
 \"auto-compact-published\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-compact-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE
 \"auto-compact-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE
 \"auto-resident-created\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-resident-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE
 \"auto-resident-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE
 \"auto-resident-verified\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-resident-verified
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE
 \"auto-resident-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE
 \"auto-resident-published\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-resident-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE
 \"auto-resident-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-APPEND
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"before-append\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 before-append
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"before-append\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
MODE-VERIFIED v1 after-flush
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"after-flush\" :STATUS
 :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-INDEX-UPDATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"auto-index-updated\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v1 auto-index-updated
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"auto-index-updated\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 1 :STAGE \"after-commit\" :STATUS
 :SIGNALED :CODE 9)
MODE-VERIFIED v1 after-commit
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 1 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-PAGE-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-page-created\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-page-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"auto-page-created\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-PAGE-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-page-verified\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-page-verified
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"auto-page-verified\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-PAGE-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-page-published\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-page-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"auto-page-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-compact-created\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-compact-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE
 \"auto-compact-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-COPIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-compact-copied\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-compact-copied
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"auto-compact-copied\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-COMPACT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE
 \"auto-compact-published\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-compact-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE
 \"auto-compact-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-CREATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE
 \"auto-resident-created\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-resident-created
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE
 \"auto-resident-created\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE
 \"auto-resident-verified\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-resident-verified
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE
 \"auto-resident-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-RESIDENT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE
 \"auto-resident-published\" :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-resident-published
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE
 \"auto-resident-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :BEFORE-APPEND
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"before-append\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 before-append
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"before-append\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-FLUSH
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"after-flush\" :STATUS
 :SIGNALED :CODE 9)
MODE-VERIFIED v2 after-flush
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"after-flush\" :STATUS
 :EXITED :CODE 0)
ENGINE-CRASH-READY :AUTO-INDEX-UPDATED
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"auto-index-updated\"
 :STATUS :SIGNALED :CODE 9)
MODE-VERIFIED v2 auto-index-updated
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"auto-index-updated\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"after-commit\" :STATUS
 :SIGNALED :CODE 9)
MODE-VERIFIED v2 after-commit
(:KIND :ENGINE-CHILD :MODE \"mode-verify\" :FORMAT 2 :STAGE \"after-commit\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-IDX-013-SIGKILL-MIGRATIONS-COMPACTION-AND-COMMIT-V1-V2
ok    TEST-REQ-IDX-013-STARTUP-STAMP-CATCHES-ALTERED-PRIVATE-ROOT
ENGINE-CRASH-READY :AFTER-COMMIT
(:KIND :ENGINE-CHILD :MODE \"mode-write\" :FORMAT 2 :STAGE \"after-commit\" :STATUS
 :SIGNALED :CODE 9)
ENGINE-FAIL SIMPLE-ERROR: ENGINE-ORACLE-MISMATCH expected=999 observed=(0 41 0
                                                                        41)
(:KIND :ENGINE-CHILD :MODE \"mode-wrong\" :FORMAT 2 :STAGE \"after-commit\" :STATUS
 :EXITED :CODE 1)
ok    TEST-REQ-IDX-013-PROCESS-ORACLE-DETECTS-WRONG-FRONTIER
ok    TEST-REQ-IDX-013-RETIRED-FILE-CLOSED-AFTER-POSTPUBLICATION-ERROR-OR-NONLOCAL-EXIT
ok    TEST-REQ-IDX-013-INCREASED-GRANT-ON-RESIDENT-HANDLE-PERMITS-NEW-MAINTENANCE-PEAK
ok    TEST-REQ-IDX-013-DISK-INDEPENDENT-RANDOMIZED-MODEL-AND-CACHE-TAIL
ok    TEST-REQ-IDX-013-DISK-FULL-DIGEST-COLLISION-U64-BOUNDARIES-AND-COPY
ok    TEST-REQ-IDX-013-DISK-FIELD-REFERENCE-AND-FIXED-WORK-BOUNDS
ok    TEST-REQ-IDX-013-DISK-PARTIAL-APPEND-FAULTS-BEFORE-ROOT-PUBLICATION
ok    TEST-REQ-IDX-013-REMOVAL-REJECTS-CANONICAL-FOREIGN-REPLACED-SYMLINK-AND-USED-PROOF
ok    TEST-REQ-IDX-013-REMOVAL-MISSING-CALLBACK-AND-CLOSE-ERROR-AGGREGATION
ok    TEST-REQ-IDX-013-CLOSED-CAPABILITY-REJECTED-EVEN-WITH-WARM-CACHE
ok    TEST-REQ-IDX-013-DISK-REJECTS-NONINCREASING-PUT-AND-DELETE-CSN
ok    TEST-REQ-IDX-013-REMOVAL-CALLBACK-ERRORS-CONSUME-PROOF-WITHOUT-RETRY
ok    TEST-REQ-IDX-013-DISK-CACHE-COMPLETE-PARTIAL-AND-FAILED-READ
ok    TEST-REQ-STO-003-LIVE-ROTATION-RECORD-QUOTA-ALL-INDEX-PROFILES-V1-V2
ok    TEST-REQ-STO-003-LIVE-ROTATION-SEGMENT-LIMIT-REFUSES-BEFORE-EFFECTS
ok    TEST-REQ-STO-003-LIVE-ROTATION-BYTE-QUOTA-V1-V2
ok    TEST-REQ-STO-003-LIVE-ROTATION-FAIL-STOP-BEFORE-NEXT-DATA-CSN
ENGINE-CRASH-READY :ROTATION-STARTING
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 1 :STAGE \"rotation-starting\"
 :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v1 rotate-verify rotation-starting
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 1 :STAGE \"rotation-starting\"
 :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v1 rotate-final rotation-starting
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 1 :STAGE \"rotation-starting\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :CHECKPOINT-PREPARED
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 1 :STAGE
 \"checkpoint-prepared\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v1 rotate-verify checkpoint-prepared
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 1 :STAGE
 \"checkpoint-prepared\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v1 rotate-final checkpoint-prepared
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 1 :STAGE
 \"checkpoint-prepared\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :CHECKPOINT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 1 :STAGE
 \"checkpoint-published\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v1 rotate-verify checkpoint-published
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 1 :STAGE
 \"checkpoint-published\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v1 rotate-final checkpoint-published
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 1 :STAGE
 \"checkpoint-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :ROTATION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 1 :STAGE
 \"rotation-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v1 rotate-verify rotation-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 1 :STAGE
 \"rotation-canonical-ready\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v1 rotate-final rotation-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 1 :STAGE
 \"rotation-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :ROTATION-READY
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 1 :STAGE \"rotation-ready\"
 :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v1 rotate-verify rotation-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 1 :STAGE \"rotation-ready\"
 :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v1 rotate-final rotation-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 1 :STAGE \"rotation-ready\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :ROTATION-STARTING
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 2 :STAGE \"rotation-starting\"
 :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v2 rotate-verify rotation-starting
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 2 :STAGE \"rotation-starting\"
 :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v2 rotate-final rotation-starting
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 2 :STAGE \"rotation-starting\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :CHECKPOINT-PREPARED
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 2 :STAGE
 \"checkpoint-prepared\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v2 rotate-verify checkpoint-prepared
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 2 :STAGE
 \"checkpoint-prepared\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v2 rotate-final checkpoint-prepared
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 2 :STAGE
 \"checkpoint-prepared\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :CHECKPOINT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 2 :STAGE
 \"checkpoint-published\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v2 rotate-verify checkpoint-published
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 2 :STAGE
 \"checkpoint-published\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v2 rotate-final checkpoint-published
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 2 :STAGE
 \"checkpoint-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :ROTATION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 2 :STAGE
 \"rotation-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v2 rotate-verify rotation-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 2 :STAGE
 \"rotation-canonical-ready\" :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v2 rotate-final rotation-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 2 :STAGE
 \"rotation-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :ROTATION-READY
(:KIND :ENGINE-CHILD :MODE \"rotate-crash\" :FORMAT 2 :STAGE \"rotation-ready\"
 :STATUS :SIGNALED :CODE 9)
ROTATION-VERIFIED v2 rotate-verify rotation-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-verify\" :FORMAT 2 :STAGE \"rotation-ready\"
 :STATUS :EXITED :CODE 0)
ROTATION-VERIFIED v2 rotate-final rotation-ready
(:KIND :ENGINE-CHILD :MODE \"rotate-final\" :FORMAT 2 :STAGE \"rotation-ready\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-STO-003-LIVE-ROTATION-REAL-SIGKILL-PUBLISH-AND-REOPEN-V1-V2
ok    TEST-REQ-STO-003-LIVE-ROTATION-SEALED-IMAGE-DELTA-AND-AUTO-RENEWAL-V1-V2
ok    TEST-REQ-STO-003-LIVE-ROTATION-NONLOCAL-EXIT-CLOSES-ADMISSION
ok    TEST-REQ-STO-003-LIVE-ROTATION-CORRUPT-CLOSED-REFUSED-BEFORE-CHECKPOINT
ok    TEST-REQ-CMP-001-PRODUCTION-VALUES-SPACE-AND-REOPEN-ALL-INDEX-MODES-V1-V2
ok    TEST-REQ-CMP-001-PRODUCTION-AUTOMATIC-COMPACTION-KEEPS-WRITING-WITH-BOUNDED-FILES
ok    TEST-REQ-CMP-001-PRODUCTION-EMPTY-AND-ALL-DELETED-PRESERVE-CSN-WITHOUT-RESURRECTION
ok    TEST-REQ-CMP-001-PRODUCTION-NO-GAIN-SKIPS-WITH-NO-CANONICAL-OR-FD-CHANGES
ok    TEST-REQ-CMP-001-PRODUCTION-CORRUPT-OUTPUT-REFUSED-BEFORE-CONTROL
ok    TEST-REQ-CMP-001-PRODUCTION-DECLARED-ERRORS-RECOVER-EVERY-MAINTENANCE-PHASE
ok    TEST-REQ-CMP-001-PRODUCTION-NONLOCAL-EXIT-AFTER-RECLAIM-KEEPS-ACKED-DATA
ok    TEST-REQ-CMP-001-PRODUCTION-PAGED-RELOCATION-STALE-AND-NORMAL-CSN-GUARDS
ok    TEST-REQ-CMP-001-PRODUCTION-UNLINK-ERRORS-BEFORE-AND-AFTER-KERNEL-EFFECT
ok    TEST-REQ-CMP-001-PRODUCTION-BORROWED-READER-REFUSES-BEFORE-EFFECTS
ok    TEST-REQ-CMP-001-PRODUCTION-HELD-SNAPSHOT-REFUSES-BEFORE-EFFECTS
ENGINE-CRASH-READY :COMPACTION-PLANNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-planned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-planned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-planned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-planned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRODUCED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-produced\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-produced\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-produced
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-produced\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-verified\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-verified\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-verified
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PUBLISH
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-before-publish
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-before-publish\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-published\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-published
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RELOCATED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-relocated
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-relocated\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-UNLINKED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-unlinked
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-unlinked\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RECLAIMED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-reclaimed
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PRUNE
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-before-prune
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-before-prune\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRUNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"resident--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"resident--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final resident--compaction-pruned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"resident--compaction-pruned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PLANNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-planned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-planned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-planned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-planned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRODUCED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-produced\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-produced\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-produced
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-produced\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-verified\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-verified\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-verified
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PUBLISH
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-before-publish
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-before-publish\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-published\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-published
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RELOCATED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-relocated
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-relocated\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-UNLINKED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-unlinked
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-unlinked\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RECLAIMED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-reclaimed
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PRUNE
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-before-prune
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-before-prune\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRUNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 1 :STAGE
 \"paged--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 1 :STAGE
 \"paged--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v1 compact-final paged--compaction-pruned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 1 :STAGE
 \"paged--compaction-pruned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PLANNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-planned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-planned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-planned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-planned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRODUCED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-produced\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-produced\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-produced
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-produced\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-verified\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-verified\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-verified
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PUBLISH
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-before-publish
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-before-publish\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-published\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-published
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RELOCATED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-relocated
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-relocated\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-UNLINKED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-unlinked
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-unlinked\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RECLAIMED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-reclaimed
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-reclaimed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PRUNE
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-before-prune
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-before-prune\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRUNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"resident--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"resident--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final resident--compaction-pruned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"resident--compaction-pruned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PLANNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-planned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-planned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-planned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-planned\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRODUCED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-produced\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-produced\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-produced
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-produced\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-VERIFIED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-verified\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-verified\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-verified
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-verified\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PUBLISH
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-before-publish\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-before-publish
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-before-publish\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-published\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-published
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-published\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-CANONICAL-READY
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-canonical-ready
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-canonical-ready\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RELOCATED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-relocated\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-relocated
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-relocated\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-UNLINKED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-unlinked\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-unlinked
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-unlinked\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-RECLAIMED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-reclaimed
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-reclaimed\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-BEFORE-PRUNE
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-before-prune\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-before-prune
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-before-prune\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :COMPACTION-PRUNED
(:KIND :ENGINE-CHILD :MODE \"compact-crash\" :FORMAT 2 :STAGE
 \"paged--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :POST-COMPACTION-ACK
(:KIND :ENGINE-CHILD :MODE \"compact-verify\" :FORMAT 2 :STAGE
 \"paged--compaction-pruned\" :STATUS :SIGNALED :CODE 9)
COMPACTION-VERIFIED v2 compact-final paged--compaction-pruned
(:KIND :ENGINE-CHILD :MODE \"compact-final\" :FORMAT 2 :STAGE
 \"paged--compaction-pruned\" :STATUS :EXITED :CODE 0)
ok    TEST-REQ-CMP-001-PRODUCTION-REAL-SIGKILL-AND-SECOND-WRITE-CRASH-V1-V2
ok    TEST-REQ-CMP-001-REVIEW-COUNTER-RESERVES-BEFORE-OUTPUT-EFFECTS
ok    TEST-REQ-CMP-001-REVIEW-LAST-RESERVED-COUNTERS-AND-INTERRUPTED-PRUNE
ok    TEST-REQ-CMP-001-REVIEW-MIXED-MODEL-TRANSPARENT-RAM-PAGED-AND-REOPEN
ok    TEST-REQ-CMP-001-REVIEW-STARTUP-CAPACITY-REFUSED-BEFORE-CHECKPOINT
ok    TEST-REQ-CMP-001-PERFORMANCE-LIVE-FLOOR-BOUNDS-HISTORICAL-PROBES
ok    TEST-REQ-CMP-001-PERFORMANCE-FLOOR-PRESERVES-OLD-COLD-KEY
ok    TEST-REQ-CMP-001-PERFORMANCE-VALID-CRC-SUBSTITUTION-REJECTED
ok    TEST-REQ-CMP-001-PERFORMANCE-WRONG-DERIVED-FLOOR-REJECTED-BEFORE-CONTROL
ok    TEST-REQ-CMP-001-PERFORMANCE-EMPTY-COUNT-CANNOT-HIDE-LIVE-TREE
ok    TEST-REQ-CMP-001-PERFORMANCE-SIGNATURE-COLLISIONS-FALL-BACK-TO-EXACT-PROBES
ok    TEST-REQ-CMP-001-PERFORMANCE-DAMAGED-SIGNATURE-REJECTED-BEFORE-CONTROL
ok    TEST-REQ-CCH-001-ENGINE-CACHE-GEOMETRY-EXACT-MINIMUM-AND-ZERO
ok    TEST-REQ-CCH-002-ENGINE-ACTIVE-CLOSED-AND-REOPEN-HITS-V1-V2-ALL-MODES
ok    TEST-REQ-CCH-004-ENGINE-CORRUPT-CACHE-REREADS-SEGMENT-AND-NOTIFIES
ok    TEST-REQ-CCH-004-ENGINE-CACHE-AND-SEGMENT-CORRUPTION-NEVER-DELIVERED
ok    TEST-REQ-CCH-002-ENGINE-CACHE-UPDATES-DELETE-COMPACTION-AND-MODE-CHANGES
ok    TEST-REQ-CCH-001-ENGINE-ZERO-BUDGET-AND-CLOSE-RELEASE
ok    TEST-REQ-CCH-004-ENGINE-WARM-CACHE-NEVER-BYPASSES-CANONICAL-CLOSED-PROOF
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"tail\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"checkpoint-prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :CHECKPOINT-PREPARED
(:KIND :ENGINE-CHILD :MODE \"recovery-crash\" :FORMAT 1 :STAGE
 \"checkpoint-prepared\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"checkpoint-prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"checkpoint-prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"checkpoint-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :CHECKPOINT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"recovery-crash\" :FORMAT 1 :STAGE
 \"checkpoint-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"checkpoint-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"checkpoint-published\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"tail\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"checkpoint-prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :CHECKPOINT-PREPARED
(:KIND :ENGINE-CHILD :MODE \"recovery-crash\" :FORMAT 2 :STAGE
 \"checkpoint-prepared\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"checkpoint-prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"checkpoint-prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"checkpoint-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :CHECKPOINT-PUBLISHED
(:KIND :ENGINE-CHILD :MODE \"recovery-crash\" :FORMAT 2 :STAGE
 \"checkpoint-published\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"checkpoint-published\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"checkpoint-published\"
 :STATUS :EXITED :CODE 0)
ok    TEST-REQ-REC-001-PRODUCTION-TWO-SIGKILL-RESTART-WITHOUT-HARNESS-V1-V2
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-FAIL SIMPLE-ERROR: ENGINE-ORACLE-MISMATCH expected=8 observed=(0 9 0 9)
(:KIND :ENGINE-CHILD :MODE \"verify-wrong\" :FORMAT 2 :STAGE \"plain\" :STATUS
 :EXITED :CODE 1)
ok    TEST-REQ-VAL-001-PRODUCTION-INDEPENDENT-ORACLE-REJECTS-WRONG-FRONTIER
ok    TEST-REQ-WAL-002-GROUP-ONE-FLUSH-DISTINCT-CSNS-AND-REOPEN-V1-V2-ALL-MODES
ok    TEST-REQ-IDX-005-GROUP-CUMULATIVE-LOAD-AND-REPEATED-KEY-ARENA
ok    TEST-REQ-IDX-005-GROUP-CUMULATIVE-SEQUENCE-AND-REVISION-HEADROOM
ok    TEST-REQ-WAL-005-GROUP-INPUT-BUDGETS-AND-CSN-EXHAUSTION-BEFORE-EFFECTS
ok    TEST-REQ-WAL-006-GROUP-MODEL-ROTATION-COMPACTION-MIGRATION-AND-RECOVERY
ok    TEST-REQ-WAL-006-GROUP-ADMITTED-FAILURE-NO-OUTPUT-NO-REENTRY
ok    TEST-REQ-IDX-012-GROUP-DELTA-UNIQUE-RESERVATIONS-AND-ONE-RENEWAL
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"resident:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"resident:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"resident:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"resident:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"resident:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"resident:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE
 \"resident:partial-seal\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"resident:partial-seal\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"resident:partial-seal\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE
 \"resident:after-flush\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"resident:after-flush\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"resident:after-flush\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE
 \"resident:published-3\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"resident:published-3\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"resident:published-3\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE
 \"resident:after-commit\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"resident:after-commit\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"resident:after-commit\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:partial-seal\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:after-flush\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:published-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:published-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:published-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"paged:after-commit\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"paged:after-commit\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"paged:after-commit\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"legacy:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"legacy:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"legacy:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"legacy:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"legacy:partial-seal\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"legacy:partial-seal\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"legacy:after-flush\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"legacy:after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:published-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE \"legacy:published-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE \"legacy:published-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 1 :STAGE \"legacy:after-commit\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 1 :STAGE
 \"legacy:after-commit\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 1 :STAGE
 \"legacy:after-commit\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"resident:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"resident:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"resident:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"resident:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"resident:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"resident:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE
 \"resident:partial-seal\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"resident:partial-seal\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"resident:partial-seal\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE
 \"resident:after-flush\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"resident:after-flush\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"resident:after-flush\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE
 \"resident:published-3\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"resident:published-3\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"resident:published-3\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE
 \"resident:after-commit\" :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"resident:after-commit\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"resident:after-commit\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:partial-seal\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:after-flush\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:published-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:published-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:published-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"paged:after-commit\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"paged:after-commit\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"paged:after-commit\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PREPARED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:prepared\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"legacy:prepared\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"legacy:prepared\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-APPEND-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:append-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"legacy:append-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"legacy:append-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PARTIAL-SEAL
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:partial-seal\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"legacy:partial-seal\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"legacy:partial-seal\" :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-FLUSHED
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:after-flush\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"legacy:after-flush\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"legacy:after-flush\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-PUBLISHED-3
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:published-3\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE \"legacy:published-3\"
 :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE \"legacy:published-3\"
 :STATUS :EXITED :CODE 0)
ENGINE-CRASH-READY :GROUP-COMMIT
(:KIND :ENGINE-CHILD :MODE \"group-crash\" :FORMAT 2 :STAGE \"legacy:after-commit\"
 :STATUS :SIGNALED :CODE 9)
ENGINE-CRASH-READY :GROUP-RESUMED
(:KIND :ENGINE-CHILD :MODE \"group-resume\" :FORMAT 2 :STAGE
 \"legacy:after-commit\" :STATUS :SIGNALED :CODE 9)
GROUP-VERIFIED group-verify
(:KIND :ENGINE-CHILD :MODE \"group-verify\" :FORMAT 2 :STAGE
 \"legacy:after-commit\" :STATUS :EXITED :CODE 0)
(:KIND :GROUP-CRASH-MATRIX :STATUS :PASSED :SCENARIOS 36 :CHILDREN 108
 :SIGKILLS 72)
ok    TEST-REQ-WAL-006-GROUP-REAL-SIGKILL-SEALED-PREFIX-FLUSH-AND-PUBLICATION
ok    TEST-REQ-WAL-002-ENGINE-BOUNDED-APPEND-BOTH-FORMATS-AND-PRIMARY-MODES
ok    TEST-REQ-WAL-006-ENGINE-APPEND-ARENA-KEEPS-OLD-ROOT-PREFIX-V1-V2
ok    TEST-REQ-IDX-013-ENGINE-APPEND-ARENA-FOLLOWS-ACTIVE-NOT-PRIMARY-BACKEND
ok    TEST-REQ-TXS-002-CONDITIONAL-ABA-ROTATION-REOPEN-AND-LEGACY-ARITY
ok    TEST-REQ-TXS-003-CONDITIONAL-CONFLICTS-BEFORE-CAPACITY-ROTATION-AND-FLUSH
ok    TEST-REQ-TXS-002-CONDITIONAL-INDEPENDENT-MODEL-WITH-COMPACTION
ok    TEST-REQ-TXS-002-CONDITIONAL-INVALID-INPUT-BEFORE-LOOKUP
ok    TEST-REQ-AFF-001-CONDITIONAL-LOOKUP-ERROR-AND-NONLOCAL-EXIT-FAULT
ok    TEST-REQ-WAL-006-CONDITIONAL-ADMITTED-FAULT-NEVER-CONFIRMS-AND-REOPENS
ok    TEST-REQ-CON-002-CONDITIONAL-MAINTENANCE-CALLBACK-CANNOT-CHANGE-VERSION
ok    TEST-REQ-MVC-006-CONDITIONAL-FULL-U64-VERSION-CARRY
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-MIXED-ORDINARY-CONFLICT-AND-ABSENT-DELETE
ok    TEST-REQ-TXS-003-CONDITIONAL-GROUP-ALL-CONFLICTS-BEFORE-FULL-ACTIVE-PREFLIGHT
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-FULL-VALIDATION-BEFORE-ANY-PROBE
ok    TEST-REQ-LIM-003-CONDITIONAL-GROUP-UNADMITTED-CAPACITY-PRESERVES-OUTPUT
ok    TEST-REQ-AFF-001-CONDITIONAL-GROUP-PROBE-ERROR-AND-THROW-CLEAR-OUTPUT
ok    TEST-REQ-WAL-006-CONDITIONAL-GROUP-POST-FLUSH-FAULT-NO-OUTPUT-AND-RECOVERY
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-INDEPENDENT-HISTORY-MODEL-AND-REOPEN
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-ALIASES-REJECTED-BEFORE-EFFECTS
(:KIND :PRODUCTION-ENGINE-TESTS :STATUS :PASSED :TESTS 194 :BENCHMARK NIL
 :POWER-LOSS-QUALIFICATION NIL)
ok    TEST-REQ-AFF-010-REPORT-LISTS-PRIVATE-BETWEEN-CALLS
ok    TEST-REQ-AFF-010-TERMINAL-TOMBSTONE-PRESERVES-MAXIMUM
ok    TEST-REQ-AFF-010-CLEAN-REPEAT-V1-V2-NO-STARTUP-EFFECTS
ok    TEST-REQ-AFF-010-EXACT-SEGMENT-BUDGET-WITHOUT-RECOVERY-HEADROOM
ok    TEST-REQ-AFF-010-ROTATION-AND-COMPACTION-V1-V2
ok    TEST-REQ-AFF-010-INCOMPLETE-TAILS-REPORTED-NOT-TRUNCATED
ok    TEST-REQ-AFF-010-UNPUBLISHED-AND-UNVERIFIED-FILES-NEVER-CLEAN
ok    TEST-REQ-AFF-010-MIXED-FORMAT-EMPTY-ACTIVE-AND-DECISIONS
ok    TEST-REQ-AFF-010-HEADER-AND-COMMITTED-BODY-CORRUPTION
ok    TEST-REQ-AFF-010-MISSING-SOURCE-AND-UNKNOWN-FINAL-PRESERVED
ok    TEST-REQ-AFF-010-CONFIG-AND-RESOURCE-REFUSALS
ok    TEST-REQ-AFF-010-RUNNING-ENGINE-EXCLUDED-AND-LOCK-RELEASED
ok    TEST-REQ-AFF-010-INJECTED-CLEANUP-KEEPS-PRIMARY-NO-NATIVE-FALLBACK
ok    TEST-REQ-AFF-010-VALID-CRCS-DO-NOT-HIDE-DUPLICATE-CSN
ok    TEST-REQ-AFF-010-SOURCE-OBSERVER-CONTRACT
ok    TEST-REQ-AFF-010-FOREIGN-EXIT-RELEASES-DIRECTORY-ONCE
ok    TEST-REQ-AFF-010-CLI-ARGUMENT-FIXTURES
ok    TEST-REQ-AFF-010-CLI-CLEAN-ATTENTION-CORRUPTION
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 1 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 1 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v1 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 1 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ENGINE-CRASH-READY :WRITTEN
(:KIND :ENGINE-CHILD :MODE \"write\" :FORMAT 2 :STAGE \"tail\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-CRASH-READY :RESUMED
(:KIND :ENGINE-CHILD :MODE \"resume\" :FORMAT 2 :STAGE \"plain\" :STATUS :SIGNALED
 :CODE 9)
ENGINE-VERIFIED v2 verify
(:KIND :ENGINE-CHILD :MODE \"verify\" :FORMAT 2 :STAGE \"plain\" :STATUS :EXITED
 :CODE 0)
ok    TEST-REQ-AFF-010-BEFORE-RECOVERY-TWO-REAL-SIGKILL-V1-V2
19 offline M1 verifier tests passed.
ok    TEST-REQ-IPC-002-INDEPENDENT-PING-AND-HELLO-FIXTURES
ok    TEST-REQ-IPC-002-EXACT-WELCOME-CAPACITIES
ok    TEST-REQ-IPC-002-PREFIX-BOUNDS-BEFORE-BODY
ok    TEST-REQ-IPC-002-API-TYPEGUARDS-BEFORE-ARRAY-ACCESS
ok    TEST-REQ-IPC-002-REUSES-SUPPLIED-SCRATCH-AFTER-PROTOCOL-ERROR
ok    TEST-REQ-IPC-002-ENVELOPE-REJECTS-NONMINIMAL-SHAPE-AND-TRAILING
ok    TEST-REQ-IPC-002-IDS-DIRECTION-AND-CORRELATION
ok    TEST-REQ-IPC-002-HANDSHAKE-EXACT-MAPS-AND-LIMITS
ok    TEST-REQ-IPC-002-UNKNOWN-PAYLOAD-NESTED-MAP-ORDER-AND-DUPLICATES
ok    TEST-REQ-IPC-002-ENVELOPE-DEPTH-AND-TAG-CHAIN-BOUNDED
ok    TEST-REQ-IPC-002-COMMAND-SHAPES-STATUS-ONE
ok    TEST-REQ-IPC-002-PUT-GET-DELETE-PRESERVE-BINARY-AND-COPY-OWNERSHIP
ok    TEST-REQ-IPC-002-SEPARATE-KEY-DOCUMENT-BUDGETS
ok    TEST-REQ-IPC-002-DOCUMENT-MINIMAL-COMPLETE-AND-DEPTH100-SEPARATE
ok    TEST-REQ-IPC-002-GET-BUDGET-BEFORE-ENGINE
ok    TEST-REQ-IPC-002-RESPONSE-SHAPES-AND-SUPPLIED-FOUND-NIL
ok    TEST-REQ-IPC-002-RESPONSE-ERRORS-NULL-AND-TYPED-REJECTIONS
ok    TEST-REQ-IPC-002-OUTPUT-PREFLIGHT-PRESERVES-BUFFER-AND-INPUT
ok    TEST-REQ-IPC-002-GROUP-HANDSHAKE-EXACT-AND-NO-DOWNGRADE
ok    TEST-REQ-IPC-002-GROUP-FULL-VALIDATION-BEFORE-COPY-AND-BUDGETS
ok    TEST-REQ-IPC-002-GROUP-ENCODER-PREFIX-PREFLIGHT-AND-EXACT-FRAME
ok    TEST-REQ-WAL-006-GROUP-RESPONSE-U64-EXACT-COUNT-ORDER-AND-ERRORS
ok    TEST-REQ-IPC-002-READ-GROUP-ALL-CAPABILITIES-EXACT-BYTES-AND-TWO-VALUES
ok    TEST-REQ-IPC-002-READ-GROUP-CAPABILITY-ERRORS-AND-OPTION-PREFLIGHT
ok    TEST-REQ-IPC-002-READ-GROUP-COMPLETE-KEY-VALIDATION-BEFORE-COPY
ok    TEST-REQ-IPC-002-READ-GROUP-PREFIX-ALIAS-AND-EXACT-REQUEST-FRAME
ok    TEST-REQ-IPC-002-READ-GROUP-RESPONSE-COPIES-NULL-ABSENCE-AND-DUPLICATES
ok    TEST-REQ-IPC-002-READ-GROUP-INVALID-LAST-RESULT-NEVER-COPIES
ok    TEST-REQ-IPC-002-VERSION-EIGHT-CAPABILITY-COMBINATIONS-EXACT-BYTES
ok    TEST-REQ-IPC-002-VERSION-REQUEST-ROUNDTRIP-INDEPENDENT-FIXTURES
ok    TEST-REQ-IPC-002-VERSION-INVALID-COMPLETE-REQUEST-NEVER-COPIES
ok    TEST-REQ-IPC-002-VERSION-RESULTS-EXACT-SHAPES-AND-TOKEN-RANGES
ok    TEST-REQ-IPC-002-VERSION-CAPABILITY-ERRORS-AND-PREFLIGHT
33 test wire locale superati.
ok    TEST-REQ-IPC-002-NATIVE-SPAN-GUARDS-BEFORE-BACKEND
ok    TEST-REQ-IPC-002-NATIVE-SHORT-EINTR-EAGAIN-EOF-AND-FD-ZERO
ok    TEST-REQ-AFF-004-NATIVE-IMPOSSIBLE-RESULT-AND-CALLBACK-CAUSE
ok    TEST-REQ-IPC-002-NATIVE-SEND-ZERO-FATAL-AND-UNCHANGED-BUFFER
ok    TEST-REQ-IPC-001-NATIVE-PATH-BYTE-PREFLIGHT
ok    TEST-REQ-IPC-003-NATIVE-ANCHOR-PRECEDES-SOCKET-AND-PRESERVES-FD-ZERO
ok    TEST-REQ-IPC-003-NATIVE-REJECTS-UNSAFE-DIRECTORIES-BEFORE-SOCKET
ok    TEST-REQ-IPC-003-NATIVE-OCCUPIED-NODE-AND-ACCESS-ERROR-PRESERVED
ok    TEST-REQ-IPC-003-NATIVE-LISTENER-BORROWS-ANCHOR-CHMOD-BEFORE-LISTEN
ok    TEST-REQ-IPC-003-NATIVE-OWNED-ANCHOR-CLOSE-AND-REPLACEMENT-DIAGNOSIS
ok    TEST-REQ-IPC-003-NATIVE-CLEANUP-TRIES-ALL-PRESERVES-PRIMARY-AND-ERRNOS
ok    TEST-REQ-IPC-003-NATIVE-NAMESPACE-REPLACEMENT-AFTER-BIND-FAILS-CLOSED
ok    TEST-REQ-IPC-003-NATIVE-BIND-FAILURE-NEVER-UNLINKS-OTHER-NODE
ok    TEST-REQ-IPC-001-NATIVE-GATE-AND-NAMESPACE-MISMATCH-BEFORE-EFFECTS
ok    TEST-REQ-IPC-002-NATIVE-SOCKET-CONFIGURE-AND-ACCEPT-FD-ZERO
ok    TEST-REQ-IPC-002-NATIVE-CONNECT-CLOCK-AND-PENDING-WITHOUT-RETRY
ok    TEST-REQ-IPC-002-NATIVE-CONNECT-SO-ERROR-CLOSE-AND-CAUSE
ok    TEST-REQ-AFF-004-NATIVE-BACKEND-AND-PUBLIC-BOUNDARY-GUARDS
ok    TEST-REQ-IPC-003-NATIVE-OPENAT-NOFOLLOW-FSTAT-AND-LOCK-FAULTS
ok    TEST-REQ-IPC-003-NATIVE-CHMOD-LISTEN-ERRORS-CLEAN-OWNED-NODE
ok    TEST-REQ-IPC-003-NATIVE-BIND-WITHOUT-IDENTITY-KEEPS-ORPHAN
ok    TEST-REQ-IPC-003-NATIVE-LISTENER-OPEN-ERROR-KEEPS-BORROWED-ANCHOR
ok    TEST-REQ-IPC-003-NATIVE-REPLACEMENT-DURING-LISTEN-PRESERVED
ok    TEST-REQ-AFF-004-NATIVE-CLOSE-EINTR-SINGLE-ATTEMPT-AND-INVALID-METADATA
(:KIND :LOCAL-NATIVE-TESTS :STATUS :PASSED :TESTS 24 :NATIVE-SYSCALLS-EXECUTED
 NIL :FAULT-INJECTION T)
ok    TEST-REQ-IPC-002-DISPATCH-REAL-STRONG-PUT-GET-DELETE
ok    TEST-REQ-IPC-002-GET-FRAME-BUDGET-BEFORE-ADMISSION
ok    TEST-REQ-IPC-002-INDEX-BUSY-NEVER-COMMITTED
ok    TEST-REQ-IPC-002-POST-COMMIT-FAULT-IS-NOT-BUSY
ok    TEST-REQ-IPC-002-INCOMPATIBLE-RECOVERY-BEFORE-CHECKPOINT
ok    TEST-REQ-IPC-002-CLIENT-OWNER-AND-ID-EXHAUSTION
ok    TEST-REQ-IPC-002-DEADLINES-CLOSE-ONLY-EXPIRED-SLOT
ok    TEST-REQ-IPC-002-PARTIAL-PROGRESS-NEVER-RENEWS-DEADLINE
ok    TEST-REQ-IPC-001-DISCOVERY-CLI-DOMAINS-AND-DEFAULT-PROFILE
ok    TEST-REQ-IPC-001-DISCOVERY-REJECTED-BEFORE-CLOCK-OR-NAMESPACE
ok    TEST-REQ-IPC-002-READINESS-DEADLINE-CEIL-CAP-AND-ALL-SLOT-INTERESTS
ok    TEST-REQ-IPC-002-CLIENT-READINESS-PARTIAL-EINTR-AND-ABSOLUTE-DEADLINE
ok    TEST-REQ-IDX-013-LOCAL-DISPATCH-GROWS-AUTOMATICALLY-BEFORE-STRONG-ACK
ok    TEST-REQ-IDX-013-LOCAL-INDEX-BUDGET-CLI-VALIDATION
ok    TEST-REQ-IDX-013-LOCAL-INDEX-POLICY-BEFORE-RESOURCES
ok    TEST-REQ-CCH-001-LOCAL-RECORD-CACHE-CLI-AND-EARLY-VALIDATION
ok    TEST-REQ-CCH-002-LOCAL-DISPATCH-VERIFIED-CACHE-HIT-AND-FALLBACK
ok    TEST-REQ-WAL-002-LOCAL-READY-WRITES-SHARE-ONE-FLUSH-AND-CLEAR-QUEUE
ok    TEST-REQ-IPC-002-LOCAL-READY-GET-ORDER-IS-A-WRITE-BARRIER
ok    TEST-REQ-IPC-002-LOCAL-GROUP-REFUSAL-SPLITS-ONLY-BEFORE-ADMISSION
ok    TEST-REQ-IPC-002-LOCAL-PENDING-DEADLINE-BEFORE-GROUP-ADMISSION
ok    TEST-REQ-WAL-006-LOCAL-GROUP-ADMITTED-FAULT-NEVER-RETRIES-OR-RESPONDS
ok    TEST-REQ-WAL-006-EXPLICIT-GROUP-RESPONSE-FAILURE-NEVER-BECOMES-BUSY
ok    TEST-REQ-WAL-002-EXPLICIT-GROUP-ONE-FLUSH-MIXED-KEYS-REOPEN-ALL-MODES
ok    TEST-REQ-IPC-002-EXPLICIT-GROUP-REFUSALS-HAVE-NO-SIDE-EFFECTS-OR-SPLIT
ok    TEST-REQ-IPC-002-EXPLICIT-GROUP-VALIDATION-DEADLINE-BEFORE-ADMISSION
ok    TEST-REQ-WAL-002-EXPLICIT-GROUP-DRAINS-EARLIER-WRITE-AND-GET-BARRIER
ok    TEST-REQ-IPC-002-EXPLICIT-GROUP-RECHECKS-DEADLINE-AFTER-DRAINING
ok    TEST-REQ-IPC-002-GROUP-CLIENT-FRAGMENTED-SUCCESS-AND-OUTPUT-TAIL
ok    TEST-REQ-WAL-006-GROUP-CLIENT-MALFORMED-LAST-RESULT-AND-EOF-PRESERVE-OUTPUT
ok    TEST-REQ-IPC-002-GROUP-CLIENT-REJECTION-READY-AND-LEGACY-UNKNOWN-OPCODE
ok    TEST-REQ-IPC-002-CLIENT-FINAL-BYTE-DEADLINE-NEVER-ACKNOWLEDGED
ok    TEST-REQ-IPC-002-GROUP-CLIENT-PREFLIGHT-NO-SEND-OR-ID-CONSUMPTION
ok    TEST-REQ-AFF-004-GROUP-CLIENT-NONLOCAL-EXIT-CLOSES-AND-RETAINS-CLEANUP-ERROR
ok    TEST-REQ-IDX-001-READ-GROUP-CANONICAL-ORDER-DUPLICATES-ABSENCE-V1-V2-ALL-MODES
ok    TEST-REQ-IPC-002-READ-GROUP-AGGREGATE-EXACT-LIMIT-REFUSAL-KEEPS-ENGINE-READY
ok    TEST-REQ-IPC-002-READ-GROUP-REFUSAL-BEFORE-GET-AND-UNAVAILABLE
ok    TEST-REQ-IDX-001-READ-GROUP-WRITE-BARRIERS-AND-INDEPENDENT-WRITE-LIMIT
ok    TEST-REQ-IPC-002-READ-GROUP-EVERY-DEADLINE-BOUNDARY-AND-CLEANUP
ok    TEST-REQ-CCH-004-READ-GROUP-CACHE-FALLBACK-AND-MIDDLE-FAULT-NO-PARTIAL-RESULT
ok    TEST-REQ-CMP-001-READ-GROUPS-AFTER-ROTATION-COMPACTION-AND-REOPEN-V1-V2
ok    TEST-REQ-IPC-002-READ-CLIENT-FRAGMENTS-COMPLETE-PRIVATE-RESULTS-AND-PREFIX
ok    TEST-REQ-IPC-002-READ-CLIENT-ERRORS-AND-DEADLINES-NEVER-EXPOSE-VECTOR
ok    TEST-REQ-IPC-002-READ-CLIENT-REJECTIONS-PREFLIGHT-OWNER-AND-ID-BOUNDARY
ok    TEST-REQ-AFF-004-READ-CLIENT-NONLOCAL-EXIT-CLOSES-WITH-ORIGINAL-CONTROL
ok    TEST-REQ-AFF-004-HANDSHAKE-NEGOTIATION-DEADLINE-AND-NONLOCAL-CLEANUP
ok    TEST-REQ-TXS-002-VERSION-BARRIER-SEES-EARLIER-COLLECTED-WRITE
ok    TEST-REQ-IPC-002-VERSION-EXPIRED-AFTER-DRAIN-NEVER-COMPARES-OR-WRITES
ok    TEST-REQ-TXS-002-VERSION-DISPATCH-V1-V2-ALL-PRIMARY-PROFILES
ok    TEST-REQ-IPC-002-VERSION-BUDGET-CAPABILITY-AND-DEADLINE-BEFORE-ENGINE
ok    TEST-REQ-IPC-002-VERSION-MAXIMUM-DOCUMENT-AND-READ-GRANT
ok    TEST-REQ-WAL-006-VERSION-POST-COMMIT-ERROR-IS-NOT-REJECTION
ok    TEST-REQ-IPC-002-VERSION-CLIENT-FRAGMENTS-CONFLICT-AND-READ-THREE-VALUES
ok    TEST-REQ-IPC-002-VERSION-CLIENT-FAILURE-CLASSIFICATION-AND-DECODE-DEADLINE
ok    TEST-REQ-IPC-002-VERSION-CLIENT-PREFLIGHT-AND-KNOWN-REJECTION-REMAIN-READY
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-DEADLINE-AFTER-ENCODING-BEFORE-QUEUE
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-ADMIN-LIMITS-AND-PARTIAL-PEER
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-UNNEGOTIATED-REQUEST-IS-BARRIER
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-ACTOR-INDEPENDENT-MIXED-ONE-FLUSH
ok    TEST-REQ-TXS-002-CONDITIONAL-GROUP-ACTOR-SAME-KEY-ABA-BARRIERS
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-READ-PING-AND-VERSIONED-GET-BARRIERS
ok    TEST-REQ-TXS-003-CONDITIONAL-GROUP-EXPIRATION-KEEPS-CONDITION-OWNER-ALIGNED
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-CAPACITY-FALLBACK-RECHECKS-ORIGINAL-CONDITIONS
ok    TEST-REQ-IPC-002-CONDITIONAL-GROUP-EXPIRED-AFTER-COMMIT-NEVER-ACKNOWLEDGED
ok    TEST-REQ-WAL-006-CONDITIONAL-GROUP-ENCODER-ERROR-NEVER-FALLS-BACK
ok    TEST-REQ-AFF-004-CONDITIONAL-GROUP-NONLOCAL-EXIT-CLEARS-COLLECTOR
ok    TEST-REQ-REC-001-PRODUCTION-LOCAL-TWO-SIGKILL-RESTARTS-AND-STARTUP-REFUSALS-V1-V2
ok    TEST-REQ-IPC-001-DISCOVERY-CLI-REAL-GET-WRITE-AND-STALE-RESTART-V1-V2
ok    TEST-REQ-IPC-001-DISCOVERY-CORRUPT-SELECTED-IMAGE-NO-LISTENER-V1-V2
ok    TEST-REQ-IDX-013-LOCAL-INDEX-BUDGET-PAGED-CRASH-RECOVERY-V1-V2
ok    TEST-REQ-STO-003-LIVE-ROTATION-REAL-LOCAL-SERVICE-BYTE-LIMIT-V1-V2
ok    TEST-REQ-CMP-001-AUTOMATIC-COMPACTION-REAL-LOCAL-SERVICE-V1-V2
ok    TEST-REQ-WAL-002-REAL-UNIX-EIGHT-STRONG-WRITES-ONE-FLUSH-AND-SIGKILL
ok    TEST-REQ-WAL-006-EXPLICIT-UNIX-STRONG-GROUP-SIGKILL-REOPEN-AND-NEXT-CSN
ok    TEST-REQ-WAL-006-EXPLICIT-UNIX-RESPONSE-LOST-AFTER-STRONG-NO-RETRY
ok    TEST-REQ-IPC-002-READ-GROUP-REAL-UNIX-MIXED-CAPABILITIES-OVERFLOW-SIGKILL-AND-REOPEN
ok    TEST-REQ-IPC-002-READ-GROUP-REAL-RESPONSE-LOSS-PAGED-CACHE-AND-SUBSEQUENT-CLIENT
ok    TEST-REQ-IPC-002-READ-GROUP-REAL-PARTIAL-PEER-AND-COALESCED-FRAMES
ok    TEST-REQ-TXS-002-VERSION-REAL-TWO-CLIENTS-STALE-TOKEN-SIGKILL-REOPEN
ok    TEST-REQ-WAL-006-VERSION-REAL-LOST-RESPONSE-CONFLICT-DOES-NOT-RETRY
ok    TEST-REQ-TXS-002-CONDITIONAL-COHORT-REAL-MIXED-SAME-KEY-SIGKILL-REOPEN
ok    TEST-REQ-WAL-006-CONDITIONAL-COHORT-REAL-PUBLIC-CLIENT-LOST-RESPONSE
(:KIND :PRODUCTION-LOCAL-TESTS :STATUS :PASSED :TESTS 16 :ROOT #A((55) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/\") :RETAINED NIL :PROCESSES ((:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v1-server-1\") :ROLE :SERVER :PID 91524 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :FIRST-DURABLE-WORKLOAD :DURATION-SECONDS 9.514636d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/001-v1-server-1.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/001-v1-server-1.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 91524) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91542 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.824286d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/002-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/002-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 91565 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182A\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.816332d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/003-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/003-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 1)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91588 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.770328d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/004-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/004-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 91600 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"put\") \"FF00000102030405060708090A0B0C0D\" \"F4\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.784016d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/005-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/005-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91612 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.794581d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/006-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/006-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"F4\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 91625 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.769557d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/007-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/007-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 3)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 91639 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((6) BASE-CHAR . \"delete\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.763236d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/008-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/008-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 4)) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91651 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.757961d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/009-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/009-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91664 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.84032d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/010-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/010-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91686 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.767707d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/011-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/011-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91698 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-1.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.807745d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/012-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/012-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v1-server-2\") :ROLE :SERVER :PID 91710 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :SECOND-DURABLE-WORKLOAD :DURATION-SECONDS 8.682809d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/013-v1-server-2.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/013-v1-server-2.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 91710) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91722 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.847822d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/014-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/014-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91736 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.758328d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/015-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/015-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91748 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.780114d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/016-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/016-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91759 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.761998d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/017-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/017-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 91772 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"put\") \"8000000102030405060708090A0B0C0D\" \"4300FF80\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.761949d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/018-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/018-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 5)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 91784 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.806518d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/019-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/019-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 6)) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91804 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.772477d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/020-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/020-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91816 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.747248d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/021-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/021-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91828 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.747271d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/022-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/022-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91840 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-2.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.737223d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/023-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/023-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"4300FF80\")) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v1-server-3\") :ROLE :SERVER :PID 91852 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :VERIFICATION-COMPLETE :DURATION-SECONDS 4.48181d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/024-v1-server-3.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/024-v1-server-3.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 91852) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91864 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.742625d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/025-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/025-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91876 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.763387d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/026-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/026-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91890 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.728269d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/027-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/027-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 91902 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.739591d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/028-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/028-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"4300FF80\")) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 91914 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-3.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.739153d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/029-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/029-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-collision\") :ROLE :SERVER :PID 91926 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-collision.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.750315d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/030-v1-collision.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/030-v1-collision.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((19) BASE-CHAR . \"v1-engine-not-ready\") :ROLE :SERVER :PID 91938 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-not-ready.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.754028d0 :STDOUT #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/031-v1-engine-not-ready.stdout\") :STDERR #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/031-v1-engine-not-ready.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((24) BASE-CHAR . \"v1-stored-cbor-not-ready\") :ROLE :SERVER :PID 91957 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1-bad-cbor/\") #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-bad-cbor.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.74913d0 :STDOUT #A((90) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/032-v1-stored-cbor-not-ready.stdout\") :STDERR #A((90) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/032-v1-stored-cbor-not-ready.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v1-server-4\") :ROLE :SERVER :PID 91968 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-fault-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1-lost-ack/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-4.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-4.sock\") :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 1.550217d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/033-v1-server-4.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/033-v1-server-4.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 91968) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME \"put-lost-ack\" :ROLE :CLIENT :PID 91982 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-4.sock\") \"put\" \"00FF000102030405060708090A0B0C0D\" \"182A\") :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.766437d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/034-put-lost-ack.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/034-put-lost-ack.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v1-server-5\") :ROLE :SERVER :PID 91994 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v1-lost-ack/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-5.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-5.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :LOST-ACK-RECOVERED :DURATION-SECONDS 2.285392d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/035-v1-server-5.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/035-v1-server-5.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 91994) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92007 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-5.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.758724d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/036-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/036-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92019 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v1-5.sock\") #A((3) BASE-CHAR . \"put\") \"FF00000102030405060708090A0B0C0D\" \"F4\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.747135d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/037-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/037-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v2-server-1\") :ROLE :SERVER :PID 92035 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :FIRST-DURABLE-WORKLOAD :DURATION-SECONDS 9.148019d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/038-v2-server-1.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/038-v2-server-1.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92035) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92069 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.750659d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/039-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/039-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92080 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182A\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.86373d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/040-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/040-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 1)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92093 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.763335d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/041-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/041-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92105 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"put\") \"FF00000102030405060708090A0B0C0D\" \"F4\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.754322d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/042-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/042-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92119 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.736304d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/043-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/043-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"F4\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92130 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.745694d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/044-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/044-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 3)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92168 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((6) BASE-CHAR . \"delete\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.745893d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/045-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/045-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 4)) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92180 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.741365d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/046-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/046-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92192 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.742282d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/047-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/047-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92204 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.744782d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/048-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/048-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92216 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-1.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.75315d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/049-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/049-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v2-server-2\") :ROLE :SERVER :PID 92228 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :SECOND-DURABLE-WORKLOAD :DURATION-SECONDS 8.375461d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/050-v2-server-2.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/050-v2-server-2.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92228) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92240 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.769136d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/051-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/051-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92254 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.768015d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/052-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/052-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92268 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.74367d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/053-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/053-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92280 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.742764d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/054-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/054-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92292 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"put\") \"8000000102030405060708090A0B0C0D\" \"4300FF80\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.764974d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/055-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/055-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 5)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92304 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.767344d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/056-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/056-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 6)) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92316 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.778229d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/057-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/057-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92337 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.757034d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/058-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/058-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92349 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.764172d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/059-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/059-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92361 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-2.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.738981d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/060-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/060-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"4300FF80\")) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v2-server-3\") :ROLE :SERVER :PID 92374 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :VERIFICATION-COMPLETE :DURATION-SECONDS 4.563992d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/061-v2-server-3.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/061-v2-server-3.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92374) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92387 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.756724d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/062-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/062-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92398 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.750945d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/063-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/063-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92410 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") #A((3) BASE-CHAR . \"get\") \"FF00000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.749529d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/064-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/064-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92422 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") #A((3) BASE-CHAR . \"get\") \"8000000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.75631d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/065-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/065-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"4300FF80\")) (:KIND :LOCAL-PROCESS :NAME #A((4) BASE-CHAR . \"ping\") :ROLE :CLIENT :PID 92434 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-3.sock\") #A((4) BASE-CHAR . \"ping\")) :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.777297d0 :STDOUT #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/066-ping.stdout\") :STDERR #A((70) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/066-ping.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PING :RESULT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-collision\") :ROLE :SERVER :PID 92444 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-collision.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.748991d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/067-v2-collision.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/067-v2-collision.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((19) BASE-CHAR . \"v2-engine-not-ready\") :ROLE :SERVER :PID 92455 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-not-ready.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.781096d0 :STDOUT #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/068-v2-engine-not-ready.stdout\") :STDERR #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/068-v2-engine-not-ready.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((24) BASE-CHAR . \"v2-stored-cbor-not-ready\") :ROLE :SERVER :PID 92470 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2-bad-cbor/\") #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-bad-cbor.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.884462d0 :STDOUT #A((90) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/069-v2-stored-cbor-not-ready.stdout\") :STDERR #A((90) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/069-v2-stored-cbor-not-ready.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v2-server-4\") :ROLE :SERVER :PID 92481 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-fault-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2-lost-ack/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-4.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-4.sock\") :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 1.673533d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/070-v2-server-4.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/070-v2-server-4.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92481) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME \"put-lost-ack\" :ROLE :CLIENT :PID 92494 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-4.sock\") \"put\" \"00FF000102030405060708090A0B0C0D\" \"182A\") :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.809969d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/071-put-lost-ack.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/071-put-lost-ack.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((11) BASE-CHAR . \"v2-server-5\") :ROLE :SERVER :PID 92505 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/data-v2-lost-ack/\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-5.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-5.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :LOST-ACK-RECOVERED :DURATION-SECONDS 2.409328d0 :STDOUT #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/072-v2-server-5.stdout\") :STDERR #A((77) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/072-v2-server-5.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92505) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92517 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-5.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.786787d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/073-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/073-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92529 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/runtime/v2-5.sock\") #A((3) BASE-CHAR . \"put\") \"FF00000102030405060708090A0B0C0D\" \"F4\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.825207d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/074-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/074-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-70\") :ROLE :SERVER :PID 92542 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-v1/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-70.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--discover-index\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-70.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :DISCOVERY-WRITE-COMPLETED :DURATION-SECONDS 3.164886d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/075-v1-server-70.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/075-v1-server-70.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92542) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92554 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-70.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.775866d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/076-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/076-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92565 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-70.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.798017d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/077-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/077-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92579 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-70.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.794753d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/078-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/078-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-71\") :ROLE :SERVER :PID 92591 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-v1/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-71.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--discover-index\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-71.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :DISCOVERY-STALE-COMPLETED :DURATION-SECONDS 3.072096d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/079-v1-server-71.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/079-v1-server-71.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92591) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92602 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-71.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.768919d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/080-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/080-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92614 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-71.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.740293d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/081-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/081-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 3)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92626 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v1-71.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.769244d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/082-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/082-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-70\") :ROLE :SERVER :PID 92638 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-v2/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-70.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--discover-index\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-70.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :DISCOVERY-WRITE-COMPLETED :DURATION-SECONDS 3.137791d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/083-v2-server-70.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/083-v2-server-70.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92638) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92649 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-70.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.80817d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/084-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/084-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92661 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-70.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.785239d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/085-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/085-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 2)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92672 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-70.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.763139d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/086-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/086-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-71\") :ROLE :SERVER :PID 92684 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-v2/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-71.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--discover-index\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-71.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :DISCOVERY-STALE-COMPLETED :DURATION-SECONDS 3.193932d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/087-v2-server-71.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/087-v2-server-71.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92684) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92697 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-71.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.781361d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/088-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/088-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182B\")) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92709 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-71.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.774586d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/089-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/089-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 3)) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92721 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-runtime/v2-71.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.809385d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/090-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/090-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((20) BASE-CHAR . \"discovery-corrupt-v1\") :ROLE :SERVER :PID 92734 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-v1/\") #A((96) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/corrupt-v1.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\") \"--discover-index\") :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.965728d0 :STDOUT #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/091-discovery-corrupt-v1.stdout\") :STDERR #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/091-discovery-corrupt-v1.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-72\") :ROLE :SERVER :PID 92746 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-v1/\") #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v1-72.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v1-72.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :RESIDENT-AFTER-DISCOVERY-REFUSAL :DURATION-SECONDS 3.223909d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/092-v1-server-72.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/092-v1-server-72.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92746) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92759 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v1-72.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 2.1532d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/093-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/093-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((20) BASE-CHAR . \"discovery-corrupt-v2\") :ROLE :SERVER :PID 92778 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-v2/\") #A((96) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/corrupt-v2.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\") \"--discover-index\") :SOCKET NIL :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.941721d0 :STDOUT #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/094-discovery-corrupt-v2.stdout\") :STDERR #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/094-discovery-corrupt-v2.stderr\") :READY NIL :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-72\") :ROLE :SERVER :PID 92790 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-v2/\") #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v2-72.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v2-72.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :RESIDENT-AFTER-DISCOVERY-REFUSAL :DURATION-SECONDS 1.848617d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/095-v2-server-72.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/095-v2-server-72.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92790) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92802 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((91) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/discovery-corrupt-runtime/v2-72.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 1.00537d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/096-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/096-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND T :DOCUMENT \"182A\")) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-80\") :ROLE :SERVER :PID 92814 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v1/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-80.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-80.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-CRASH :DURATION-SECONDS 5.571569d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/097-v1-server-80.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/097-v1-server-80.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92814) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-81\") :ROLE :SERVER :PID 92902 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v1/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-81.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-81.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-RECOVERED :DURATION-SECONDS 2.446202d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/098-v1-server-81.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/098-v1-server-81.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92902) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92903 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-81.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.761824d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/099-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/099-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 1201)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92905 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-81.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.761235d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/100-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/100-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 1202)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-82\") :ROLE :SERVER :PID 92907 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v1/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-82.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-82.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-DEFAULT-RECOVERED :DURATION-SECONDS 1.60872d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/101-v1-server-82.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/101-v1-server-82.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92907) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92909 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v1-82.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.778258d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/102-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/102-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-80\") :ROLE :SERVER :PID 92912 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v2/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-80.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-80.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-CRASH :DURATION-SECONDS 5.467807d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/103-v2-server-80.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/103-v2-server-80.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92912) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-81\") :ROLE :SERVER :PID 92914 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v2/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-81.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-81.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-RECOVERED :DURATION-SECONDS 2.466435d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/104-v2-server-81.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/104-v2-server-81.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92914) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"put\") :ROLE :CLIENT :PID 92915 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-81.sock\") #A((3) BASE-CHAR . \"put\") \"00FF000102030405060708090A0B0C0D\" \"182B\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.797086d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/105-put.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/105-put.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :PUT :CSN 1201)) (:KIND :LOCAL-PROCESS :NAME #A((6) BASE-CHAR . \"delete\") :ROLE :CLIENT :PID 92916 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-81.sock\") #A((6) BASE-CHAR . \"delete\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.762075d0 :STDOUT #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/106-delete.stdout\") :STDERR #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/106-delete.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :DELETE :CSN 1202)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-82\") :ROLE :SERVER :PID 92917 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((63) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-v2/\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-82.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-82.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-INDEX-DEFAULT-RECOVERED :DURATION-SECONDS 1.58084d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/107-v2-server-82.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/107-v2-server-82.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92917) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((3) BASE-CHAR . \"get\") :ROLE :CLIENT :PID 92918 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-client.lisp\") #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/auto-runtime/v2-82.sock\") #A((3) BASE-CHAR . \"get\") \"00FF000102030405060708090A0B0C0D\") :SOCKET NIL :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON NIL :DURATION-SECONDS 0.749159d0 :STDOUT #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/108-get.stdout\") :STDERR #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/108-get.stderr\") :READY NIL :RESPONSE (:KIND :LOCAL-CLIENT :OPERATION :GET :FOUND NIL :DOCUMENT NIL)) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-90\") :ROLE :SERVER :PID 92919 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-v1/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v1-90.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v1-90.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AFTER-LIVE-ROTATION :DURATION-SECONDS 2.087962d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/109-v1-server-90.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/109-v1-server-90.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92919) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-91\") :ROLE :SERVER :PID 92920 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-v1/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v1-91.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v1-91.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :LIVE-ROTATION-RECOVERED :DURATION-SECONDS 0.833245d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/110-v1-server-91.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/110-v1-server-91.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92920) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-90\") :ROLE :SERVER :PID 92923 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-v2/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v2-90.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v2-90.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AFTER-LIVE-ROTATION :DURATION-SECONDS 2.090904d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/111-v2-server-90.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/111-v2-server-90.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92923) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-91\") :ROLE :SERVER :PID 92926 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-v2/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v2-91.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/rotation-runtime/v2-91.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :LIVE-ROTATION-RECOVERED :DURATION-SECONDS 0.854425d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/112-v2-server-91.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/112-v2-server-91.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92926) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-94\") :ROLE :SERVER :PID 92927 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-v1/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v1-94.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v1-94.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AFTER-AUTOMATIC-COMPACTION :DURATION-SECONDS 6.038389d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/113-v1-server-94.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/113-v1-server-94.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92927) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v1-server-95\") :ROLE :SERVER :PID 92953 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-v1/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v1-95.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v1-95.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-COMPACTION-RECOVERED :DURATION-SECONDS 0.822267d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/114-v1-server-95.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/114-v1-server-95.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92953) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-94\") :ROLE :SERVER :PID 92954 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-v2/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v2-94.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v2-94.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AFTER-AUTOMATIC-COMPACTION :DURATION-SECONDS 5.869257d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/115-v2-server-94.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/115-v2-server-94.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92954) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((12) BASE-CHAR . \"v2-server-95\") :ROLE :SERVER :PID 92995 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-v2/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v2-95.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/compaction-runtime/v2-95.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :AUTOMATIC-COMPACTION-RECOVERED :DURATION-SECONDS 0.774855d0 :STDOUT #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/116-v2-server-95.stdout\") :STDERR #A((78) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/116-v2-server-95.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92995) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-100\") :ROLE :SERVER :PID 92996 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-group-server.lisp\") #A((64) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-v1/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v1-100.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--test-group-limit\" #A((1) BASE-CHAR . \"8\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v1-100.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :STRONG-GROUP-ACKNOWLEDGED :DURATION-SECONDS 0.765052d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/117-v1-server-100.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/117-v1-server-100.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92996) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-101\") :ROLE :SERVER :PID 92997 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((64) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-v1/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v1-101.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v1-101.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :STRONG-GROUP-RECOVERED :DURATION-SECONDS 0.750695d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/118-v1-server-101.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/118-v1-server-101.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92997) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-100\") :ROLE :SERVER :PID 92998 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-group-server.lisp\") #A((64) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-v2/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v2-100.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--test-group-limit\" #A((1) BASE-CHAR . \"8\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v2-100.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :STRONG-GROUP-ACKNOWLEDGED :DURATION-SECONDS 0.787667d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/119-v2-server-100.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/119-v2-server-100.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92998) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-101\") :ROLE :SERVER :PID 92999 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((64) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-v2/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v2-101.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/group-runtime/v2-101.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :STRONG-GROUP-RECOVERED :DURATION-SECONDS 0.765657d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/120-v2-server-101.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/120-v2-server-101.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 92999) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-210\") :ROLE :SERVER :PID 93000 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-group-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-v1/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v1-210.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v1-210.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-STRONG-ACKNOWLEDGED :DURATION-SECONDS 0.788396d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/121-v1-server-210.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/121-v1-server-210.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93000) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-211\") :ROLE :SERVER :PID 93001 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-v1/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v1-211.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v1-211.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-RECOVERED :DURATION-SECONDS 0.768605d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/122-v1-server-211.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/122-v1-server-211.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93001) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-210\") :ROLE :SERVER :PID 93002 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-group-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-v2/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v2-210.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v2-210.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-STRONG-ACKNOWLEDGED :DURATION-SECONDS 0.773766d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/123-v2-server-210.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/123-v2-server-210.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93002) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-211\") :ROLE :SERVER :PID 93003 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((67) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-v2/\") #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v2-211.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((83) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-runtime/v2-211.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-RECOVERED :DURATION-SECONDS 0.788414d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/124-v2-server-211.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/124-v2-server-211.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93003) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-220\") :ROLE :SERVER :PID 93004 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-fault-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-v1/\") #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v1-220.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v1-220.sock\") :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.802033d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/125-v1-server-220.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/125-v1-server-220.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93004) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-221\") :ROLE :SERVER :PID 93005 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-v1/\") #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v1-221.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v1-221.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-LOSS-RECOVERED :DURATION-SECONDS 0.75213d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/126-v1-server-221.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/126-v1-server-221.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93005) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-220\") :ROLE :SERVER :PID 93008 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((101) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-fault-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-v2/\") #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v2-220.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v2-220.sock\") :STATUS :EXITED :CODE 1 :OUTCOME :PASS :EXPECTED-FAILURE T :STOP-REASON NIL :DURATION-SECONDS 0.762131d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/127-v2-server-220.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/127-v2-server-220.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93008) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-221\") :ROLE :SERVER :PID 93009 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((72) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-v2/\") #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v2-221.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((88) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/explicit-loss-runtime/v2-221.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :EXPLICIT-LOSS-RECOVERED :DURATION-SECONDS 0.748078d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/128-v2-server-221.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/128-v2-server-221.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93009) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-310\") :ROLE :SERVER :PID 93010 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-v1/\") #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v1-310.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v1-310.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-GROUP-VERIFIED :DURATION-SECONDS 0.770942d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/129-v1-server-310.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/129-v1-server-310.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93010) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-311\") :ROLE :SERVER :PID 93011 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-v1/\") #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v1-311.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v1-311.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-GROUP-RECOVERED :DURATION-SECONDS 0.775113d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/130-v1-server-311.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/130-v1-server-311.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93011) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-310\") :ROLE :SERVER :PID 93012 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-v2/\") #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v2-310.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v2-310.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-GROUP-VERIFIED :DURATION-SECONDS 0.782058d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/131-v2-server-310.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/131-v2-server-310.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93012) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-311\") :ROLE :SERVER :PID 93013 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((69) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-v2/\") #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v2-311.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-group-runtime/v2-311.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-GROUP-RECOVERED :DURATION-SECONDS 0.770807d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/132-v2-server-311.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/132-v2-server-311.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93013) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-320\") :ROLE :SERVER :PID 93014 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((105) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-read-loss-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-v1/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-runtime/v1-320.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-runtime/v1-320.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-LOSS-VERIFIED :DURATION-SECONDS 0.794091d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/133-v1-server-320.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/133-v1-server-320.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93014) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-320\") :ROLE :SERVER :PID 93015 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((105) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-read-loss-server.lisp\") #A((68) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-v2/\") #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-runtime/v2-320.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"1048576\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((84) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-loss-runtime/v2-320.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-LOSS-VERIFIED :DURATION-SECONDS 0.794981d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/134-v2-server-320.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/134-v2-server-320.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93015) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-330\") :ROLE :SERVER :PID 93016 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-frame-data/\") #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-frame-runtime/v2-330.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((85) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/read-frame-runtime/v2-330.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :READ-FRAMES-VERIFIED :DURATION-SECONDS 0.916831d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/135-v2-server-330.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/135-v2-server-330.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93016) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-410\") :ROLE :SERVER :PID 93017 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((66) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-v1/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v1-410.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v1-410.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-STRONG-CONFIRMED :DURATION-SECONDS 0.777023d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/136-v1-server-410.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/136-v1-server-410.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93017) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-411\") :ROLE :SERVER :PID 93018 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((66) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-v1/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v1-411.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v1-411.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-RECOVERED :DURATION-SECONDS 0.752671d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/137-v1-server-411.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/137-v1-server-411.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93018) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-410\") :ROLE :SERVER :PID 93019 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((66) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-v2/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v2-410.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v2-410.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-STRONG-CONFIRMED :DURATION-SECONDS 0.771711d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/138-v2-server-410.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/138-v2-server-410.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93019) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-411\") :ROLE :SERVER :PID 93020 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((66) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-v2/\") #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v2-411.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((82) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-runtime/v2-411.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-RECOVERED :DURATION-SECONDS 0.760727d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/139-v2-server-411.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/139-v2-server-411.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93020) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-420\") :ROLE :SERVER :PID 93021 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((108) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-version-loss-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-v1/\") #A((87) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-runtime/v1-420.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((87) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-runtime/v1-420.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-LOSS-VERIFIED :DURATION-SECONDS 0.788963d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/140-v1-server-420.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/140-v1-server-420.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93021) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-420\") :ROLE :SERVER :PID 93024 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((108) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-version-loss-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-v2/\") #A((87) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-runtime/v2-420.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((87) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/version-loss-runtime/v2-420.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-LOSS-VERIFIED :DURATION-SECONDS 0.778352d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/141-v2-server-420.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/141-v2-server-420.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93024) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-710\") :ROLE :SERVER :PID 93025 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((74) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v1-RESIDENT/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-710.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-710.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-STRONG-CONFIRMED :DURATION-SECONDS 0.789281d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/142-v1-server-710.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/142-v1-server-710.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93025) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-711\") :ROLE :SERVER :PID 93026 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((74) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v1-RESIDENT/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-711.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-711.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-RECOVERED :DURATION-SECONDS 0.774257d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/143-v1-server-711.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/143-v1-server-711.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93026) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-712\") :ROLE :SERVER :PID 93027 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v1-PAGED/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-712.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-712.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-STRONG-CONFIRMED :DURATION-SECONDS 0.786527d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/144-v1-server-712.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/144-v1-server-712.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93027) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-713\") :ROLE :SERVER :PID 93030 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v1-PAGED/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-713.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v1-713.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-RECOVERED :DURATION-SECONDS 0.775432d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/145-v1-server-713.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/145-v1-server-713.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93030) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-710\") :ROLE :SERVER :PID 93032 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((74) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v2-RESIDENT/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-710.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-710.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-STRONG-CONFIRMED :DURATION-SECONDS 0.806988d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/146-v2-server-710.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/146-v2-server-710.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93032) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-711\") :ROLE :SERVER :PID 93033 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((74) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v2-RESIDENT/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-711.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-711.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-RECOVERED :DURATION-SECONDS 0.765815d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/147-v2-server-711.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/147-v2-server-711.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93033) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-712\") :ROLE :SERVER :PID 93036 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v2-PAGED/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-712.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-712.sock\") :STATUS :SIGNALED :CODE 9 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-STRONG-CONFIRMED :DURATION-SECONDS 0.790676d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/148-v2-server-712.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/148-v2-server-712.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93036) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-713\") :ROLE :SERVER :PID 93037 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((95) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-server.lisp\") #A((71) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-v2-PAGED/\") #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-713.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((81) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-runtime/v2-713.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-RECOVERED :DURATION-SECONDS 0.776535d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/149-v2-server-713.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/149-v2-server-713.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93037) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-720\") :ROLE :SERVER :PID 93038 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-v1-RESIDENT/\") #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v1-720.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v1-720.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-LOSS-VERIFIED :DURATION-SECONDS 0.81087d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/150-v1-server-720.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/150-v1-server-720.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93038) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-722\") :ROLE :SERVER :PID 93039 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-v1-PAGED/\") #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v1-722.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v1-722.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-LOSS-VERIFIED :DURATION-SECONDS 0.803545d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/151-v1-server-722.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/151-v1-server-722.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93039) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-720\") :ROLE :SERVER :PID 93040 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-v2-RESIDENT/\") #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v2-720.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v2-720.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-LOSS-VERIFIED :DURATION-SECONDS 0.795767d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/152-v2-server-720.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/152-v2-server-720.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93040) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-722\") :ROLE :SERVER :PID 93041 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((113) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/tools/local-conditional-group-server.lisp\") #A((76) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-v2-PAGED/\") #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v2-722.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"8388608\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((86) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/cohort-loss-runtime/v2-722.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CONDITIONAL-COHORT-LOSS-VERIFIED :DURATION-SECONDS 0.801526d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/153-v2-server-722.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZUR-1TWZ-0/153-v2-server-722.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 93041) :RESPONSE NIL)) :SCENARIOS ((:KIND :FRAGMENTED-AND-COALESCED-RAW-PEER :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 3.07d-4) (:KIND :SLOW-PEER-AND-NEGOTIATED-CAPACITIES :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 3.13d-4) (:KIND :TWO-SIGKILL-THREE-STARTS :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 22.680397d0) (:KIND :EXISTING-NODE-PRESERVED :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.750848d0) (:KIND :ENGINE-NOT-READY-NO-LISTENER :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.754801d0) (:KIND :INVALID-STORED-CBOR-NO-LISTENER :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.783733d0) (:KIND :LOST-ACK-AFTER-STRONG-COMMIT :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 3.836239d0) (:KIND :FRAGMENTED-AND-COALESCED-RAW-PEER :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 2.03d-4) (:KIND :SLOW-PEER-AND-NEGOTIATED-CAPACITIES :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.98d-4) (:KIND :TWO-SIGKILL-THREE-STARTS :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 22.088353d0) (:KIND :EXISTING-NODE-PRESERVED :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.74948d0) (:KIND :ENGINE-NOT-READY-NO-LISTENER :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.781755d0) (:KIND :INVALID-STORED-CBOR-NO-LISTENER :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.914356d0) (:KIND :LOST-ACK-AFTER-STRONG-COMMIT :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 4.083681d0) (:KIND :AUTOMATIC-INDEX-BUDGET :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 9.628064d0) (:KIND :AUTOMATIC-INDEX-BUDGET :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 9.516544d0) (:KIND :LIVE-SEGMENT-ROTATION :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 2.921976d0) (:KIND :LIVE-SEGMENT-ROTATION :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 2.946274d0) (:KIND :AUTOMATIC-SEGMENT-COMPACTION :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 6.861697d0) (:KIND :AUTOMATIC-SEGMENT-COMPACTION :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 6.644876d0) (:KIND :STRONG-GROUP-NATIVE :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.516329d0) (:KIND :STRONG-GROUP-NATIVE :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.554045d0) (:KIND :EXPLICIT-STRONG-GROUP :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.557623d0) (:KIND :EXPLICIT-STRONG-GROUP :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.562847d0) (:KIND :EXPLICIT-LOST-RESPONSE :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.554864d0) (:KIND :EXPLICIT-LOST-RESPONSE :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.510836d0) (:KIND :EXPLICIT-READ-GROUP :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.546682d0) (:KIND :EXPLICIT-READ-GROUP :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.553582d0) (:KIND :READ-RESPONSE-LOST :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.794434d0) (:KIND :READ-RESPONSE-LOST :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.795401d0) (:KIND :CONDITIONAL-CLIENTS :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.53043d0) (:KIND :CONDITIONAL-CLIENTS :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.533122d0) (:KIND :CONDITIONAL-RESPONSE-LOST :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.789273d0) (:KIND :CONDITIONAL-RESPONSE-LOST :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.778799d0) (:KIND :CONDITIONAL-COHORT :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.564203d0) (:KIND :CONDITIONAL-COHORT :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 1.562804d0) (:KIND :CONDITIONAL-COHORT :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.57372d0) (:KIND :CONDITIONAL-COHORT :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 1.568087d0) (:KIND :CONDITIONAL-COHORT-LOSS :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.811272d0) (:KIND :CONDITIONAL-COHORT-LOSS :VERSION 1 :OUTCOME :PASS :DURATION-SECONDS 0.804064d0) (:KIND :CONDITIONAL-COHORT-LOSS :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.796328d0) (:KIND :CONDITIONAL-COHORT-LOSS :VERSION 2 :OUTCOME :PASS :DURATION-SECONDS 0.801997d0)) :SIGKILLS 22 :CONDITION NIL :CLEANUP-ERRORS NIL :BENCHMARK NIL :POWER-LOSS-QUALIFICATION NIL)
(:KIND :METRICS-PRODUCT-VERIFICATION :STATUS :PASSED :PLANNED 2633 :PASSED 2633
 :FAILED 0 :NOT-RUN 0 :SKIPPED 0 :SUITES 59 :BENCHMARK NIL)
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
