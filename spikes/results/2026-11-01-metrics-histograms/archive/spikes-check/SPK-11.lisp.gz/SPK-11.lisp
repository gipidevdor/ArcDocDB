(:SCHEMA-VERSION 1 :ID "SPK-11" :COMMAND
 (#A((48) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl")
  "--dynamic-space-size" "4096" "--noinform" "--no-userinit" "--no-sysinit"
  "--script" "spikes/SPK-11-unix-socket/run.lisp"
  #A((7) BASE-CHAR . "--check"))
 :EXIT-CODE 0 :STARTED-AT-UNIVERSAL-TIME 4002524327 :FINISHED-AT-UNIVERSAL-TIME
 4002524336 :WALL-SECONDS 8.334501d0 :STATUS :OK :SOURCE-BLOBS-BEFORE
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-BLOBS-AFTER
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-CONSISTENCY :STABLE :RESULT
 (:STATUS :OK :SPIKE :SPK-11 :FRAMING
  (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
   :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
  :SESSION
  (:STATUS :OK :CASES
   ((:CASE #A((18) BASE-CHAR . "CHECK-SESSION-WIRE") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-MAPS") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-NEGOTIATION") :STATUS :OK)
    (:CASE #A((20) BASE-CHAR . "CHECK-SESSION-CREDIT") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-CORRELATION") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-TIME") :STATUS :OK)
    (:CASE #A((23) BASE-CHAR . "CHECK-SESSION-ISOLATION") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-SENSITIVITY") :STATUS :OK))
   :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
   (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
    :NO-PRODUCTION-ALLOCATION-CLAIM))
  :NATIVE-IO
  (:STATUS :OK :SCRIPTS
   (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS
    T :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
   :EMPTY-AND-CLOSED
   (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
   :SATURATION
   (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
   :ALLOCATION
   (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420865584 :SUCCESS-AFTER
    420865584 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420865584 :EMPTY-AFTER
    420865584 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
    :POSITIVE-BEFORE 420865584 :POSITIVE-MINIMUM-DETECTED 1048576
    :POSITIVE-AFTER 422910064 :POSITIVE-BYTES-CONSED 2044480
    :NATIVE-ALLOCATOR-TRACED NIL)
   :DISASSEMBLY
   ((:FUNCTION #A((16) BASE-CHAR . "NATIVE-RECV-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x80125E1988                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; 988:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 98C:       AA0F00F9         STR R0, [CFP, #24]
; 990:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 994:       693F0091         ADD TMP, CSP, #15
; 998:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 99C:       3B410091         ADD CSP, TMP, #16
; 9A0:       2C1D0091         ADD R2, TMP, #7
; 9A4:       AB1740F9         LDR R1, [CFP, #40]
; 9A8:       2B3500A9         STP R1, R3, [TMP]
; 9AC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 9B0:       20400091         ADD NL0, NL1, #16
; 9B4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 9B8:       003A80D2         MOVZ NL0, #464
; 9BC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 9C0:       2A0000A9         STP R0, NL0, [NL1]
; 9C4:       AC6A20F8         STR R2, [THREAD, NL0]
; 9C8:       AA1740F9         LDR R0, [CFP, #40]
; 9CC:       41050091         ADD NL1, R0, #1
; 9D0:       A01B40F9         LDR NL0, [CFP, #48]
; 9D4:       00FC4193         ASR NL0, NL0, #1
; 9D8:       2100008B         ADD NL1, NL1, NL0
; 9DC:       AA1340F9         LDR R0, [CFP, #32]
; 9E0:       AD1F40F9         LDR R3, [CFP, #56]
; 9E4:       041080D2         MOVZ NL4, #128
; 9E8:       40FD4193         ASR NL0, R0, #1
; 9EC:       A2FD4193         ASR NL2, R3, #1
; 9F0:       E30304AA         MOV NL3, NL4
; 9F4:       74430091         ADD R10, CSP, #16
; 9F8:       D6010010         ADR LEXENV, L0
; 9FC:       7D5B00A9         STP CFP, LEXENV, [CSP]
; A00:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; A04:       B3F7FF58         LDR R9, #x80125E18F8            ; recv
; A08:       60023FD6         BLR R9
; A0C:       110080D2         MOVZ R7, #0
; A10:       100080D2         MOVZ R6, #0
; A14:       0F0080D2         MOVZ R5, #0
; A18:       0E0080D2         MOVZ R4, #0
; A1C:       0D0080D2         MOVZ R3, #0
; A20:       0C0080D2         MOVZ R2, #0
; A24:       0B0080D2         MOVZ R1, #0
; A28:       0A0080D2         MOVZ R0, #0
; A2C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; A30: L0:   0C0000AB         ADDS R2, NL0, NL0
; A34:       E7010054         BVC L2
; A38:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; A3C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; A40:       2C410091         ADD R2, TMP, #16
; A44:       9F011EEB         CMP R2, LR
; A48:       C8040054         BHI L5
; A4C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; A50: L1:   2C3D0091         ADD R2, TMP, #15
; A54:       3E2280D2         MOVZ LR, #273
; A58:       3E0100A9         STP LR, NL0, [TMP]
; A5C:       BF3A03D5         DMB ISHST
; A60:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; A64:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; A68:       5E0000B4         CBZ LR, L2
; A6C:       200120D4         BRK #9                          ; Pending interrupt trap
; A70: L2:   9F0900B1         CMN R2, #2
; A74:       01030054         BNE L4
; A78:       AC2300F9         STR R2, [CFP, #64]
; A7C:       7D0300F9         STR CFP, [CSP]
; A80:       96F2FF58         LDR LEXENV, #x80125E18D0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; A84:       170080D2         MOVZ NARGS, #0
; A88:       DE9240F8         LDR LR, [LEXENV, #9]
; A8C:       FD031BAA         MOV CFP, CSP
; A90:       C0033FD6         BLR LR
; A94:       AC2340F9         LDR R2, [CFP, #64]
; A98:       EB030AAA         MOV R1, R0
; A9C: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; AA0:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; AA4:       AA6A20F8         STR R0, [THREAD, NL0]
; AA8:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; AAC:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; AB0:       EA030CAA         MOV R0, R2
; AB4:       F9031DAA         MOV OCFP, CFP
; AB8:       3B430091         ADD CSP, OCFP, #16
; ABC:       970080D2         MOVZ NARGS, #4
; AC0:       EC031AAA         MOV R2, NULL
; AC4:       ED031AAA         MOV R3, NULL
; AC8:       FF031FEB         CMP ZR, ZR
; ACC:       BD7B40A9         LDP CFP, LR, [CFP]
; AD0:       C0035FD6         RET
; AD4: L4:   0B0080D2         MOVZ R1, #0
; AD8:       F1FFFF17         B L3
; ADC:       E00120D4         BRK #15                         ; Invalid argument count trap
; AE0: L5:   090280D2         MOVZ TMP, #16
; AE4:       ECF0FF58         LDR R2, #x80125E1900            ; SB-VM::ALLOC-TRAMP
; AE8:       80013FD6         BLR R2
; AEC:       D9FFFF17         B L1
")
    (:FUNCTION #A((16) BASE-CHAR . "NATIVE-SEND-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x80125BC7A8                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 7A8:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 7AC:       AA0F00F9         STR R0, [CFP, #24]
; 7B0:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 7B4:       693F0091         ADD TMP, CSP, #15
; 7B8:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 7BC:       3B410091         ADD CSP, TMP, #16
; 7C0:       2C1D0091         ADD R2, TMP, #7
; 7C4:       AB1740F9         LDR R1, [CFP, #40]
; 7C8:       2B3500A9         STP R1, R3, [TMP]
; 7CC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7D0:       20400091         ADD NL0, NL1, #16
; 7D4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 7D8:       003A80D2         MOVZ NL0, #464
; 7DC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 7E0:       2A0000A9         STP R0, NL0, [NL1]
; 7E4:       AC6A20F8         STR R2, [THREAD, NL0]
; 7E8:       AA1740F9         LDR R0, [CFP, #40]
; 7EC:       41050091         ADD NL1, R0, #1
; 7F0:       A01B40F9         LDR NL0, [CFP, #48]
; 7F4:       00FC4193         ASR NL0, NL0, #1
; 7F8:       2100008B         ADD NL1, NL1, NL0
; 7FC:       AA1340F9         LDR R0, [CFP, #32]
; 800:       AD1F40F9         LDR R3, [CFP, #56]
; 804:       E4036DB2         MOV NL4, #524288
; 808:       041080F2         MOVK NL4, #128
; 80C:       40FD4193         ASR NL0, R0, #1
; 810:       A2FD4193         ASR NL2, R3, #1
; 814:       E30304AA         MOV NL3, NL4
; 818:       74430091         ADD R10, CSP, #16
; 81C:       D6010010         ADR LEXENV, L0
; 820:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 824:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 828:       93F7FF58         LDR R9, #x80125BC718            ; send
; 82C:       60023FD6         BLR R9
; 830:       110080D2         MOVZ R7, #0
; 834:       100080D2         MOVZ R6, #0
; 838:       0F0080D2         MOVZ R5, #0
; 83C:       0E0080D2         MOVZ R4, #0
; 840:       0D0080D2         MOVZ R3, #0
; 844:       0C0080D2         MOVZ R2, #0
; 848:       0B0080D2         MOVZ R1, #0
; 84C:       0A0080D2         MOVZ R0, #0
; 850:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 854: L0:   0C0000AB         ADDS R2, NL0, NL0
; 858:       E7010054         BVC L2
; 85C:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 860:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 864:       2C410091         ADD R2, TMP, #16
; 868:       9F011EEB         CMP R2, LR
; 86C:       C8040054         BHI L5
; 870:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 874: L1:   2C3D0091         ADD R2, TMP, #15
; 878:       3E2280D2         MOVZ LR, #273
; 87C:       3E0100A9         STP LR, NL0, [TMP]
; 880:       BF3A03D5         DMB ISHST
; 884:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 888:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 88C:       5E0000B4         CBZ LR, L2
; 890:       200120D4         BRK #9                          ; Pending interrupt trap
; 894: L2:   9F0900B1         CMN R2, #2
; 898:       01030054         BNE L4
; 89C:       AC2300F9         STR R2, [CFP, #64]
; 8A0:       7D0300F9         STR CFP, [CSP]
; 8A4:       76F2FF58         LDR LEXENV, #x80125BC6F0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 8A8:       170080D2         MOVZ NARGS, #0
; 8AC:       DE9240F8         LDR LR, [LEXENV, #9]
; 8B0:       FD031BAA         MOV CFP, CSP
; 8B4:       C0033FD6         BLR LR
; 8B8:       AC2340F9         LDR R2, [CFP, #64]
; 8BC:       EB030AAA         MOV R1, R0
; 8C0: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 8C4:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 8C8:       AA6A20F8         STR R0, [THREAD, NL0]
; 8CC:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 8D0:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 8D4:       EA030CAA         MOV R0, R2
; 8D8:       F9031DAA         MOV OCFP, CFP
; 8DC:       3B430091         ADD CSP, OCFP, #16
; 8E0:       970080D2         MOVZ NARGS, #4
; 8E4:       EC031AAA         MOV R2, NULL
; 8E8:       ED031AAA         MOV R3, NULL
; 8EC:       FF031FEB         CMP ZR, ZR
; 8F0:       BD7B40A9         LDP CFP, LR, [CFP]
; 8F4:       C0035FD6         RET
; 8F8: L4:   0B0080D2         MOVZ R1, #0
; 8FC:       F1FFFF17         B L3
; 900:       E00120D4         BRK #15                         ; Invalid argument count trap
; 904: L5:   090280D2         MOVZ TMP, #16
; 908:       CCF0FF58         LDR R2, #x80125BC720            ; SB-VM::ALLOC-TRAMP
; 90C:       80013FD6         BLR R2
; 910:       D9FFFF17         B L1
")
    (:FUNCTION #A((7) BASE-CHAR . "IO-STEP") :CODE
     "; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x80125E08F0                       ; ARCDOCDB.SPK11::IO-STEP
; 8F0:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 8F4:       AA0F00F9         STR R0, [CFP, #24]
; 8F8:       EED146F8         LDR R4, [R5, #109]
; 8FC:       EAF9FF58         LDR R0, #x80125E0838            ; :ACTIVE
; 900:       DF010AEB         CMP R4, R0
; 904:       C0000054         BEQ L1
; 908:       EAD146F8         LDR R0, [R5, #109]
; 90C: L0:   FB031DAA         MOV CSP, CFP
; 910:       5F0300F1         CMP NULL, #0
; 914:       BD7B40A9         LDP CFP, LR, [CFP]
; 918:       C0035FD6         RET
; 91C: L1:   E15144F8         LDR NL1, [R5, #69]
; 920:       A01340F9         LDR NL0, [CFP, #32]
; 924:       1F0001EB         CMP NL0, NL1
; 928:       4AE30091         ADD R0, NULL, #56               ; T
; 92C:       4AB38A9A         CSEL R0, NULL, R0, LT
; 930:       AF1700F9         STR R5, [CFP, #40]
; 934:       7D0300F9         STR CFP, [CSP]
; 938:       4BF8FF58         LDR R1, #x80125E0840            ; :IO-CLOCK
; 93C:       B6F6FF58         LDR LEXENV, #x80125E0810        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; 940:       970080D2         MOVZ NARGS, #4
; 944:       DE9240F8         LDR LR, [LEXENV, #9]
; 948:       FD031BAA         MOV CFP, CSP
; 94C:       C0033FD6         BLR LR
; 950:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 954:       AF1740F9         LDR R5, [CFP, #40]
; 958:       AB1340F9         LDR R1, [CFP, #32]
; 95C:       EB5104F8         STR R1, [R5, #69]
; 960:       E1D143F8         LDR NL1, [R5, #61]
; 964:       A01340F9         LDR NL0, [CFP, #32]
; 968:       1F0001EB         CMP NL0, NL1
; 96C:       8A090054         BGE L7
; 970:       E25143F8         LDR NL2, [R5, #53]
; 974:       E35142F8         LDR NL3, [R5, #37]
; 978:       E15145F8         LDR NL1, [R5, #85]
; 97C:       610001CB         SUB NL1, NL3, NL1
; 980:       3F0002EB         CMP NL1, NL2
; 984:       21B0829A         CSEL NL1, NL1, NL2, LT
; 988:       E20301AA         MOV NL2, NL1
; 98C:       EED144F8         LDR R4, [R5, #77]
; 990:       AE061037         TBNZ WR4, #2, L5
; 994:       F6030EAA         MOV LEXENV, R4
; 998: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; 99C:       E1D145F8         LDR NL1, [R5, #93]
; 9A0:       210800B1         ADDS NL1, NL1, #2
; 9A4:       A6080054         BVS L8
; 9A8:       E1D105F8         STR NL1, [R5, #93]
; 9AC:       EAD140F8         LDR R0, [R5, #13]
; 9B0:       EB5141F8         LDR R1, [R5, #21]
; 9B4:       EC5145F8         LDR R2, [R5, #85]
; 9B8:       7D0300F9         STR CFP, [CSP]
; 9BC:       ED0302AA         MOV R3, NL2
; 9C0:       170180D2         MOVZ NARGS, #8
; 9C4:       DED25FF8         LDR LR, [LEXENV, #-3]
; 9C8:       FD031BAA         MOV CFP, CSP
; 9CC:       C0033FD6         BLR LR
; 9D0:       4B138B9A         CSEL R1, NULL, R1, NE
; 9D4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 9D8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; 9DC:       F0030AAA         MOV R6, R0
; 9E0:       EE030BAA         MOV R4, R1
; 9E4:       F0000036         TBZ WR6, #0, L3
; 9E8:       010E4092         AND NL1, R6, #15
; 9EC:       3F3C00F1         CMP NL1, #15
; 9F0:       C1010054         BNE L4
; 9F4:       01125FF8         LDR NL1, [R6, #-15]
; 9F8:       3F4404F1         CMP NL1, #273
; 9FC:       61010054         BNE L4
; A00: L3:   4E010037         TBNZ WR4, #0, L4
; A04:       EA030FAA         MOV R0, R5
; A08:       EB0310AA         MOV R1, R6
; A0C:       EC030EAA         MOV R2, R4
; A10:       ED0302AA         MOV R3, NL2
; A14:       36F0FF58         LDR LEXENV, #x80125E0818        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; A18:       170180D2         MOVZ NARGS, #8
; A1C:       DE9240F8         LDR LR, [LEXENV, #9]
; A20:       DE130091         ADD LR, LR, #4
; A24:       C0031FD6         BR LR
; A28: L4:   AF1700F9         STR R5, [CFP, #40]
; A2C:       EAF0FF58         LDR R0, #x80125E0848            ; :FAULTED
; A30:       E97D4BD3         UBFM TMP, R5, #11, #31
; A34:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; A38:       EAD106F8         STR R0, [R5, #109]
; A3C:       7D0300F9         STR CFP, [CSP]
; A40:       8AF0FF58         LDR R0, #x80125E0850            ; 'ARCDOCDB.SPK11::REJECTION
; A44:       ABF0FF58         LDR R1, #x80125E0858            ; :REASON
; A48:       CCF0FF58         LDR R2, #x80125E0860            ; :IO-RESULT
; A4C:       29A680D2         MOVZ TMP, #1329
; A50:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; A54:       D70080D2         MOVZ NARGS, #6
; A58:       FD031BAA         MOV CFP, CSP
; A5C:       C0033FD6         BLR LR
; A60:       AF1740F9         LDR R5, [CFP, #40]
; A64: L5:   EED142F8         LDR R4, [R5, #45]
; A68:       0AF0FF58         LDR R0, #x80125E0868            ; :INPUT
; A6C:       DF010AEB         CMP R4, R0
; A70:       C0000054         BEQ L6
; A74:       6AEDFF58         LDR R0, #x80125E0820            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; A78:       561140F8         LDR LEXENV, [R0, #1]
; A7C:       DF021AEB         CMP LEXENV, NULL
; A80:       E0010054         BEQ L9
; A84:       C5FFFF17         B L2
; A88: L6:   0AEDFF58         LDR R0, #x80125E0828            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; A8C:       561140F8         LDR LEXENV, [R0, #1]
; A90:       DF021AEB         CMP LEXENV, NULL
; A94:       60010054         BEQ L10
; A98:       C0FFFF17         B L2
; A9C: L7:   AAEEFF58         LDR R0, #x80125E0870            ; :EXPIRED
; AA0:       E97D4BD3         UBFM TMP, R5, #11, #31
; AA4:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; AA8:       EAD106F8         STR R0, [R5, #109]
; AAC:       2AEEFF58         LDR R0, #x80125E0870            ; :EXPIRED
; AB0:       97FFFF17         B L0
; AB4:       E00120D4         BRK #15                         ; Invalid argument count trap
; AB8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; ABC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; AC0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
")))
  :PROCESSES
  ((:STATUS :OK :MODE "fragmented" :SERVER-PID 89708 :CLIENT-PID 89711 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "fragmented"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((10) BASE-CHAR . \"fragmented\") :PID 89711)
"
    :STDERR "")
   (:STATUS :OK :MODE "coalesced" :SERVER-PID 89708 :CLIENT-PID 89713 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "coalesced"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"coalesced\") :PID 89713)
"
    :STDERR "")
   (:STATUS :OK :MODE "maximum" :SERVER-PID 89708 :CLIENT-PID 89714 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "maximum"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
    "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"maximum\") :PID 89714)
"
    :STDERR "")
   (:STATUS :OK :MODE "zero" :SERVER-PID 89708 :CLIENT-PID 89716 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "zero"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((4) BASE-CHAR . \"zero\") :PID 89716)
"
    :STDERR "")
   (:STATUS :OK :MODE "oversize" :SERVER-PID 89708 :CLIENT-PID 89717 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "oversize"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((8) BASE-CHAR . \"oversize\") :PID 89717)
"
    :STDERR "")
   (:STATUS :OK :MODE "truncated" :SERVER-PID 89708 :CLIENT-PID 89719 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "truncated"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"truncated\") :PID 89719)
"
    :STDERR "")
   (:STATUS :OK :MODE "session" :SERVER-PID 89708 :CLIENT-PID 89720 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "session"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"session\") :PID 89720)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-invalid-hello" :SERVER-PID 89708 :CLIENT-PID
    89721 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "session-invalid-hello"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((21) BASE-CHAR . \"session-invalid-hello\") :PID 89721)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-pre-hello" :SERVER-PID 89708 :CLIENT-PID 89723
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "session-pre-hello"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((17) BASE-CHAR . \"session-pre-hello\") :PID 89723)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-oversize-hello" :SERVER-PID 89708 :CLIENT-PID
    89724 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "session-oversize-hello"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((22) BASE-CHAR . \"session-oversize-hello\") :PID 89724)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-id-reuse" :SERVER-PID 89708 :CLIENT-PID 89725
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "session-id-reuse"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"session-id-reuse\") :PID 89725)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-server" :SERVER-PID 89708 :CLIENT-PID 89727 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "native-server"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-server\") :PID 89727)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-client" :SERVER-PID 89708 :CLIENT-PID 89728 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "native-client"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-client\") :PID 89728)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-truncated" :SERVER-PID 89708 :CLIENT-PID 89730
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((106) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-e1uyev/ipc.sock" "native-truncated"
     #A((115) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/"))
    :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"native-truncated\") :PID 89730)
"
    :STDERR ""))
  :NAMESPACE
  (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
   :REPLACEMENT-PRESERVED T)
  :NATIVE-SYMLINK-BIND
  (:BIND-RESULT :BOUND :LINK (16777232 1569349201 41453) :TARGET
   (16777232 1569349202 49645))
  :LIMITS
  (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
   :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
 :STDOUT "(:STATUS :OK :SPIKE :SPK-11 :FRAMING
 (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
  :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
 :SESSION
 (:STATUS :OK :CASES
  ((:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-WIRE\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-MAPS\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-NEGOTIATION\") :STATUS :OK)
   (:CASE #A((20) BASE-CHAR . \"CHECK-SESSION-CREDIT\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-CORRELATION\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-TIME\") :STATUS :OK)
   (:CASE #A((23) BASE-CHAR . \"CHECK-SESSION-ISOLATION\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-SENSITIVITY\") :STATUS :OK))
  :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
  (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
   :NO-PRODUCTION-ALLOCATION-CLAIM))
 :NATIVE-IO
 (:STATUS :OK :SCRIPTS
  (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS T
   :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
  :EMPTY-AND-CLOSED
  (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
  :SATURATION
  (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
  :ALLOCATION
  (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420865584 :SUCCESS-AFTER
   420865584 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420865584 :EMPTY-AFTER
   420865584 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
   :POSITIVE-BEFORE 420865584 :POSITIVE-MINIMUM-DETECTED 1048576
   :POSITIVE-AFTER 422910064 :POSITIVE-BYTES-CONSED 2044480
   :NATIVE-ALLOCATOR-TRACED NIL)
  :DISASSEMBLY
  ((:FUNCTION #A((16) BASE-CHAR . \"NATIVE-RECV-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x80125E1988                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; 988:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 98C:       AA0F00F9         STR R0, [CFP, #24]
; 990:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 994:       693F0091         ADD TMP, CSP, #15
; 998:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 99C:       3B410091         ADD CSP, TMP, #16
; 9A0:       2C1D0091         ADD R2, TMP, #7
; 9A4:       AB1740F9         LDR R1, [CFP, #40]
; 9A8:       2B3500A9         STP R1, R3, [TMP]
; 9AC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 9B0:       20400091         ADD NL0, NL1, #16
; 9B4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 9B8:       003A80D2         MOVZ NL0, #464
; 9BC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 9C0:       2A0000A9         STP R0, NL0, [NL1]
; 9C4:       AC6A20F8         STR R2, [THREAD, NL0]
; 9C8:       AA1740F9         LDR R0, [CFP, #40]
; 9CC:       41050091         ADD NL1, R0, #1
; 9D0:       A01B40F9         LDR NL0, [CFP, #48]
; 9D4:       00FC4193         ASR NL0, NL0, #1
; 9D8:       2100008B         ADD NL1, NL1, NL0
; 9DC:       AA1340F9         LDR R0, [CFP, #32]
; 9E0:       AD1F40F9         LDR R3, [CFP, #56]
; 9E4:       041080D2         MOVZ NL4, #128
; 9E8:       40FD4193         ASR NL0, R0, #1
; 9EC:       A2FD4193         ASR NL2, R3, #1
; 9F0:       E30304AA         MOV NL3, NL4
; 9F4:       74430091         ADD R10, CSP, #16
; 9F8:       D6010010         ADR LEXENV, L0
; 9FC:       7D5B00A9         STP CFP, LEXENV, [CSP]
; A00:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; A04:       B3F7FF58         LDR R9, #x80125E18F8            ; recv
; A08:       60023FD6         BLR R9
; A0C:       110080D2         MOVZ R7, #0
; A10:       100080D2         MOVZ R6, #0
; A14:       0F0080D2         MOVZ R5, #0
; A18:       0E0080D2         MOVZ R4, #0
; A1C:       0D0080D2         MOVZ R3, #0
; A20:       0C0080D2         MOVZ R2, #0
; A24:       0B0080D2         MOVZ R1, #0
; A28:       0A0080D2         MOVZ R0, #0
; A2C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; A30: L0:   0C0000AB         ADDS R2, NL0, NL0
; A34:       E7010054         BVC L2
; A38:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; A3C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; A40:       2C410091         ADD R2, TMP, #16
; A44:       9F011EEB         CMP R2, LR
; A48:       C8040054         BHI L5
; A4C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; A50: L1:   2C3D0091         ADD R2, TMP, #15
; A54:       3E2280D2         MOVZ LR, #273
; A58:       3E0100A9         STP LR, NL0, [TMP]
; A5C:       BF3A03D5         DMB ISHST
; A60:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; A64:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; A68:       5E0000B4         CBZ LR, L2
; A6C:       200120D4         BRK #9                          ; Pending interrupt trap
; A70: L2:   9F0900B1         CMN R2, #2
; A74:       01030054         BNE L4
; A78:       AC2300F9         STR R2, [CFP, #64]
; A7C:       7D0300F9         STR CFP, [CSP]
; A80:       96F2FF58         LDR LEXENV, #x80125E18D0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; A84:       170080D2         MOVZ NARGS, #0
; A88:       DE9240F8         LDR LR, [LEXENV, #9]
; A8C:       FD031BAA         MOV CFP, CSP
; A90:       C0033FD6         BLR LR
; A94:       AC2340F9         LDR R2, [CFP, #64]
; A98:       EB030AAA         MOV R1, R0
; A9C: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; AA0:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; AA4:       AA6A20F8         STR R0, [THREAD, NL0]
; AA8:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; AAC:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; AB0:       EA030CAA         MOV R0, R2
; AB4:       F9031DAA         MOV OCFP, CFP
; AB8:       3B430091         ADD CSP, OCFP, #16
; ABC:       970080D2         MOVZ NARGS, #4
; AC0:       EC031AAA         MOV R2, NULL
; AC4:       ED031AAA         MOV R3, NULL
; AC8:       FF031FEB         CMP ZR, ZR
; ACC:       BD7B40A9         LDP CFP, LR, [CFP]
; AD0:       C0035FD6         RET
; AD4: L4:   0B0080D2         MOVZ R1, #0
; AD8:       F1FFFF17         B L3
; ADC:       E00120D4         BRK #15                         ; Invalid argument count trap
; AE0: L5:   090280D2         MOVZ TMP, #16
; AE4:       ECF0FF58         LDR R2, #x80125E1900            ; SB-VM::ALLOC-TRAMP
; AE8:       80013FD6         BLR R2
; AEC:       D9FFFF17         B L1
\")
   (:FUNCTION #A((16) BASE-CHAR . \"NATIVE-SEND-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x80125BC7A8                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 7A8:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 7AC:       AA0F00F9         STR R0, [CFP, #24]
; 7B0:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 7B4:       693F0091         ADD TMP, CSP, #15
; 7B8:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 7BC:       3B410091         ADD CSP, TMP, #16
; 7C0:       2C1D0091         ADD R2, TMP, #7
; 7C4:       AB1740F9         LDR R1, [CFP, #40]
; 7C8:       2B3500A9         STP R1, R3, [TMP]
; 7CC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7D0:       20400091         ADD NL0, NL1, #16
; 7D4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 7D8:       003A80D2         MOVZ NL0, #464
; 7DC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 7E0:       2A0000A9         STP R0, NL0, [NL1]
; 7E4:       AC6A20F8         STR R2, [THREAD, NL0]
; 7E8:       AA1740F9         LDR R0, [CFP, #40]
; 7EC:       41050091         ADD NL1, R0, #1
; 7F0:       A01B40F9         LDR NL0, [CFP, #48]
; 7F4:       00FC4193         ASR NL0, NL0, #1
; 7F8:       2100008B         ADD NL1, NL1, NL0
; 7FC:       AA1340F9         LDR R0, [CFP, #32]
; 800:       AD1F40F9         LDR R3, [CFP, #56]
; 804:       E4036DB2         MOV NL4, #524288
; 808:       041080F2         MOVK NL4, #128
; 80C:       40FD4193         ASR NL0, R0, #1
; 810:       A2FD4193         ASR NL2, R3, #1
; 814:       E30304AA         MOV NL3, NL4
; 818:       74430091         ADD R10, CSP, #16
; 81C:       D6010010         ADR LEXENV, L0
; 820:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 824:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 828:       93F7FF58         LDR R9, #x80125BC718            ; send
; 82C:       60023FD6         BLR R9
; 830:       110080D2         MOVZ R7, #0
; 834:       100080D2         MOVZ R6, #0
; 838:       0F0080D2         MOVZ R5, #0
; 83C:       0E0080D2         MOVZ R4, #0
; 840:       0D0080D2         MOVZ R3, #0
; 844:       0C0080D2         MOVZ R2, #0
; 848:       0B0080D2         MOVZ R1, #0
; 84C:       0A0080D2         MOVZ R0, #0
; 850:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 854: L0:   0C0000AB         ADDS R2, NL0, NL0
; 858:       E7010054         BVC L2
; 85C:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 860:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 864:       2C410091         ADD R2, TMP, #16
; 868:       9F011EEB         CMP R2, LR
; 86C:       C8040054         BHI L5
; 870:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 874: L1:   2C3D0091         ADD R2, TMP, #15
; 878:       3E2280D2         MOVZ LR, #273
; 87C:       3E0100A9         STP LR, NL0, [TMP]
; 880:       BF3A03D5         DMB ISHST
; 884:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 888:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 88C:       5E0000B4         CBZ LR, L2
; 890:       200120D4         BRK #9                          ; Pending interrupt trap
; 894: L2:   9F0900B1         CMN R2, #2
; 898:       01030054         BNE L4
; 89C:       AC2300F9         STR R2, [CFP, #64]
; 8A0:       7D0300F9         STR CFP, [CSP]
; 8A4:       76F2FF58         LDR LEXENV, #x80125BC6F0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 8A8:       170080D2         MOVZ NARGS, #0
; 8AC:       DE9240F8         LDR LR, [LEXENV, #9]
; 8B0:       FD031BAA         MOV CFP, CSP
; 8B4:       C0033FD6         BLR LR
; 8B8:       AC2340F9         LDR R2, [CFP, #64]
; 8BC:       EB030AAA         MOV R1, R0
; 8C0: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 8C4:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 8C8:       AA6A20F8         STR R0, [THREAD, NL0]
; 8CC:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 8D0:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 8D4:       EA030CAA         MOV R0, R2
; 8D8:       F9031DAA         MOV OCFP, CFP
; 8DC:       3B430091         ADD CSP, OCFP, #16
; 8E0:       970080D2         MOVZ NARGS, #4
; 8E4:       EC031AAA         MOV R2, NULL
; 8E8:       ED031AAA         MOV R3, NULL
; 8EC:       FF031FEB         CMP ZR, ZR
; 8F0:       BD7B40A9         LDP CFP, LR, [CFP]
; 8F4:       C0035FD6         RET
; 8F8: L4:   0B0080D2         MOVZ R1, #0
; 8FC:       F1FFFF17         B L3
; 900:       E00120D4         BRK #15                         ; Invalid argument count trap
; 904: L5:   090280D2         MOVZ TMP, #16
; 908:       CCF0FF58         LDR R2, #x80125BC720            ; SB-VM::ALLOC-TRAMP
; 90C:       80013FD6         BLR R2
; 910:       D9FFFF17         B L1
\")
   (:FUNCTION #A((7) BASE-CHAR . \"IO-STEP\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x80125E08F0                       ; ARCDOCDB.SPK11::IO-STEP
; 8F0:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 8F4:       AA0F00F9         STR R0, [CFP, #24]
; 8F8:       EED146F8         LDR R4, [R5, #109]
; 8FC:       EAF9FF58         LDR R0, #x80125E0838            ; :ACTIVE
; 900:       DF010AEB         CMP R4, R0
; 904:       C0000054         BEQ L1
; 908:       EAD146F8         LDR R0, [R5, #109]
; 90C: L0:   FB031DAA         MOV CSP, CFP
; 910:       5F0300F1         CMP NULL, #0
; 914:       BD7B40A9         LDP CFP, LR, [CFP]
; 918:       C0035FD6         RET
; 91C: L1:   E15144F8         LDR NL1, [R5, #69]
; 920:       A01340F9         LDR NL0, [CFP, #32]
; 924:       1F0001EB         CMP NL0, NL1
; 928:       4AE30091         ADD R0, NULL, #56               ; T
; 92C:       4AB38A9A         CSEL R0, NULL, R0, LT
; 930:       AF1700F9         STR R5, [CFP, #40]
; 934:       7D0300F9         STR CFP, [CSP]
; 938:       4BF8FF58         LDR R1, #x80125E0840            ; :IO-CLOCK
; 93C:       B6F6FF58         LDR LEXENV, #x80125E0810        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; 940:       970080D2         MOVZ NARGS, #4
; 944:       DE9240F8         LDR LR, [LEXENV, #9]
; 948:       FD031BAA         MOV CFP, CSP
; 94C:       C0033FD6         BLR LR
; 950:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 954:       AF1740F9         LDR R5, [CFP, #40]
; 958:       AB1340F9         LDR R1, [CFP, #32]
; 95C:       EB5104F8         STR R1, [R5, #69]
; 960:       E1D143F8         LDR NL1, [R5, #61]
; 964:       A01340F9         LDR NL0, [CFP, #32]
; 968:       1F0001EB         CMP NL0, NL1
; 96C:       8A090054         BGE L7
; 970:       E25143F8         LDR NL2, [R5, #53]
; 974:       E35142F8         LDR NL3, [R5, #37]
; 978:       E15145F8         LDR NL1, [R5, #85]
; 97C:       610001CB         SUB NL1, NL3, NL1
; 980:       3F0002EB         CMP NL1, NL2
; 984:       21B0829A         CSEL NL1, NL1, NL2, LT
; 988:       E20301AA         MOV NL2, NL1
; 98C:       EED144F8         LDR R4, [R5, #77]
; 990:       AE061037         TBNZ WR4, #2, L5
; 994:       F6030EAA         MOV LEXENV, R4
; 998: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; 99C:       E1D145F8         LDR NL1, [R5, #93]
; 9A0:       210800B1         ADDS NL1, NL1, #2
; 9A4:       A6080054         BVS L8
; 9A8:       E1D105F8         STR NL1, [R5, #93]
; 9AC:       EAD140F8         LDR R0, [R5, #13]
; 9B0:       EB5141F8         LDR R1, [R5, #21]
; 9B4:       EC5145F8         LDR R2, [R5, #85]
; 9B8:       7D0300F9         STR CFP, [CSP]
; 9BC:       ED0302AA         MOV R3, NL2
; 9C0:       170180D2         MOVZ NARGS, #8
; 9C4:       DED25FF8         LDR LR, [LEXENV, #-3]
; 9C8:       FD031BAA         MOV CFP, CSP
; 9CC:       C0033FD6         BLR LR
; 9D0:       4B138B9A         CSEL R1, NULL, R1, NE
; 9D4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 9D8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; 9DC:       F0030AAA         MOV R6, R0
; 9E0:       EE030BAA         MOV R4, R1
; 9E4:       F0000036         TBZ WR6, #0, L3
; 9E8:       010E4092         AND NL1, R6, #15
; 9EC:       3F3C00F1         CMP NL1, #15
; 9F0:       C1010054         BNE L4
; 9F4:       01125FF8         LDR NL1, [R6, #-15]
; 9F8:       3F4404F1         CMP NL1, #273
; 9FC:       61010054         BNE L4
; A00: L3:   4E010037         TBNZ WR4, #0, L4
; A04:       EA030FAA         MOV R0, R5
; A08:       EB0310AA         MOV R1, R6
; A0C:       EC030EAA         MOV R2, R4
; A10:       ED0302AA         MOV R3, NL2
; A14:       36F0FF58         LDR LEXENV, #x80125E0818        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; A18:       170180D2         MOVZ NARGS, #8
; A1C:       DE9240F8         LDR LR, [LEXENV, #9]
; A20:       DE130091         ADD LR, LR, #4
; A24:       C0031FD6         BR LR
; A28: L4:   AF1700F9         STR R5, [CFP, #40]
; A2C:       EAF0FF58         LDR R0, #x80125E0848            ; :FAULTED
; A30:       E97D4BD3         UBFM TMP, R5, #11, #31
; A34:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; A38:       EAD106F8         STR R0, [R5, #109]
; A3C:       7D0300F9         STR CFP, [CSP]
; A40:       8AF0FF58         LDR R0, #x80125E0850            ; 'ARCDOCDB.SPK11::REJECTION
; A44:       ABF0FF58         LDR R1, #x80125E0858            ; :REASON
; A48:       CCF0FF58         LDR R2, #x80125E0860            ; :IO-RESULT
; A4C:       29A680D2         MOVZ TMP, #1329
; A50:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; A54:       D70080D2         MOVZ NARGS, #6
; A58:       FD031BAA         MOV CFP, CSP
; A5C:       C0033FD6         BLR LR
; A60:       AF1740F9         LDR R5, [CFP, #40]
; A64: L5:   EED142F8         LDR R4, [R5, #45]
; A68:       0AF0FF58         LDR R0, #x80125E0868            ; :INPUT
; A6C:       DF010AEB         CMP R4, R0
; A70:       C0000054         BEQ L6
; A74:       6AEDFF58         LDR R0, #x80125E0820            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; A78:       561140F8         LDR LEXENV, [R0, #1]
; A7C:       DF021AEB         CMP LEXENV, NULL
; A80:       E0010054         BEQ L9
; A84:       C5FFFF17         B L2
; A88: L6:   0AEDFF58         LDR R0, #x80125E0828            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; A8C:       561140F8         LDR LEXENV, [R0, #1]
; A90:       DF021AEB         CMP LEXENV, NULL
; A94:       60010054         BEQ L10
; A98:       C0FFFF17         B L2
; A9C: L7:   AAEEFF58         LDR R0, #x80125E0870            ; :EXPIRED
; AA0:       E97D4BD3         UBFM TMP, R5, #11, #31
; AA4:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; AA8:       EAD106F8         STR R0, [R5, #109]
; AAC:       2AEEFF58         LDR R0, #x80125E0870            ; :EXPIRED
; AB0:       97FFFF17         B L0
; AB4:       E00120D4         BRK #15                         ; Invalid argument count trap
; AB8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; ABC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; AC0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
\")))
 :PROCESSES
 ((:STATUS :OK :MODE \"fragmented\" :SERVER-PID 89708 :CLIENT-PID 89711 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"fragmented\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 89711)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"coalesced\" :SERVER-PID 89708 :CLIENT-PID 89713 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"coalesced\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 89713)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"maximum\" :SERVER-PID 89708 :CLIENT-PID 89714 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"maximum\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
   \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 89714)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"zero\" :SERVER-PID 89708 :CLIENT-PID 89716 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"zero\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 89716)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"oversize\" :SERVER-PID 89708 :CLIENT-PID 89717 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"oversize\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 89717)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"truncated\" :SERVER-PID 89708 :CLIENT-PID 89719 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"truncated\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 89719)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session\" :SERVER-PID 89708 :CLIENT-PID 89720 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 89720)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 89708 :CLIENT-PID
   89721 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-invalid-hello\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 89721)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 89708 :CLIENT-PID 89723
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-pre-hello\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 89723)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 89708 :CLIENT-PID
   89724 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-oversize-hello\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 89724)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 89708 :CLIENT-PID 89725
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-id-reuse\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 89725)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-server\" :SERVER-PID 89708 :CLIENT-PID 89727 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-server\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 89727)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-client\" :SERVER-PID 89708 :CLIENT-PID 89728 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-client\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 89728)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 89708 :CLIENT-PID 89730
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((106) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-truncated\"
    #A((115) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
   :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 89730)
\"
   :STDERR \"\"))
 :NAMESPACE
 (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
  :REPLACEMENT-PRESERVED T)
 :NATIVE-SYMLINK-BIND
 (:BIND-RESULT :BOUND :LINK (16777232 1569349201 41453) :TARGET
  (16777232 1569349202 49645))
 :LIMITS
 (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
  :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
"
 :STDERR
 "(:STATUS :OK :MODE \"fragmented\" :SERVER-PID 89708 :CLIENT-PID 89711 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"fragmented\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 89711)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"coalesced\" :SERVER-PID 89708 :CLIENT-PID 89713 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"coalesced\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 89713)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"maximum\" :SERVER-PID 89708 :CLIENT-PID 89714 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"maximum\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
 \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 89714)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"zero\" :SERVER-PID 89708 :CLIENT-PID 89716 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"zero\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 89716)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"oversize\" :SERVER-PID 89708 :CLIENT-PID 89717 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"oversize\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 89717)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"truncated\" :SERVER-PID 89708 :CLIENT-PID 89719 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"truncated\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 89719)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session\" :SERVER-PID 89708 :CLIENT-PID 89720 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 89720)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 89708 :CLIENT-PID 89721
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-invalid-hello\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 89721)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 89708 :CLIENT-PID 89723
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-pre-hello\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 89723)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 89708 :CLIENT-PID 89724
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-oversize-hello\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 89724)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 89708 :CLIENT-PID 89725 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"session-id-reuse\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 1
  :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 89725)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-server\" :SERVER-PID 89708 :CLIENT-PID 89727 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-server\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 89727)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-client\" :SERVER-PID 89708 :CLIENT-PID 89728 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-client\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 89728)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 89708 :CLIENT-PID 89730 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((106) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-e1uyev/ipc.sock\" \"native-truncated\"
  #A((115) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB/spikes/SPK-11-unix-socket/out/build-aF2yY5/\"))
 :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF) :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 89730)
\"
 :STDERR \"\")
")
