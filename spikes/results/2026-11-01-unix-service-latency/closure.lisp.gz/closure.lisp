(:KIND :UNIX-BUFFER-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002533360
 :VERIFIED-FILES 1690 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/statistics-data.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6206 :STORED-BYTES 1279 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "statistics-data.lisp.gz" :UNCOMPRESSED-BYTES 6206 :UNCOMPRESSED-SHA256
    "6714850646f8c8f1caf04536846666350fab8e978b572773c186e31ffebd9442"
    :COMPRESSED-BYTES 959 :COMPRESSED-SHA256
    "d5fe8215a46dc75fb25b84339deed08d027ee16692d077777ded18e166cbe200"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 175857 :STORED-BYTES 56502 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 175857 :UNCOMPRESSED-SHA256
    "814b1515c85f2fde25e56f4f0f74a8f6cbb343d91d92a56b93693d6fd0f8eb41"
    :COMPRESSED-BYTES 56178 :COMPRESSED-SHA256
    "109458fcc9d9e72c248c3b9e8e993e1fe27240de293f5262197cccc3299dcca2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/initial-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 26125 :STORED-BYTES 3829 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "initial-archive.lisp.gz" :UNCOMPRESSED-BYTES 26125 :UNCOMPRESSED-SHA256
    "830f686bc444644d337dc5a9b0af96eb34d7f8111ec23ce22440641eaa3df595"
    :COMPRESSED-BYTES 3507 :COMPRESSED-SHA256
    "b8760e5396b20b7e1c186e8ef3c1cc97d0ef5e32c7d0d3cf3619793b333e8f37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 216662 :STORED-BYTES 21172 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-archive.lisp.gz" :UNCOMPRESSED-BYTES 216662 :UNCOMPRESSED-SHA256
    "36321b5ee59e2d919947e72c080a3f5d96895bf0aa400c5b2d06d8264870bc0d"
    :COMPRESSED-BYTES 20850 :COMPRESSED-SHA256
    "5831f196736423edf399d8d70fa078e19696be3c9bfd910735e83a587a7251ba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/comparison-final.lisp"
   :STATUS :OK :ORIGINAL-BYTES 97799 :STORED-BYTES 12258 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-final.lisp.gz" :UNCOMPRESSED-BYTES 97799 :UNCOMPRESSED-SHA256
    "8bb1534634b8c1809df5453bf52c0558f35c5e30fdea56e0a9a40c6a2d9a48d7"
    :COMPRESSED-BYTES 11934 :COMPRESSED-SHA256
    "e5070d2cc0a36cd2a018b26a4c11fcb024ba828cad616ae7cb20df4993ab53df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 96742 :STORED-BYTES 4915 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "buffer-profile-analysis.lisp.gz" :UNCOMPRESSED-BYTES 96742
    :UNCOMPRESSED-SHA256
    "96c899622e968c21b9b9f5a5c9f8501b872bfd79f2b51ae510d5fb5c7ce64748"
    :COMPRESSED-BYTES 4584 :COMPRESSED-SHA256
    "a91ea8cccc2a16bfef5c54acfbd396c71b1b1afb63fa93fd0cbd59e874014fa3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 96971 :STORED-BYTES 5628 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-profile-analysis.lisp.gz" :UNCOMPRESSED-BYTES 96971
    :UNCOMPRESSED-SHA256
    "77f93fd9192311beaa385f026d044c680567bf51e7091de681b4e79cb215bc69"
    :COMPRESSED-BYTES 5295 :COMPRESSED-SHA256
    "3c3f8036297f72dc00920a8f5a029f80ac9122391c6fc004a7ce144aadbf871e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22889 :STORED-BYTES 3708 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-analysis.lisp.gz" :UNCOMPRESSED-BYTES 22889 :UNCOMPRESSED-SHA256
    "f8ddba2b578b74898a80bf4f013bc3c3caabbf420652f5282683ea89cf965dc5"
    :COMPRESSED-BYTES 3384 :COMPRESSED-SHA256
    "72fab3f76ab08df88a33a670ac2588f7f16e82d7f26fe5f5ddd0356d475940cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-8.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11483 :STORED-BYTES 1627 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-8.lisp.gz" :UNCOMPRESSED-BYTES 11483 :UNCOMPRESSED-SHA256
    "0beedbfb568deba0c0ad79fcc105d4e4ee41e48dad6d4e7487c126ccf795d598"
    :COMPRESSED-BYTES 1312 :COMPRESSED-SHA256
    "c2ce7f84af03c4b7c4bf8c2c8ad864182bca53e6b78c9d0b7b56eb36405ddce6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-7.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11316 :STORED-BYTES 1516 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-7.lisp.gz" :UNCOMPRESSED-BYTES 11316 :UNCOMPRESSED-SHA256
    "1908deaf67f57a1831eff07fdcf39a4b83a224cb212bd7beba38c2311f3bf426"
    :COMPRESSED-BYTES 1201 :COMPRESSED-SHA256
    "d5f2afe208a4e27c69d868e05b8b5daafe179dfadce92a3e8ed85c7e81feae76"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-6.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11354 :STORED-BYTES 1489 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-6.lisp.gz" :UNCOMPRESSED-BYTES 11354 :UNCOMPRESSED-SHA256
    "0d17ef773044efe6b4f17239bd9e6474811d7c05220340f0aa0c78bdcaea11a0"
    :COMPRESSED-BYTES 1174 :COMPRESSED-SHA256
    "bfc9c55ca57791af41c716a9ec97002363484605b03f63df5df50504d075160e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11183 :STORED-BYTES 1308 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-5.lisp.gz" :UNCOMPRESSED-BYTES 11183 :UNCOMPRESSED-SHA256
    "737d91cffcdb5f01453b683006c430aabe04497fa51e7669dcf2ef8b55eb35ef"
    :COMPRESSED-BYTES 994 :COMPRESSED-SHA256
    "b70ae4dba2caee52f44a0126b921c235352c018edb8b3e7d710a4b224ca11540"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11449 :STORED-BYTES 1505 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 11449 :UNCOMPRESSED-SHA256
    "5648c83b402f8e7ff027846275e24466e9ed7e7c93bd0da79ca3efad98e33e22"
    :COMPRESSED-BYTES 1190 :COMPRESSED-SHA256
    "8650be11ebf610caef3defd58dae3d76f38cf6321b047c77030f5a665d310435"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11329 :STORED-BYTES 1414 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 11329 :UNCOMPRESSED-SHA256
    "f5424db041e54f992bb4a894c101a20bf9a7fe8f2f4c8ddfae9456e6638df8b9"
    :COMPRESSED-BYTES 1099 :COMPRESSED-SHA256
    "059d4368e73997da0ae122cc58091ce4c1627b4f09a76e5a63cbae8fd88c30a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11312 :STORED-BYTES 1438 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 11312 :UNCOMPRESSED-SHA256
    "c0253382d267e76ceb76dcf7f98deb4a5f28fa0bd6141e9f722ef4e3c39534ac"
    :COMPRESSED-BYTES 1123 :COMPRESSED-SHA256
    "e80ff915ef6258aa38beb16fa8560124acae64a095098257a6eedace501df624"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/server-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11203 :STORED-BYTES 1286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-1.lisp.gz" :UNCOMPRESSED-BYTES 11203 :UNCOMPRESSED-SHA256
    "266cd4f3474daf6967b6b4b08cf1951dde68c882fad928db20734adf0098d434"
    :COMPRESSED-BYTES 972 :COMPRESSED-SHA256
    "387751462a84852dd2868cf1b2b02b43c68fa0a4303e70f2c9790570cf480f7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6546 :STORED-BYTES 1567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6546 :UNCOMPRESSED-SHA256
    "3822489402a8151d896d673a5e47bab75d6c325556249e03f36608ceb749307d"
    :COMPRESSED-BYTES 1252 :COMPRESSED-SHA256
    "5cef1bdc295334914c7b2969b8e9d39f0afc36fa9a198c78ff4416ba241e8441"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6346 :STORED-BYTES 1449 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6346 :UNCOMPRESSED-SHA256
    "1571ce900105e6463bf91dfa8765d707b1ff2f91d465b7f60659d376f47208ed"
    :COMPRESSED-BYTES 1131 :COMPRESSED-SHA256
    "20246d3949a7fb1e22d57b6358f1f7c9ee902c2c58866e571cba8c8c7741512e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11349 :STORED-BYTES 1569 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 11349 :UNCOMPRESSED-SHA256
    "8fcac8dbf182eba83e4981d20d721e665c1bc9c706251feb66c63ab83fb05275"
    :COMPRESSED-BYTES 1247 :COMPRESSED-SHA256
    "e653d6bef6fbcffa83b09e516955bc154f7892afdb363de2a7083aa5db5cf1f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11182 :STORED-BYTES 1457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 11182 :UNCOMPRESSED-SHA256
    "c3791700c6869c11fb8ad53f6463c9ef0ec2c7df14a2d3285e7a7ff569bde24d"
    :COMPRESSED-BYTES 1135 :COMPRESSED-SHA256
    "cc1378cc5897e42ed3e13770a5ea084b4900eb199c750f6aa4498f1606d95c4b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11221 :STORED-BYTES 1433 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 11221 :UNCOMPRESSED-SHA256
    "d837a19af56bd55d9aea3165dd102230e994710445b2d4e696c8af60761eb481"
    :COMPRESSED-BYTES 1111 :COMPRESSED-SHA256
    "91f1f3788ce775295ca02e170c30793964252b33f0d17720b456cdc8c03ad306"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11050 :STORED-BYTES 1253 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 11050 :UNCOMPRESSED-SHA256
    "60d30ac0722463a124e8fdedc695a09b8d57c55eb1e74a545a1cb37b0d039473"
    :COMPRESSED-BYTES 932 :COMPRESSED-SHA256
    "07f783ec65f0201ddab827b41a45ae792c60a9329d2b0d5e2e613025a17ae502"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11312 :STORED-BYTES 1441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 11312 :UNCOMPRESSED-SHA256
    "9b2083b5d22c9f44a40fc048c41def725f504f16c8015531b9de38f88c030de0"
    :COMPRESSED-BYTES 1119 :COMPRESSED-SHA256
    "96fc5e330b823e439f7c71ffe179eb606882caee20542da91698e9b7f5e932d6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11192 :STORED-BYTES 1352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 11192 :UNCOMPRESSED-SHA256
    "3a496bd839987f9dbb6aba300d397d9702277392bd61918db94983ddc9cb730e"
    :COMPRESSED-BYTES 1030 :COMPRESSED-SHA256
    "ac3ddfda62dfa00f82314a530778b789ebea1d1a9cb54e0d247ce399029f7b48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11176 :STORED-BYTES 1377 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 11176 :UNCOMPRESSED-SHA256
    "af895e8d78695c15eb6e973d84a189d2292942be2af882226116a280110da775"
    :COMPRESSED-BYTES 1055 :COMPRESSED-SHA256
    "1817e90f5c738ca1799fb1695b64df1cb4f030f75c8c59b72ee9f24e8a9f20ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11067 :STORED-BYTES 1227 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 11067 :UNCOMPRESSED-SHA256
    "1aa0e45fa7da87273657eb2fdf9baa3a98650a9a311734d718902d6729f67394"
    :COMPRESSED-BYTES 906 :COMPRESSED-SHA256
    "d7a915ac20147acae225e2048006a65e6957c5e2d62143be002e09ddf9b72210"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21838 :STORED-BYTES 6826 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-5.lisp.gz" :UNCOMPRESSED-BYTES 21838 :UNCOMPRESSED-SHA256
    "d5de4bd298a1281cf2679af8d4cffea8323e9c1f0b3f680f1f26b90799ca3f05"
    :COMPRESSED-BYTES 6516 :COMPRESSED-SHA256
    "56498da61f316d126b3e3b1a88beca9985798241dadf67748b43d3b4f2261d95"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21518 :STORED-BYTES 6164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 21518 :UNCOMPRESSED-SHA256
    "d5a91bda728f703a6bee8b5268c77dbabfe33308df95705647be859b5df291af"
    :COMPRESSED-BYTES 5854 :COMPRESSED-SHA256
    "3d41b21f8f3e0de8b0ffcf143e33a7be9a6dd43fbd1612f755c25564ac10a2cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21721 :STORED-BYTES 6271 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 21721 :UNCOMPRESSED-SHA256
    "0d8e2f48be188c3d459fb4b1d62407576f7111838bb7fae94cef95fce7e731bd"
    :COMPRESSED-BYTES 5961 :COMPRESSED-SHA256
    "dc1a9dceedd258407b44cc3943298a362c6347b4b0229aa9c69b5ffce29796c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21453 :STORED-BYTES 5772 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 21453 :UNCOMPRESSED-SHA256
    "67a80a284edf5b6f3833b84cd0985ed62f7fa3a7315fccf35690e47f2c8d6f45"
    :COMPRESSED-BYTES 5462 :COMPRESSED-SHA256
    "e905ae9396457402605ea921ea2040ad0a8e2b4cffbe50d6e1e729dad63034f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21687 :STORED-BYTES 6224 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 21687 :UNCOMPRESSED-SHA256
    "0fb6ae8200e4474a8762f1fda5bbce2707a0b289c6d92da10720e8ecfd057054"
    :COMPRESSED-BYTES 5914 :COMPRESSED-SHA256
    "cf46d67d9140a7b9efb1618b43e335e46dc940a660bdea44b52ae2a96a4ed70e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21460 :STORED-BYTES 6412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 21460 :UNCOMPRESSED-SHA256
    "a056d4d310c372f2aafa670ce539f97af6f32c19735457b1858b22457bd7b8a8"
    :COMPRESSED-BYTES 6102 :COMPRESSED-SHA256
    "8151b3876fb55456cd97bdb8498065a465a6d39331bd5bf4947733c13fc6e0f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-5.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "58259e8b18b840113a2c991e061dce284e21e8fa5ff83bc42f74e64e49d9f4af"
    :COMPRESSED-BYTES 2413 :COMPRESSED-SHA256
    "376db4ed6607c5e4679f276fcafe372dafccdbf170bc1f720133beb3b496151e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20004 :STORED-BYTES 2668 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 20004 :UNCOMPRESSED-SHA256
    "e5fa53c3aa58363ebdc75d27cd1c4d20d3eafc5b798c02cf632d89987a80e40b"
    :COMPRESSED-BYTES 2358 :COMPRESSED-SHA256
    "dc083c30971f4b155abf3ab36696a622354117f45e193d4b244a80c10d039118"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2871 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "a20a3e6454684f109c0c20ae157c9a4be890440a1bb133775c4e7b32ff8cef3d"
    :COMPRESSED-BYTES 2561 :COMPRESSED-SHA256
    "856f64c365121f9a24f8395d88fb7b4492fd92fb02881f644b3615609a781abc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19963 :STORED-BYTES 2658 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 19963 :UNCOMPRESSED-SHA256
    "9970f8b250208db58650d9b977fe58efef8bf3581e2f02e98d8b7017f2483171"
    :COMPRESSED-BYTES 2348 :COMPRESSED-SHA256
    "d067b3dfec63e0d4dfbe9f0c6a095675e4ca4ce7ee81577cf6546a87a0d802df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2679 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "8230510467f0d750414019ef9607c0d7ecd4883a5a8757fa4c445357de825d89"
    :COMPRESSED-BYTES 2369 :COMPRESSED-SHA256
    "ec085f17e0e48ab0d600bd3cdeea1a82213b261446031ec188c21313366658e7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19992 :STORED-BYTES 2805 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 19992 :UNCOMPRESSED-SHA256
    "50ef5573af7322c386d9f7a33e22e789dcee727b8a67d418d9fbf24e84c0c11c"
    :COMPRESSED-BYTES 2495 :COMPRESSED-SHA256
    "8009b9afbefd7a5c2346ac850d6e683747409c82681e9f0704795e9dcf4f8a3e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21133 :STORED-BYTES 5292 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-5.lisp.gz" :UNCOMPRESSED-BYTES 21133 :UNCOMPRESSED-SHA256
    "78286b1b497bbdea04bd1eef0e4568cc0acdc096b7877db9aaf62d2f5ff50a00"
    :COMPRESSED-BYTES 4982 :COMPRESSED-SHA256
    "e3e2d2b953c50c0143dee432129c20bdc691694a3c8bac98a6b9f98d186035ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21318 :STORED-BYTES 5815 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 21318 :UNCOMPRESSED-SHA256
    "b0c2bb5a100eff3f091070565dc093b9afc7b3a5269c6ed22b6dc1f9eab1939e"
    :COMPRESSED-BYTES 5505 :COMPRESSED-SHA256
    "aa42c4aa5d489b407c00789c908ed548999bf52b75406f80f7c1b39bb5c02fe5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21487 :STORED-BYTES 6581 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 21487 :UNCOMPRESSED-SHA256
    "bb951599a55fdab92d59caee812b77b450ebe4c15a775037621a4b0ac44aeff2"
    :COMPRESSED-BYTES 6271 :COMPRESSED-SHA256
    "8f8283d4ffd6cb000fa42fb1c3d74b30e5b90dc7e31e32463e50d18c67ce3051"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21277 :STORED-BYTES 6104 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 21277 :UNCOMPRESSED-SHA256
    "ecd5fc66f0640c5661ab3581bb1d0f191257af24c02e75a5cc1e42ae3a7d3c64"
    :COMPRESSED-BYTES 5794 :COMPRESSED-SHA256
    "097a0ab4caa0a9b3a4b8b86c116ff9b8e02b11e4ce23e4aaa8959ef63ec8a4b0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21656 :STORED-BYTES 5793 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 21656 :UNCOMPRESSED-SHA256
    "1f18a7bd8533f038fc0eb4a3832351953d6503a9cf002200c419bb88f9434db0"
    :COMPRESSED-BYTES 5483 :COMPRESSED-SHA256
    "6799fccd038e500e8baa418811d7c6e313f31c035f9f9a0cad8f6c1938bb8be6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21333 :STORED-BYTES 6026 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 21333 :UNCOMPRESSED-SHA256
    "7d3af47f58af43a44f9363d231a186a65a152a1a2e8bc1bb5bf3802d9540f084"
    :COMPRESSED-BYTES 5716 :COMPRESSED-SHA256
    "71ed0cb50cb4777f23fbd924a4b37f5dab86db824264e82c02e84e64d2bb7630"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18477 :STORED-BYTES 2641 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-5.lisp.gz" :UNCOMPRESSED-BYTES 18477 :UNCOMPRESSED-SHA256
    "7b2b2c74792677cdec15c06ce90065c0e6cf759dc00028451a38003528f4bf9c"
    :COMPRESSED-BYTES 2331 :COMPRESSED-SHA256
    "e4821a84bc60ab06afc772390773b5d22b2f984e6fddcf713402f25bfbfd32bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17758 :STORED-BYTES 2636 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 17758 :UNCOMPRESSED-SHA256
    "8e6390a1f49043bad36de8cec2c5cfef9c8fde599eddc51d028e8b65605b9e0f"
    :COMPRESSED-BYTES 2326 :COMPRESSED-SHA256
    "aeab9342803bb9de2b05c19f00b6374bd297b472906844b20ded4f11a2febe08"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18391 :STORED-BYTES 2576 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 18391 :UNCOMPRESSED-SHA256
    "88813e45c1228ba9f31de00181220e7ac215b914afd4da5010a99c1c7a532a08"
    :COMPRESSED-BYTES 2266 :COMPRESSED-SHA256
    "722527cb58f1dbaa46df498135620fef97c33648f36cf839a3f9117343e3a0a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19622 :STORED-BYTES 3509 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 19622 :UNCOMPRESSED-SHA256
    "e1a9baa1a76abd461ab7a6184f76453fd3e6feb0309d3d9b4003d7c5b82f39f1"
    :COMPRESSED-BYTES 3199 :COMPRESSED-SHA256
    "618d5c142d2292442f43cfd91880e02f0b303893214175bdf576ea626c762d63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19843 :STORED-BYTES 3484 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 19843 :UNCOMPRESSED-SHA256
    "80786641834aea62d81f22fb37dc21c16e3a2032df14f0d669db485803a834f8"
    :COMPRESSED-BYTES 3174 :COMPRESSED-SHA256
    "c09faf8022fa0cbd1fe6d8dbe3fe09824bc0305c7caa5ffcba8a759fc63701eb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline-profile/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19707 :STORED-BYTES 3319 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 19707 :UNCOMPRESSED-SHA256
    "05c810624ed5c17e5efd82abf29ad5d9ec60fba63e5f7aa084863316c2f8a628"
    :COMPRESSED-BYTES 3009 :COMPRESSED-SHA256
    "1d22a9479bb5fb1c31f1aa525562ce5594718bb0f9e8ab9e0a6ccbef024006a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 51632 :STORED-BYTES 7733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 51632 :UNCOMPRESSED-SHA256
    "1d2c9913d0b4befadea5068b393cec972b2b175a2832886b6cbb32e36d40e9b0"
    :COMPRESSED-BYTES 7417 :COMPRESSED-SHA256
    "998e71f155726c0a07cdd6fb411777cb24bff1fa14b32f0785d291a0f7347996"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 51446 :STORED-BYTES 7592 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 51446 :UNCOMPRESSED-SHA256
    "5aca06eab33a482feb025fd67aaf3decd4f7cdfdcac0186576bdcc832fbd793f"
    :COMPRESSED-BYTES 7273 :COMPRESSED-SHA256
    "393ffe8fae5cac57bd050d0bf71f865e6a58b1e30a89e2ad1b8ea5616fda29c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/066-latency-66.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2726 :STORED-BYTES 891 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "066-latency-66.stderr.gz" :UNCOMPRESSED-BYTES 2726 :UNCOMPRESSED-SHA256
    "4f46e8a422a4664ed19eddfd44de07c16b62d9704ea2c445864ffd9fdab9e681"
    :COMPRESSED-BYTES 570 :COMPRESSED-SHA256
    "75d0c6a17dccef5224e98fe3b00712306c44c276b5d72851f70d5c6341d8d6bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/065-latency-65.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2690 :STORED-BYTES 798 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "065-latency-65.stderr.gz" :UNCOMPRESSED-BYTES 2690 :UNCOMPRESSED-SHA256
    "e9f4b2efa27659b1d31545eeb283a1182f34c3657b9be25f4408710ee3289e7a"
    :COMPRESSED-BYTES 477 :COMPRESSED-SHA256
    "243a6f45ee9905d0d89dec503aefe1ee7a42c6cf9a6daec1666ba2ffef1c5c9a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/064-latency-64.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2716 :STORED-BYTES 883 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "064-latency-64.stderr.gz" :UNCOMPRESSED-BYTES 2716 :UNCOMPRESSED-SHA256
    "ad75ac713c61256544240ff6f8b8a35610dd0f54f12083bc4f2cb58e4b265b05"
    :COMPRESSED-BYTES 562 :COMPRESSED-SHA256
    "5e22a1aa1293ae3d4c365e287d07a890bb1705923aa5adf29e26b95d481300e9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/063-latency-63.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2684 :STORED-BYTES 854 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "063-latency-63.stderr.gz" :UNCOMPRESSED-BYTES 2684 :UNCOMPRESSED-SHA256
    "7d26eeb49704f98ac226cf20d577d740cb25e6b1f1922dbdde60e786f1daec49"
    :COMPRESSED-BYTES 533 :COMPRESSED-SHA256
    "9a3f796a8b1b119ae38faa4c6c9455da96269ea46d35176f716e43e85167ff1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/062-latency-62.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2696 :STORED-BYTES 875 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "062-latency-62.stderr.gz" :UNCOMPRESSED-BYTES 2696 :UNCOMPRESSED-SHA256
    "1b726402c367ecbf2d8f191cbd2a57dd5416ba3fea9db3fa27fd297ad6df7b33"
    :COMPRESSED-BYTES 554 :COMPRESSED-SHA256
    "e9e7164819f411078f09be7b1134cdfd2d98783ca4568cb9421e693937356d00"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/061-latency-61.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2651 :STORED-BYTES 840 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "061-latency-61.stderr.gz" :UNCOMPRESSED-BYTES 2651 :UNCOMPRESSED-SHA256
    "116ba281dfdb21688072e05736fa85d300dca4d513412b38e8d2c7e3a41e715c"
    :COMPRESSED-BYTES 519 :COMPRESSED-SHA256
    "8efe8382c393562d433bc69a7215556bb03349bb4238afd0b7f2fa8f1304eba6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/060-latency-60.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2676 :STORED-BYTES 863 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "060-latency-60.stderr.gz" :UNCOMPRESSED-BYTES 2676 :UNCOMPRESSED-SHA256
    "4726b98b052a8e27a8b4e80ece79f7e0010589c0b8a2d3fc68a7a6a4c9ff1f83"
    :COMPRESSED-BYTES 542 :COMPRESSED-SHA256
    "d0b0866fc59da265c7b12afa7c8ab9cfc6d57b329260af8d43ca1aa53f1e3ca3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/059-latency-59.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 829 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "059-latency-59.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "a27e0b393174e5a359c2b8c0bd88fe2362aec2c452f76cf22964ee8b16650cae"
    :COMPRESSED-BYTES 508 :COMPRESSED-SHA256
    "e264ed1a83c3894ecbdbfc704137cedfd92dff6e5067985ac30032b12cd47063"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/058-latency-58.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2653 :STORED-BYTES 832 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "058-latency-58.stderr.gz" :UNCOMPRESSED-BYTES 2653 :UNCOMPRESSED-SHA256
    "dc93cb07ed885bf4c18e930000d5c098eb12cc91f4f4df266cdc0fa78ce60ebe"
    :COMPRESSED-BYTES 511 :COMPRESSED-SHA256
    "d38c40c72e9f84ad98b872b534ffd077a4da526976d798d6ab680d37289b0480"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/057-latency-57.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2613 :STORED-BYTES 817 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "057-latency-57.stderr.gz" :UNCOMPRESSED-BYTES 2613 :UNCOMPRESSED-SHA256
    "6b52a8aac9b98b90f2550f61d3f796f1411847ac866b1d413681252c1ddc303b"
    :COMPRESSED-BYTES 496 :COMPRESSED-SHA256
    "2a719fd820600cf5127fbe3cc49ca7ab9643bfa4d0f10355954616b41e95e4b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/056-latency-56.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2685 :STORED-BYTES 799 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "056-latency-56.stderr.gz" :UNCOMPRESSED-BYTES 2685 :UNCOMPRESSED-SHA256
    "b627ffb57541b29d3924ca35d59891bf18af01402477effe9677c81979977d33"
    :COMPRESSED-BYTES 478 :COMPRESSED-SHA256
    "78fee1e716e6cb923b2bc98a0c1ef1edd39cd1ef246ca586496ab88fdffda929"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/055-latency-55.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2655 :STORED-BYTES 769 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "055-latency-55.stderr.gz" :UNCOMPRESSED-BYTES 2655 :UNCOMPRESSED-SHA256
    "5384b6af9fa109e50c3d51d6f2f329e0e0f8fbb6108f183264431877de369da1"
    :COMPRESSED-BYTES 448 :COMPRESSED-SHA256
    "6748e805884bf0ff17fb5cef54c52336708f4572b2f1f692152e79046c0c8cd9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/054-latency-54.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2666 :STORED-BYTES 785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "054-latency-54.stderr.gz" :UNCOMPRESSED-BYTES 2666 :UNCOMPRESSED-SHA256
    "0af9c6075a284f0afd3d01658cb62ea48630495ced5d503478760607a6a074cf"
    :COMPRESSED-BYTES 464 :COMPRESSED-SHA256
    "f3af7b3fb2e58e4f2bc1e73fcd036856712d4502eb35decbcf565b9dada6e39a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/053-latency-53.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "053-latency-53.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "8ce227982b4da439d7dc2b6d1ef0e97bc2b2df739561e4103c9d849d2c71081e"
    :COMPRESSED-BYTES 446 :COMPRESSED-SHA256
    "0344058a36f574cacb1b79ca380d8bce2384ff2975feffcb44e44e89010a1dba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/052-latency-52.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2656 :STORED-BYTES 777 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "052-latency-52.stderr.gz" :UNCOMPRESSED-BYTES 2656 :UNCOMPRESSED-SHA256
    "3ae389da37a5ea09c0a3df35d6621e4bfdc37274b4f79cd0cfb677898315d19b"
    :COMPRESSED-BYTES 456 :COMPRESSED-SHA256
    "a2e92fab049a4b0c44a5a045f8955157cbc8b9c97080c10e0cecef461a8ab397"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/051-latency-51.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2631 :STORED-BYTES 761 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "051-latency-51.stderr.gz" :UNCOMPRESSED-BYTES 2631 :UNCOMPRESSED-SHA256
    "6355abe990e01183c5eb8291d6ba0b7714f15601c432ba1da2dec0d98f2037bb"
    :COMPRESSED-BYTES 440 :COMPRESSED-SHA256
    "3f69276384cfbebade5b7e9ff2b754f0f3ef62b2dc76dd8dac03c360af30a76c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/050-latency-50.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2642 :STORED-BYTES 759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "050-latency-50.stderr.gz" :UNCOMPRESSED-BYTES 2642 :UNCOMPRESSED-SHA256
    "26df2c5192c66d959838bf9521c6474c0a98127280038387f179578577e542a4"
    :COMPRESSED-BYTES 438 :COMPRESSED-SHA256
    "26241b2f925734984cf4d31ca9e20ada1136ff1f0294f1402219f413314640d4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/049-latency-49.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2617 :STORED-BYTES 764 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "049-latency-49.stderr.gz" :UNCOMPRESSED-BYTES 2617 :UNCOMPRESSED-SHA256
    "cbdcee968998d9ebfdbc3d25fb564553e15dce93c9bd158129dfe8ab0615356e"
    :COMPRESSED-BYTES 443 :COMPRESSED-SHA256
    "441d4ad3ad011096c8d93e0c118e60ad6dbe263fb50c325b48f5367e6eb0a6d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/048-latency-48.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "048-latency-48.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "0b2f827ef45837fcfd42607ff22beb2744ed7a5e6dd27da42bc6ef373cefc45f"
    :COMPRESSED-BYTES 468 :COMPRESSED-SHA256
    "8cfbf88cb47c990349910f7cb501680794bc8dcc08a143df01364806cd7344f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/047-latency-47.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "047-latency-47.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "281243c5f70441b147efbee0d2eae86ed833f797cb4efc94cb076fdccb7d3f17"
    :COMPRESSED-BYTES 438 :COMPRESSED-SHA256
    "fb846bf5473dcfafc5c77e160c3e990b04f260852fee1bb1637c4311759c0608"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/046-latency-46.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2611 :STORED-BYTES 752 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "046-latency-46.stderr.gz" :UNCOMPRESSED-BYTES 2611 :UNCOMPRESSED-SHA256
    "d3b7eb92b1558a60d74bf91fd6700b2a4ba7e55caf56b3a0c358cdd2a34e6527"
    :COMPRESSED-BYTES 431 :COMPRESSED-SHA256
    "f147708384b660eb0e495413dd9d39c3256439cecdc799c8faa057dcb9463e92"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/045-latency-45.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2580 :STORED-BYTES 745 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "045-latency-45.stderr.gz" :UNCOMPRESSED-BYTES 2580 :UNCOMPRESSED-SHA256
    "4f2fe820c995143acd974e05b0b1e20901ebdddca1c351d87df44e48478f2f58"
    :COMPRESSED-BYTES 424 :COMPRESSED-SHA256
    "09f9acb3eb80daa8b476ac7b06750c74d268f9cbae0d1b91ae6ddf8d31641c51"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/044-latency-44.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 794 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "044-latency-44.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "d597a385d44de12c59bfe8fd158a0dfbc6b6bdcf966bd3b4febe25850027e7e9"
    :COMPRESSED-BYTES 473 :COMPRESSED-SHA256
    "97729f290c42243bc2aa1e104dbe0a3c04ceccb00c5ce6023909336ebdc6dda1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/043-latency-43.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 752 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "043-latency-43.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "2ecaae7c1d5ebd209aa46244a8077686553d29f51bbfe206222c75b3cf8d81f3"
    :COMPRESSED-BYTES 431 :COMPRESSED-SHA256
    "4b7e16f7a27709615229998535afc41e57c990973bd10d012739f426a720d267"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/042-latency-42.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "042-latency-42.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "ec22ba72361aa253b5db665721af6c9fcfc3b76e49a7c472e0be45d6172ebb3c"
    :COMPRESSED-BYTES 426 :COMPRESSED-SHA256
    "01dbef2a551df6c7c7a9fbe140935856f8af6658bb786c3c6f35b6f5b6ae7928"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/041-latency-41.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2571 :STORED-BYTES 747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "041-latency-41.stderr.gz" :UNCOMPRESSED-BYTES 2571 :UNCOMPRESSED-SHA256
    "b24552376a3c5eaee195dda82f2945307e0add39b2874eaa8482b65b39111c67"
    :COMPRESSED-BYTES 426 :COMPRESSED-SHA256
    "83f5473b01dce2c6833d2b0dfd8ccbf3c07afd9ed7c48192101ad2eaf7bbb08a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/040-latency-40.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 790 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "040-latency-40.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "580988acda2a3be95edc4366129e47a99ab59e7beebb83acf1320d31a0708dc0"
    :COMPRESSED-BYTES 469 :COMPRESSED-SHA256
    "df8970b0ef723438dd2635939e2b0dca9f036c19a690396f37c30ba5300dde16"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/039-latency-39.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 745 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "039-latency-39.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "f799aee2619efe9513056a6bcbe0577e76fc590a1940338353d22bfe12e27711"
    :COMPRESSED-BYTES 424 :COMPRESSED-SHA256
    "fe6fae43a3bdc5d02284244da3c1dc527c1fc46ee0016435dba980b31206c1a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/038-latency-38.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "038-latency-38.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "a0aa07b959b7c311b592a58c6499afd2fd61e9d2abd815c85082730d882ddec3"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "b8b1dcb7448e7f5f784f6afd84c43ebf34a6becbf05fa82ec4bcb016e3300ef8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/037-latency-37.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2571 :STORED-BYTES 743 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "037-latency-37.stderr.gz" :UNCOMPRESSED-BYTES 2571 :UNCOMPRESSED-SHA256
    "a9d910e58b4307a1268b5ad22617b1ceec7f8ef0df3a75fb20131115b7b9fe05"
    :COMPRESSED-BYTES 422 :COMPRESSED-SHA256
    "8439bf02f64dd7d97925782b933de0e05a426b2c5002eefca5b8e3956e876ce4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/036-latency-36.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2630 :STORED-BYTES 741 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "036-latency-36.stderr.gz" :UNCOMPRESSED-BYTES 2630 :UNCOMPRESSED-SHA256
    "88cf067240ceb7b4d61f2a7ae3c0407866ab961fde59c52b2ad856130043ab2e"
    :COMPRESSED-BYTES 420 :COMPRESSED-SHA256
    "f1ca9b15c5aedf110dd024eff5c95c4388290be4b205b96e1f2384e1f3e24f68"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/035-latency-35.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2625 :STORED-BYTES 746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "035-latency-35.stderr.gz" :UNCOMPRESSED-BYTES 2625 :UNCOMPRESSED-SHA256
    "dbc5ec84e7de24557c558f05cf858f1e92dd08bedffdb1c06abf8f8a4cab39d6"
    :COMPRESSED-BYTES 425 :COMPRESSED-SHA256
    "6dab29506110f0369f75adbfcdbfe2b0bd6c692dba953afea8aa8071c4e1c269"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/034-latency-34.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2618 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "034-latency-34.stderr.gz" :UNCOMPRESSED-BYTES 2618 :UNCOMPRESSED-SHA256
    "9630814e586557f24212d472b350abe738328cbd0a3e18fbd91f1e88a55e33fd"
    :COMPRESSED-BYTES 414 :COMPRESSED-SHA256
    "e06e8c37a054b95deaf283f9c331ff1fb4d6182c46d13452174728f01f5f519b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/033-latency-33.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2597 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "033-latency-33.stderr.gz" :UNCOMPRESSED-BYTES 2597 :UNCOMPRESSED-SHA256
    "75b681a7c94ad318a9df1fc2565c76126c17ba407341ded423af9a7079e47516"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "22dee20b0e2df04ada3f2416809691a4b663929a61c994438ad41f7471c3ea4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/032-latency-32.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "032-latency-32.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "9b2b03c24ba6073d716ad0393e786855205e6940e47035b5f891bb7319a67b65"
    :COMPRESSED-BYTES 412 :COMPRESSED-SHA256
    "17c824c87c15f079cef91c83a1bb77ac391e139a6d20647b5de0d0a732972e5f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/031-latency-31.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "031-latency-31.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "eabfb2a0700d70b21196db471fce848e76927a391453caf55138b465b990cd32"
    :COMPRESSED-BYTES 414 :COMPRESSED-SHA256
    "0478643b9caa579a51442985821f20aa3bdcfb004a5a5f871fff2de3e9a09661"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/030-latency-30.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "030-latency-30.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "90d74dfbea5b1160318bb4d6888d10d072970f647be81f717b398f27cb4b0771"
    :COMPRESSED-BYTES 402 :COMPRESSED-SHA256
    "9ddacd661b2798bbdb0db99d5857ea4695c02bda7d649ecadbcf383a379e5011"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/029-latency-29.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2590 :STORED-BYTES 721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "029-latency-29.stderr.gz" :UNCOMPRESSED-BYTES 2590 :UNCOMPRESSED-SHA256
    "9c14276e52bea8574a808eed1e7ad798d28a7efe4b1496682b0e9297461a02b0"
    :COMPRESSED-BYTES 400 :COMPRESSED-SHA256
    "1c208b77342401bdbf7feb4007a87d73efc7e04dceef8cd7e807b580f3153368"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/028-latency-28.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "028-latency-28.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "af142f8101e9e2c6a67c77ed0b90ba9ec574e6390325e9d8f12b155b45bf8d47"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "889b42895a6434a461e24dfa755e127328b0ef1309ed7299e15a61b80e478048"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/027-latency-27.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "027-latency-27.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "6199c229fbb6427edafc130234ccc1c1c72021517e12fb2a003cfb844404273a"
    :COMPRESSED-BYTES 402 :COMPRESSED-SHA256
    "e6e74db66085e6d54d1381a79528edd4017440530a30a6a7702db43d83d509c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/026-latency-26.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 724 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "026-latency-26.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "f819c13c51788c88a07de7d6c8e24c901bc213838b7ab8956b4308fe332b466b"
    :COMPRESSED-BYTES 403 :COMPRESSED-SHA256
    "687a7518588b0bd22e5a7cd63ba2235092fe059650c948b970e0286ef5e73f48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/025-latency-25.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2590 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "025-latency-25.stderr.gz" :UNCOMPRESSED-BYTES 2590 :UNCOMPRESSED-SHA256
    "3fe4b64df3e3c5ed408970d33a01035df8809048ff3e8636098bcac992c9dbbd"
    :COMPRESSED-BYTES 399 :COMPRESSED-SHA256
    "3aef1fbc07843a7e682e7fd5924c3cb3ed7d9269860bcccdde8b93310a64e9d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/024-latency-24.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 798 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "024-latency-24.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "bae345dc3a302a8500346a9ca3b289a756ac9e3fa016bd47557ff4d818c2e2f1"
    :COMPRESSED-BYTES 477 :COMPRESSED-SHA256
    "fec3978c0bed150aefd9aa2ce09369d88ee4ba713edb6878c74f6c006461bd75"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/023-latency-23.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 757 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "023-latency-23.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "154fdc4e3c3ecf8832a85635d8041f1beed3e43ef92848c1e715b0da4332de92"
    :COMPRESSED-BYTES 436 :COMPRESSED-SHA256
    "f036a68103833d950d2b1f7b8cb4dae9461380ebab2cb4d0f3949f627b99f454"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/022-latency-22.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2613 :STORED-BYTES 753 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "022-latency-22.stderr.gz" :UNCOMPRESSED-BYTES 2613 :UNCOMPRESSED-SHA256
    "bd398185281be25ed245217d297e05c97fc8816503ca57869498e1ce958fb70b"
    :COMPRESSED-BYTES 432 :COMPRESSED-SHA256
    "063463015f21f5587373dea813e254534c1c8b91991c3acf54e4acc8c37600a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/021-latency-21.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2579 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "021-latency-21.stderr.gz" :UNCOMPRESSED-BYTES 2579 :UNCOMPRESSED-SHA256
    "8ee7e74c6dd8818d7cf3068b0bc6650612b8176a0c54d2ebcdd4241a6718c16e"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "d0f279fcf3d501f663fc04fcef80710f79bbc88c70d8ce7f0c16ed102e3339a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/020-latency-20.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2643 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "020-latency-20.stderr.gz" :UNCOMPRESSED-BYTES 2643 :UNCOMPRESSED-SHA256
    "e751ef09e5386067b5fdb71d489a7aaaeb46d745077a1e68d72b0d238f14a446"
    :COMPRESSED-BYTES 468 :COMPRESSED-SHA256
    "34fb8e06f52388d438ac6603a22b1d9a8c393f96ed400c98cc6173f67c049533"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/019-latency-19.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "019-latency-19.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "53c02a16020c396890cac28338f72303a53dd66d61f7c3dbd0a6084a64e0b8d3"
    :COMPRESSED-BYTES 435 :COMPRESSED-SHA256
    "4b327e907aafd3daf385037b6821729c1a6f7a9d23e6c3e7155220cbfa47e327"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/018-latency-18.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "018-latency-18.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "661f082fa7f2eb6c32f52e470e78cf6f3bada21bbcf9d9d91b98daa4421aaf71"
    :COMPRESSED-BYTES 419 :COMPRESSED-SHA256
    "e407c102e104ef55bf7e72037c5dd0b7ba3db514ff9d2a07b4d7a0f037c3b073"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/017-latency-17.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2571 :STORED-BYTES 738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "017-latency-17.stderr.gz" :UNCOMPRESSED-BYTES 2571 :UNCOMPRESSED-SHA256
    "f34640cfe12533ebfaa14afae601f573b9138fe503c463c951d8f38b303c6df3"
    :COMPRESSED-BYTES 417 :COMPRESSED-SHA256
    "73ca0474d4b2b449a732c6fbea5137622ef31c5fd75074b0116436afe853c455"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/016-latency-16.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2644 :STORED-BYTES 781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "016-latency-16.stderr.gz" :UNCOMPRESSED-BYTES 2644 :UNCOMPRESSED-SHA256
    "78a819016d668d8f44b8ae0502bf6264270ee5c191203d0851c0e6ed6c1f8796"
    :COMPRESSED-BYTES 460 :COMPRESSED-SHA256
    "1f95304a3f2f551a9d5465bc671e707f03e9b3a58b6af8231724629b16332d0c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/015-latency-15.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "015-latency-15.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "57375e19647f2b8db8f00c5faae4ed35c1f2fba54adfde1205859aa8d30259ae"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "48dec6ee9bb66ddb42be62ef73d7073cbb4785ec664cc7fa8f5957ad2b9107e1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/014-latency-14.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 752 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "014-latency-14.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "5c107fd65c3f0b70964dc222cf6d098dbc30398ae8c83c01b5d130d114ac63bc"
    :COMPRESSED-BYTES 431 :COMPRESSED-SHA256
    "4513fe13ddef27dc1019020076746aac155eeb70b20f695364d8cdb9c5fc1428"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/013-latency-13.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2574 :STORED-BYTES 747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "013-latency-13.stderr.gz" :UNCOMPRESSED-BYTES 2574 :UNCOMPRESSED-SHA256
    "53ee9b8794425f98dbd34c5da3655e376b40e8ce4f030e30514faf0eb7868a1e"
    :COMPRESSED-BYTES 426 :COMPRESSED-SHA256
    "ef7401f6146f684be86126329c4ee4e114ec861d993674d4c184054c06428a95"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2633 :STORED-BYTES 748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 2633 :UNCOMPRESSED-SHA256
    "23b2b704bac708d9446bea0ab3ea7bb6a720fc9028a882f66df39af07cb31380"
    :COMPRESSED-BYTES 427 :COMPRESSED-SHA256
    "56ed34a585c37aec20deeaaddb167567aa8de14735d30ebf97def463ee530b14"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2625 :STORED-BYTES 746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 2625 :UNCOMPRESSED-SHA256
    "91f07357f71b0bbe2ca1daaf903200177417888e7f16c029a613ea31ca820fe1"
    :COMPRESSED-BYTES 425 :COMPRESSED-SHA256
    "5ae87c67fe4eaeb43eba1bfaeb82f4c8a81074909cc46249f5c4be6f43c8d176"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2623 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 2623 :UNCOMPRESSED-SHA256
    "67706b2453ec5137ac067b34215d0cc91f505387269fbc0ef50df3f26e696535"
    :COMPRESSED-BYTES 414 :COMPRESSED-SHA256
    "447e0586bfb9ed6f4a35a624be68f05ada7b0b212a2ece9411f53bb5bb5752a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2600 :STORED-BYTES 731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 2600 :UNCOMPRESSED-SHA256
    "3ba9a9a4ec8a00f724cfb40cdce749d848ce7d428bc4fd8f63539847a9cc2b65"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "354c103e4cf5c7e24540dd2e29c632cca25cfad2a14b9c36cdbd70df3cc1557a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "6ef37454fadfde0076b611826024f2bd259ed2052e3a9e977ea6699b9aab8729"
    :COMPRESSED-BYTES 415 :COMPRESSED-SHA256
    "224572c2b78548ee6780ea4d90afb2a8359fb43baf049b0fe46029519d687cdd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "94064feda1b5334995562df83bb38c7916e090a5570aa206fc4fd999c3f850df"
    :COMPRESSED-BYTES 413 :COMPRESSED-SHA256
    "16be0671c6441a4287b8988e788f2825994668f94b3af9264c7534d068c388fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "b50c1ee085bf96f29fe2c95603701e5137e15fd399339eaf6db62f777cf20ee9"
    :COMPRESSED-BYTES 412 :COMPRESSED-SHA256
    "174010bed7ffa55eb7a52a64a9227eff07aa8f955df6d8fb740e677e1729eaca"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2595 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2595 :UNCOMPRESSED-SHA256
    "63ea1f3e2ce9c9a48c5c2853baa8b584c9a3231d403b06bd001107ff8c3c238b"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "0e30dbfe278c24b49c38b27ec56a024a3e6c640ce3e0ce51b8d3032f5fe405d4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2621 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 2621 :UNCOMPRESSED-SHA256
    "35d896018817d7b4a3fdd6d62fe89c0a357fe84d17208e0c404f5080c32992a7"
    :COMPRESSED-BYTES 422 :COMPRESSED-SHA256
    "11d2b94b0ee366432a5569375f7da600bf889543ade5ddbab0a3edeeebaf24e3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "b1e8af429ef6a1f2eaaa10075f9a66b79234d88f6b7908629607642496b90db1"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "9b08106ceb27b67702fce5798326a2caeb78f1bdbfb0d35f0ee8184f693ca507"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "0b55b2217e2e309de459245d5732752dd418565f98256fc4084f3b908c6cda23"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "6916a5834e0af31a919c07bb0aa3162e49a0a692f43f447fd4f2c2c9175a6107"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2593 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2593 :UNCOMPRESSED-SHA256
    "133034f8119ab221d22af9834ed549e454e5956087c1eca7428c74e1f546957a"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "55bf648e54ca7c76922c9e188811f48a14e67d12a99e2961a548639903438e1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20031 :STORED-BYTES 3484 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 20031 :UNCOMPRESSED-SHA256
    "5dab30ad4183cc3a9572e86c2d4680af760f264157288553556256a9a061448c"
    :COMPRESSED-BYTES 3174 :COMPRESSED-SHA256
    "10068f1e933a8451d9c611916e3cbd1d197b5da6ee64639849118b2351dac401"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19778 :STORED-BYTES 3551 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 19778 :UNCOMPRESSED-SHA256
    "7ab47117414aa34a2df5e11b5c0a3c3797d27d97f69bbcda21e58dc96d24f264"
    :COMPRESSED-BYTES 3241 :COMPRESSED-SHA256
    "4081fcc8a594c733137c5787caaca1d70535c0deeac6074697b347826fa65d7c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18322 :STORED-BYTES 2938 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 18322 :UNCOMPRESSED-SHA256
    "5ac0e7a29b3e14fae5b9d6016dfb4cf3f6f2e5a9b6f271c9b0abda10fee38ecb"
    :COMPRESSED-BYTES 2628 :COMPRESSED-SHA256
    "8bb0ab02ee674a8d0d2b04061418118d658f37b0dca4f7453ddeb1d0ddc86881"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20036 :STORED-BYTES 3555 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 20036 :UNCOMPRESSED-SHA256
    "a3488b15561f24814cc2178df9cf41fb891cfd226745bc23d0072cc63e5f2512"
    :COMPRESSED-BYTES 3245 :COMPRESSED-SHA256
    "676e2c4c0527782733bcacf2f20c0c7e4780f428c23f21f0588c4fdafa6b7ab1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20033 :STORED-BYTES 3606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 20033 :UNCOMPRESSED-SHA256
    "f9c3a7e85384dd6f640cb90cd14c6c4eb7fe2475915ab53ca3dddca116cc825b"
    :COMPRESSED-BYTES 3296 :COMPRESSED-SHA256
    "e425ddcace5de5b23527dcf2a4ac16b35b67f49dc7d577f17f828f01ce08e07a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8958 :STORED-BYTES 2112 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 8958 :UNCOMPRESSED-SHA256
    "eda0d77276c20e71654ed13faabb3209671c2a66473adbf695d250b397b015f8"
    :COMPRESSED-BYTES 1803 :COMPRESSED-SHA256
    "d49e8dc6e50068102c201b8d1131019d94a1c445ac29c1c9b36c2a4795b2fc1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8873 :STORED-BYTES 2093 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 8873 :UNCOMPRESSED-SHA256
    "bfbb2850ad3510223a2d832c844151f83d275a027af208050fe1aad4ca3cd42b"
    :COMPRESSED-BYTES 1784 :COMPRESSED-SHA256
    "d6a6607f58e3d5f8cb483c22714f901fe6fb77bcf22ade78304fce9f84604e1c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8987 :STORED-BYTES 2205 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 8987 :UNCOMPRESSED-SHA256
    "a617c2590dbe1b3be21da8967726717e63b37e12c70da9ba1847121eb125a0b0"
    :COMPRESSED-BYTES 1896 :COMPRESSED-SHA256
    "d4d2364f6f690f7a2093b9a74ec76aaa5087de37160e9f7705858215b36309bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8840 :STORED-BYTES 1771 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 8840 :UNCOMPRESSED-SHA256
    "d4ec85c0786a3f9432447e5cd34125e864d1438c122c75a08e0b31ad34ebcaf9"
    :COMPRESSED-BYTES 1462 :COMPRESSED-SHA256
    "9217c4bc8c0a80fe7d200ea0803f39f5f96d97009787256e493ef04570954da5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8870 :STORED-BYTES 1903 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 8870 :UNCOMPRESSED-SHA256
    "39558f8ab59de519d42db3e02b9bf78fb5abf3a54750c225f925d2ca0fa7386d"
    :COMPRESSED-BYTES 1594 :COMPRESSED-SHA256
    "352ebc3281813617e94f1ca17451956763279bff95e8a106340f43978a39e1f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/66-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30106 :STORED-BYTES 11118 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-4.lisp.gz" :UNCOMPRESSED-BYTES 30106 :UNCOMPRESSED-SHA256
    "3dc89bd7637e369c72cde5b56a036f524ec695e2c21c128eb65a79f9caf277ed"
    :COMPRESSED-BYTES 10806 :COMPRESSED-SHA256
    "0a638fbf357c57c12feabde6e0a69904f6b43abae23a35ede45a68ee19cffc6f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/66-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29754 :STORED-BYTES 10983 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-3.lisp.gz" :UNCOMPRESSED-BYTES 29754 :UNCOMPRESSED-SHA256
    "b8625889052f33d09aac7202fcfa2f1873d13ae48bd5fe49da6e879c2dbf8d3c"
    :COMPRESSED-BYTES 10671 :COMPRESSED-SHA256
    "25a2698a53d4aef801901884f6c59fe40d8174d9bb2e3885c0ed01a93216e4e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/66-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30102 :STORED-BYTES 11657 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-2.lisp.gz" :UNCOMPRESSED-BYTES 30102 :UNCOMPRESSED-SHA256
    "e49a37c4edaf660355578b5fcd3b72c8e6da9a7a6decfcf4d41f97f480d6ebac"
    :COMPRESSED-BYTES 11345 :COMPRESSED-SHA256
    "26692fa54de9e45022ce8c9eede348a1f8db3bc37f7147fe0f300e598d08b13f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/66-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30186 :STORED-BYTES 11780 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-1.lisp.gz" :UNCOMPRESSED-BYTES 30186 :UNCOMPRESSED-SHA256
    "121e28bc5f361d6b3c0dbaaba78a27bd090c04e479512b18ab5534cb13b28c31"
    :COMPRESSED-BYTES 11468 :COMPRESSED-SHA256
    "a772025df0a61c20471d693b3da2c180ab93f7e7315b545b93d12d39927c3014"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/66-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28945 :STORED-BYTES 10782 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-0.lisp.gz" :UNCOMPRESSED-BYTES 28945 :UNCOMPRESSED-SHA256
    "8a7a39709f9eed3059d8d1c78c3f10668982d2ad3d9d43eb83baed47255ed7bb"
    :COMPRESSED-BYTES 10470 :COMPRESSED-SHA256
    "be26af3ef03a3d3bb266e4eb409774bd326314b6fdc8ea39c4b4afb910048f56"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/65-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29659 :STORED-BYTES 10890 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-4.lisp.gz" :UNCOMPRESSED-BYTES 29659 :UNCOMPRESSED-SHA256
    "359beb6de954b53330e9fbf7ff82e614091a406433b90f4a6845d01c2aee76a4"
    :COMPRESSED-BYTES 10578 :COMPRESSED-SHA256
    "def43f9c0f21d8fa528dd9889429acd074a47c76d846c8ffd71a3c03dad22b2b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/65-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29867 :STORED-BYTES 11263 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-3.lisp.gz" :UNCOMPRESSED-BYTES 29867 :UNCOMPRESSED-SHA256
    "fcea474cd0752671431d5b473b56bb663a638395461749ee943b61e144c764df"
    :COMPRESSED-BYTES 10951 :COMPRESSED-SHA256
    "1e831b9e59cbe34cbf8a07e3056cb10b2ac41c7558fc2e72567d89f65430e019"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/65-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29622 :STORED-BYTES 11107 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-2.lisp.gz" :UNCOMPRESSED-BYTES 29622 :UNCOMPRESSED-SHA256
    "6618a60ac2317aee923ee9418edc65b00256d1043c8145f94dcc24d94c94b0a7"
    :COMPRESSED-BYTES 10795 :COMPRESSED-SHA256
    "76c68c525c7d914fd31dd772b46494a25457def6eb8005d2468c225d21946d10"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/65-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29506 :STORED-BYTES 10861 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-1.lisp.gz" :UNCOMPRESSED-BYTES 29506 :UNCOMPRESSED-SHA256
    "bdcccb8269d52718ede45f3df27042d2d8e72d4b33f80f131c5be39ab89d0412"
    :COMPRESSED-BYTES 10549 :COMPRESSED-SHA256
    "5b0ab0ba49278962a88f86a1fe71efa7df91d8478777d7a6ad35e8963c2ea97f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/65-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28459 :STORED-BYTES 10862 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-0.lisp.gz" :UNCOMPRESSED-BYTES 28459 :UNCOMPRESSED-SHA256
    "fcf6e143174bd05c7a8801f0cfdfc41552506cd65a563eb6cfcf0631c2b4cf5e"
    :COMPRESSED-BYTES 10550 :COMPRESSED-SHA256
    "a42de2a826dbcc57f74dc37258c039f71cdc6844f1085f8bbea180b4edfa61fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/64-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29377 :STORED-BYTES 10622 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-4.lisp.gz" :UNCOMPRESSED-BYTES 29377 :UNCOMPRESSED-SHA256
    "553a7f3bf8cb6e19227b30ae5768eda9b9c58008330ecaa3ccdadf55bc1b381b"
    :COMPRESSED-BYTES 10310 :COMPRESSED-SHA256
    "0cf2135889cf94e436f9d592ed4ee2c57b4dae3a48a2f68a7c76e142fe856c30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/64-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29379 :STORED-BYTES 11012 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-3.lisp.gz" :UNCOMPRESSED-BYTES 29379 :UNCOMPRESSED-SHA256
    "5f68ac7d97aba580a3652de246cd92e54df3602abfb79a466cd42ea7107de5ea"
    :COMPRESSED-BYTES 10700 :COMPRESSED-SHA256
    "9c1b585d949586721087f6eb7bc142237f3d931ef668ad51c737bd7e3cf272ce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/64-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28954 :STORED-BYTES 10911 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-2.lisp.gz" :UNCOMPRESSED-BYTES 28954 :UNCOMPRESSED-SHA256
    "a12e5b256a7c77f3ad7d6254cdc6050b9b14caf7fe3e4f0b5a5ab7b4b8333c37"
    :COMPRESSED-BYTES 10599 :COMPRESSED-SHA256
    "0f5addc954beaf512e8d9eb6f1d61693648a4fa420cbd6bef67753f2c9d1d71f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/64-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29152 :STORED-BYTES 10801 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-1.lisp.gz" :UNCOMPRESSED-BYTES 29152 :UNCOMPRESSED-SHA256
    "ebb7c1fb965ff6e384f239311c45f44a3088354e5e1fde3e7a459a433ac2b053"
    :COMPRESSED-BYTES 10489 :COMPRESSED-SHA256
    "c7388d9e8a2562edc1004ed219472adef4f001995cd0644a13f257f8e0a447bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/64-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28674 :STORED-BYTES 10751 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-0.lisp.gz" :UNCOMPRESSED-BYTES 28674 :UNCOMPRESSED-SHA256
    "06d3ce5a137be37c7482b392b2a2cb03b0bd0ca1d97517ac347dc44343cd8e77"
    :COMPRESSED-BYTES 10439 :COMPRESSED-SHA256
    "671c0558cbdfcb123c8df1fd6cf3911a3e72b6cf1f864278dd41c6ad394d40cc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/63-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21656 :STORED-BYTES 5072 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-4.lisp.gz" :UNCOMPRESSED-BYTES 21656 :UNCOMPRESSED-SHA256
    "07e6a71f9f49bef7f8e19d7f2f5494f273e8230daf04101e8302841b5f5c39e9"
    :COMPRESSED-BYTES 4761 :COMPRESSED-SHA256
    "0ede8ea666ce5322bc9170fda6663797729d796ac81ebc41813c27a7e204237f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/63-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21643 :STORED-BYTES 4822 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-3.lisp.gz" :UNCOMPRESSED-BYTES 21643 :UNCOMPRESSED-SHA256
    "aa8d489a905a663e988722d42de6774f22f9a988bac0d26c1758fb54d0da4ac0"
    :COMPRESSED-BYTES 4511 :COMPRESSED-SHA256
    "1e4763c9a1fc6ea25dd2aaa66115f51aa5c9fd85b524b7bddcbab7401801417c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/63-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21630 :STORED-BYTES 4820 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-2.lisp.gz" :UNCOMPRESSED-BYTES 21630 :UNCOMPRESSED-SHA256
    "4bf52872a47ca84872960a225aa78b307306a64b04a1b09d9b7097b42838dd36"
    :COMPRESSED-BYTES 4509 :COMPRESSED-SHA256
    "dabc0f75852adad02b4be6930f94ae61bdabe29ff15545b1cb6d372151618ee0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/63-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21638 :STORED-BYTES 4940 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-1.lisp.gz" :UNCOMPRESSED-BYTES 21638 :UNCOMPRESSED-SHA256
    "df0689e1f1bb30ed76f1f51768ca4c0347e9dce063edeecf9aab6f49b5f82160"
    :COMPRESSED-BYTES 4629 :COMPRESSED-SHA256
    "3d71b7bd2fe77a471aaac7c32a23fea2930cf79a5e6fbcd67f5f05068e8918ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/63-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21609 :STORED-BYTES 4831 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-0.lisp.gz" :UNCOMPRESSED-BYTES 21609 :UNCOMPRESSED-SHA256
    "d1f86956caa0d9c55b79a2972986fe7387e754ec0fd832eec49acb1cb93306dc"
    :COMPRESSED-BYTES 4520 :COMPRESSED-SHA256
    "3fd11ebcff786294846b1d4678077e1331a9f1c72c5ed9957714e64d0ea9888b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/62-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14420 :STORED-BYTES 5895 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-4.lisp.gz" :UNCOMPRESSED-BYTES 14420 :UNCOMPRESSED-SHA256
    "c49668df46387cae6d44e0a194fa0e57cf85691551db6e23505e3835e9feb139"
    :COMPRESSED-BYTES 5584 :COMPRESSED-SHA256
    "e53a8986294dbadcebf6caff59b8e995bf6a8db2b9567c6b8d737a4213a9acb1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/62-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14473 :STORED-BYTES 5802 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-3.lisp.gz" :UNCOMPRESSED-BYTES 14473 :UNCOMPRESSED-SHA256
    "1df1302355f9f5a3e03bce41386365f586234a207784bb09bb5f1e050949f1e0"
    :COMPRESSED-BYTES 5491 :COMPRESSED-SHA256
    "819853406789370bdcc4847c9b07ae3634fc0ddd0625bcf06358352717b03591"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/62-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14426 :STORED-BYTES 5706 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-2.lisp.gz" :UNCOMPRESSED-BYTES 14426 :UNCOMPRESSED-SHA256
    "2c26afab2171c59d899dc82c6e2d9882591313a13b6d0409ab7684ef7c7eee33"
    :COMPRESSED-BYTES 5395 :COMPRESSED-SHA256
    "12ec8a45ed43e33773baff1d5c4ec1814e4583583ba93c88f86aa9bf5dc277da"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/62-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14234 :STORED-BYTES 5865 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-1.lisp.gz" :UNCOMPRESSED-BYTES 14234 :UNCOMPRESSED-SHA256
    "d17ba77d5886dc465293b0c201e404afa5ca349edb2553bab47def7b2d163b1d"
    :COMPRESSED-BYTES 5554 :COMPRESSED-SHA256
    "643aa82dcfd4bebacf128a15d48edf58be0f264c013fe1944b2943f8675a4f78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/62-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13581 :STORED-BYTES 5939 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-0.lisp.gz" :UNCOMPRESSED-BYTES 13581 :UNCOMPRESSED-SHA256
    "211fd4c6385a6aea18fcca10b2e85d11c61286fc2935993827665b5567958125"
    :COMPRESSED-BYTES 5628 :COMPRESSED-SHA256
    "d120c23c899ac8bcd477109a397a29c810b8ba564bb9d5204d77671252ece5d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/61-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9688 :STORED-BYTES 2587 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-4.lisp.gz" :UNCOMPRESSED-BYTES 9688 :UNCOMPRESSED-SHA256
    "87301fffbc5ccb9a757c91a5549484f65d7f95554b7f0fb95b2ec9fb419feaaf"
    :COMPRESSED-BYTES 2277 :COMPRESSED-SHA256
    "95be04ccfd78d24181b5c3852462aabe0ff6856e2bafc8c8df6b7c10d599abb6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/61-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9738 :STORED-BYTES 2607 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-3.lisp.gz" :UNCOMPRESSED-BYTES 9738 :UNCOMPRESSED-SHA256
    "5d72dc547bcbb82eb9f9a63ea5743ac24583a11b5dd7dfacec0e3fbf8243aedc"
    :COMPRESSED-BYTES 2297 :COMPRESSED-SHA256
    "e2e7523ee8ec1cb65ef53468697fc8f03dc4823f3add7f9f9e7423f730cb5e6e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/61-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9747 :STORED-BYTES 2665 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-2.lisp.gz" :UNCOMPRESSED-BYTES 9747 :UNCOMPRESSED-SHA256
    "137504743d3113dbf70540d1f51061cdc159da4dc4db6dcafed1df27960b4497"
    :COMPRESSED-BYTES 2355 :COMPRESSED-SHA256
    "9eaede64a7b2441cecacf34ec360d749d02f475ff57b6c1f01beaf47170abdaa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/61-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9693 :STORED-BYTES 2514 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-1.lisp.gz" :UNCOMPRESSED-BYTES 9693 :UNCOMPRESSED-SHA256
    "829b5ce44fea7d6a4f6d1d23d97ddba618ffee3d33faa0583c219192cf2fba1c"
    :COMPRESSED-BYTES 2204 :COMPRESSED-SHA256
    "0d512afced108f2bffe04a5e4a8bc0cb4b4be7bd72a90d17bab646c8d2d16ea5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/61-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9632 :STORED-BYTES 2508 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-0.lisp.gz" :UNCOMPRESSED-BYTES 9632 :UNCOMPRESSED-SHA256
    "155e2218ef30ba072deebbcc965a81c2430acfec80e2e8fac078e954579fb3d4"
    :COMPRESSED-BYTES 2198 :COMPRESSED-SHA256
    "c4022f442d1819bf026f1ebd76805a282bd26494e8520216d0295bf7b3c5ee07"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/60-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7398 :STORED-BYTES 3184 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-4.lisp.gz" :UNCOMPRESSED-BYTES 7398 :UNCOMPRESSED-SHA256
    "cfe4e6c37ce9c4fb0f89f1332d85304ebe7eb1d18f0fdae56a86348baf3e5114"
    :COMPRESSED-BYTES 2874 :COMPRESSED-SHA256
    "fecf89087a9cff3bb04ca09cbef270f0a27552eefffd13f2755910330bcdbee0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/60-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7451 :STORED-BYTES 3237 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-3.lisp.gz" :UNCOMPRESSED-BYTES 7451 :UNCOMPRESSED-SHA256
    "719132b36c6030a22f7d634ab5139e149df787687c1bf0fcc92e2acc5ff68b9a"
    :COMPRESSED-BYTES 2927 :COMPRESSED-SHA256
    "20b665ff1ffe468f4c13f55036611ff4d8d986af85fd0dc5edaff35266cc9d3e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/60-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7290 :STORED-BYTES 3367 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-2.lisp.gz" :UNCOMPRESSED-BYTES 7290 :UNCOMPRESSED-SHA256
    "9fcdc3ac5c12a1b0f480e9b27934048f9766962c8d4dec6467de19475ff7bad8"
    :COMPRESSED-BYTES 3057 :COMPRESSED-SHA256
    "76d99827381c71946433b4c734138a4d56caa0bd923285d08e40246ca2a08e60"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/60-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7052 :STORED-BYTES 3279 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-1.lisp.gz" :UNCOMPRESSED-BYTES 7052 :UNCOMPRESSED-SHA256
    "8911ef7c56ed2ee8191320924f53f0381889662f5f021fdcf39fbe90c9521a42"
    :COMPRESSED-BYTES 2969 :COMPRESSED-SHA256
    "4d8f2f98d322427c2da8e58a9d7843ed6c7c023645eb7db24822e0545200a34f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/60-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6962 :STORED-BYTES 3197 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-0.lisp.gz" :UNCOMPRESSED-BYTES 6962 :UNCOMPRESSED-SHA256
    "51a1fe412518fe340d8c42a00456c72856ae49a7baa5bd2401a3621430c71c47"
    :COMPRESSED-BYTES 2887 :COMPRESSED-SHA256
    "8cd4fbc433d8c6a9f6a172bef756e553e20fde3a3dc9bdafb7bab78aff15dd07"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4830 :STORED-BYTES 1329 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 4830 :UNCOMPRESSED-SHA256
    "d00b594f806b910e467bee6f0989bb32ae6733fefddd983dc1a98ff8dc05937d"
    :COMPRESSED-BYTES 1020 :COMPRESSED-SHA256
    "c59c4743684d04123ba1a9cccd12b04c55663abd820c850a0fea10432c93dcd6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1239 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "bc9dc8e72d47fd1e3c8b910caabcdd07da758e9535215cc1d301d5edec7a4345"
    :COMPRESSED-BYTES 931 :COMPRESSED-SHA256
    "866fd04f1468c533f6c1184ab1047271a5fce593d7a284beadb1be95ca972de1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4819 :STORED-BYTES 1270 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 4819 :UNCOMPRESSED-SHA256
    "1983a9b24bf0b2207240a35687f6b658e3cb7aee5f750ef997c8f168a2a7c0c8"
    :COMPRESSED-BYTES 962 :COMPRESSED-SHA256
    "d8c48cce65433aeba840de39e21ad0e2c29cf6ade8532638501f95554e28bad4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4824 :STORED-BYTES 1260 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 4824 :UNCOMPRESSED-SHA256
    "a1c6424be40c1870dbb1b2884369e3611dcb797f28cbe1796901d42f3638e63f"
    :COMPRESSED-BYTES 952 :COMPRESSED-SHA256
    "7e684cac6dfff7e317adadbd26f9659c391fd038bbd65a5b325c3565e367a3f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4819 :STORED-BYTES 1218 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 4819 :UNCOMPRESSED-SHA256
    "58036d89067d28a3a8dd0a6fe5bea198d5b2df4c77f4160a6e1f3e12a2265328"
    :COMPRESSED-BYTES 910 :COMPRESSED-SHA256
    "45ddc555a2c3b9bdaa3a64020acef10f7192e0f413aa93333424c0af60b2c6c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/59-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5171 :STORED-BYTES 1857 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-4.lisp.gz" :UNCOMPRESSED-BYTES 5171 :UNCOMPRESSED-SHA256
    "3438b42867e8c13a799cd7f4c43c5e71420567576fed77637fd4e58ab1338385"
    :COMPRESSED-BYTES 1547 :COMPRESSED-SHA256
    "392a4b99c5e6a6ae525872e86469cfc846dc79c955452afe2b42991bf4d5775d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/59-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5154 :STORED-BYTES 1830 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-3.lisp.gz" :UNCOMPRESSED-BYTES 5154 :UNCOMPRESSED-SHA256
    "d47f23680a0afb824b4f0e038aa5a8b928799fcc3af700c18de8cb5d93ef601b"
    :COMPRESSED-BYTES 1520 :COMPRESSED-SHA256
    "305912f27e29937427537b2458cc9302e4ae1e4e0492ed320211f74b1bf73709"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/59-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5164 :STORED-BYTES 1841 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-2.lisp.gz" :UNCOMPRESSED-BYTES 5164 :UNCOMPRESSED-SHA256
    "3319d3b03879344d85036a2cec5da6e6a09f0a7f0d2e22611d52da8fd619bf82"
    :COMPRESSED-BYTES 1531 :COMPRESSED-SHA256
    "946f34e7734d3b329d01818580adcd25566269bb247165f65140c73a5bf107a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/59-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5073 :STORED-BYTES 1774 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-1.lisp.gz" :UNCOMPRESSED-BYTES 5073 :UNCOMPRESSED-SHA256
    "cba5ba27f0ac595a657e9b0f6eed4bd65f6e5f95017185a06f800cb13f3e95c5"
    :COMPRESSED-BYTES 1464 :COMPRESSED-SHA256
    "b2d05c87be805fa17041e3605d27ac521243e2447d8f1729e31035b8feed7c48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/59-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5076 :STORED-BYTES 1699 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-0.lisp.gz" :UNCOMPRESSED-BYTES 5076 :UNCOMPRESSED-SHA256
    "4636ff3d95b8348e00b0954aaa5e97d36eb37c5d28a665981431f1bf83e86cda"
    :COMPRESSED-BYTES 1389 :COMPRESSED-SHA256
    "c959f4714b4adccad7e0fb767c46f842ac0b9119979c48e13ebf776b457fb054"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/56-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30817 :STORED-BYTES 11537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-4.lisp.gz" :UNCOMPRESSED-BYTES 30817 :UNCOMPRESSED-SHA256
    "5d31e825c1bb71571cf72d54174a53dc65e4cd9eaee00f90043c29b16710bbe9"
    :COMPRESSED-BYTES 11225 :COMPRESSED-SHA256
    "ad8caddde091ee8b6b31057843af21cfdc7a8d778391aa40e53400733cec4b9a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/56-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30627 :STORED-BYTES 11624 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-3.lisp.gz" :UNCOMPRESSED-BYTES 30627 :UNCOMPRESSED-SHA256
    "d5bd3d848ab24028dd50328275a7a4fd9ed4db6ca7280be07f79fa95e4f5c635"
    :COMPRESSED-BYTES 11312 :COMPRESSED-SHA256
    "e1d2dead62ad4f3cb1f5e44ba81f300e914816848eb046007e45c9d3648fabf2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/56-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30481 :STORED-BYTES 11970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-2.lisp.gz" :UNCOMPRESSED-BYTES 30481 :UNCOMPRESSED-SHA256
    "3c8dad4a5f810265e3e4f2bc26a73ebf6d8bef3bf039160483af6c6a760c6b56"
    :COMPRESSED-BYTES 11658 :COMPRESSED-SHA256
    "fcac48696e2b203d9d295ed4260b97306779b01764d0357254c1bb3bf48b31f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/56-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 31056 :STORED-BYTES 11581 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-1.lisp.gz" :UNCOMPRESSED-BYTES 31056 :UNCOMPRESSED-SHA256
    "7c3740721629a13033fabb15e27b537934dca8cab4ccdd585b3e13c400928a53"
    :COMPRESSED-BYTES 11269 :COMPRESSED-SHA256
    "8ff31a3d7a7ad0640a39b17f6fc96a04f1fa6ac0b8a95c5e9f09d7cda7dfcc86"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/56-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30153 :STORED-BYTES 11751 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-0.lisp.gz" :UNCOMPRESSED-BYTES 30153 :UNCOMPRESSED-SHA256
    "5c48a9b15f4ea97b895757cbd63117a60e189597daa6d815dedbdc9022536dc7"
    :COMPRESSED-BYTES 11439 :COMPRESSED-SHA256
    "2bf5cf3af4ac5e9c07b3e3689ac609d6867a6a99e351416e23153a8173ecc9c8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/55-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21115 :STORED-BYTES 5531 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-4.lisp.gz" :UNCOMPRESSED-BYTES 21115 :UNCOMPRESSED-SHA256
    "7410e747dcb51a69f754968e5aeaab0d1c20b4e934598509612d79228a54e1a8"
    :COMPRESSED-BYTES 5220 :COMPRESSED-SHA256
    "a05e25ffe1914897f5fd031551872c2fe6669ecb99c2a0ceeeebeb250855a0f3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/55-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20523 :STORED-BYTES 5085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-3.lisp.gz" :UNCOMPRESSED-BYTES 20523 :UNCOMPRESSED-SHA256
    "0111864247dda6b45316b38f5dfaf46f9f3daf8d26f97886d311645ad6be9023"
    :COMPRESSED-BYTES 4774 :COMPRESSED-SHA256
    "b0576626d9214955f591b563114b8aeea30c4ef27b13296f19b3a41271cd0bcd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/55-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20620 :STORED-BYTES 5264 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-2.lisp.gz" :UNCOMPRESSED-BYTES 20620 :UNCOMPRESSED-SHA256
    "b29758b436072794929455d3bfd15ea521a43df293152f5951f101c51cf00f6a"
    :COMPRESSED-BYTES 4953 :COMPRESSED-SHA256
    "061553a66be5efc468ea1da9c9304119a61bb9d8f6e44495f12922f412446a4e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/55-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20971 :STORED-BYTES 5709 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-1.lisp.gz" :UNCOMPRESSED-BYTES 20971 :UNCOMPRESSED-SHA256
    "7a25e9990332e76e67c68ff764202acb735a862022fe1385c95930d9914315b8"
    :COMPRESSED-BYTES 5398 :COMPRESSED-SHA256
    "daf7128df45577e37cf150eec501db33ee8f7bff59473229cc69bb41d58b6d34"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/55-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20513 :STORED-BYTES 4873 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-0.lisp.gz" :UNCOMPRESSED-BYTES 20513 :UNCOMPRESSED-SHA256
    "3d4f9b177358b25526dea0e2f7f1b267ed55eeed707121fb93cdd5f70c87c08e"
    :COMPRESSED-BYTES 4562 :COMPRESSED-SHA256
    "43510994311fe60515655e97dbf9c995b70c5129f2176a5c57139944474db556"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/54-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14462 :STORED-BYTES 5470 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-4.lisp.gz" :UNCOMPRESSED-BYTES 14462 :UNCOMPRESSED-SHA256
    "e3e5bfe7b027a437c296340cf315162082cadf233046fb2e443e26510f1772a3"
    :COMPRESSED-BYTES 5159 :COMPRESSED-SHA256
    "52f9be77768c9938278c6d61cbb9c8bad1d8d9d05160f36c57a2e8be34078da2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/54-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14448 :STORED-BYTES 5653 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-3.lisp.gz" :UNCOMPRESSED-BYTES 14448 :UNCOMPRESSED-SHA256
    "5b744e32746e472248592d84e3cf2c16e9cb30754d4b4a5cc26473466ea8f74d"
    :COMPRESSED-BYTES 5342 :COMPRESSED-SHA256
    "0baf0f94ff5cbdd6b9b326211a034e64797a3202d8f284ea05e85a8e9bf055b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/54-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14459 :STORED-BYTES 5573 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-2.lisp.gz" :UNCOMPRESSED-BYTES 14459 :UNCOMPRESSED-SHA256
    "7ab36f9804cb85b21edaf65a4335f87bc5b9f71bd9b1dc31f6571cffd7bc4f4f"
    :COMPRESSED-BYTES 5262 :COMPRESSED-SHA256
    "24f174ef04b1ecf970395c467d36a700e04171d7c38a9071ad3758e9f17da063"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/54-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14294 :STORED-BYTES 5612 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-1.lisp.gz" :UNCOMPRESSED-BYTES 14294 :UNCOMPRESSED-SHA256
    "9971b2a6f41e56bae1b9004cdf064429af132d00f3d33fdb9f3ad1bdb115fa5a"
    :COMPRESSED-BYTES 5301 :COMPRESSED-SHA256
    "09fd8843f4e518808ad1c0a0108da028516515ff7833318df1fce085308feeda"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/54-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13609 :STORED-BYTES 5577 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-0.lisp.gz" :UNCOMPRESSED-BYTES 13609 :UNCOMPRESSED-SHA256
    "b20603d50ee70b5497c4a3691bb2805415a77db0cac82f25b891ad42d1c8c229"
    :COMPRESSED-BYTES 5266 :COMPRESSED-SHA256
    "71eebecd77e7f0f6d4175b95ea41b5d0f0f0202d8f13ec946ed7a8f8d5e4309a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/53-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9931 :STORED-BYTES 3111 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-4.lisp.gz" :UNCOMPRESSED-BYTES 9931 :UNCOMPRESSED-SHA256
    "25c97a573b14ce8459d54357be2215aa460bf2e1911a5f5a92798b8873bf89d8"
    :COMPRESSED-BYTES 2801 :COMPRESSED-SHA256
    "cbc5d25adea8e6a1e2c9812eff464937bad8ec65aa0ac2fc81a82b2167bb038f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/53-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9780 :STORED-BYTES 2911 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-3.lisp.gz" :UNCOMPRESSED-BYTES 9780 :UNCOMPRESSED-SHA256
    "2677d81f36f75c7bb99ec3963bc31134f7900a7d8e4f1fd23160604093f3d703"
    :COMPRESSED-BYTES 2601 :COMPRESSED-SHA256
    "4cf03e3a83aeb4ecd9c49f88c463014c3b6307f34b6ce7b56cc97fb766ce32db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/53-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9844 :STORED-BYTES 2923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-2.lisp.gz" :UNCOMPRESSED-BYTES 9844 :UNCOMPRESSED-SHA256
    "7f8cd36894aab90059ac33be8433499f381a278c8822ed72f3feedafe1c87bbb"
    :COMPRESSED-BYTES 2613 :COMPRESSED-SHA256
    "d59d9bbac16a2f160a229920b9118f5c1a6bb5ab20cc1ccf1ec42e1049c35670"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/53-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9804 :STORED-BYTES 2880 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-1.lisp.gz" :UNCOMPRESSED-BYTES 9804 :UNCOMPRESSED-SHA256
    "742a97b75bc74931ca7bf747471aa578a7f66ea1d45af04d9996c8c0a6a74a87"
    :COMPRESSED-BYTES 2570 :COMPRESSED-SHA256
    "d47fd2c68bca361d45122d9337a10919cfe3eebd03bb80a7e5fc8b5641a48532"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/53-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9639 :STORED-BYTES 2695 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-0.lisp.gz" :UNCOMPRESSED-BYTES 9639 :UNCOMPRESSED-SHA256
    "de69331d320a82d301a0a310efe13d0977336d3ad09769770adacf94d16b3379"
    :COMPRESSED-BYTES 2385 :COMPRESSED-SHA256
    "cbac63dde6d045861ea840e073daeedc1e5ce52704bf5a6612cf5e7bfb5fec27"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/52-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7425 :STORED-BYTES 3147 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-4.lisp.gz" :UNCOMPRESSED-BYTES 7425 :UNCOMPRESSED-SHA256
    "b34a5d555370591cd70eec802a1a5c8334aadf566dfdc5be640d44bac35c9d36"
    :COMPRESSED-BYTES 2837 :COMPRESSED-SHA256
    "d2d93c7c90135666a7eebf0979dd424f33865fe879e4ff7accccf06c794add4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/52-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7412 :STORED-BYTES 2870 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-3.lisp.gz" :UNCOMPRESSED-BYTES 7412 :UNCOMPRESSED-SHA256
    "b86b0d3e90952be6fd865cfa6f48ae173d40df9dc3871e90990aa9b87900b3f8"
    :COMPRESSED-BYTES 2560 :COMPRESSED-SHA256
    "ca3278b97cca20f9bdce2a17e976ae6a6684216ebd393e8376b8d5d5aeaf61df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/52-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7222 :STORED-BYTES 2808 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-2.lisp.gz" :UNCOMPRESSED-BYTES 7222 :UNCOMPRESSED-SHA256
    "5cc52a5d7c9a11fce4540b2637dcefad943a8eb931e338d74f35aa9a0fdda156"
    :COMPRESSED-BYTES 2498 :COMPRESSED-SHA256
    "dd1b9bc5759797536d408cdbdebfa32e82d1351a042a4fc9378c368acaf50b9c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/52-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7012 :STORED-BYTES 2841 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-1.lisp.gz" :UNCOMPRESSED-BYTES 7012 :UNCOMPRESSED-SHA256
    "6c6cc456d5165b2891b6fc56560911ca95941b65d48101bb0e19bec24d331e30"
    :COMPRESSED-BYTES 2531 :COMPRESSED-SHA256
    "4553adc383d085d594869f8d6c74a6389abc49f153a0cb27a0fa909c7aa20c98"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/52-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6924 :STORED-BYTES 2916 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-0.lisp.gz" :UNCOMPRESSED-BYTES 6924 :UNCOMPRESSED-SHA256
    "3e02f5fe773700fbcee45c6f15fe9a9a899681f9a7eba63a334ac1c04f8b8b5b"
    :COMPRESSED-BYTES 2606 :COMPRESSED-SHA256
    "c228a13869d0947c398cc94a35087e7d6fbe53435a59a34991f6508e059ae072"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/51-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5077 :STORED-BYTES 1369 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-4.lisp.gz" :UNCOMPRESSED-BYTES 5077 :UNCOMPRESSED-SHA256
    "4c6e01d76e131aa98f941cfb0d113af14f3e18bc7e0974d796916d4ff37ae53e"
    :COMPRESSED-BYTES 1059 :COMPRESSED-SHA256
    "3fef9136140e0d86c9f8231756b8b51a007dfe9227fa3b89046f5545f57624b5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/51-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5077 :STORED-BYTES 1352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-3.lisp.gz" :UNCOMPRESSED-BYTES 5077 :UNCOMPRESSED-SHA256
    "2573019ae5af75292f13bbf25d30d48cd2e37342da4520696e8a3304b7f6688a"
    :COMPRESSED-BYTES 1042 :COMPRESSED-SHA256
    "567a7d6fe8fa9a5c737891cb3c0320098b0b400cb20fe74f5ea90d261b5d5d81"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/51-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5071 :STORED-BYTES 1372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-2.lisp.gz" :UNCOMPRESSED-BYTES 5071 :UNCOMPRESSED-SHA256
    "f4c2ad94013417a20422a754d9b674fd96feb8e54cceb06e0b94886c27fc21ca"
    :COMPRESSED-BYTES 1062 :COMPRESSED-SHA256
    "408b69694b07615cc551030c027f55cb451e1b398e6281f8c53a692a8c81b7b1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/51-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5035 :STORED-BYTES 1366 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-1.lisp.gz" :UNCOMPRESSED-BYTES 5035 :UNCOMPRESSED-SHA256
    "4debb64c04203162f257a5dd23a88b16583b74aab246876765548f35bd5faaeb"
    :COMPRESSED-BYTES 1056 :COMPRESSED-SHA256
    "05594ff458c9a26df856cc42d128b2652ba49c74f814fa59cfa80ada21de4fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/51-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5035 :STORED-BYTES 1369 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-0.lisp.gz" :UNCOMPRESSED-BYTES 5035 :UNCOMPRESSED-SHA256
    "176bb5b7fb174260b778a553ab56f0f9be501bbd3f4ca0d15f7aaaf07d0bec6e"
    :COMPRESSED-BYTES 1059 :COMPRESSED-SHA256
    "78d18e4edd666c56a585d5ed2954d8e206c68c1c04e35a8a2d796ec918a2ee34"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/48-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21829 :STORED-BYTES 5956 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-4.lisp.gz" :UNCOMPRESSED-BYTES 21829 :UNCOMPRESSED-SHA256
    "96a3b4c6a9015d460d2e9ee8e81c3ec6f1e27f1aa68fb4e5c5311dce6b15f222"
    :COMPRESSED-BYTES 5645 :COMPRESSED-SHA256
    "741e9bfe1668cc13f43b33aa939e8ee519398508c44d3853666580ac90177034"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/48-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21651 :STORED-BYTES 5845 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-3.lisp.gz" :UNCOMPRESSED-BYTES 21651 :UNCOMPRESSED-SHA256
    "8ad3ba63a982ad1b073df9b4053e3dba2481e591c2b037b16f9dd198b3582c87"
    :COMPRESSED-BYTES 5534 :COMPRESSED-SHA256
    "5ad320bc17eb92a61e2bdcc07646b4e5c3941ece2925f81bd46628ec6349663f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/48-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21752 :STORED-BYTES 5909 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-2.lisp.gz" :UNCOMPRESSED-BYTES 21752 :UNCOMPRESSED-SHA256
    "4ddf223c7a4d05e0d875c32cd8c3dc73b16363d98ccc8eef4cd1a07cf4106b1f"
    :COMPRESSED-BYTES 5598 :COMPRESSED-SHA256
    "6ec5e15b7c897ac6ff692a15039fc123b6e77ee4b47d09c63ae24d34362a94e9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/48-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21749 :STORED-BYTES 5882 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-1.lisp.gz" :UNCOMPRESSED-BYTES 21749 :UNCOMPRESSED-SHA256
    "55c881dadd542c08e061f7a627e57f2bb179c1ba1a04a603078722d48998f192"
    :COMPRESSED-BYTES 5571 :COMPRESSED-SHA256
    "231557bddc4a4069109d5c41bb450afbf99ab18e26d5d21066d6bf893b5f1446"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/48-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21820 :STORED-BYTES 5965 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-0.lisp.gz" :UNCOMPRESSED-BYTES 21820 :UNCOMPRESSED-SHA256
    "67638bca26c3ed5264024bfe6b81e2207de20c6ad03b8b5d5caf3bc16ef9257b"
    :COMPRESSED-BYTES 5654 :COMPRESSED-SHA256
    "104c9b8d6cde077456095c7c7f15f27e917892f428d5e9c7bd23fc948a5f415a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/47-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10693 :STORED-BYTES 3549 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-4.lisp.gz" :UNCOMPRESSED-BYTES 10693 :UNCOMPRESSED-SHA256
    "b3ad9a40129203460ba9830e3be8ca98483e7136c4f6daccfdc041e76eb9d49e"
    :COMPRESSED-BYTES 3238 :COMPRESSED-SHA256
    "5f826e995edd53cd8c71da1c7311fb4f508eaa897e2128c598c308ae18ed03ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/47-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10758 :STORED-BYTES 3456 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-3.lisp.gz" :UNCOMPRESSED-BYTES 10758 :UNCOMPRESSED-SHA256
    "32d1e68ff3d7095d09939b9b2cd0c7d8d05ea0767424b08b4533d64f55dc0186"
    :COMPRESSED-BYTES 3145 :COMPRESSED-SHA256
    "78578eba0d49f0ad1ba4c9cfb202d0a31ee2415df9cccd22261c8d083ec39752"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/47-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10701 :STORED-BYTES 3409 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-2.lisp.gz" :UNCOMPRESSED-BYTES 10701 :UNCOMPRESSED-SHA256
    "3e6aa51254ff8afaf0e6cf730d15a3ca234ef4ff6173cd7c21db79aaf79eba42"
    :COMPRESSED-BYTES 3098 :COMPRESSED-SHA256
    "bc9d98a7ee54cd847604f7bf7a26ff44f194674c7bd64b8da2ba1ae4e6c94f28"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/47-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10709 :STORED-BYTES 3468 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-1.lisp.gz" :UNCOMPRESSED-BYTES 10709 :UNCOMPRESSED-SHA256
    "bfb29fb1ff0af5007d55c704d627c6a1886102083d9635f037e86eebc0939fa3"
    :COMPRESSED-BYTES 3157 :COMPRESSED-SHA256
    "3d7e88ffe7cf94c3ee4e72c99690b7a5eeafd57aba0617129eabb1953f711ddd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/47-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10730 :STORED-BYTES 3454 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-0.lisp.gz" :UNCOMPRESSED-BYTES 10730 :UNCOMPRESSED-SHA256
    "7f31dd33254fe5457d1762c41df1576a1add71d6ba26a0d60ed176f7a9add1f8"
    :COMPRESSED-BYTES 3143 :COMPRESSED-SHA256
    "3e29aead2c072dcea2f8ec1ffb1d1472ddb5c54c66dd7eaea9aebe357964546f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/46-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1938 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-4.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "bc3bff16b4afa207d569d9426f8fed182afc329c240f7411d00617ea835ae7e6"
    :COMPRESSED-BYTES 1628 :COMPRESSED-SHA256
    "45574024c0ca2bff495259ce622c4dfab744770f4c2a9536addf8ab451c91000"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/46-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1772 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-3.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "e775cc0e1728aa7bf6a5d9b748f98753a1740c3b2969594356cbf19983649d19"
    :COMPRESSED-BYTES 1462 :COMPRESSED-SHA256
    "076339e8cdd5af92b82fa467e00dd777ca719ca57b994a40d9b8a3c55ceb13b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/46-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5630 :STORED-BYTES 1930 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-2.lisp.gz" :UNCOMPRESSED-BYTES 5630 :UNCOMPRESSED-SHA256
    "966547a0f9e8fb948967f3acf7051928af0e0aaa8b47d9be045260d55fd23a6b"
    :COMPRESSED-BYTES 1620 :COMPRESSED-SHA256
    "3f4b087a8158359e6219e183176c71e9ac2a8b06568da001cb86819390965c3c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/46-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1939 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-1.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "5f2c6e65a0c126c699a0cdb64666774ffd46724a55eca016130079f5c36ad19b"
    :COMPRESSED-BYTES 1629 :COMPRESSED-SHA256
    "c861dce8ee83f4466e177215ac8a6b5842bf612eff1f7ea04eb000ef0f2f09d4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/46-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1959 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-0.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "2f83aa857356a5c58dc60e0185e29ba113f5dc02c5a7f93c3c03fa0ec08190f6"
    :COMPRESSED-BYTES 1649 :COMPRESSED-SHA256
    "ecabe964a6234114681e12cd4d1756b57fcf549f5fb96dacbe6e27ee38c9b778"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/44-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19915 :STORED-BYTES 3215 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-4.lisp.gz" :UNCOMPRESSED-BYTES 19915 :UNCOMPRESSED-SHA256
    "7f2d9332cecc84f3ef82bc0cf504d5b26ebca16d2dab259fca67d8d87fd7378b"
    :COMPRESSED-BYTES 2904 :COMPRESSED-SHA256
    "e73a9f47788de38848e0aa4ae4ff4d804df54789fd9ab2a96f19b75de3487e59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/44-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20016 :STORED-BYTES 3036 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-3.lisp.gz" :UNCOMPRESSED-BYTES 20016 :UNCOMPRESSED-SHA256
    "47c4523798dfa91b15c6ac0c125091c665bc33422960098da6a2a8c5bbb27808"
    :COMPRESSED-BYTES 2725 :COMPRESSED-SHA256
    "8d9b7a3e24de12b43b2e9248ef071833611f2b9987db553f822b47df30c79764"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/44-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 3279 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-2.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "9106de7bae1cd5e15d099092b25356c5b15b2cb7006a1f18173d7758cb878b32"
    :COMPRESSED-BYTES 2968 :COMPRESSED-SHA256
    "15ad70ba102eba0a2f302bdda3d7125dfbed088c7b7da289c737982213848473"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/44-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20015 :STORED-BYTES 3595 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-1.lisp.gz" :UNCOMPRESSED-BYTES 20015 :UNCOMPRESSED-SHA256
    "7f08081ef5a94536b58fcca0673bb759e5056aeb040089e6a08c37c0fe8e09f9"
    :COMPRESSED-BYTES 3284 :COMPRESSED-SHA256
    "6cc74a79bb5bddc17b77a34486e3a965cf3c56f916dd3dc3586cff9ad328f0ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/44-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 3447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-0.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "36fd3bd9c59272f2b238dc69ceaed7d762dac489c767b7c2f4635c08c19dcfdf"
    :COMPRESSED-BYTES 3136 :COMPRESSED-SHA256
    "b65139fdd13c747b27116bee806d15a6474d2bc123e7fcac0d5588f6a4ce7a65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/43-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9027 :STORED-BYTES 1944 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-4.lisp.gz" :UNCOMPRESSED-BYTES 9027 :UNCOMPRESSED-SHA256
    "5bdfd10680c52455320fd4923e823e856bb671f336efdafb17cfcb121fa896a5"
    :COMPRESSED-BYTES 1634 :COMPRESSED-SHA256
    "8a311bdf033521d33561eb0e83f3130936d059048908531537138cd7fbb5710d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/43-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9078 :STORED-BYTES 2034 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-3.lisp.gz" :UNCOMPRESSED-BYTES 9078 :UNCOMPRESSED-SHA256
    "b39f154e4d94a9826bec09a0a3ee4edfabd0697aa4ad5ccdbda061f3716be665"
    :COMPRESSED-BYTES 1724 :COMPRESSED-SHA256
    "4c4fcbbdaa84403548b3db4310096c443e3faf8ea82614afb7e4f2d7fa359b6a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/43-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8909 :STORED-BYTES 2006 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-2.lisp.gz" :UNCOMPRESSED-BYTES 8909 :UNCOMPRESSED-SHA256
    "eeb261a4f9107c204d31d5f47e7a6ca9882d93aed1f4a0f909646c8f130c6d7f"
    :COMPRESSED-BYTES 1696 :COMPRESSED-SHA256
    "04c285652f315fca3104d29a923eaa4144ed1531a388b8329b3f5a0e583385a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/43-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8912 :STORED-BYTES 1957 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-1.lisp.gz" :UNCOMPRESSED-BYTES 8912 :UNCOMPRESSED-SHA256
    "5d6baec4eff5bb312e85af853f7234103a6aac805e7762d597467661dc6bbc36"
    :COMPRESSED-BYTES 1647 :COMPRESSED-SHA256
    "3524884fcf2055a5f9d713658c9c1ea8fb04938bf159b889d12cd0a690405dac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/43-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9048 :STORED-BYTES 1951 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-0.lisp.gz" :UNCOMPRESSED-BYTES 9048 :UNCOMPRESSED-SHA256
    "f6b12bfe5cb62e1f264f2f0dbccfd5b334838a26c3c5f3f68307f9cd3dc34546"
    :COMPRESSED-BYTES 1641 :COMPRESSED-SHA256
    "98323f48ee6c6022f504521e8086afcfa5acd75f39530a234c6d93a96184e92a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/42-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1347 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "e53b463b8c00901782449c10c439e515e621158468b4f348cf57cb1dc2fcdb8d"
    :COMPRESSED-BYTES 1037 :COMPRESSED-SHA256
    "4af2ea4bb68c7d2ddb4ed65b84e1fb8ad17c8edcddd68b8d52494ee589fe863d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/42-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4818 :STORED-BYTES 1386 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-3.lisp.gz" :UNCOMPRESSED-BYTES 4818 :UNCOMPRESSED-SHA256
    "49cfa96c681e9bcbdaf88f06f994cc91f4c4a5822afa9422e81330ec4c264c96"
    :COMPRESSED-BYTES 1076 :COMPRESSED-SHA256
    "98d87a094afb534485f487cd5bed91ab02a021e0bb89b0e54c1df090ffd2d283"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/42-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4818 :STORED-BYTES 1358 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-2.lisp.gz" :UNCOMPRESSED-BYTES 4818 :UNCOMPRESSED-SHA256
    "b60847bb8b1f901022ff2f0e8babffa433c5668d65f9a91ce3174133aa984b47"
    :COMPRESSED-BYTES 1048 :COMPRESSED-SHA256
    "ac68235894928273cc9dcc0f535cc43bb1bab9482e36348588607ea29a5c1e59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/42-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1369 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "30400546c73865b8ae61f48b9cf2c5e0970a56df32ddf3ad3876b650f615c83e"
    :COMPRESSED-BYTES 1059 :COMPRESSED-SHA256
    "964b5f10808e13837f1456c6987b325bc1d8fcd9c86386e8233328c81f7ce69a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/42-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1324 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "bed16ac696a2c0c84bdf7c317743c76e8c915d0f418cf5b33bdfb5eb4024842d"
    :COMPRESSED-BYTES 1014 :COMPRESSED-SHA256
    "7bb0e03dcc953906e07f457d2c055a0bed345d1013fc2db3c587f55d79e023e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/40-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2855 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-4.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "ea1a1a73565f14f68277d859fcaf6d0cbb32e1c466ad08eced6d5a917c6faaaa"
    :COMPRESSED-BYTES 2544 :COMPRESSED-SHA256
    "aedc3edbbb3c06b32bc91e38427bcacf444a6bf7075db69880725267dff76a38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/40-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20023 :STORED-BYTES 2815 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-3.lisp.gz" :UNCOMPRESSED-BYTES 20023 :UNCOMPRESSED-SHA256
    "ef56e20dc250eda76ce09c6d3e87f8f1eede43cafa1a0202b25ed5466f3fbda6"
    :COMPRESSED-BYTES 2504 :COMPRESSED-SHA256
    "5902ecbd0863bb21d4c6b879e26e446e1dc13c0a15830f9405b21d9d8b717d47"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/40-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2815 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-2.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "8b150584724edc2817b472672748e6145b120edd1605debadfd8a63c681e33ac"
    :COMPRESSED-BYTES 2504 :COMPRESSED-SHA256
    "02b8bc5027f90e9706359908f3fe6b3ac9f5608e5296211bd79dd41a99029970"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/40-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20012 :STORED-BYTES 2931 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-1.lisp.gz" :UNCOMPRESSED-BYTES 20012 :UNCOMPRESSED-SHA256
    "f42d90f32402b797748838aa6ce1e6293794561c84a6f58dcab38b08273cf4b4"
    :COMPRESSED-BYTES 2620 :COMPRESSED-SHA256
    "79517b98167fdfb7dcfc9be03a939dae80159efbef18ffde19654f2c902656cd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/40-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19918 :STORED-BYTES 3059 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-0.lisp.gz" :UNCOMPRESSED-BYTES 19918 :UNCOMPRESSED-SHA256
    "096bfc610a76ee4a69e61ffab2630d5fc1d860e09983160057d921954418c903"
    :COMPRESSED-BYTES 2748 :COMPRESSED-SHA256
    "873af1347fd6979d87aa18cf47d241a0b46b3b081eaf8e6bffdbff13a8b0b19e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19259 :STORED-BYTES 3497 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 19259 :UNCOMPRESSED-SHA256
    "74a6e7bfd452b03a1c3eddf69b6f33c7c63c0b17a4e21c58bd67f009cdbe0cde"
    :COMPRESSED-BYTES 3187 :COMPRESSED-SHA256
    "b6f6fa9d9ce1db255b2547ee087d6f7fb4fcb0aaf1feed293009365279a005c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19176 :STORED-BYTES 3024 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 19176 :UNCOMPRESSED-SHA256
    "0c3d049560cd4dbcf5424055b180f855ecac887ffe971281e5e4d0b43d5e8b9d"
    :COMPRESSED-BYTES 2714 :COMPRESSED-SHA256
    "b920c4abaef669a448787caf902eda6035eeb364b4558db4eb609e569edc0a1d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18736 :STORED-BYTES 3470 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 18736 :UNCOMPRESSED-SHA256
    "c057f020047d91fbf3d130c451181386902153ee6eeef93ad25d9d8ae7ffdf99"
    :COMPRESSED-BYTES 3160 :COMPRESSED-SHA256
    "561d9800acc6303e6833e504e020c3bc99132d641f7fe1c30761e93210f3b09d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18091 :STORED-BYTES 2740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 18091 :UNCOMPRESSED-SHA256
    "ec1f3e84817de27a4b07669f1b52de7c6152026326f8ecb76444cd98e844dbe0"
    :COMPRESSED-BYTES 2430 :COMPRESSED-SHA256
    "f17955963ce9c49ef11ce044db30dbf74868dae1ac560ac4dc5a644fbb6768ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18800 :STORED-BYTES 3152 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 18800 :UNCOMPRESSED-SHA256
    "b371168ae4fc95b13243894244479d9bff33fe5948ee4d9f01fcbc61822b80bc"
    :COMPRESSED-BYTES 2842 :COMPRESSED-SHA256
    "55efc754f86ac050c87c02f1c0bcc511c41345f729f58c56533e381b18486497"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/39-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8837 :STORED-BYTES 1959 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-4.lisp.gz" :UNCOMPRESSED-BYTES 8837 :UNCOMPRESSED-SHA256
    "829dfbd4f9d42e9f122f70801c681e4cdb1cf8315dae3a4d275dc6819f43e39e"
    :COMPRESSED-BYTES 1649 :COMPRESSED-SHA256
    "718b22573b563cd92b9d8285134d4bd7bc14e375ae984e43908f57b851735cf8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/39-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8841 :STORED-BYTES 1965 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-3.lisp.gz" :UNCOMPRESSED-BYTES 8841 :UNCOMPRESSED-SHA256
    "4fa9d0cafd5df8e360c5cd298d7f483dec91bd376a430869adbd9a48f2dbab57"
    :COMPRESSED-BYTES 1655 :COMPRESSED-SHA256
    "6ca2ea00b8e49601b063934d450fe3576722e82246564f44e66548e0bfc150a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/39-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8848 :STORED-BYTES 1915 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-2.lisp.gz" :UNCOMPRESSED-BYTES 8848 :UNCOMPRESSED-SHA256
    "136628c1ae94fbf1043627b148853db6c73d52ce4c2ac1a06e709fb9cac8c481"
    :COMPRESSED-BYTES 1605 :COMPRESSED-SHA256
    "cbc6a267929f3a7bf9e60057b5789770b504f97d96ad69ab763d363f40145af2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/39-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8850 :STORED-BYTES 2001 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-1.lisp.gz" :UNCOMPRESSED-BYTES 8850 :UNCOMPRESSED-SHA256
    "f0c2a287aec1e56b70d3cec7e2954180b4a1f4800da431d47a40e7c2ecffd64b"
    :COMPRESSED-BYTES 1691 :COMPRESSED-SHA256
    "7e434ee819cdb2a7d0f3f37c3593077115afaa6b3198549ebc273b21af2c72c9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/39-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8858 :STORED-BYTES 1846 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-0.lisp.gz" :UNCOMPRESSED-BYTES 8858 :UNCOMPRESSED-SHA256
    "04b53653947d6bc76f6d894516c8bf0ef675814deb72012f2a58bec173ffa22e"
    :COMPRESSED-BYTES 1536 :COMPRESSED-SHA256
    "a6c5ee79375c1aae3297a82f04c48063e1cdc84cdf1a9efc650682e6cf96b42d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/38-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4815 :STORED-BYTES 1222 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-4.lisp.gz" :UNCOMPRESSED-BYTES 4815 :UNCOMPRESSED-SHA256
    "6457f7ced59072ef7b105463a11efd96adc9e7fd25a27e70358833de0acd6d74"
    :COMPRESSED-BYTES 913 :COMPRESSED-SHA256
    "e209ff8f333d53259246a44150dccd395b5b983fb370020837b76a00f8f6c641"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/38-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4812 :STORED-BYTES 1179 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-3.lisp.gz" :UNCOMPRESSED-BYTES 4812 :UNCOMPRESSED-SHA256
    "8921840f81d0fe4f933123035355cb41efa8b746d30ccab20634a3b8020442cf"
    :COMPRESSED-BYTES 870 :COMPRESSED-SHA256
    "8cbae3875bcb95c6045290008b3fd64b9ebaba4cec82390a6a924e750b78dfc4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/38-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1258 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "a3600b533bdc6c1760ea58427241ea7a36092ffa85f25b984b7df65114614b8d"
    :COMPRESSED-BYTES 949 :COMPRESSED-SHA256
    "07e1ee0c40649869d8a4069e5959cb43ffe9fc2eac237607155954d2e7fac5eb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/38-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4812 :STORED-BYTES 1286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-1.lisp.gz" :UNCOMPRESSED-BYTES 4812 :UNCOMPRESSED-SHA256
    "dd483e214ab53b5ad2254acec5df1f2803a76f016c7eb9175b5cf5db639fefdb"
    :COMPRESSED-BYTES 977 :COMPRESSED-SHA256
    "4031f50c75dd4d656c712e05b62a4c821530efdc9eba0d9870d4fa7ede589254"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/38-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4817 :STORED-BYTES 1254 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-0.lisp.gz" :UNCOMPRESSED-BYTES 4817 :UNCOMPRESSED-SHA256
    "6e295fb9bc118edc34f34daf087e7951477f76d7ef408652cbb77c6c4e37ee07"
    :COMPRESSED-BYTES 945 :COMPRESSED-SHA256
    "63a6dcadbbdbed5d58b7c00b06674a13488b7b5d1bcb4d3d2f864b48766dd24b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/36-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21622 :STORED-BYTES 6180 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-4.lisp.gz" :UNCOMPRESSED-BYTES 21622 :UNCOMPRESSED-SHA256
    "c4db36d084838767c81a8deb488f04b9ebc4b4c44b28d70fbb649315d01b8b07"
    :COMPRESSED-BYTES 5869 :COMPRESSED-SHA256
    "c51fa94ee2416aadb68eabb2055f72dd518faf20cb186d746d2e1934d687297f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/36-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21515 :STORED-BYTES 5892 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-3.lisp.gz" :UNCOMPRESSED-BYTES 21515 :UNCOMPRESSED-SHA256
    "16427cce6bce6e06e1b5fa69290cd850cae7dfdba0044d1dd59dc55a031c369f"
    :COMPRESSED-BYTES 5581 :COMPRESSED-SHA256
    "c733b344415ff4947d936c14bb0002ab47b632898db092e137c9e8f752441fe9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/36-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21604 :STORED-BYTES 5785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-2.lisp.gz" :UNCOMPRESSED-BYTES 21604 :UNCOMPRESSED-SHA256
    "26dc59ae12eb00845c82f2d6600cd457fef142b6cd460342520de6b04f4e5cb8"
    :COMPRESSED-BYTES 5474 :COMPRESSED-SHA256
    "4c23a77b86ea6af043e462ae8b4edc5166334371237ab0d4e5aa4ccb440ac88f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/36-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21521 :STORED-BYTES 5880 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-1.lisp.gz" :UNCOMPRESSED-BYTES 21521 :UNCOMPRESSED-SHA256
    "b6770e564abb9a2e77138777c7a5a1ad173cd84bf03ef81cda64c1b9479828cf"
    :COMPRESSED-BYTES 5569 :COMPRESSED-SHA256
    "6b1a571ed95b039a0390f8116b4faa2427aee4fc91c1188c98687b30db5b77c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/36-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21569 :STORED-BYTES 5932 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-0.lisp.gz" :UNCOMPRESSED-BYTES 21569 :UNCOMPRESSED-SHA256
    "2cb1d7362923be890a6b3de9d9e6a82252956a4e9e6352deb66662a0556c953e"
    :COMPRESSED-BYTES 5621 :COMPRESSED-SHA256
    "431abdfa3f6187c00c4d47b652ced9441993c94f88ab82fd666e4e8d32fd7c77"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/35-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10625 :STORED-BYTES 3395 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-4.lisp.gz" :UNCOMPRESSED-BYTES 10625 :UNCOMPRESSED-SHA256
    "308687cff4035b80d43dcc56b982d3866d6a002e9d8e3892ba494cd6fe634ffa"
    :COMPRESSED-BYTES 3084 :COMPRESSED-SHA256
    "51610edb874b4bc41bcb132862226eb1e5b23a064a60f738dfbf21f742d2d69d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/35-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10510 :STORED-BYTES 3280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-3.lisp.gz" :UNCOMPRESSED-BYTES 10510 :UNCOMPRESSED-SHA256
    "16079b981c4577d0830772ea60ea4c04f9addd64c57d964b47bf63124e1a66ac"
    :COMPRESSED-BYTES 2969 :COMPRESSED-SHA256
    "fa8b5ee076bb7991e41b2f8f4241a5e6a06b7798497a02337b4a2528873a27fb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/35-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10717 :STORED-BYTES 3453 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-2.lisp.gz" :UNCOMPRESSED-BYTES 10717 :UNCOMPRESSED-SHA256
    "4783706e5d590dade501c692713a2b89bda446291d09ca80f5bee136a30f1941"
    :COMPRESSED-BYTES 3142 :COMPRESSED-SHA256
    "4b01c99a1c4fceb8a1cb83603f439abe690d1fa729655be84d27dd7163bf8175"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/35-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10673 :STORED-BYTES 3482 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-1.lisp.gz" :UNCOMPRESSED-BYTES 10673 :UNCOMPRESSED-SHA256
    "39d37d7ac1bcd12b8797b09e9261d0d170fda0babcef973c230e622936758dce"
    :COMPRESSED-BYTES 3171 :COMPRESSED-SHA256
    "1f173bdbcde6a603bf30fa47d23c52968db08028851a9e3c697c7b729c4d1736"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/35-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10623 :STORED-BYTES 3599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-0.lisp.gz" :UNCOMPRESSED-BYTES 10623 :UNCOMPRESSED-SHA256
    "49a444d4baaf08e4e0c36b23515f69d3d2d712f408d2a3f824d34befe47af997"
    :COMPRESSED-BYTES 3288 :COMPRESSED-SHA256
    "3a36e2be98d2c5e0231e44414e62acb086bbfefaead21bf2774681dc1bdd954c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/34-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1980 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-4.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "61391d54293ccd9a95eb45fd3b85aa86925b893a800ac7a484fe623e4abd4168"
    :COMPRESSED-BYTES 1670 :COMPRESSED-SHA256
    "d38814068da6010ff9ada072153bd63b57f807ba3fb9485c1fada857e6ec982f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/34-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5633 :STORED-BYTES 1970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-3.lisp.gz" :UNCOMPRESSED-BYTES 5633 :UNCOMPRESSED-SHA256
    "3c866555ceb33e5eea84008d720a89e8bd578b7f651c2abdf437b6264b91aff0"
    :COMPRESSED-BYTES 1660 :COMPRESSED-SHA256
    "4529bbf783e1d13c45ec342296278315b940a0518364b5f7215e5a6015a0cbfe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/34-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5639 :STORED-BYTES 1963 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-2.lisp.gz" :UNCOMPRESSED-BYTES 5639 :UNCOMPRESSED-SHA256
    "80012b4ff6fcb8d14be37abec82444cfec6c7e4582b242972961f767ba94c325"
    :COMPRESSED-BYTES 1653 :COMPRESSED-SHA256
    "ca6e837c54e1525546d0f7c7d24684104b3f6f16a5329f303fe6c04e82eb2ed8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/34-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5639 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-1.lisp.gz" :UNCOMPRESSED-BYTES 5639 :UNCOMPRESSED-SHA256
    "e9b97f6ebd9d42e3a25a933620ad91334fa6e08045bfb53a073db175c3a18167"
    :COMPRESSED-BYTES 1613 :COMPRESSED-SHA256
    "74250ea656eacca56eb279076a621bd8067d35cde3f9dcb3afc1f78524757587"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/34-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5642 :STORED-BYTES 1969 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-0.lisp.gz" :UNCOMPRESSED-BYTES 5642 :UNCOMPRESSED-SHA256
    "bda79b02e2045db9fa3d268b8493694528f3e1eddb5e7c4deb54006823496a00"
    :COMPRESSED-BYTES 1659 :COMPRESSED-SHA256
    "2e54d45dce08a02305709669446db6e856e901dfe85083cc6db6b101f8d18fb5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/32-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19963 :STORED-BYTES 2958 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-4.lisp.gz" :UNCOMPRESSED-BYTES 19963 :UNCOMPRESSED-SHA256
    "58d49b3ece6dd10cc876fb019faf448541ba2ac9543dd1996aaaf3d296bd3ef1"
    :COMPRESSED-BYTES 2647 :COMPRESSED-SHA256
    "703ee81267a5048194a733d60ab772c305c1c16f1ffee8d8911116eadf6a5093"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/32-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19816 :STORED-BYTES 2860 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-3.lisp.gz" :UNCOMPRESSED-BYTES 19816 :UNCOMPRESSED-SHA256
    "840d58c092ce0b636c696d0709758e51caaad5dc96e3d080e21afb3e782e42d6"
    :COMPRESSED-BYTES 2549 :COMPRESSED-SHA256
    "5a23c1336174f8a450147880cdaad626693c904c28f4c1ad864b67454f6d0e10"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/32-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18945 :STORED-BYTES 3101 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-2.lisp.gz" :UNCOMPRESSED-BYTES 18945 :UNCOMPRESSED-SHA256
    "e3530df60cb97b1d880242896e5005188e6576704b3359cb41a55900d7d8fbb4"
    :COMPRESSED-BYTES 2790 :COMPRESSED-SHA256
    "41137e87f66c365f8d4a6effe3e04a866419a90d3cf5e096b7722759d3f2b3d5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/32-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19214 :STORED-BYTES 2979 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-1.lisp.gz" :UNCOMPRESSED-BYTES 19214 :UNCOMPRESSED-SHA256
    "3a445c81f2fe3ddaa78689c1785b39d03b83e622f650546c6d22069f864fc1d8"
    :COMPRESSED-BYTES 2668 :COMPRESSED-SHA256
    "fc16b5345033dcfbfa8401231fde417542b7b7c3d0827b37da0cfe0b2b61e4d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/32-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19585 :STORED-BYTES 3704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-0.lisp.gz" :UNCOMPRESSED-BYTES 19585 :UNCOMPRESSED-SHA256
    "ce7a6f9bf2c05065ef2221743be4b06caea4b9cd75836a6c11aaac7aceb3f65f"
    :COMPRESSED-BYTES 3393 :COMPRESSED-SHA256
    "2d94b3b0abde0672ed572478bbb275def96a795651a6ac031e24ae9f86ff8e8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/31-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8829 :STORED-BYTES 1633 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-4.lisp.gz" :UNCOMPRESSED-BYTES 8829 :UNCOMPRESSED-SHA256
    "4294d930b4f4874b7e3f8791594d60eb22cc9823697259a6e3d81c941bd0f312"
    :COMPRESSED-BYTES 1323 :COMPRESSED-SHA256
    "c0148c814de549fbc05afea7704182ae72d9cec2ae16b15180f8b8378c60ac3b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/31-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8919 :STORED-BYTES 2043 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-3.lisp.gz" :UNCOMPRESSED-BYTES 8919 :UNCOMPRESSED-SHA256
    "b1582c21e5e4c5c54fcc4d8de189c3004877e43e9dd3fe36179d0f8310c5cb13"
    :COMPRESSED-BYTES 1733 :COMPRESSED-SHA256
    "4491028e0e60db8096e0e582046543c6f955e33a7c8222b137413c32be7fd00c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/31-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8834 :STORED-BYTES 1954 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-2.lisp.gz" :UNCOMPRESSED-BYTES 8834 :UNCOMPRESSED-SHA256
    "a9ed09474945e6214877cfab78aa81900cf069207213d880c3426d48a0757ddb"
    :COMPRESSED-BYTES 1644 :COMPRESSED-SHA256
    "e340b7c1e25c974eb6659fde6105c4f2a5200836d2e312508fd057f60dae93a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/31-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8828 :STORED-BYTES 1970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-1.lisp.gz" :UNCOMPRESSED-BYTES 8828 :UNCOMPRESSED-SHA256
    "478da5d339c9ffdf14de0dee9acaae1e9d548e399701f219bd6ba6a5dcec082a"
    :COMPRESSED-BYTES 1660 :COMPRESSED-SHA256
    "7f0e9f649183c876b6b4aa950b5298e136665361769a003e023fe85092e7e9a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/31-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8831 :STORED-BYTES 1848 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-0.lisp.gz" :UNCOMPRESSED-BYTES 8831 :UNCOMPRESSED-SHA256
    "806f72293685428162b6ab0aac36cde2bcc1689a0477dd34bddc72c4be36af87"
    :COMPRESSED-BYTES 1538 :COMPRESSED-SHA256
    "93774fc5489fd35bb44ce4162a882222492cb02632919c8c9e0d5d642222bde4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/30-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1299 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "86d6ec928d8671155514dbbd6e616086ff8fe77eda171b8e5a4600e8845efcd9"
    :COMPRESSED-BYTES 990 :COMPRESSED-SHA256
    "6554acf11b45f4582a2eec1edfdbc0a5e42706742dc9d6af413403eb28e5cb87"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/30-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1397 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "1d71a33333743884952ce4790e750a8fd6805c4e0b58ced36e0bcc1c8795941d"
    :COMPRESSED-BYTES 1087 :COMPRESSED-SHA256
    "584d7c1124f8b3fa0f58753e43ab997f7c5ec6dfc8c351edf6e9b5487032421e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/30-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1326 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "19018fcae38e03e6cf58b47925ae3cb56233754911157bc82d817f32c748fb99"
    :COMPRESSED-BYTES 1016 :COMPRESSED-SHA256
    "a49789fe7ad27d5cda97ca7bf6957b762c5a4e04302656d8911c9a1a3a6d6083"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/30-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4818 :STORED-BYTES 1329 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-1.lisp.gz" :UNCOMPRESSED-BYTES 4818 :UNCOMPRESSED-SHA256
    "86e364e70492d9efa06d26b7e79259595afdb71085f0dd86c172bf2073169922"
    :COMPRESSED-BYTES 1019 :COMPRESSED-SHA256
    "23110ba98a6d79c4df0f93e71001572a7812df39cc9b1fc09fb35d7ab73b91e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/30-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4818 :STORED-BYTES 1202 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-0.lisp.gz" :UNCOMPRESSED-BYTES 4818 :UNCOMPRESSED-SHA256
    "19d93f859de804cab36d24f85fb7b2ba20999ab5410c5d02c337fec542594798"
    :COMPRESSED-BYTES 893 :COMPRESSED-SHA256
    "e14d2172e7f36bc8d5455ab1915621bac0036ceea2415a8e708d0df927db0c80"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8969 :STORED-BYTES 1978 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 8969 :UNCOMPRESSED-SHA256
    "d03f7de3dc47013a384cbaa38d86712a00a30802c2a96766ee6d79d070ff4e7f"
    :COMPRESSED-BYTES 1669 :COMPRESSED-SHA256
    "d8811e81842d4eb4255141e0e5e296682d406a22b02951dc2ad6dc8cade690c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8872 :STORED-BYTES 1830 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 8872 :UNCOMPRESSED-SHA256
    "5e73428dcd425eeecd04b80866bf792b5620a9fb1ee5bda059093544a121f29d"
    :COMPRESSED-BYTES 1521 :COMPRESSED-SHA256
    "a898c3de2f2e3dd848ca2f92ee51f5968d4f1324c9fb4e52ee95797b2b693980"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8853 :STORED-BYTES 1951 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 8853 :UNCOMPRESSED-SHA256
    "5476b0631232f5820a1ce4c264c874d6f8e865475a501c3e709dbbda41d6c04b"
    :COMPRESSED-BYTES 1642 :COMPRESSED-SHA256
    "b7b76ebbd796a0a5a5eafe133be957b50f9400c17625c28fd32e1aa7c08a3690"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8844 :STORED-BYTES 1794 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 8844 :UNCOMPRESSED-SHA256
    "929bbb4e09f008d03e5e1263f816107fe68e101996c363e62e3a49a41d8c10d8"
    :COMPRESSED-BYTES 1485 :COMPRESSED-SHA256
    "84f19d47af2e0e40dbb3745195f5044294fb46f07019add4060f9e7d6145a7a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8847 :STORED-BYTES 1759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 8847 :UNCOMPRESSED-SHA256
    "e1607ed7399392925946b571599f5d6cd6771f8115ff725e85a414d0e8bdae73"
    :COMPRESSED-BYTES 1450 :COMPRESSED-SHA256
    "97b0b0e59024ad6bedaaa245883c55dd40b9087eeb548306fbb1d42abd0f7955"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/28-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19881 :STORED-BYTES 2740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-4.lisp.gz" :UNCOMPRESSED-BYTES 19881 :UNCOMPRESSED-SHA256
    "c7832458435f666cc707721763b502cc3f2e2a8df735f530f43ed5a16e1d0379"
    :COMPRESSED-BYTES 2429 :COMPRESSED-SHA256
    "3db9824cf1859d0012050af7c218f50193b9bed3b5d48b4e1197a0594b1b3a45"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/28-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19758 :STORED-BYTES 2821 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-3.lisp.gz" :UNCOMPRESSED-BYTES 19758 :UNCOMPRESSED-SHA256
    "7c673d4c933272ed57b19e054f1eeef6c98bcbf7f70140028debb23326117f1f"
    :COMPRESSED-BYTES 2510 :COMPRESSED-SHA256
    "ac19511e5fc4e1a1535575351b33ae82c1fbc9a8f939c9114521b01145b5500c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/28-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17732 :STORED-BYTES 2582 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-2.lisp.gz" :UNCOMPRESSED-BYTES 17732 :UNCOMPRESSED-SHA256
    "7c757144d0de527e6e0ecf53ceeaf11fc5f46aa3a7206caa7f7d28220ff36086"
    :COMPRESSED-BYTES 2271 :COMPRESSED-SHA256
    "9d4c69abdbc401375b21506a0475d2fec1399d132b7780277439015cc3822b63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/28-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19782 :STORED-BYTES 2798 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-1.lisp.gz" :UNCOMPRESSED-BYTES 19782 :UNCOMPRESSED-SHA256
    "926261e5d57747bb8bb396ff659d3b70a3c2858803e48286d1bbc93000ac0553"
    :COMPRESSED-BYTES 2487 :COMPRESSED-SHA256
    "f09f606740249bdf06902a50dfb0c3b3568487849a04ad08985c074a18bb6366"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/28-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19686 :STORED-BYTES 2981 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-0.lisp.gz" :UNCOMPRESSED-BYTES 19686 :UNCOMPRESSED-SHA256
    "f3aa60140684bd943cc93ed4c468d5038c6b6fdafbf080e8b606a50b657e841a"
    :COMPRESSED-BYTES 2670 :COMPRESSED-SHA256
    "582efb2df51ff43695933395cb68fd4b18dc6774e77bafa8b5a0f46895aa5fb2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/27-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8835 :STORED-BYTES 1954 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-4.lisp.gz" :UNCOMPRESSED-BYTES 8835 :UNCOMPRESSED-SHA256
    "237a282d8f5ce9c29d224b12a432b5175af7c81f1017adef66e6c6db2da17bf1"
    :COMPRESSED-BYTES 1644 :COMPRESSED-SHA256
    "594521bac8ffa0263fff09a41188805f9c7163756e976fa703a63739365911b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/27-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8870 :STORED-BYTES 1805 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-3.lisp.gz" :UNCOMPRESSED-BYTES 8870 :UNCOMPRESSED-SHA256
    "166d87e855731219e5bed00e71e8731c42e44f093f2e7b9817573a3fdd642daf"
    :COMPRESSED-BYTES 1495 :COMPRESSED-SHA256
    "09343dc134a99e19c398e080a421690e0ac4ccfe6a0afca5a04b824ae804c779"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/27-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8833 :STORED-BYTES 1783 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-2.lisp.gz" :UNCOMPRESSED-BYTES 8833 :UNCOMPRESSED-SHA256
    "fd9d4b6868ad12559b7012142c6af1a0ee88fb38010a7fa62465b0813b743999"
    :COMPRESSED-BYTES 1473 :COMPRESSED-SHA256
    "37196a2dfbe2ea7f549e852b1bcfe70e53e89a1af9816b3fafaf6db92735104f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/27-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8841 :STORED-BYTES 1736 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-1.lisp.gz" :UNCOMPRESSED-BYTES 8841 :UNCOMPRESSED-SHA256
    "bdd3852a095f9344fd742d99334c8c77bcc8198d8dc5f497eaf48a399d0661a6"
    :COMPRESSED-BYTES 1426 :COMPRESSED-SHA256
    "59900202ef8086f67839543b60ebbf81e9d80c4f63cc73442d80264e33cef668"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/27-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8954 :STORED-BYTES 1920 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-0.lisp.gz" :UNCOMPRESSED-BYTES 8954 :UNCOMPRESSED-SHA256
    "9925a294f8431028ac0365633cac771aedcda19d831421a54680c6c4cbc570b1"
    :COMPRESSED-BYTES 1610 :COMPRESSED-SHA256
    "4a875111fda8b19c028bd532f0703bf9b2259040b3c338980e8b0cc470b18771"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/26-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1171 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "85aac40e8ed452f7eb64125ae8eee4491f48f986e0e5a833caee6130b37baee7"
    :COMPRESSED-BYTES 862 :COMPRESSED-SHA256
    "741536f9a376a264885b43570464542e2a5766e5ff9d9117492a50296bb8fca3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/26-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1218 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "22c74e94140e851d14d2a3e977bd4c0581ddb3cfbdc8a1e02ba508a7f59e4a30"
    :COMPRESSED-BYTES 909 :COMPRESSED-SHA256
    "a84c122b710e60c21ce7db90f987d933e224a697b16398171694a6d69e7be21e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/26-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1202 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "009447891b626dda32146e630845a6ac2396c4fd7c85f4284b6e478c8a5c0cb8"
    :COMPRESSED-BYTES 893 :COMPRESSED-SHA256
    "78b89e1f1b33e04e8b468b90fa753eeaaacf55bbf776e544f36b6826515ca900"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/26-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "4fb3d3f73ac104915cdfaf8dc86edaae79df23ec7dd34d530dded530a2b7ee1b"
    :COMPRESSED-BYTES 806 :COMPRESSED-SHA256
    "0666ba9030e26a9bff38b74d39fb222863b1e8f514bfd7f9ad0d4ad624ee7061"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/26-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4815 :STORED-BYTES 1227 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-0.lisp.gz" :UNCOMPRESSED-BYTES 4815 :UNCOMPRESSED-SHA256
    "87f369602e89d61c3773359c5835a16490a5843aa1cbebfd6ed2ca1a46a46d50"
    :COMPRESSED-BYTES 918 :COMPRESSED-SHA256
    "20b919136be1cd51bb13f3145da5a05ee903ac18150a8e535824e35af2d6419f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/24-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20832 :STORED-BYTES 6025 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-4.lisp.gz" :UNCOMPRESSED-BYTES 20832 :UNCOMPRESSED-SHA256
    "aa74848dfd4a3ea776140e8db0d3dc97cceefc3ea57494dae14326c093c782f4"
    :COMPRESSED-BYTES 5714 :COMPRESSED-SHA256
    "f3c63cfe8831a8b71b263fc803cb11cb1fe1a9a112c70daff604f5a08f3a7b86"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/24-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20591 :STORED-BYTES 5771 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-3.lisp.gz" :UNCOMPRESSED-BYTES 20591 :UNCOMPRESSED-SHA256
    "e3592c2f4876cb5384875945dbff2243eac8111557a28b94aca16cfa64111717"
    :COMPRESSED-BYTES 5460 :COMPRESSED-SHA256
    "274f72ec37295fe00f8c091b441091f1be8e8a69aef47538e4ae927d05e028d9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/24-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21017 :STORED-BYTES 6440 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-2.lisp.gz" :UNCOMPRESSED-BYTES 21017 :UNCOMPRESSED-SHA256
    "e3f053920f5c12b2491e3df41d50bc7fe5893abdbb9c8585431ad568a80f6c58"
    :COMPRESSED-BYTES 6129 :COMPRESSED-SHA256
    "880e384b424ea53dbbaf8cbf0d3547d18b3d196c562f35c9c610a13d15e32363"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/24-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20679 :STORED-BYTES 5841 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-1.lisp.gz" :UNCOMPRESSED-BYTES 20679 :UNCOMPRESSED-SHA256
    "ccc2ee53a6ff9a26dd10c0fdb63df746a6f07e6549936648b04ec193d93e2226"
    :COMPRESSED-BYTES 5530 :COMPRESSED-SHA256
    "4f3cbdb04f75e8f6307e8a1a73a3de27ab2900f804ade8f3dcd85c2c51ccb691"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/24-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20563 :STORED-BYTES 5396 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-0.lisp.gz" :UNCOMPRESSED-BYTES 20563 :UNCOMPRESSED-SHA256
    "28007754ffc1532815e83e56287e849ca4c8f55a0b3cf6297ea9ebb5420421c4"
    :COMPRESSED-BYTES 5085 :COMPRESSED-SHA256
    "48134297c9fd2c45c2b20ff56254c1c5e517d54418a7e3a66832b315a0627375"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/23-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-4.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "670e254fb89cbf3fe2f9f12b4bd45250cac9c6f9a53216640b448fd245307203"
    :COMPRESSED-BYTES 2389 :COMPRESSED-SHA256
    "1db0c5e756d6770449469cf6568ebe3704e34c369159aadd762d9a02c3747767"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/23-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2564 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-3.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "887d6783198aceaf852b018de6baa0704a203628fb81a61edc4f2c0f08cd36ef"
    :COMPRESSED-BYTES 2253 :COMPRESSED-SHA256
    "62e53dd6ca4b8d33aeffcd7f441631bc2277235abbebce02c643559d76e4f3c9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/23-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-2.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "ffbbdbcb7385f1183c0d8b05e997c613f6f56935a0309f9ad3408f5ab01ec581"
    :COMPRESSED-BYTES 2414 :COMPRESSED-SHA256
    "b0bd71b522851247d48941c0c7f4db9df64f6d2d27b48be90b0c6dde3ad0167b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/23-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10487 :STORED-BYTES 3160 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-1.lisp.gz" :UNCOMPRESSED-BYTES 10487 :UNCOMPRESSED-SHA256
    "05b4e426d048a6d6aec3bb4f38ade934f003f62406d1f7fac7f5369c35e3ee55"
    :COMPRESSED-BYTES 2849 :COMPRESSED-SHA256
    "b27f8e018c0d130d89bad1f37655444407ba422bbf5057d9f07a4998f681afff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/23-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10487 :STORED-BYTES 3289 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-0.lisp.gz" :UNCOMPRESSED-BYTES 10487 :UNCOMPRESSED-SHA256
    "1a6b86630ee5f5a834916c79e8b18800529aabb450c7849429129966c438c8b4"
    :COMPRESSED-BYTES 2978 :COMPRESSED-SHA256
    "1eb4f86cdfda75435b7d65b9b9c2623d96bc814dfcadd16cf6a15b2c09816986"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/22-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5631 :STORED-BYTES 2083 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-4.lisp.gz" :UNCOMPRESSED-BYTES 5631 :UNCOMPRESSED-SHA256
    "8d63e820406cb752b25d104dc06b79c0cdb157bc4987fa0b0f7fbeb4518cc048"
    :COMPRESSED-BYTES 1773 :COMPRESSED-SHA256
    "4ede658c7236ce5dcaa16e4f6477774fc88e1e15d3735d5232f300bcb0af3d19"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/22-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1845 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-3.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "9a1978d0961c5d9d4184ee01dfc923d59e02ef16c19502b892f42575d01ec366"
    :COMPRESSED-BYTES 1535 :COMPRESSED-SHA256
    "0d3a383212eefc742f5974cbbe1ba985f2e5de10674035721dd3656e52a154d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/22-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1977 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-2.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "87bfb6a790c0481c39cb93173c6d221243cb641e4a9848a361406495db4af024"
    :COMPRESSED-BYTES 1667 :COMPRESSED-SHA256
    "1e0a01c8ac39d99e4ce50072e3a4c89887bfcbc37f37c80d985d54df62f81c8b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/22-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5636 :STORED-BYTES 1983 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-1.lisp.gz" :UNCOMPRESSED-BYTES 5636 :UNCOMPRESSED-SHA256
    "5f0e3d857ad99dc46899508349f78b524a4bd897d0779c06e93ca106b79318a4"
    :COMPRESSED-BYTES 1673 :COMPRESSED-SHA256
    "aff876bc5a973cad47e0df0e0c2893bfab4d4f03751e7ebe0f7801b492dd2341"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/22-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 2062 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-0.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "092e6552097bf0393d48aecdd9937c120fe5db7a0c06b362cf91576266f879ad"
    :COMPRESSED-BYTES 1752 :COMPRESSED-SHA256
    "b682b4e73480f295962b1ce5a99be9019f17a66381c5cc9b0996a2e7d86c71a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/20-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20115 :STORED-BYTES 4509 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-4.lisp.gz" :UNCOMPRESSED-BYTES 20115 :UNCOMPRESSED-SHA256
    "723fa5e56dcdbcad74eb61dd2f56fc96d86b4bb1f2366cb2b2e926327091e703"
    :COMPRESSED-BYTES 4198 :COMPRESSED-SHA256
    "ae612f8e5ef401a42f0d98d842edb7b4d54c41724e861481ff265f80bf2cc032"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/20-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20013 :STORED-BYTES 4130 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-3.lisp.gz" :UNCOMPRESSED-BYTES 20013 :UNCOMPRESSED-SHA256
    "ae53c5f42f91a139c55fcacf8ca404a491d010be2b024ccbb4408a0c2dabf400"
    :COMPRESSED-BYTES 3819 :COMPRESSED-SHA256
    "93a050c21aad78fcbcd83c2c61d48bef18a453419f4760458d9af27e74c02105"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/20-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20024 :STORED-BYTES 4082 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-2.lisp.gz" :UNCOMPRESSED-BYTES 20024 :UNCOMPRESSED-SHA256
    "601cae5d5d987ad30e55a94dddbc653509428155c53144562eb31b2a34befb99"
    :COMPRESSED-BYTES 3771 :COMPRESSED-SHA256
    "7dcdba5d90daa027668b14cc4a3ad15008328f85a55a3cc641525a764a3c97fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/20-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20107 :STORED-BYTES 4599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-1.lisp.gz" :UNCOMPRESSED-BYTES 20107 :UNCOMPRESSED-SHA256
    "5ee5495b74fb15a5796c814fcdc9ebcec00c26c1432a8f879a16bcee28c9b078"
    :COMPRESSED-BYTES 4288 :COMPRESSED-SHA256
    "dbd7a8826aad1b3e93654c1742edd27f18bfff55bebd154b06cd7edb722d3724"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/20-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20185 :STORED-BYTES 4756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-0.lisp.gz" :UNCOMPRESSED-BYTES 20185 :UNCOMPRESSED-SHA256
    "12517d672713e60b7cb2be99a75d197e4864de0b5ce431c21a43d2e7efd73941"
    :COMPRESSED-BYTES 4445 :COMPRESSED-SHA256
    "270a4df6d79bbf6184f44c5d1786a5dc4445b62c1d42a1ebb70c90076250e998"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4815 :STORED-BYTES 1225 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 4815 :UNCOMPRESSED-SHA256
    "72e6c58d58de7f31ba92d84791087191230765c37611728dffbe66072c1136e2"
    :COMPRESSED-BYTES 917 :COMPRESSED-SHA256
    "9ff5ab48eab4c09c58d27551b0900477ffdcce5d6d2167c13355e96125753493"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4826 :STORED-BYTES 1416 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 4826 :UNCOMPRESSED-SHA256
    "7180338a4ecfa27a122a601e4a0f9e8be08b22d0f6da3b5602c33fd5a6ddf27d"
    :COMPRESSED-BYTES 1107 :COMPRESSED-SHA256
    "4653b59e34ce744629444bf81d4e42db6728ed395be630ed730db2e6f13117a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4816 :STORED-BYTES 1517 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 4816 :UNCOMPRESSED-SHA256
    "96d9f9e7175486be723f22e0476452e2865c7b1142b6df05112102d958b122b0"
    :COMPRESSED-BYTES 1208 :COMPRESSED-SHA256
    "975cc3db223e0aad32f3b44bc946708941982add2c54a5cae31d68232383e9f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1397 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "cb0ec8d966bd3d720325820d887141a35aeefce5f8b35faec93e5c1bccc44ef9"
    :COMPRESSED-BYTES 1088 :COMPRESSED-SHA256
    "4600ee30cd9cbe22e4b2ae3b2a89327bc764218204f9d00a1f9963f50ff5d285"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4817 :STORED-BYTES 1429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 4817 :UNCOMPRESSED-SHA256
    "f96f3eb2b20ca2b1a7df1a35feadd27936594fe0885205ce076c1ab5407f262d"
    :COMPRESSED-BYTES 1120 :COMPRESSED-SHA256
    "2cac482c1f3281e27de0a54c9ef9b0755de9545efd0f80470c3f560d325df55b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/19-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9145 :STORED-BYTES 2165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-4.lisp.gz" :UNCOMPRESSED-BYTES 9145 :UNCOMPRESSED-SHA256
    "278488c8411d401211b45949e7de02a57f7541bf803571f82adcadf8b0eaa70a"
    :COMPRESSED-BYTES 1855 :COMPRESSED-SHA256
    "b5853be9a96e3450f458e815d7e05e7eaeeea7edd8b8e6ef5ed8b36c12b69bfe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/19-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9344 :STORED-BYTES 2329 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-3.lisp.gz" :UNCOMPRESSED-BYTES 9344 :UNCOMPRESSED-SHA256
    "72dc6c79aa39d681f534995a38221c3f1bf0a1cd16e9b55ee2273053ca72ad1d"
    :COMPRESSED-BYTES 2019 :COMPRESSED-SHA256
    "f79405716f2ad4dc2779d29549e9a8fa196635b9f69a9cc21db8b21e4296fa38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/19-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9155 :STORED-BYTES 2145 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-2.lisp.gz" :UNCOMPRESSED-BYTES 9155 :UNCOMPRESSED-SHA256
    "323b544a4a20971d00fb696369d49aeb234c518752ad4123b721c7fc2f80dd24"
    :COMPRESSED-BYTES 1835 :COMPRESSED-SHA256
    "1b2fcb885dd1513cf11a000e820bbc9522fb0214794e2757c1a0420a18dbf427"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/19-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8964 :STORED-BYTES 2042 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-1.lisp.gz" :UNCOMPRESSED-BYTES 8964 :UNCOMPRESSED-SHA256
    "b26e2b1697ebf92cfcf909e89587a171cf5924d53529fad630a16c78a6bfab20"
    :COMPRESSED-BYTES 1732 :COMPRESSED-SHA256
    "5792a42aa6d1816504b56abd65c1de86e1af2880712b0a672c13cf362e73b77a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/19-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8873 :STORED-BYTES 1903 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-0.lisp.gz" :UNCOMPRESSED-BYTES 8873 :UNCOMPRESSED-SHA256
    "4e7ba62fb4cdb43d24390e0a9338a0d9e6a759d37e52c557cbf296dcb8bff192"
    :COMPRESSED-BYTES 1593 :COMPRESSED-SHA256
    "36436c7fbebfc6dbe180702ed1a32ea7a7c6cba482337cffbc88926bfbc040d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/18-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4847 :STORED-BYTES 1627 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-4.lisp.gz" :UNCOMPRESSED-BYTES 4847 :UNCOMPRESSED-SHA256
    "9fe7d9b34ee57e4d72660385fe6832cd6ed8ebe71a8c41386db87657c7a59d9e"
    :COMPRESSED-BYTES 1317 :COMPRESSED-SHA256
    "a667594a5060de06f119f2bc60f11e768dcb59f50a48bf999e1d8c44d8ba2ba3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/18-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4854 :STORED-BYTES 1582 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-3.lisp.gz" :UNCOMPRESSED-BYTES 4854 :UNCOMPRESSED-SHA256
    "237b21a291029edbd97a196760a49b2c15280b5ae4124f42e3f82b0f9d037ee4"
    :COMPRESSED-BYTES 1272 :COMPRESSED-SHA256
    "c0194010a13cbf006ab4f4839f47a6ba0bd7360b110f799ab0b3e2b3c26ef349"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/18-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4872 :STORED-BYTES 1636 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-2.lisp.gz" :UNCOMPRESSED-BYTES 4872 :UNCOMPRESSED-SHA256
    "2267dda0515b93f80328c9cb9a5dbff8fda7feba28d26af72dc8d0d58564b8f2"
    :COMPRESSED-BYTES 1326 :COMPRESSED-SHA256
    "67e0a6764a4228f12e8608cdee4b1dfe5a2a4f5a5f3338edbfec40f757ce7694"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/18-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4842 :STORED-BYTES 1592 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-1.lisp.gz" :UNCOMPRESSED-BYTES 4842 :UNCOMPRESSED-SHA256
    "a4357c2d9f396db7d42506f229a333ba21d02b3dc68d4a151a5a6ab924fd2303"
    :COMPRESSED-BYTES 1282 :COMPRESSED-SHA256
    "0f22c659a6f7bfbb347f42a1fa93dbdb7f9a60a910bcd0aebb7e79caa6289de0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/18-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4855 :STORED-BYTES 1582 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-0.lisp.gz" :UNCOMPRESSED-BYTES 4855 :UNCOMPRESSED-SHA256
    "550c8fea8f62a1c0dc7442495ffe5b222c518fc661f8dbbc7e322946798849a0"
    :COMPRESSED-BYTES 1272 :COMPRESSED-SHA256
    "e5d07f66bd8d2c35d3c6d9b7095bccc7a8a08cd349fc40af9ff80c6dc89be7d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/16-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20101 :STORED-BYTES 4167 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-4.lisp.gz" :UNCOMPRESSED-BYTES 20101 :UNCOMPRESSED-SHA256
    "d533fbe3fd662ca45e325f3829e2e094b3cb7cc6dd0881aa0a0859f766dccb62"
    :COMPRESSED-BYTES 3856 :COMPRESSED-SHA256
    "d647a4653b4513259faaa93eef305495ec84b9ff17a7fc38c16294c5d48e701a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/16-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20077 :STORED-BYTES 4122 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-3.lisp.gz" :UNCOMPRESSED-BYTES 20077 :UNCOMPRESSED-SHA256
    "e7ffb9f7fbb065150da0b73c21d3abc42d5078870d2ebf822422fc3a2fa5debf"
    :COMPRESSED-BYTES 3811 :COMPRESSED-SHA256
    "d814a0cd16cbb2e8a0127fc5453511135386e0942c2a11c6a216090989f7c094"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/16-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20027 :STORED-BYTES 3693 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-2.lisp.gz" :UNCOMPRESSED-BYTES 20027 :UNCOMPRESSED-SHA256
    "d2d8dc07fb8f30c475e48a87fd750efe7f335484b6a1dcfeed1a79c287a56065"
    :COMPRESSED-BYTES 3382 :COMPRESSED-SHA256
    "a9db6008582dad29d13ae49d82f28d6b012d43615e306c1eacdc97853c23f9f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/16-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 3583 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-1.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "0b69072c85638788fdedd2c7d9694bb1df5e1ff84e34470771a0e0f7a103c281"
    :COMPRESSED-BYTES 3272 :COMPRESSED-SHA256
    "3c4b9cc13346cfe910236d72d3639815cbb123c318d32ea6ed59050451196c33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/16-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20081 :STORED-BYTES 3664 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-0.lisp.gz" :UNCOMPRESSED-BYTES 20081 :UNCOMPRESSED-SHA256
    "ac99f7aa12281893bfa6410f1aa6f55b470d3fd6a5b068d7765d2f0dc3dd4cc3"
    :COMPRESSED-BYTES 3353 :COMPRESSED-SHA256
    "a815eebf77800a932327f5acbe7da5ce60b6f79a9aa3f0df7a1b9335edf92245"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/15-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9944 :STORED-BYTES 2244 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-4.lisp.gz" :UNCOMPRESSED-BYTES 9944 :UNCOMPRESSED-SHA256
    "36de490cc5db794b531a4d321691015de3ca9c6d982927c1080180e217970ce0"
    :COMPRESSED-BYTES 1934 :COMPRESSED-SHA256
    "2a2acd42d530dad2f06d26b488535a028e6c0aa024ff7121bcc9ff9470e2035a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/15-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9887 :STORED-BYTES 2221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-3.lisp.gz" :UNCOMPRESSED-BYTES 9887 :UNCOMPRESSED-SHA256
    "a61b3476888e60cdf536d5ae3cde38a80abbbf5c6fc0616a5dac4a3d5036f149"
    :COMPRESSED-BYTES 1911 :COMPRESSED-SHA256
    "2f08ffb317c7463b8de0edc01b003749798784534f080544d6d837bb1bd64d92"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/15-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10107 :STORED-BYTES 2208 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-2.lisp.gz" :UNCOMPRESSED-BYTES 10107 :UNCOMPRESSED-SHA256
    "564bee717284a096227ff2b85619bc924340416a9e54d78d714ff4ff3e396e19"
    :COMPRESSED-BYTES 1897 :COMPRESSED-SHA256
    "792d11fe6a579c627ce5bae43f76f80430bc480d3773a64236f5bd38bad8e813"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/15-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9957 :STORED-BYTES 2173 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-1.lisp.gz" :UNCOMPRESSED-BYTES 9957 :UNCOMPRESSED-SHA256
    "3202935bb756c58f0d560eb450864cd00b73d00db7a066af1bc4e655ce2fab8d"
    :COMPRESSED-BYTES 1863 :COMPRESSED-SHA256
    "315f2c396e7423492e2ce2cf15a12ce679649cdc31b467e3a9d7097b60290e26"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/15-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9143 :STORED-BYTES 2047 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-0.lisp.gz" :UNCOMPRESSED-BYTES 9143 :UNCOMPRESSED-SHA256
    "8cb3a00fbbc0ef122853b922f3b5dea62bcd9a089b9777c0f61f3b4569bafc1a"
    :COMPRESSED-BYTES 1737 :COMPRESSED-SHA256
    "35c2961b940f9383c714818d19e3cc8abb554e49e8c316b6f499494c029c5771"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/14-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4848 :STORED-BYTES 1504 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-4.lisp.gz" :UNCOMPRESSED-BYTES 4848 :UNCOMPRESSED-SHA256
    "4d6a15cb1615f49cf2b33db6a65180b2ae302ee9247e27e76d0cafcc57870281"
    :COMPRESSED-BYTES 1194 :COMPRESSED-SHA256
    "63ae3fdbbf3c8310d4f320938e6ce1477a67a5c588cbffcb3af1ce279f828fb0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/14-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4840 :STORED-BYTES 1457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-3.lisp.gz" :UNCOMPRESSED-BYTES 4840 :UNCOMPRESSED-SHA256
    "3b961d907e685bd2c3af8578fb9ed074ad09415043c78325b29215025d1a984f"
    :COMPRESSED-BYTES 1147 :COMPRESSED-SHA256
    "ec6f42e898049341a22b6d6c8719e9e1622c785a01cfa0c6d0b14094bc5f81cd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/14-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4868 :STORED-BYTES 1549 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-2.lisp.gz" :UNCOMPRESSED-BYTES 4868 :UNCOMPRESSED-SHA256
    "a3674ada85962bb969e6e5c81c674e9666cd3d640db40fac5b9449348fc630a7"
    :COMPRESSED-BYTES 1239 :COMPRESSED-SHA256
    "c78daa2ab9a21679113fc1fed33b7bb76b1a497218abb3a5b1e29a0d008ead7e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/14-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4828 :STORED-BYTES 1436 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-1.lisp.gz" :UNCOMPRESSED-BYTES 4828 :UNCOMPRESSED-SHA256
    "08fd8f330fe9128aefd0ec852a535c6e7e38e2fb9e3873e68f79ae9464b69644"
    :COMPRESSED-BYTES 1126 :COMPRESSED-SHA256
    "d7f4d23c91e3fb0020d8d588f2f4b5661cef426d56a3eb867695332f255f7ecd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/14-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4913 :STORED-BYTES 1553 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-0.lisp.gz" :UNCOMPRESSED-BYTES 4913 :UNCOMPRESSED-SHA256
    "81b9078935c3bb798522bfe12b64a02e28aaa48660facf2c135053aac1eec334"
    :COMPRESSED-BYTES 1243 :COMPRESSED-SHA256
    "314f6f22a7bdf05ff6be012f0542e9d7910cf50acd36d66b41b4c4366fb970a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21991 :STORED-BYTES 7110 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 21991 :UNCOMPRESSED-SHA256
    "4d8d2d2c313b0815c999e0ecec7fce8134ae2f83fc085819ea4a1e1de25f737a"
    :COMPRESSED-BYTES 6799 :COMPRESSED-SHA256
    "5e08db072758662482ed32467f389f315ee320437d4ed68d48446ea730310333"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21927 :STORED-BYTES 7272 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 21927 :UNCOMPRESSED-SHA256
    "48e8d6510ed56d31632746f538920a846022e9d25cc99f66ac016a893a7188b3"
    :COMPRESSED-BYTES 6961 :COMPRESSED-SHA256
    "21807769a47d69bd4de680261c67c3e936e6385641aacb343366c5fd78087b00"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22602 :STORED-BYTES 7540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 22602 :UNCOMPRESSED-SHA256
    "208dc7851cf0903368a85cd999bd0b12883f898017007022803a970a1d3b41f8"
    :COMPRESSED-BYTES 7229 :COMPRESSED-SHA256
    "45d349ab07277e52856a288e1b5de87d311947734907d01576c71be37f34310d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22414 :STORED-BYTES 7413 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 22414 :UNCOMPRESSED-SHA256
    "a8c4767c4e859525e749c4b9568c99639fbc002d56b8d22a522143841424fbef"
    :COMPRESSED-BYTES 7102 :COMPRESSED-SHA256
    "2d4b71f4110ac597376cc4375154d2b2b0a04203020ee3d51a721ff156723d8c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21888 :STORED-BYTES 7129 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 21888 :UNCOMPRESSED-SHA256
    "dd422d95f3869808dedc27280d3255f33c634612e785ca18b7aac164e2cbdf5b"
    :COMPRESSED-BYTES 6818 :COMPRESSED-SHA256
    "5b654583fcd7473ec5447017c2d14fc30076c1adb5876d48168474e581b72c9a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10519 :STORED-BYTES 3648 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 10519 :UNCOMPRESSED-SHA256
    "2b05f4d349ada555892f778a215703d30e21147dbd89b1d23557323948e83c63"
    :COMPRESSED-BYTES 3337 :COMPRESSED-SHA256
    "b0c20173c0a59dfbfef4f5cadf0bde72d05191e7a4ea9e91d8faa4ea9e690780"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11031 :STORED-BYTES 3854 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 11031 :UNCOMPRESSED-SHA256
    "944175ab14861fe12839a072a49b723de949a9c4c03c4fbd40fee0bfc6be78ab"
    :COMPRESSED-BYTES 3543 :COMPRESSED-SHA256
    "47c819667e3e621e48fe23c4ead794bcb8db8dee6e27cc6e5711c3d46939bf7c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11125 :STORED-BYTES 3766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 11125 :UNCOMPRESSED-SHA256
    "5907f4df95ef977a92c15b9f47efa2498efd8984bda8aff48f5359b98798c6c3"
    :COMPRESSED-BYTES 3455 :COMPRESSED-SHA256
    "4b8e4760daf86fe810bda48c4dadf74748f017aff2f9b40ade047a939ef8b8ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11194 :STORED-BYTES 3817 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 11194 :UNCOMPRESSED-SHA256
    "6a4160b5642c29e863f18f6dc339e971a7f5e3a0f816729977ab8d795606fa66"
    :COMPRESSED-BYTES 3506 :COMPRESSED-SHA256
    "24370a685eb44fb72394da5e1e2b2d6fc14f239528d16ecf58567cc0292f04c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11138 :STORED-BYTES 3764 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 11138 :UNCOMPRESSED-SHA256
    "c3e38ecedeb6d4d29bdb44f16ebd513a526f6b21e834a5c325fcbe62d085daf5"
    :COMPRESSED-BYTES 3453 :COMPRESSED-SHA256
    "33906025b92c488ce178c3e6edb9bfe2a1a53de30eb38931a98bde31699c9343"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5643 :STORED-BYTES 2113 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 5643 :UNCOMPRESSED-SHA256
    "f382dc0188ec1da546e058b55f4d347c9e4da260411e5ed962e8509f84dc97d2"
    :COMPRESSED-BYTES 1803 :COMPRESSED-SHA256
    "24ed7b63b5b9d3de0b5afead33b60c759e5de92e17cf6269c55401e4f93981d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5639 :STORED-BYTES 2106 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 5639 :UNCOMPRESSED-SHA256
    "e7fc7998999dfea72565612684ba361a779e92522d02bff75e812de618668e40"
    :COMPRESSED-BYTES 1796 :COMPRESSED-SHA256
    "39d283c2ada7b9e3d433a76dd5ff4d368d41fa85c581ee1a6c1dfb24d44f0d27"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5639 :STORED-BYTES 2081 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 5639 :UNCOMPRESSED-SHA256
    "7685aa581bc12665944478d74f42a27c467c7aa73334b39360a79c25deabada6"
    :COMPRESSED-BYTES 1771 :COMPRESSED-SHA256
    "dd88d49bdb9b1b7e8825975e87abd6336cd154fed0cf64f9f3166d8036c06c0f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5639 :STORED-BYTES 2109 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 5639 :UNCOMPRESSED-SHA256
    "518766da9fec15ffa873f77bd3c91ba74d42071f2c34cf49cd69877a24ebb936"
    :COMPRESSED-BYTES 1799 :COMPRESSED-SHA256
    "af22bc4706ddd37ebbb50770c8f54efb4b7cebafecd320620e171c52107020a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/baseline/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5656 :STORED-BYTES 2173 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 5656 :UNCOMPRESSED-SHA256
    "87fa9634990bf919eb93972618bdccff8a958f5de93ff685bb68d127d311cb40"
    :COMPRESSED-BYTES 1863 :COMPRESSED-SHA256
    "ef845b72f03f738809037d83ae93b908771e59880b7540a971a89e233a27d6d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-8.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11454 :STORED-BYTES 1506 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-8.lisp.gz" :UNCOMPRESSED-BYTES 11454 :UNCOMPRESSED-SHA256
    "ae11bfe47664d6b170d283fb9808f81e1a1b2d960b9511a4efca17610bdc1f49"
    :COMPRESSED-BYTES 1191 :COMPRESSED-SHA256
    "cd9f927537ba0d012473f94d3cf85a05507a2d3a67cbb101f39c1a228d897985"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-7.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11265 :STORED-BYTES 1407 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-7.lisp.gz" :UNCOMPRESSED-BYTES 11265 :UNCOMPRESSED-SHA256
    "c10795ae3007511f9f9fd655939c89cbd31324a937742f8c21ca4f15dd734fd4"
    :COMPRESSED-BYTES 1092 :COMPRESSED-SHA256
    "8dc211fcd9a2d37cff9e435a7458feaa59451f2e765ffe96d2ba247042e70f4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-6.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11335 :STORED-BYTES 1425 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-6.lisp.gz" :UNCOMPRESSED-BYTES 11335 :UNCOMPRESSED-SHA256
    "10c1cf97ad8dbf7a37a4b148881fe904170d4bfaa4dd623d3fd6b3fbd31c55ea"
    :COMPRESSED-BYTES 1110 :COMPRESSED-SHA256
    "9fe264c6925ce836989c1c63b57d9bc3281b27eec2252350ad97365c8ad82fcd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11177 :STORED-BYTES 1303 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-5.lisp.gz" :UNCOMPRESSED-BYTES 11177 :UNCOMPRESSED-SHA256
    "129d16620783aa923e8114d9a374c605dcaf611a71246d83e7a31a243d8ae4b8"
    :COMPRESSED-BYTES 989 :COMPRESSED-SHA256
    "829e5046f3ea4a0495dbeb06540c299bcbdee1a879a59e4c50f055d6363a55c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11446 :STORED-BYTES 1519 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 11446 :UNCOMPRESSED-SHA256
    "2b0138e1916455370958f5357ada1c62793891c6244cf3bf120a1619ae3545c6"
    :COMPRESSED-BYTES 1204 :COMPRESSED-SHA256
    "d66fc2cc4ad2a5a726c0a9642f367497a1ef0c1e8515157d3cde4a3bfa4b08a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11270 :STORED-BYTES 1304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 11270 :UNCOMPRESSED-SHA256
    "cd9e041f4b6a38dc4ebe2a622ab0cca31116abd368439a28460c77e59816db53"
    :COMPRESSED-BYTES 990 :COMPRESSED-SHA256
    "fa0da6cc570d7fa60320f65b64fcd7a1ec1f81f0cf29d5c27c4d1c5bbf30262f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11299 :STORED-BYTES 1304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 11299 :UNCOMPRESSED-SHA256
    "e204d8795e1d422aafacf33f90c76f2454fef452ad2e6ff2721223dd2e0bd21f"
    :COMPRESSED-BYTES 990 :COMPRESSED-SHA256
    "efe55a2883d70907347b7ca58081fa867df98d97e9a35bf2baa40279f1d0b84b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/server-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11189 :STORED-BYTES 1256 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-1.lisp.gz" :UNCOMPRESSED-BYTES 11189 :UNCOMPRESSED-SHA256
    "3a94d4a117335f2ab197f1943473e65aa47eb762d510bc207282432dff7ca63a"
    :COMPRESSED-BYTES 942 :COMPRESSED-SHA256
    "d4b6ae37fc77fe361d0fc3c427ecd85261762b4a5dd1e89e6d277ba99a57e388"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6512 :STORED-BYTES 1561 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6512 :UNCOMPRESSED-SHA256
    "8c5de5301edcf85851b47bfb7dbb9496dd43ec094516615c8f52cc52f31f7bd3"
    :COMPRESSED-BYTES 1246 :COMPRESSED-SHA256
    "c4e6b18d053ddb43fdc938bd399d68dd837f5cb99669455d2ff59b742f5e7a9e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6314 :STORED-BYTES 1444 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6314 :UNCOMPRESSED-SHA256
    "68d4652f547ebcf8fc505814ab1e848d3426ca79016efc21fa14b4759e921d29"
    :COMPRESSED-BYTES 1126 :COMPRESSED-SHA256
    "f50e435e3b59d45778d5d15d5109ea6403a0ac21553baae7fc8fadd3045d3da4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11320 :STORED-BYTES 1446 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 11320 :UNCOMPRESSED-SHA256
    "a89c30f186e15ae743dab8ac8a0bc33dbefcb25dad57763cfdd22f8a41a765a7"
    :COMPRESSED-BYTES 1124 :COMPRESSED-SHA256
    "4dc5641d046d26a504af0127f05699b8586c99dc73d8a45684e3fd9c31de55b1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11131 :STORED-BYTES 1351 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 11131 :UNCOMPRESSED-SHA256
    "fbcf85e195f8142264218275598ef4b9928a22d1e8e9fa19221c9c9835004d82"
    :COMPRESSED-BYTES 1029 :COMPRESSED-SHA256
    "c129bea418aae705d10c90cddf62a05ddb586597b770362ba8c30a12fe8d392d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11202 :STORED-BYTES 1365 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 11202 :UNCOMPRESSED-SHA256
    "9dcfea330be0325e410d0844eeb12d0dc1a77a67218e903ea0ad924e0afad53f"
    :COMPRESSED-BYTES 1043 :COMPRESSED-SHA256
    "a3c9f5f6149b9570e326ea302b03c9734508e081ae7556f670a0d813df14d9ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11044 :STORED-BYTES 1246 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 11044 :UNCOMPRESSED-SHA256
    "a2ce2a5d61ab3877de7ecf79ef199b85aa2aa9198f1784825bff8cbdbe893cd7"
    :COMPRESSED-BYTES 925 :COMPRESSED-SHA256
    "2d74ff8f076db72a5d669cc9a944084b9dcc152b41051500031ec2e52c79b3a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11309 :STORED-BYTES 1457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 11309 :UNCOMPRESSED-SHA256
    "d4c7725ed0b8fac3d7fe83eea22807019f3c817cb88087b211539ae192b6e6c8"
    :COMPRESSED-BYTES 1135 :COMPRESSED-SHA256
    "7458d7db127606019642760d1676aace6afdcc5c13baecb7f43b038d19fe5215"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11133 :STORED-BYTES 1244 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 11133 :UNCOMPRESSED-SHA256
    "a8cbb2a1f7b0862e39678fab6e0e5cf72de00db057cc975d4f47487de381fc70"
    :COMPRESSED-BYTES 923 :COMPRESSED-SHA256
    "9a3aee05e63629ce38d140c8fab727ec93caf0dc5869bde7a77507ce634bf41e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11163 :STORED-BYTES 1241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 11163 :UNCOMPRESSED-SHA256
    "7575367b43b0e8d38f2a315237a5bf403dd490f90c23796e549b150a0fb8f830"
    :COMPRESSED-BYTES 920 :COMPRESSED-SHA256
    "e93f2696016427ec38fecea679311c0dd93f77dcd369d5bf88566d3de1cbc0c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 11053 :STORED-BYTES 1193 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 11053 :UNCOMPRESSED-SHA256
    "d2d926e90f94101dca1fa7344bd4572b838a871668e2a6061e6d369e370e86bf"
    :COMPRESSED-BYTES 872 :COMPRESSED-SHA256
    "dc4236cc22750c1bc775ecb90a525089397491c31c2c5aead3e040f864a3f9c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20051 :STORED-BYTES 3394 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-5.lisp.gz" :UNCOMPRESSED-BYTES 20051 :UNCOMPRESSED-SHA256
    "7c9b545c4e6b5c5660d009fa69f70f7447343caeac912d70eae778f66697c01f"
    :COMPRESSED-BYTES 3084 :COMPRESSED-SHA256
    "e4f15198e2d9d90b481323fd8a79615ea67aa1b3e49dcbcbe1bfbf27d8ba2160"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20045 :STORED-BYTES 3301 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 20045 :UNCOMPRESSED-SHA256
    "232eac6283079b8ce9e9ae586b9747762bc7e26ead3dcedb31d5090be20bb1fe"
    :COMPRESSED-BYTES 2991 :COMPRESSED-SHA256
    "5c2bdd9d931ba106608d7a23cbb057475df3270e82ef64abb59fc4880edf1942"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20047 :STORED-BYTES 3614 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 20047 :UNCOMPRESSED-SHA256
    "266e2580243436f31e1e76d3c445ef9f9aa9ac3b044a881e14649494be7a7e54"
    :COMPRESSED-BYTES 3304 :COMPRESSED-SHA256
    "40c1e5e212a07682b7b45fa21b54a8da07dc92266474ac3cacdd14cc9d3fd136"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20049 :STORED-BYTES 3277 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 20049 :UNCOMPRESSED-SHA256
    "536204c7d5c6d031bb574dcdca5d2733bddfb55fb5a5bf8f2bcfbb793470dd05"
    :COMPRESSED-BYTES 2967 :COMPRESSED-SHA256
    "ece52d00071efaa17c1182db1af2cdbe5f692e4a6b13852975e18cfe1911bd74"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20046 :STORED-BYTES 3545 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 20046 :UNCOMPRESSED-SHA256
    "a8717097d084a1e713172e05f54457b2b79f217576abb8f03115d94d0dbb2d96"
    :COMPRESSED-BYTES 3235 :COMPRESSED-SHA256
    "47c1d2ce01c4d536eba5e029a1c527f69940c7a1bc8477118ed140bf974df035"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3839 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "e12fec3c67e39ee42a74041bd0a44a5d6d1c7523e0f0e6eb33c865e54946a189"
    :COMPRESSED-BYTES 3529 :COMPRESSED-SHA256
    "efe7bd7e15d48f3733648748cf53467fb0b31aba1a0f2136d4a8708f9ebb2f97"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2556 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-5.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "9851de22757b1860c573973ebbde73fc5c2d3a392b22ce3a312165d4b0408430"
    :COMPRESSED-BYTES 2246 :COMPRESSED-SHA256
    "abf9b5b422895758a05bb55b0dbb45fc2cfeb9337db8a036f2527b0bacedf627"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20002 :STORED-BYTES 2627 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 20002 :UNCOMPRESSED-SHA256
    "11b6a340c6bdc35570469e297f8028b945349956b8f26345f0b9586a38cdbb45"
    :COMPRESSED-BYTES 2317 :COMPRESSED-SHA256
    "e9b48071aebf672a954a3078a664cf1f8a4ba52a1fd8687beb6f4f7e9885c9e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2779 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "93066d60bc4d3c5e6852ef2d4351a52424609bbb6bf15d98f0950541022094c9"
    :COMPRESSED-BYTES 2469 :COMPRESSED-SHA256
    "549374ad9f3d6fe29a96453fc10ebda3a20e0f4b4d44579fe3aa67376d231d7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20006 :STORED-BYTES 2593 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 20006 :UNCOMPRESSED-SHA256
    "25aca3cbc33bc6372f052cb40011a2827d2c7291ff382adb5572ee2292509854"
    :COMPRESSED-BYTES 2283 :COMPRESSED-SHA256
    "b1a225913c93812a3ca8729704cd487c0211e6684be7053ba8ff0cac58c8309c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2681 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "1b66b969f6494407b99ecd879da08a69689ad6703e5aa1e60b5d2a2f2f8a516c"
    :COMPRESSED-BYTES 2371 :COMPRESSED-SHA256
    "1fd156e7f821b924c0791419aa0f93d313bbb47229ebf404f34d2784e34a8175"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19976 :STORED-BYTES 2676 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 19976 :UNCOMPRESSED-SHA256
    "c5bdd3949a8f6cdbd933ba71c7c5c6156b871d9cc0cb96bc430ed969479cf9cc"
    :COMPRESSED-BYTES 2366 :COMPRESSED-SHA256
    "bd673070bb2700a28a29e314a8d0244d6a3499d8d76789e5b2061a420ca95fd1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20049 :STORED-BYTES 3263 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-5.lisp.gz" :UNCOMPRESSED-BYTES 20049 :UNCOMPRESSED-SHA256
    "1d6d2e9ed5caec8040650454c951c0b4828291bbe9fbd0364bb30091c477ca14"
    :COMPRESSED-BYTES 2953 :COMPRESSED-SHA256
    "1e48657013273f59be43704be1154b5419808164c47008c008c9aab92c3a1e7b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20056 :STORED-BYTES 3552 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 20056 :UNCOMPRESSED-SHA256
    "7d57994aa3fbfa7a02af16fc95c97431f5b471ebc0e90a90feacab6ee2d648f0"
    :COMPRESSED-BYTES 3242 :COMPRESSED-SHA256
    "dfac0eb36b097b79e0bc6ad3eb97cae994ac475cd38a6b096cfabad2952356c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20054 :STORED-BYTES 3422 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 20054 :UNCOMPRESSED-SHA256
    "03441f55800b66c7036aa0f473853fcbf16d47c44d4b94af6afbd7c26a34d891"
    :COMPRESSED-BYTES 3112 :COMPRESSED-SHA256
    "3eb28489a119a80d6aca5e7b61fd53dffacf45a28d7d53201b807c2bc22a42b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20058 :STORED-BYTES 4015 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 20058 :UNCOMPRESSED-SHA256
    "81d76fea1618b2bc083ea46c46d8a9b1b93e5576ce89cbf6e8d8a62b05736a8f"
    :COMPRESSED-BYTES 3705 :COMPRESSED-SHA256
    "3240a07794a1817987f0dcc80430c4014eb48a732e3d92f8d3fb24711fe258e7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20065 :STORED-BYTES 4503 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 20065 :UNCOMPRESSED-SHA256
    "a12c1874cbe5454153f0f9f1719652f6fcf1c61580a4c7a5c9a4cf838a229292"
    :COMPRESSED-BYTES 4193 :COMPRESSED-SHA256
    "b88d5dcc5bd610b66c2b8f50ac39f49ad7f4aec2e1c2c4c76404f3d1f4e54b57"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20057 :STORED-BYTES 3607 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 20057 :UNCOMPRESSED-SHA256
    "b2f4a321973974a627b6339985be548085a3be60a37dd503a4478d0b9265c57e"
    :COMPRESSED-BYTES 3297 :COMPRESSED-SHA256
    "a752b9184b99644f7b5cc4a22b3e7af838af8165f5cefd874398454f5b2aac38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18476 :STORED-BYTES 2575 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-5.lisp.gz" :UNCOMPRESSED-BYTES 18476 :UNCOMPRESSED-SHA256
    "23e46e379c1f7324943c0a6ced60d18739b1b2106eb49d9e32e026a5f3fb2cfb"
    :COMPRESSED-BYTES 2265 :COMPRESSED-SHA256
    "27339e21de7122820af07b9dd9501935a5aa527ccd889b79008fe8ee312176d9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17808 :STORED-BYTES 2738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 17808 :UNCOMPRESSED-SHA256
    "bd20cb8f8521b18cb57e62d94b662ca69b9852d8d04659377db0bbac3f17cef5"
    :COMPRESSED-BYTES 2428 :COMPRESSED-SHA256
    "263e5adf383e20a1cbda6e8d4cf0ad31e7a92a7cb37f70ad5e4d1431d5e0707a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18380 :STORED-BYTES 2413 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 18380 :UNCOMPRESSED-SHA256
    "af70b297a3ef59925fc40a70ba9a2f619d25ace670e9567fe2565cf67dfb02b7"
    :COMPRESSED-BYTES 2103 :COMPRESSED-SHA256
    "23931ef28612676a943385b501c463cd411589c4e5a0b1b52c485bf71cd23e34"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17937 :STORED-BYTES 2386 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 17937 :UNCOMPRESSED-SHA256
    "204026d33e7511c1ef7ba186544519a9148b9db776fdadadba83c447af702b2c"
    :COMPRESSED-BYTES 2076 :COMPRESSED-SHA256
    "e0e0d1dbfa16ebe0c4aa68d9bfa28ce770679b684cec1e74ba7a9e2e1034f038"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18403 :STORED-BYTES 2464 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 18403 :UNCOMPRESSED-SHA256
    "1e3609e35f89cdaf0f44efae70f473a7d076bc8bcbc7341bfe83f53081078881"
    :COMPRESSED-BYTES 2154 :COMPRESSED-SHA256
    "59e1245a2aae20879c168badee1052b7418653a116d1370b9b526a301c568458"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/buffer-profile/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17875 :STORED-BYTES 2673 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 17875 :UNCOMPRESSED-SHA256
    "4fd5c33e3d5701192bed9cb79542ff273e3d3dd393eb689352c16b528f702e9c"
    :COMPRESSED-BYTES 2363 :COMPRESSED-SHA256
    "e69719bfffb12bc1ccbcdf1243e931e2d8f6fd4c04da2898ae298a5e87a92cd9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/4002530612-command-55834-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352534 :STORED-BYTES 113039 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352534 :UNCOMPRESSED-SHA256
    "2634a48fb11c8356c3fcaa2ebe85a9fbc924430ac891961a6438ec78509016ea"
    :COMPRESSED-BYTES 112723 :COMPRESSED-SHA256
    "7c09f1a6490fd16dffa2672dead9cea288f95cf0d0253240d99f335d75268bcb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-analysis-self-test-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351183 :STORED-BYTES 112638 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351183 :UNCOMPRESSED-SHA256
    "31c3cec94a329ad69d128a8ae21ffbbba0e8be81db9bcca9fdfc81317edb89c2"
    :COMPRESSED-BYTES 112322 :COMPRESSED-SHA256
    "268f835ab91ee5c15ebcae2dfa46410505e11099d6f95cfda47ea88d6c84aa0b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 354657 :STORED-BYTES 113593 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 354657 :UNCOMPRESSED-SHA256
    "49e288e1a501620ce719ba4050139ec3cf714994c7c1083795f40d53d96ff4ce"
    :COMPRESSED-BYTES 113277 :COMPRESSED-SHA256
    "fb7d41eba8d542f4d724b0ad570ccb968cc9cd089f83e3a35125d80dd93fbf30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-archive-self-test-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351890 :STORED-BYTES 112872 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351890 :UNCOMPRESSED-SHA256
    "c0ea9e84f8022c12a6f28fe8be4e6a8294c4993a3c6ba9d270b930432340e251"
    :COMPRESSED-BYTES 112556 :COMPRESSED-SHA256
    "4f4c4b86ca6ac684e392904316a3ba9610b8cc5b6370f70b6cb30d5cc64937a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357751 :STORED-BYTES 114488 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357751 :UNCOMPRESSED-SHA256
    "7f4feab179c81b591de7e16f8dd4ca5b8b07fab3c4aa11ab886ba492b13a93eb"
    :COMPRESSED-BYTES 114172 :COMPRESSED-SHA256
    "630e7946c9c97918cbc7e1b99fd3bbce8ec278a857fe6d7d05f1d32d0d6b750d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-baseline-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 373622 :STORED-BYTES 116026 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 373622 :UNCOMPRESSED-SHA256
    "88b33fceac5527c92520458e6f7106ccc6aa6dfda1f4e8f34309a57c3bf75a31"
    :COMPRESSED-BYTES 115710 :COMPRESSED-SHA256
    "cba04fdc1e5ee2da9678dcffbcccd7f53de6ebb45ca5b7b5df0e4704d0e2d97b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-baseline-identity/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351888 :STORED-BYTES 112863 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351888 :UNCOMPRESSED-SHA256
    "94d8865c4c18258c324e88a7d67775c97277c3f61299e6756440304b75d8d6d3"
    :COMPRESSED-BYTES 112547 :COMPRESSED-SHA256
    "34803eb5a2364d27e0b6fdb2081030f0a67eaf7872754bb0d3eba4a60448173e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-baseline-profile-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 353943 :STORED-BYTES 113241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 353943 :UNCOMPRESSED-SHA256
    "b4884b911e0becd675f4a7f6ce24d67c7bf5cbd501229cc15747df84262619a9"
    :COMPRESSED-BYTES 112925 :COMPRESSED-SHA256
    "e60899762f0414d5b16f2bd4cf216956977a74a18a49f309dad57ad5035b0dd0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-baseline-profile/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360806 :STORED-BYTES 113595 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360806 :UNCOMPRESSED-SHA256
    "e250f75a50c8c1768287c79edbf2a3483014e9c58ca2ff91443e510818e698f3"
    :COMPRESSED-BYTES 113279 :COMPRESSED-SHA256
    "4c51444b803a19c2c6b65d2a0be3466455d4c138d19378262eb90a53e3d05a26"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 428234 :STORED-BYTES 116143 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 428234 :UNCOMPRESSED-SHA256
    "6aefd65d80f94574397db3912bcaadc0a87c233f3e21656cdc273ecb445cf178"
    :COMPRESSED-BYTES 115827 :COMPRESSED-SHA256
    "63e534c1f28b2082025eb0e37f891500c68b858df7fdc14dc279d0ea1af1472b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-buffer-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 376016 :STORED-BYTES 116455 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 376016 :UNCOMPRESSED-SHA256
    "5d4f0fa1e62911ea104ff966cbf2e6f722639ff744b8166458b30ab818edbad9"
    :COMPRESSED-BYTES 116139 :COMPRESSED-SHA256
    "2f377bb789364c3948eecd19d27cd71bab881c721a77f6356cdf2202f07adbce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-buffer-focused-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351413 :STORED-BYTES 112721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351413 :UNCOMPRESSED-SHA256
    "f7d813f234d8bcc993a502caf3a77deeeff441179cdf06d949bddd0dd59df294"
    :COMPRESSED-BYTES 112405 :COMPRESSED-SHA256
    "6941e36ac0ec0239dd098f154c6d8edc7ff68d308b5726bd25b12e0bc50ed03f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-buffer-focused-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351413 :STORED-BYTES 112721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351413 :UNCOMPRESSED-SHA256
    "78747a541e6d34c31f279f3d60069685f339cba3a2f25910b9dc9113b987ac1b"
    :COMPRESSED-BYTES 112405 :COMPRESSED-SHA256
    "26fa2f725c692499be06821a4f1244b30de09d953ad64e578b8e21d7273b46bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-buffer-profile-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 354207 :STORED-BYTES 113337 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 354207 :UNCOMPRESSED-SHA256
    "35fd61d4638075ab3fa7c53fa1053039fa22f3e275a5447606cccb02fab11827"
    :COMPRESSED-BYTES 113021 :COMPRESSED-SHA256
    "97aaa185c1f0980ae463c497bac3646eb17c4b1053e9a6218adb840e13d8a755"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-buffer-profile/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361074 :STORED-BYTES 113684 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361074 :UNCOMPRESSED-SHA256
    "c5aef714e0a6d4a2b729874d0c225306400e0d18b26ce9f886f7ea868ff1d4e1"
    :COMPRESSED-BYTES 113368 :COMPRESSED-SHA256
    "c5eeeee704b1be5a542b90f8d54d1a17cd6745d58726aae11d2327abd966b0e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-cleanup-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351921 :STORED-BYTES 112901 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351921 :UNCOMPRESSED-SHA256
    "c2a76688f0ff24a20c2945192c69011a78cb974b8d6dedf1bd79f7144cd274fc"
    :COMPRESSED-BYTES 112585 :COMPRESSED-SHA256
    "244416cb421408574169d7f33923a001164fcfa52cb852ac0ed8443c2608394f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-closure-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351884 :STORED-BYTES 112859 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351884 :UNCOMPRESSED-SHA256
    "1bbf5594c6801e12a5c19f11eb464e943909fd3a079bcbbea06eac3515daf572"
    :COMPRESSED-BYTES 112543 :COMPRESSED-SHA256
    "ccad68fa3b91cdfbf2aba4acfa7c63807aae2c776d3b5e2579d21ffa9de553a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-comparison/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351929 :STORED-BYTES 112872 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351929 :UNCOMPRESSED-SHA256
    "71a5eb15bd34838a3f4328c164a3e78510e6f45dad8aa9633c772ade9222f275"
    :COMPRESSED-BYTES 112556 :COMPRESSED-SHA256
    "ad50ecb43426b524488c504aae132eb9184e31cb68e1d4a958bbfc4ea2a99912"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-documentation-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357975 :STORED-BYTES 114257 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357975 :UNCOMPRESSED-SHA256
    "59c412edd9e0ab20ecbbc94031943dc58c5132f4b3542c872ca91c0c1380dd2d"
    :COMPRESSED-BYTES 113941 :COMPRESSED-SHA256
    "ad8a70132155cf30a914f27ab8d997ab7e5455efecf8f79cd4d7336e0c2fb6e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 358985 :STORED-BYTES 114209 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 358985 :UNCOMPRESSED-SHA256
    "da45f36461600d2491c7078a1c7f9ac72ab3295e9c2cfc12a0e3e66ec8c63f9e"
    :COMPRESSED-BYTES 113893 :COMPRESSED-SHA256
    "97e2c798d7d9fb77e8556fbabca0e14c183fe4c3e83cdd1e966417f1adf67811"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360283 :STORED-BYTES 115112 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360283 :UNCOMPRESSED-SHA256
    "cfb45397ec3091bf621a138254fcc2bf768796830fc8625797a4d8c7bcd3cec6"
    :COMPRESSED-BYTES 114796 :COMPRESSED-SHA256
    "4bb572bb0f938fece3120da308071cb9105021775e470d245c690b1f08ce4598"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-final-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360520 :STORED-BYTES 115161 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360520 :UNCOMPRESSED-SHA256
    "b40a7040e87e5971a14c2d3d3ade6e49b95a5cc7b061073e52d4babb183770e9"
    :COMPRESSED-BYTES 114845 :COMPRESSED-SHA256
    "100e145d14f5dfaa984a11415546991a4df38832464c9615f2f9b17378136918"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 428923 :STORED-BYTES 116314 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 428923 :UNCOMPRESSED-SHA256
    "11f16fe07097b4952022827e5f197f676a929f179c89953fc4c2bde303581117"
    :COMPRESSED-BYTES 115998 :COMPRESSED-SHA256
    "29e57beddebe90fcf488f3a1e351205d2691d4f7fc26601245ef0092e53faa63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-focused-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351837 :STORED-BYTES 112848 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351837 :UNCOMPRESSED-SHA256
    "ab1c3df54e71ab318ae6bef4256de29f58406f1858a310280176e7b9de4d1117"
    :COMPRESSED-BYTES 112532 :COMPRESSED-SHA256
    "ea5bb78e08bb0c67034ac793f4e77fd226d199edbbde940337ebdb456f765587"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351878 :STORED-BYTES 112855 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351878 :UNCOMPRESSED-SHA256
    "49a9de8a159785eae24a7a9a023029bf93de2bbe2384c98e74f0c68cd12972d2"
    :COMPRESSED-BYTES 112539 :COMPRESSED-SHA256
    "03c933d2004031438b6c8a1567546c6dceb690899a5564115d32864f653d41a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-increment-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351913 :STORED-BYTES 112858 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351913 :UNCOMPRESSED-SHA256
    "179c7a3654c4b6dc45b70fb395c9901cb3e8a79986b2b55dff7bdd2db0a0a2d7"
    :COMPRESSED-BYTES 112542 :COMPRESSED-SHA256
    "928f0aecbf7e8e8d4e16aff151124b7074eed3db4c6c51c751246463de2f32f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-increment-ci-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351916 :STORED-BYTES 112860 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351916 :UNCOMPRESSED-SHA256
    "4f64a2370a3b990f462374cef00633720f108f2107c6a6b3e3f59fc9de746e96"
    :COMPRESSED-BYTES 112544 :COMPRESSED-SHA256
    "380ee0f5a5d0f687926a60f2258c86cbdaf31016302182a273306670d841e33c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-increment-identity/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351882 :STORED-BYTES 112863 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351882 :UNCOMPRESSED-SHA256
    "4d6ae92dbb75ee4142e3f720db532fb98d612f06f27be4309a39bb6e32e63fef"
    :COMPRESSED-BYTES 112547 :COMPRESSED-SHA256
    "6729375374809e70d2ce675ee54c0f6f1b78aaf4b61260dad2a44e2bec1b2e4b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-initial-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351910 :STORED-BYTES 112860 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351910 :UNCOMPRESSED-SHA256
    "904cef9ee98c21812181646ec08cd1bed9273b8e3861740a0271a8d7ff9c2d74"
    :COMPRESSED-BYTES 112544 :COMPRESSED-SHA256
    "50d60a4e110288b59a972e9c69870a254bf3d7d74151b1d6d453a7f3f5954545"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 559927 :STORED-BYTES 128928 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 559927 :UNCOMPRESSED-SHA256
    "b18f16af8d95f59f503cb21a7347fdf93b35f7b2c477a68bb54c0805f5743bde"
    :COMPRESSED-BYTES 128612 :COMPRESSED-SHA256
    "da403a28e70325bc4c76155726407142cfbab1f5deeb09459d66d9f8961d9428"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-2.6.9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 559895 :STORED-BYTES 128912 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 559895 :UNCOMPRESSED-SHA256
    "e74551dee9f477fd4437d21d08d7d18b8e9660026bdf0dff7dc7c04066afa3f8"
    :COMPRESSED-BYTES 128596 :COMPRESSED-SHA256
    "78353fd820292704070c2e1c542f8d37364d18cd5d82ec2f064e6f4bf12a1e63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-audits/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360994 :STORED-BYTES 115386 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360994 :UNCOMPRESSED-SHA256
    "1b595c7b48d2fdc102f7c0cc6ab322c7e2e0787fd782dec8ed0745f44857d134"
    :COMPRESSED-BYTES 115070 :COMPRESSED-SHA256
    "c215c9aa75f418aba162eafb8a8e9299648f0c5616ee94d897fc75571c5923d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 437424 :STORED-BYTES 118607 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 437424 :UNCOMPRESSED-SHA256
    "f2fb04a567144f00ea4ce7c16ca208dc126affc6ae0e9e3909149221c4cfda1d"
    :COMPRESSED-BYTES 118291 :COMPRESSED-SHA256
    "403d17e38949563a7db773771cc8c267710e6b271ca6d461f71f7985ba977fe3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-ci/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360838 :STORED-BYTES 115291 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360838 :UNCOMPRESSED-SHA256
    "0e69a35460669db26e73db5b13684a6ec202cc56bea3eda03ba5647776470043"
    :COMPRESSED-BYTES 114975 :COMPRESSED-SHA256
    "4e9871a31758384cee80d5a1ea6a6ea0ada5c59d1c0e98ee6b6d7f5418449a56"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-comparison/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360231 :STORED-BYTES 115109 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360231 :UNCOMPRESSED-SHA256
    "0a84b99015606a19f0693a87fdf96d70444ffd7fe6ab6181de6591a0285f8de4"
    :COMPRESSED-BYTES 114793 :COMPRESSED-SHA256
    "582544f0594725831f957d16c6ecb21dc45eaa962e40efb79d69dee349df44b7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integrated-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363303 :STORED-BYTES 115920 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363303 :UNCOMPRESSED-SHA256
    "8be250f4e2131f44b8e477194882c0a6eafc739d91b2507206dfbafcf2eb0697"
    :COMPRESSED-BYTES 115604 :COMPRESSED-SHA256
    "f5598529ef6b590f51af06a17c1c3c356772434f21df2da09f5cbc60d8abf26b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-integration-identity/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360400 :STORED-BYTES 115132 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360400 :UNCOMPRESSED-SHA256
    "bd4a2400a88378403a42dcdd12dec3fe3afd2989e3ec687872322578fd5a341a"
    :COMPRESSED-BYTES 114816 :COMPRESSED-SHA256
    "0bf3173f5167492d5377af622a4e993e5c0bcf5c6a867561451f1b6a17ba5368"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-platform-sdk/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360593 :STORED-BYTES 115269 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360593 :UNCOMPRESSED-SHA256
    "b10c69ce205c81f72e1326babca570cb6011e2b46cec495c5223b2e8399d71e8"
    :COMPRESSED-BYTES 114953 :COMPRESSED-SHA256
    "511037f164096a9246f0ab998dc4020d8d5ca98b2691786d8b204c995541e1a3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-platform/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360296 :STORED-BYTES 115056 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360296 :UNCOMPRESSED-SHA256
    "08554c08f2f55cb6b207fb44f06bc5dd02a51dd7a49330689980280800e4f553"
    :COMPRESSED-BYTES 114740 :COMPRESSED-SHA256
    "6757ee9347d86778f11138a527a7e4f0ebbc17f37a3d3ff1c92675a76a7ff4f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-qualification-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351898 :STORED-BYTES 112867 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351898 :UNCOMPRESSED-SHA256
    "ec5c57483717b859d217faa3bcabe86d5edab3fe42c82644f71309928b98e26b"
    :COMPRESSED-BYTES 112551 :COMPRESSED-SHA256
    "f6445f4f428a131faec701755e0624aba5ce7ec09dfe4b1ce37d69d6f1332636"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-qualification-summary/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352023 :STORED-BYTES 112888 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352023 :UNCOMPRESSED-SHA256
    "53c3e99b63f8774a48e5c6a88eadd512cba535990e8da119cc5affd934f2976f"
    :COMPRESSED-BYTES 112572 :COMPRESSED-SHA256
    "e78238629bbbcbae8e98f5f6ddcb75b108e8e4112d7dc6ef754931180d09d5c8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-smoke-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365156 :STORED-BYTES 114556 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365156 :UNCOMPRESSED-SHA256
    "35e7993aeed4350bbe1b61dd91d5f4d1e3386ddbbe12333d848f7383cc0cb747"
    :COMPRESSED-BYTES 114240 :COMPRESSED-SHA256
    "f184ac5ab39dafc364ef47466d39bc8f5c9bd8d8c3bc406e3b353776fa8a1345"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-smoke-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365976 :STORED-BYTES 114782 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365976 :UNCOMPRESSED-SHA256
    "73477d95588e0631d1e9b0d48625f2970ba3c28c647a3e1191a7d0dfe9ec5db2"
    :COMPRESSED-BYTES 114466 :COMPRESSED-SHA256
    "74a32a4d3fa5d79e5e7070e3c1a0c07501dd1d468b0caa1a82b41d29e86ff3c6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-smoke-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365976 :STORED-BYTES 114784 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365976 :UNCOMPRESSED-SHA256
    "f8fe60e0b1216a053d2c7e52a20b36206c2c0bd0e0024f3723117d638cc5f9b4"
    :COMPRESSED-BYTES 114468 :COMPRESSED-SHA256
    "93c73e4ec7470e9ae247e6728027f5ab5c85908a1969c6aacdffa1ebe70c3ed8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-smoke-04/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365975 :STORED-BYTES 114784 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365975 :UNCOMPRESSED-SHA256
    "5ab6fe721ce94dddd68b60a779349f35f7904c7ef0440ae7d1fdac9f03f4c4fd"
    :COMPRESSED-BYTES 114468 :COMPRESSED-SHA256
    "1ada6813ee6edaef938ad20b653744e3f18e2bd9e84cd91150668ff833b37509"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-smoke-05/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 353827 :STORED-BYTES 113316 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 353827 :UNCOMPRESSED-SHA256
    "3c5f75a89dde894f638068b010c341828a39cb9e6c6053217b9daaf2eab34a81"
    :COMPRESSED-BYTES 113000 :COMPRESSED-SHA256
    "33a48ba8e0e1b48186ccb9b86bc85c848d53aab4f5727893197e0c42c2377204"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-statistics-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351891 :STORED-BYTES 112867 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351891 :UNCOMPRESSED-SHA256
    "28bc5377b5b55d28e11c889bf1087b5572eddc865b76e2371d9f00f1df8b72b2"
    :COMPRESSED-BYTES 112551 :COMPRESSED-SHA256
    "f8e79df5ab0abc0c848b87a471fa5e2d9ea187bbf3fd4e31e4e94297771a1b64"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/commands/unix-latency-statistics/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 358019 :STORED-BYTES 113797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 358019 :UNCOMPRESSED-SHA256
    "0b501f26e3c6b8ec5c68e9ab837c7df947d0c98f5c1b276eb8e0aba591673380"
    :COMPRESSED-BYTES 113481 :COMPRESSED-SHA256
    "39eb94bf1720f1a7e71e6910aedb613fe69c5a2d81834b49b94321d83f54974a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/failed-fixtures/1U7027V-G5S-0/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4745 :STORED-BYTES 1644 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 4745 :UNCOMPRESSED-SHA256
    "cfe972ccdb1a3206bfa9e8d404f7d1e65f6d359b19874d2d7fe1e8fad71e2534"
    :COMPRESSED-BYTES 1323 :COMPRESSED-SHA256
    "49238d15dffde60907aa3608e3af0b609520a28aff11ff1216de13ace197a2d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/failed-fixtures/1U702BX-I60-0/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3632 :STORED-BYTES 1309 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 3632 :UNCOMPRESSED-SHA256
    "acf5e0ad0c0c1335459adf42edd9e53dedf23c043b1ce5865ae070247a5a3d1a"
    :COMPRESSED-BYTES 989 :COMPRESSED-SHA256
    "327cef048ad92ef60b92284d7c30c179f5cdc8213490e58a57310b4fdfb0b30b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/failed-fixtures/1U702CZ-IFP-0/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3636 :STORED-BYTES 1313 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 3636 :UNCOMPRESSED-SHA256
    "8fba3100306d5464ba7ec690b22aeebaaa270d6941cc7aac9da6dc7987cbaeba"
    :COMPRESSED-BYTES 993 :COMPRESSED-SHA256
    "9f5e881646fe63e0f437b486119a4420da7d7b25aa530b553dcd946debbe7217"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 51233 :STORED-BYTES 7744 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 51233 :UNCOMPRESSED-SHA256
    "5f2c40760a4bc668a5ac4a15d50b0a7b28431ec157750179bc4bd0b91c3e9d94"
    :COMPRESSED-BYTES 7428 :COMPRESSED-SHA256
    "f9bd08186c75e8450c24f8f2f6f498829a3577ba9803abd7b08262869d81a981"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 51050 :STORED-BYTES 7601 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 51050 :UNCOMPRESSED-SHA256
    "35b928de211160ee28996be56e4dcc41080bc9dcc18b54607340d8a1464d3931"
    :COMPRESSED-BYTES 7282 :COMPRESSED-SHA256
    "f7e5b287bc94567457684bcc7f86739d44acf6a8daa3072035d4d2767d1d184d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/066-latency-66.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2726 :STORED-BYTES 883 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "066-latency-66.stderr.gz" :UNCOMPRESSED-BYTES 2726 :UNCOMPRESSED-SHA256
    "fbf00064aa68adf305c81075efb7bffbc6c90853382c4768dd2de0e9d77f7d2f"
    :COMPRESSED-BYTES 562 :COMPRESSED-SHA256
    "28d299e5a3e9aa12f1402f3beadf37ee988b1658f9600f530a922c0f6b917479"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/065-latency-65.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2690 :STORED-BYTES 796 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "065-latency-65.stderr.gz" :UNCOMPRESSED-BYTES 2690 :UNCOMPRESSED-SHA256
    "aa10f29c98931e25c6a91fb47919eacb8bb6b6be4ec026b6ed65e0715874adb1"
    :COMPRESSED-BYTES 475 :COMPRESSED-SHA256
    "dd41afd7a31e4458f72fd3c26a943e67a3b83821643f89015eea799227a85c4c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/064-latency-64.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2716 :STORED-BYTES 874 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "064-latency-64.stderr.gz" :UNCOMPRESSED-BYTES 2716 :UNCOMPRESSED-SHA256
    "b7216ef8a441534edbb8b50544f1ce8afaf4de9016f488126cff01a9a8b2933c"
    :COMPRESSED-BYTES 553 :COMPRESSED-SHA256
    "bf3fd441d46c6c62c341db73c93ecf68aa40b47634e8263729ed987398bd50ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/063-latency-63.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2689 :STORED-BYTES 851 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "063-latency-63.stderr.gz" :UNCOMPRESSED-BYTES 2689 :UNCOMPRESSED-SHA256
    "17e5139afc444668f3fa092eb45a561b67ae7d5260312fe8a7d60fdd97226d2a"
    :COMPRESSED-BYTES 530 :COMPRESSED-SHA256
    "739e2b5b2000eeb754d7c3cc9a0b5b329f6dcb983cfede901bf6b1997fe277f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/062-latency-62.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2697 :STORED-BYTES 873 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "062-latency-62.stderr.gz" :UNCOMPRESSED-BYTES 2697 :UNCOMPRESSED-SHA256
    "f4a5052f9de7de9fe6f583bad1212625cf169adc09e8e274090d022f8ae5b1ef"
    :COMPRESSED-BYTES 552 :COMPRESSED-SHA256
    "cc79602284545857b5bbf1413b816108c16761c23cf4f586afe462b36cc2915e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/061-latency-61.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2651 :STORED-BYTES 843 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "061-latency-61.stderr.gz" :UNCOMPRESSED-BYTES 2651 :UNCOMPRESSED-SHA256
    "191bb609f2b8a42c03d089b81e1190e01c1ff65049bc66fa6e6e73a50a58aaba"
    :COMPRESSED-BYTES 522 :COMPRESSED-SHA256
    "7367855c971c729213524c79ab7f501bbc6b90586bb9ad557f8a4bb9be034862"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/060-latency-60.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2680 :STORED-BYTES 854 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "060-latency-60.stderr.gz" :UNCOMPRESSED-BYTES 2680 :UNCOMPRESSED-SHA256
    "dcc19327e8e4e0a4dc92ec17e5e989ef0b087677bb2168893289f7f513df6e04"
    :COMPRESSED-BYTES 533 :COMPRESSED-SHA256
    "af09a138afbb02cbf6cb42f19cdb2048f99ed4af20a2390b27c0fbc450ce5e54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/059-latency-59.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 833 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "059-latency-59.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "a00d5f1f7902bb08e76fe05010e03064e89948cc0e390db4965ca3365a85e472"
    :COMPRESSED-BYTES 512 :COMPRESSED-SHA256
    "bff3f96351708da425cdf2dfbe2984b8343cfd676958326df3fa55e42eacac4d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/058-latency-58.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2653 :STORED-BYTES 833 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "058-latency-58.stderr.gz" :UNCOMPRESSED-BYTES 2653 :UNCOMPRESSED-SHA256
    "4ef74a911eafdfb70eeeb6c0a5411bc16a01d8c2f30ebd56624816c0db1e3338"
    :COMPRESSED-BYTES 512 :COMPRESSED-SHA256
    "fde3e987473ce39c3c4d89fb2a631f36584ba3d838b8e4612ef654869644ea55"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/057-latency-57.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2613 :STORED-BYTES 820 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "057-latency-57.stderr.gz" :UNCOMPRESSED-BYTES 2613 :UNCOMPRESSED-SHA256
    "ff3e28c2143a9d1cfe6b350bb3e589918f712d7bed2ed895628f1010c1443c2e"
    :COMPRESSED-BYTES 499 :COMPRESSED-SHA256
    "64fc08e4be9072c328c718fc696beaa8893f4afc7e11fb38c3d97689d121c07b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/056-latency-56.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2685 :STORED-BYTES 794 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "056-latency-56.stderr.gz" :UNCOMPRESSED-BYTES 2685 :UNCOMPRESSED-SHA256
    "5ab0e34487f2185932c9467e67b89a5725f0bd2366801149c6dd3ee149c7f1ec"
    :COMPRESSED-BYTES 473 :COMPRESSED-SHA256
    "aea280b18b8c3fd4c8c8c31239b539cb9af8311e43df83b795be2484227aee69"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/055-latency-55.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2659 :STORED-BYTES 768 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "055-latency-55.stderr.gz" :UNCOMPRESSED-BYTES 2659 :UNCOMPRESSED-SHA256
    "bc58261c10300486f5dfd84c8af7adb94bfdc7b6e4274079aa2f594cf4bad10b"
    :COMPRESSED-BYTES 447 :COMPRESSED-SHA256
    "3c4cf535cade6642d6ed65c65381196eb2d2019de7738c5d2306a229c11996e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/054-latency-54.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2666 :STORED-BYTES 788 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "054-latency-54.stderr.gz" :UNCOMPRESSED-BYTES 2666 :UNCOMPRESSED-SHA256
    "f9ad8d9290cfa91a477cdc3de0fc6b375e81d63f5701b140af41c3a8eec4c359"
    :COMPRESSED-BYTES 467 :COMPRESSED-SHA256
    "b2bd624b8dac72e8ba97cc2b12274946a02f8392d1457f09e67c49501aa7d1dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/053-latency-53.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "053-latency-53.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "d6a316379557c8674353a88e73424aba3d080bbf519daf86c485e64077b2eaea"
    :COMPRESSED-BYTES 446 :COMPRESSED-SHA256
    "93a135a388f90126c8d796f4e4d9de0fddf1461bc565511cb50b05677e8a2c2c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/052-latency-52.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2656 :STORED-BYTES 780 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "052-latency-52.stderr.gz" :UNCOMPRESSED-BYTES 2656 :UNCOMPRESSED-SHA256
    "c031ad404ea40c7f85391c791bcd4626940fdd9710fc1c16d44a9bfa53685a8e"
    :COMPRESSED-BYTES 459 :COMPRESSED-SHA256
    "4f6d47ef6ff6314deb180dffb39df440b6adcdefb4c9ee3444b8cc5a83b9421c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/051-latency-51.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2631 :STORED-BYTES 764 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "051-latency-51.stderr.gz" :UNCOMPRESSED-BYTES 2631 :UNCOMPRESSED-SHA256
    "09d3911ad652fc1c00ec04d8cc73ac8a7fda2afe15c6c1807cff9454182af022"
    :COMPRESSED-BYTES 443 :COMPRESSED-SHA256
    "73ecd222cf362c3a7855db96db12f6e1bcdb341050c2738459c2b15c28c1fdc4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/050-latency-50.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2642 :STORED-BYTES 761 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "050-latency-50.stderr.gz" :UNCOMPRESSED-BYTES 2642 :UNCOMPRESSED-SHA256
    "fa33043fe624c81e833a47ba5ff0ba689804563b77d1a07c603cffb937c49351"
    :COMPRESSED-BYTES 440 :COMPRESSED-SHA256
    "31a998b53ea264252dd21fd7d6f25a186261ba2a63bddf3de6769704447d55c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/049-latency-49.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2612 :STORED-BYTES 756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "049-latency-49.stderr.gz" :UNCOMPRESSED-BYTES 2612 :UNCOMPRESSED-SHA256
    "428037eecdb140f9ba2e2fd889994b6a09acf25f2dc8bd583910fa4448bd1dd0"
    :COMPRESSED-BYTES 435 :COMPRESSED-SHA256
    "1ff530ee4a81cc31788ffa4cc33818734edd6a7e64222ed1f1c0474343b913ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/048-latency-48.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 790 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "048-latency-48.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "1ba55bfd96ac7df4a0762e09aefa2fbc1f95913cf321974c8fbd81f9efd8a658"
    :COMPRESSED-BYTES 469 :COMPRESSED-SHA256
    "42e13f65b5bf4b52ac24aeb96cb5cb76379f5f303c8a0f786f971e59055bc0f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/047-latency-47.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "047-latency-47.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "9d64d9e958014eebff2d12f65916f4e9033d99aa02f20c4db1340c7bcb2b832c"
    :COMPRESSED-BYTES 428 :COMPRESSED-SHA256
    "3323c17d4e3cfcab76fd6fa9448fd1ce8453f0c5c2df75ff0fbf982ddabaa9bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/046-latency-46.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "046-latency-46.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "001b4657d021028e7cfd7c9331b5624a22f055d5f455a85f7c2fddca30d2636f"
    :COMPRESSED-BYTES 428 :COMPRESSED-SHA256
    "70d82e445254ba57317800bad62439c94237baa9938d1cb27dccb498e8a43e4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/045-latency-45.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2575 :STORED-BYTES 743 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "045-latency-45.stderr.gz" :UNCOMPRESSED-BYTES 2575 :UNCOMPRESSED-SHA256
    "a0552414888466580fe5c6d138dff2242e85233db46806ddb20b010d31818f7c"
    :COMPRESSED-BYTES 422 :COMPRESSED-SHA256
    "6153a2459cd7ac287dac581999540a732ddddd69c6cc9444b83f6606f59d8043"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/044-latency-44.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 791 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "044-latency-44.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "8e19ea7cf275caecf5e6f542bacf2f30bd97edbb61069feaa1c1a3ce9a81c791"
    :COMPRESSED-BYTES 470 :COMPRESSED-SHA256
    "0b87ca5e69c2819839e1a486f73a18df140aa3ac2057c43089b495b5fe1034c6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/043-latency-43.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "043-latency-43.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "a99ab60249226592fd34fbde3d64aff08393d5cc9bbf2b6323d19c43bd44c130"
    :COMPRESSED-BYTES 427 :COMPRESSED-SHA256
    "77ef6f94eb5cfd342207a4d8b5352c022955d287778643856bb7e1a0e48fb926"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/042-latency-42.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "042-latency-42.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "b67a552a3253b0950c63805f70a868c359cff3e7d5e346699ec5a9a92db2af61"
    :COMPRESSED-BYTES 419 :COMPRESSED-SHA256
    "161d82fa1ef03def13d1acd1481b0012e365b7b1bfacf9d946531b8660cda3e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/041-latency-41.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2570 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "041-latency-41.stderr.gz" :UNCOMPRESSED-BYTES 2570 :UNCOMPRESSED-SHA256
    "7745442e88e17092f44cdbcf3ab6286c41cfdfef288de26818f11433f2fa6998"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "496173166d1a454ad434951fc703ef38c73dd9dc8a594e15c94fab323e900966"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/040-latency-40.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "040-latency-40.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "401c79456ccc5e42f57a522d677141ff57b0a16ff2f4fb7d9dfb6d121cb00917"
    :COMPRESSED-BYTES 464 :COMPRESSED-SHA256
    "c915ea760f47503ec8e5a8219d941f9361becc593572e30b2743e4e27f5aa500"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/039-latency-39.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 752 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "039-latency-39.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "12ceeaaa5674ffef7a6b5da675d016b79a3c89014c4916cef1652f7eb38dccaf"
    :COMPRESSED-BYTES 431 :COMPRESSED-SHA256
    "c9a9c691fd2f4095ea8b98a07eaa9dc4871dd933f9164b26ab83d2c5d73c4ace"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/038-latency-38.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "038-latency-38.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "d8f8cf41ca1a7fd459478be42bbde2e98a256e8eff34f574444e702099a896d5"
    :COMPRESSED-BYTES 417 :COMPRESSED-SHA256
    "aac2fdb61b7022a96b54a527c80150d083efb78e5ba0fe29472512bd700532f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/037-latency-37.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2565 :STORED-BYTES 737 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "037-latency-37.stderr.gz" :UNCOMPRESSED-BYTES 2565 :UNCOMPRESSED-SHA256
    "c0c66a7927d27c884fcbd875550b641628dbb38e9241fa8c11c93adb657a7fe2"
    :COMPRESSED-BYTES 416 :COMPRESSED-SHA256
    "e291662d9b523adea9a3643f582f5f6fe32d18152cd5962c8d1941ba15c22c4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/036-latency-36.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2629 :STORED-BYTES 737 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "036-latency-36.stderr.gz" :UNCOMPRESSED-BYTES 2629 :UNCOMPRESSED-SHA256
    "feba7545db0355dac2a8c4593b3413cc29020ebffd23bcc9a552680c47a01270"
    :COMPRESSED-BYTES 416 :COMPRESSED-SHA256
    "e9c717c6255b358180f246777587103e92c0e52adba8a0b054c9bdf54fbff44e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/035-latency-35.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2615 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "035-latency-35.stderr.gz" :UNCOMPRESSED-BYTES 2615 :UNCOMPRESSED-SHA256
    "afa065079b3b362fc1f04c84021ee121cda3254bcf99fc358c27d0451f5adeb2"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "a9fe1ba02503183ca8f35810d46b62d0d3ed8145d0e7767ada4d7e6441009202"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/034-latency-34.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 726 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "034-latency-34.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "46a75f09a816937f6afc8f779daddc44632b68bdcba9e7d7a8b9a474a8c7cdcc"
    :COMPRESSED-BYTES 405 :COMPRESSED-SHA256
    "f22abe916c69727360481a33de3ae66ca0b4bedf5e58499e94b0fdc18f2eb0cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/033-latency-33.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2595 :STORED-BYTES 717 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "033-latency-33.stderr.gz" :UNCOMPRESSED-BYTES 2595 :UNCOMPRESSED-SHA256
    "b83542113b00909b740d4660bf4c2081c199abb28203925201b8cd823eae50ae"
    :COMPRESSED-BYTES 396 :COMPRESSED-SHA256
    "96d4a919e2b72168f7c24edf84b50e194a6d693e714a869c675e44c916f29db8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/032-latency-32.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 729 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "032-latency-32.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "c0794d848e09bf51d7379656f7c79109533053632bf3d3bb13f3a0db7764650e"
    :COMPRESSED-BYTES 408 :COMPRESSED-SHA256
    "d99e2d08df1e952de1cb59b0c6a0bd65c8827179471d82f75c069033ab218e7e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/031-latency-31.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "031-latency-31.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "ff21b9d35bfc9e9370ed06832048cff9b923a54b4080ec9a0164a1f3114ff9f1"
    :COMPRESSED-BYTES 409 :COMPRESSED-SHA256
    "a2d19eac55d2e12f8703c6f8a9b76817c1660d3d124e616554069d72ef4fdc23"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/030-latency-30.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 724 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "030-latency-30.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "6b3ed819037e43133106f5da405dfe6b0b3c74189277da28e6190a146a70dbe1"
    :COMPRESSED-BYTES 403 :COMPRESSED-SHA256
    "7c05ab53bc8c8c6b5e66721b60c47ce20da578bf7df61a9720e03ebeee8c2dcd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/029-latency-29.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2587 :STORED-BYTES 719 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "029-latency-29.stderr.gz" :UNCOMPRESSED-BYTES 2587 :UNCOMPRESSED-SHA256
    "4a81868dcd43384eb35a36c15a5bffa026284b167e45e7f15ffc0d0f87a8bb85"
    :COMPRESSED-BYTES 398 :COMPRESSED-SHA256
    "f18897484b622502a524f420aa8fd937cb017209fd650b239a808be278d2cd42"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/028-latency-28.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "028-latency-28.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "8d2285187eb00108ce6e38a80a2abed9ed9a0f6e49e4e9bc097fc330d7bd9cdd"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "e9983bee48b1795185c24e8f796ab168a78da0b3b6c7f23410e76fad4a92af59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/027-latency-27.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "027-latency-27.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "65347490d6a878b10094c8b1b3cdb84f20bceaa9d00d4d1f61493fb7859f65ed"
    :COMPRESSED-BYTES 404 :COMPRESSED-SHA256
    "998afcbecf748e4b577a8cea88fd7e7fc87441c77e49a315f4f1de443c7a59d9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/026-latency-26.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "026-latency-26.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "e8b8574c0c2191392ef551660870d20fffdae4f6c95f96069e11bf4412895e81"
    :COMPRESSED-BYTES 404 :COMPRESSED-SHA256
    "f335e779f8a3073c221001e8a7d52790fbe94bde6ab7997263b2508d07962f6e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/025-latency-25.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2586 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "025-latency-25.stderr.gz" :UNCOMPRESSED-BYTES 2586 :UNCOMPRESSED-SHA256
    "fb68dd14c1ac7550ddda48ad868bb9704791854688927cba29a4becec43052d9"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "b43132db858d352d62fe6e975ae36ca48e6ec6bcdd060a6e0afb3a11aa762edb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/024-latency-24.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 787 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "024-latency-24.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "5489d12c63eba8551f7a6b79d3e40dceb6ae6ca144ebed351f509fec639e1886"
    :COMPRESSED-BYTES 466 :COMPRESSED-SHA256
    "c2cc2d917db84a1f16cd508319817c9d76c9596be44af33a17cce40058a8858d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/023-latency-23.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "023-latency-23.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "84e5cb8513d1d74bbac9b098465f09e208b8e262f7dff146c5419a9e21f9eb23"
    :COMPRESSED-BYTES 427 :COMPRESSED-SHA256
    "6abb78b81f408a7f0cc4e21164b22b0738f0e1d00bedde4e8b513122b41b3821"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/022-latency-22.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "022-latency-22.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "5bf8df50e8edcd13e1cf965d065fcb18f66e773e008b8b47f3eb5009ddc06954"
    :COMPRESSED-BYTES 428 :COMPRESSED-SHA256
    "f8b37056b691ca67529572b6f4ca41cfce0384dc45fcf1b0bc0a7d5d36baf2e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/021-latency-21.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2575 :STORED-BYTES 734 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "021-latency-21.stderr.gz" :UNCOMPRESSED-BYTES 2575 :UNCOMPRESSED-SHA256
    "d2ccf73d11a075c08f1a91bdeb663a9eb053094723a5e050ddc952e3006e484c"
    :COMPRESSED-BYTES 413 :COMPRESSED-SHA256
    "670fbf2e7e75ab624c9a57b78e439f5437bf5113b01103f4827fe642d95a94a8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/020-latency-20.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 791 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "020-latency-20.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "9e946947a9b24bdb8046576469713a9ac5031286093da8c24da99fa7d2cd1074"
    :COMPRESSED-BYTES 470 :COMPRESSED-SHA256
    "cd5ffc415ddaf148ef6083f84a3f045b6a83f68bd61a3fc2db16ac3486dd7bda"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/019-latency-19.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "019-latency-19.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "ac8bed4e2625901ef2c5ec8739c3013e4a5947a492b25c38b6d6739ff48bd04a"
    :COMPRESSED-BYTES 427 :COMPRESSED-SHA256
    "ef37278c07be9dd438ea02c43a92f540fc4a3c0aa21528accf0834ce193a2a8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/018-latency-18.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "018-latency-18.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "6eb2055ff033c1db6c7d618d932fd7a76df94da0e41a4799b9be0a49911330d7"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "0a3da45a5457831dbf3e37fb3c5d1d5b3ad2526d789a45be8820798971dbbbb4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/017-latency-17.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2570 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "017-latency-17.stderr.gz" :UNCOMPRESSED-BYTES 2570 :UNCOMPRESSED-SHA256
    "edd9d67a3b12ffedbb7a0d0545869d8e0dca209b02c57e54e5ed9fd255963c66"
    :COMPRESSED-BYTES 411 :COMPRESSED-SHA256
    "629c92f7a64692b3dca4313ed92e94bd8a681a6b8304a5952e6eb016a8159a3f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/016-latency-16.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "016-latency-16.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "ce2aa08a19b3ae7b734ef7ed0d8d1bc664a79211947250ab536aa9fcbd2d2de9"
    :COMPRESSED-BYTES 468 :COMPRESSED-SHA256
    "ee23bfe11caf461d2efd9dbf145d53d2a3807270dfe10f448092057aaf1e02cc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/015-latency-15.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "015-latency-15.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "e28d3b1365a51b6a529033204fa962fe045289357e25acd33c235b1ae181024e"
    :COMPRESSED-BYTES 426 :COMPRESSED-SHA256
    "f98ebc61e36ba8cd609b0534f14a96946f92a3af20dd85e54552c03fe5859e27"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/014-latency-14.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 739 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "014-latency-14.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "4d29a5f2ee661d4ed3f25b4f3275c4eddd98c03ba8bc51ea15413bea54e9d008"
    :COMPRESSED-BYTES 418 :COMPRESSED-SHA256
    "d635f38e8e25c64e832ac9fbd8f1791b5995051dbcd82abbcdc273b3dd91cfb9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/013-latency-13.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2565 :STORED-BYTES 734 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "013-latency-13.stderr.gz" :UNCOMPRESSED-BYTES 2565 :UNCOMPRESSED-SHA256
    "16d7cd76d9a853b90dc7719111c8000390a40105098045cca04ab1a0641f45a4"
    :COMPRESSED-BYTES 413 :COMPRESSED-SHA256
    "1128d1d2579b2ee47bda1cf2dc874cfd1a99d3de965003076610891d1dd02d55"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2630 :STORED-BYTES 734 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 2630 :UNCOMPRESSED-SHA256
    "42018752ee61ee448485d2d6dd185b57e1349d91d4bc4456f218b92191b9edcb"
    :COMPRESSED-BYTES 413 :COMPRESSED-SHA256
    "8d9a198690eca0dc1c3e59a01125f0a97d1b7cf7ece48786719712c112234912"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2615 :STORED-BYTES 731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 2615 :UNCOMPRESSED-SHA256
    "e16543392c43599361336e2e11c0b0d59e4daaf0f7ca99d71f39d9d54aefffab"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "f8cc9827a36045d5755668f2af4fb256758aef16ff2aa0e2ba4af8e4ab5675a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "5ac6249137dc58ffb60cd09b2a5a0b19a0126056ccfeb9b266f60b5a351aaafa"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "de66085fe5d634f9f062ce4494e8a4ebf824f37830c6e765af237ef65c49085a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2595 :STORED-BYTES 719 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 2595 :UNCOMPRESSED-SHA256
    "0efd01354615f3223be00c32df092255bef947338c2967c0025905cea1173c0e"
    :COMPRESSED-BYTES 399 :COMPRESSED-SHA256
    "043d4a86d1c425d6bdc2c72350615c93b775dfc982575f87bf2a5c98a0389a85"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "2119b397dcd9a2c4735a061eaed29a01e514884805903602b6161a47050b5085"
    :COMPRESSED-BYTES 408 :COMPRESSED-SHA256
    "5bab2693b1715cbe67c59bb6ae805eefa0f2bc1b6ddb7f00799768d4e9e57ed2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "feb9a8da625902677e36a044fbc4be374bd865bc83d340f5c42aff2a603b94aa"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "9003069e4704d42d2813bed0eda4706f3bdbc660eb8f30250607228fe39b985f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 727 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "6233d56f0608dd80a42ce634afae589182c770542d4d92354149c5418b57c4b9"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "40b650ec53c5872f216271f7afa8f76a4ac6d8034f78f4259e762d2e427019b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2586 :STORED-BYTES 715 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2586 :UNCOMPRESSED-SHA256
    "4614279bdb7cc8758b5c4e385f8cf8d2923f54af975aa41a7996ba4f96019aaa"
    :COMPRESSED-BYTES 395 :COMPRESSED-SHA256
    "3352a21afb81acb22cbe708d5bd62184875b0603e8976e6d397f5541aa8cb463"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 736 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "85635a1fe3fb335fdfb958f6dacd83cc2d8c917d4c88967d20562d656dea82c8"
    :COMPRESSED-BYTES 416 :COMPRESSED-SHA256
    "6f73acdd76c9a76b756e2e1fc57e58898cd61e3cd534feb7180d5289a8406178"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "7524ee4a0e4d64013bda14ccb7d9ef49dffe8a6bb2c062ba34b23cc608f1f3ea"
    :COMPRESSED-BYTES 405 :COMPRESSED-SHA256
    "e2ec909122074b57a3d51d1b85406b9a2a685668d171f8362f5c37c005ac667b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 726 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "9279e572309fbca17dc473bcce0f32584bacbe5a75b82ed19bf0a02f58516f95"
    :COMPRESSED-BYTES 406 :COMPRESSED-SHA256
    "13913a3d7947fb7e6acfc229d348d35af5355747c5c3e073d418a2506c92bfec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2585 :STORED-BYTES 718 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2585 :UNCOMPRESSED-SHA256
    "cef783f7973dbf4b77aaa422b32d0544039b1d95decdd7acaacf14ec2bc90564"
    :COMPRESSED-BYTES 398 :COMPRESSED-SHA256
    "c6318a707b14216b6e04d89b0ebbe4429e01bf2bca4f84e1b8966876c5dfa065"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17901 :STORED-BYTES 2790 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 17901 :UNCOMPRESSED-SHA256
    "e41cde4017ffda65d6b8f4bb2a2a6b5191d48c97eae438f10cc02b617dd60e90"
    :COMPRESSED-BYTES 2480 :COMPRESSED-SHA256
    "204a1dd5216754d858766190582eccd35c0905d0520e3684378a3daca3e9829c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17869 :STORED-BYTES 2748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 17869 :UNCOMPRESSED-SHA256
    "9ae23eec1bf2a3ee81d619fa95f21bad3334001bc24dea539772d2d94888f1e6"
    :COMPRESSED-BYTES 2438 :COMPRESSED-SHA256
    "e2c8f1848cbe970eb93ad4f891af2004e01d2a6f10dd62047eee90fe795422e9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17974 :STORED-BYTES 2892 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 17974 :UNCOMPRESSED-SHA256
    "2d8b39cc78bc5b940cf461c05ad110d8420e219634b90e89948408e1d4c5fb2e"
    :COMPRESSED-BYTES 2582 :COMPRESSED-SHA256
    "8122a926ba9e3d15b9510022399d6694fed2d56f5e1ffc424a1df76eed27edd6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17833 :STORED-BYTES 2826 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 17833 :UNCOMPRESSED-SHA256
    "16c0abbb65e74c28b7838384256b184c1b816bb27282d17fa8cf7f16eda00a80"
    :COMPRESSED-BYTES 2516 :COMPRESSED-SHA256
    "cf348619316f58409d05507438dd2bacd4470b3a41c4451365c37f143a07b714"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18279 :STORED-BYTES 3121 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 18279 :UNCOMPRESSED-SHA256
    "6723feaa74779ca757f492b6f7ba6b93a166c8f6905f594c8b0878196f139865"
    :COMPRESSED-BYTES 2811 :COMPRESSED-SHA256
    "74c5c84ff08dbc6e053ec6d8e5616a3de2034e629f49efeda12db6fe61ac1780"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1615 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "47eebc69c2db2be5f38beafed81dd44fcb3f80829945f5befdc8c0296583d43e"
    :COMPRESSED-BYTES 1306 :COMPRESSED-SHA256
    "d876134a4a09c0d3b6d14750e17f7725378f8dcd56f557311df360bb040afe0c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1650 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "cf41b4637e0a602ee1256b021e9957610f6e2df0ec360d4e25c6aef6b0711878"
    :COMPRESSED-BYTES 1341 :COMPRESSED-SHA256
    "540cea551d1daac165916423288b07891a81b57981a5742e86e9663db4cf3cf2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8838 :STORED-BYTES 1764 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 8838 :UNCOMPRESSED-SHA256
    "062c9b6e33e5f353df6693c39ce6b1e73bbd47de872ac675e2cc3df608d0ca91"
    :COMPRESSED-BYTES 1455 :COMPRESSED-SHA256
    "d14bb1fbb69c90dddde6649d3a446b0cbc40a16256853ee795b2c51e2ad2c2b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8851 :STORED-BYTES 1829 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 8851 :UNCOMPRESSED-SHA256
    "2e5eb3caac31f2c484658d8dddf829dd6ac6d1a9d8ef997de1faf781307f3712"
    :COMPRESSED-BYTES 1520 :COMPRESSED-SHA256
    "42e0ca42220835808a0ec17a806091a899cad4199bbdbd0f9be5306ac510214f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8828 :STORED-BYTES 1781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 8828 :UNCOMPRESSED-SHA256
    "4f26c7eb35a255969cb17aa62a5dcaf546f5a2d645d90372ac10116bb0636fb2"
    :COMPRESSED-BYTES 1472 :COMPRESSED-SHA256
    "bf6bbed1205737b0fdd157591907e02a7f3ef12399286c6b8678439641ccb50e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/66-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30397 :STORED-BYTES 11293 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-4.lisp.gz" :UNCOMPRESSED-BYTES 30397 :UNCOMPRESSED-SHA256
    "19edd8cc34487c4f1f43a05e6681cfedad52117d127942bd1785f8885dc4afbd"
    :COMPRESSED-BYTES 10981 :COMPRESSED-SHA256
    "c135590a82ecd76abc20bc7df52724c92a0058c32cc4b5c8f70bc100ef5354a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/66-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30271 :STORED-BYTES 11437 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-3.lisp.gz" :UNCOMPRESSED-BYTES 30271 :UNCOMPRESSED-SHA256
    "65507648d57a635fb26087b23ca2899e277a495980d6781cd05ab477140270ca"
    :COMPRESSED-BYTES 11125 :COMPRESSED-SHA256
    "ce69c3d8e0ebd1caee89e8b4fe70f21a42742d4042e00b8c10101185249630b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/66-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30207 :STORED-BYTES 11535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-2.lisp.gz" :UNCOMPRESSED-BYTES 30207 :UNCOMPRESSED-SHA256
    "956bfe3f1140bab29c5525bf2d288b3f87dc2422c73d0a404ff851778a3a94f6"
    :COMPRESSED-BYTES 11223 :COMPRESSED-SHA256
    "26a9cd6add7bd433c7ffed8458cb849b2ded956efe0e2f1eacd3aa9a88662cbf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/66-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30427 :STORED-BYTES 11457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-1.lisp.gz" :UNCOMPRESSED-BYTES 30427 :UNCOMPRESSED-SHA256
    "9df74613d5a032bc49338e9f292632b6f95f00b6a3b6bfafbdfb82ff5f3a2097"
    :COMPRESSED-BYTES 11145 :COMPRESSED-SHA256
    "71a688451efbd9e28ba59015dce6d38b60a35cc693eaf6eeb2a2acbfba89dcb8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/66-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29538 :STORED-BYTES 11325 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-0.lisp.gz" :UNCOMPRESSED-BYTES 29538 :UNCOMPRESSED-SHA256
    "a8386b96c862c06be034ee963d3212b79743f69fe9bb344fd561a26265106b19"
    :COMPRESSED-BYTES 11013 :COMPRESSED-SHA256
    "41ed9d090394b24fea09dbd8b75a669158cb1c1d075b1f4d8d0a91810f929553"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/65-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30315 :STORED-BYTES 11094 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-4.lisp.gz" :UNCOMPRESSED-BYTES 30315 :UNCOMPRESSED-SHA256
    "2cf55c532e7941822097844eb45cbb0ead4dc5e382288a738322b69225e36749"
    :COMPRESSED-BYTES 10782 :COMPRESSED-SHA256
    "6f44a551440ffe4fb64952737c0ebed006efbe70c300bc99ac52e64e9112f426"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/65-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30592 :STORED-BYTES 10822 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-3.lisp.gz" :UNCOMPRESSED-BYTES 30592 :UNCOMPRESSED-SHA256
    "4ad4a83f02014b82d65d77a6cfffa845b89db8171244c0b68ca2795fbb9b9ef4"
    :COMPRESSED-BYTES 10510 :COMPRESSED-SHA256
    "b260a853fe09980e5030e30e5e2ae8dc4b573e8a38f2cee51ead106ae9ff3da9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/65-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30475 :STORED-BYTES 11116 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-2.lisp.gz" :UNCOMPRESSED-BYTES 30475 :UNCOMPRESSED-SHA256
    "f9142c6068953acab834651e03166692db1450be878a7a98eb0608da33119057"
    :COMPRESSED-BYTES 10804 :COMPRESSED-SHA256
    "c3c91b1a0131ca4b3097fef7b4882b7151e8246ef54f58570c58962cb7649731"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/65-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30461 :STORED-BYTES 11005 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-1.lisp.gz" :UNCOMPRESSED-BYTES 30461 :UNCOMPRESSED-SHA256
    "d8349212a6e87f8b1d9f4478fa5b0e7e2e577ae45065292f389bada34b4f8000"
    :COMPRESSED-BYTES 10693 :COMPRESSED-SHA256
    "b0eb5a117bca24ea2dd90deb0bd9b0ada0b137ba5e6db6918296b16bf64d2eb7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/65-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29480 :STORED-BYTES 10927 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-0.lisp.gz" :UNCOMPRESSED-BYTES 29480 :UNCOMPRESSED-SHA256
    "5678c47ab2fc8edd4e107647f302a498ae9bb6125a1bebe08f3f11e526633daf"
    :COMPRESSED-BYTES 10615 :COMPRESSED-SHA256
    "287936532b28f6368d3513a3675dcbec2d6c2746121796795771655090f1172f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/64-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28262 :STORED-BYTES 10293 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-4.lisp.gz" :UNCOMPRESSED-BYTES 28262 :UNCOMPRESSED-SHA256
    "4f6610681d38f7908e141f7317cf026f4d4b67b9bf0d286904a0af23a1cbdfb5"
    :COMPRESSED-BYTES 9982 :COMPRESSED-SHA256
    "e6d5647c8d21b24662351f3722197d130fd28dc1dab0676c2ddc7ae262c53278"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/64-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28216 :STORED-BYTES 10409 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-3.lisp.gz" :UNCOMPRESSED-BYTES 28216 :UNCOMPRESSED-SHA256
    "1606582a45257b7ae02f4872f179d241f01211e33870c4b4fe4dfc863cc489d2"
    :COMPRESSED-BYTES 10097 :COMPRESSED-SHA256
    "94281de8b1919549e129eafcbca7489b0f583a289fabe50e8e5a52de53d143f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/64-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28237 :STORED-BYTES 10099 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-2.lisp.gz" :UNCOMPRESSED-BYTES 28237 :UNCOMPRESSED-SHA256
    "cdb0327e8cc3c6be107901a7ce5ab74ce6b15ac871389e11fae5599628105f09"
    :COMPRESSED-BYTES 9788 :COMPRESSED-SHA256
    "8fbdd9bd22feafdc1eaf24f8f3793b291086f4a66a770182d175f3207c80ac14"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/64-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28454 :STORED-BYTES 10767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-1.lisp.gz" :UNCOMPRESSED-BYTES 28454 :UNCOMPRESSED-SHA256
    "960001c3a5c24851d5b1ba89a71b23e11f3134e180e1972d4dd8d0a88b9839f4"
    :COMPRESSED-BYTES 10455 :COMPRESSED-SHA256
    "dd18e38c51f75e0936d463396c0c0002b976510ce02077806e0b5853225fb991"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/64-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27872 :STORED-BYTES 10786 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-0.lisp.gz" :UNCOMPRESSED-BYTES 27872 :UNCOMPRESSED-SHA256
    "f7544dd6e37acc1d902be8c78488172e90b9906c9667a0ea03b35210350984b0"
    :COMPRESSED-BYTES 10474 :COMPRESSED-SHA256
    "0628f460763bd5c2347acafd74809917bd3fca49f87a8cfd1cd0f4d578be2729"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/63-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21490 :STORED-BYTES 5659 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-4.lisp.gz" :UNCOMPRESSED-BYTES 21490 :UNCOMPRESSED-SHA256
    "a3f5378541e5469c39c51f755c73fedac78f585878ae9cfa44d0ef07e42df23c"
    :COMPRESSED-BYTES 5348 :COMPRESSED-SHA256
    "a0f6e653a20115a7969bd33e1340a723c4fe1c4840ba40ee5c4942e17f7a5fb5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/63-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21546 :STORED-BYTES 5734 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-3.lisp.gz" :UNCOMPRESSED-BYTES 21546 :UNCOMPRESSED-SHA256
    "5dd4230cb2fee87bc707d8d406efb449ac3bc821059e460ecde3a33917ea885e"
    :COMPRESSED-BYTES 5423 :COMPRESSED-SHA256
    "c7cc2731f5326203965ed380fcb989b948455d38ed3cc3bcfe975a92e395c346"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/63-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21568 :STORED-BYTES 5518 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-2.lisp.gz" :UNCOMPRESSED-BYTES 21568 :UNCOMPRESSED-SHA256
    "d865fdc1da634abc7fd97c5ecfcf66ef6a06debca1bb43eecfd809f02b5fc10e"
    :COMPRESSED-BYTES 5207 :COMPRESSED-SHA256
    "a68585e01207b011114d7654a16b80934b103339d4ee333b9b41715b48521fcc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/63-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21549 :STORED-BYTES 5627 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-1.lisp.gz" :UNCOMPRESSED-BYTES 21549 :UNCOMPRESSED-SHA256
    "71507863136220e6bcfa2f1b64d330dffa095776ecb4d676a18a577a22ae1750"
    :COMPRESSED-BYTES 5316 :COMPRESSED-SHA256
    "d383f458f976697be483d6689f74d768ad541a63a88e98f60c6d678b5b38bf7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/63-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21453 :STORED-BYTES 5801 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-0.lisp.gz" :UNCOMPRESSED-BYTES 21453 :UNCOMPRESSED-SHA256
    "fa95b4d058650827196a53ee0a25e38f5704a2d072b737df10f3351093d0299e"
    :COMPRESSED-BYTES 5490 :COMPRESSED-SHA256
    "b0d608487d2d8fc404f43d40864814d35dc7360164e65c3aea302e1025219fd9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/62-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14457 :STORED-BYTES 5777 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-4.lisp.gz" :UNCOMPRESSED-BYTES 14457 :UNCOMPRESSED-SHA256
    "b84e94f5ab60e6b06d613963c5659f33fb7102d227b9b49ca29f86880c8ab7cb"
    :COMPRESSED-BYTES 5466 :COMPRESSED-SHA256
    "8d1c8e3b69b052648ba1c9163e8ffc8e514724a36cb48b1e5ed9f2ddd58554d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/62-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14459 :STORED-BYTES 5774 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-3.lisp.gz" :UNCOMPRESSED-BYTES 14459 :UNCOMPRESSED-SHA256
    "3f2155030d88513a848becac2be2bcc145c4f18e30a5c384374375eed22a0814"
    :COMPRESSED-BYTES 5463 :COMPRESSED-SHA256
    "725a63f7ccc4da30cab06a3dee38f976335626093173e6dbcc327bdc4d1c7214"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/62-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14458 :STORED-BYTES 5670 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-2.lisp.gz" :UNCOMPRESSED-BYTES 14458 :UNCOMPRESSED-SHA256
    "22a4757da87ce9f5056c3f975948f156673dc6a625c14456b728f687effde965"
    :COMPRESSED-BYTES 5359 :COMPRESSED-SHA256
    "bcfd5da565d05ea006468d58907c5e0d10bdf37d489bf20336cc3254ee034087"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/62-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14289 :STORED-BYTES 5735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-1.lisp.gz" :UNCOMPRESSED-BYTES 14289 :UNCOMPRESSED-SHA256
    "80f18bc15ec21e372c150635ef4545e318a588af4c9026c7e8dc86ee5869d566"
    :COMPRESSED-BYTES 5424 :COMPRESSED-SHA256
    "3222bef8f6d76d02f088b07c4bda8efc2db5145ee10da700942bf41e122ea36e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/62-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13595 :STORED-BYTES 5533 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-0.lisp.gz" :UNCOMPRESSED-BYTES 13595 :UNCOMPRESSED-SHA256
    "6ef4824af5115069f3a82dbb225c43b28eaa16ee498c00ae4535571b9ad89a11"
    :COMPRESSED-BYTES 5222 :COMPRESSED-SHA256
    "034131a834884cbdd0109f8da7dc64c4223125e4e1fe5db0dd228620548c3e97"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/61-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10833 :STORED-BYTES 3058 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-4.lisp.gz" :UNCOMPRESSED-BYTES 10833 :UNCOMPRESSED-SHA256
    "e310e1c66a29311437b9a88fdb34282c0efd684982f961d6a5470502708fab10"
    :COMPRESSED-BYTES 2747 :COMPRESSED-SHA256
    "e4d35cca4519231434d25a045159374d462bb3051836c6b90607b98567222bd7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/61-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10818 :STORED-BYTES 3100 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-3.lisp.gz" :UNCOMPRESSED-BYTES 10818 :UNCOMPRESSED-SHA256
    "055c5089ed517ae362391695579b4fe9a533929442d4a7c55c48b2caa23d8929"
    :COMPRESSED-BYTES 2789 :COMPRESSED-SHA256
    "02eb50ad12e63a304b8ddb76560f5db865b3760435068a198b26678c7638a808"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/61-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10813 :STORED-BYTES 3110 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-2.lisp.gz" :UNCOMPRESSED-BYTES 10813 :UNCOMPRESSED-SHA256
    "2685ea45055bf03f2e67944eb8d229d6bf2c5f212c08610b0fd6eb6e0e36b3db"
    :COMPRESSED-BYTES 2799 :COMPRESSED-SHA256
    "0cbe8f16dd8829ec987292b304f7966bfb27ca62a96dd7c64ddf846b716f0e95"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/61-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10876 :STORED-BYTES 3349 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-1.lisp.gz" :UNCOMPRESSED-BYTES 10876 :UNCOMPRESSED-SHA256
    "e333f59bd8e2453d45b031cabc0a28df9fd4ec8b8e09be025cd00566553c89ca"
    :COMPRESSED-BYTES 3038 :COMPRESSED-SHA256
    "f89c4b04ad88f46ab9b95de0b712de5b48a46f1c57419f7334cfdd5c0984c418"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/61-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10606 :STORED-BYTES 3247 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-0.lisp.gz" :UNCOMPRESSED-BYTES 10606 :UNCOMPRESSED-SHA256
    "a9cdf8140bc996dcbad99ae3d1ea8cbe93444b4180be49e1c886b36e9b3dd09d"
    :COMPRESSED-BYTES 2936 :COMPRESSED-SHA256
    "e778d8bac87e7139043f13ce4edb97e716717218ac1979e4bf7cebd878878dcc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/60-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7523 :STORED-BYTES 3266 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-4.lisp.gz" :UNCOMPRESSED-BYTES 7523 :UNCOMPRESSED-SHA256
    "93870a04a69aa8663fc2422d4bd5cddaed2b154601243ee0acaa5229a747ae00"
    :COMPRESSED-BYTES 2956 :COMPRESSED-SHA256
    "0636303ed96b7935a60b5a4e4c921f927a94989b9c4b7b020795374e121996bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/60-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7516 :STORED-BYTES 3193 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-3.lisp.gz" :UNCOMPRESSED-BYTES 7516 :UNCOMPRESSED-SHA256
    "9ecc220171e77f77e1a684370357bcf84874038c30a4c0a7be2041e4e7e81f68"
    :COMPRESSED-BYTES 2883 :COMPRESSED-SHA256
    "459800288affff32eb4b63ed2ab4508cd995b38bc2598a8bb09e92e115956ed2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/60-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7339 :STORED-BYTES 3096 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-2.lisp.gz" :UNCOMPRESSED-BYTES 7339 :UNCOMPRESSED-SHA256
    "0c9e19def2d52a5f15937ab75e5d1604dc6ee5a9064ec4c62e94a22d1eac71dd"
    :COMPRESSED-BYTES 2786 :COMPRESSED-SHA256
    "bfc26a8d568575179a5000d6458f07b928f431edd5b48c541f6000b5e38296ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/60-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7112 :STORED-BYTES 3229 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-1.lisp.gz" :UNCOMPRESSED-BYTES 7112 :UNCOMPRESSED-SHA256
    "4941185db815358fab9bed08f544c1b9319630b8e3155212a0a585d480e72abd"
    :COMPRESSED-BYTES 2919 :COMPRESSED-SHA256
    "cb13dcb6e0fd9f3f048ea39b2df5fdb623a3137910408d1f13f41545ecbdfd43"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/60-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7026 :STORED-BYTES 3102 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-0.lisp.gz" :UNCOMPRESSED-BYTES 7026 :UNCOMPRESSED-SHA256
    "c15dbf8cecc48227bfec62d3e05c8114d4efc54925aa3cdede0abdb5138dadc5"
    :COMPRESSED-BYTES 2792 :COMPRESSED-SHA256
    "5f5a6f4966f070bead7a30d55078db63349c86231bda81a0ee68a4bd1872d8fb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1218 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "9e2d02e08d79571a9c4404d3aac25317c5fe9b03dd8da2344423ab87bd15693a"
    :COMPRESSED-BYTES 910 :COMPRESSED-SHA256
    "6c4049860d70621dfdb8fcb79be5e0307492f3b9389ae62510ee9a080f821f2a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1175 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "6b4ea159840ecc701842f5939cf1ec58097d06eccc39488ea190ac2e098e66e6"
    :COMPRESSED-BYTES 867 :COMPRESSED-SHA256
    "60fcd5b9dd159c5c8d53a1fa8fc44a10502902124d59d7f03144a736c284f630"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1233 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "85bfda80892bc0f34ed2900d2abf2af3a2619ea3d9be1571f27a6f7b88e3de19"
    :COMPRESSED-BYTES 925 :COMPRESSED-SHA256
    "c77808fa9836f354b6ca7bc0ea8a8d4fc8d5d7990d2ded935191df04066d9417"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1198 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "346b45c537a86439dfcd74a567c47a0edf4c5e721b8b9f6d3cfc0aa5f4ec044f"
    :COMPRESSED-BYTES 890 :COMPRESSED-SHA256
    "a48a57222f52fc9ee86bef2b1af4514a8b1a5affc0fc4e2be95c0fe87a1e1c12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4831 :STORED-BYTES 1282 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 4831 :UNCOMPRESSED-SHA256
    "beae006ccc71b0958490189e67b4e372dee58d7518f460aa3abfb67345774167"
    :COMPRESSED-BYTES 974 :COMPRESSED-SHA256
    "e2de7d40efc10fc4dea8513b71bac0e4a836721dcb2d645809959c8b2fca41a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/59-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5163 :STORED-BYTES 1699 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-4.lisp.gz" :UNCOMPRESSED-BYTES 5163 :UNCOMPRESSED-SHA256
    "a8ee6ca45945cf22af36f0231bc1c8c98bc997c48ee98f5e5cbe55af7d917ed4"
    :COMPRESSED-BYTES 1389 :COMPRESSED-SHA256
    "6b133d3929a0df39ccb212cc099b11ef672bf1449a7c3704936c84f6fd556b5e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/59-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5345 :STORED-BYTES 1785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-3.lisp.gz" :UNCOMPRESSED-BYTES 5345 :UNCOMPRESSED-SHA256
    "346454092d2b6f6d07fe24179e308e7f88e69abcf8e019e13ef6f7a4bb24660f"
    :COMPRESSED-BYTES 1475 :COMPRESSED-SHA256
    "e2c4bd02806a81a1c752d01313b1e6e3fbd82e7d3570f1c3d05747d8501333b9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/59-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5698 :STORED-BYTES 1784 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-2.lisp.gz" :UNCOMPRESSED-BYTES 5698 :UNCOMPRESSED-SHA256
    "a607ea48c456b2db986c41477d59b3b6d7901cbfb4abca387888da1a4d36fa6a"
    :COMPRESSED-BYTES 1474 :COMPRESSED-SHA256
    "17685fecb632b9e3782f2fcd27abfbdb8326f6bd158208c1bdb3bfd5a2cc86be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/59-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5556 :STORED-BYTES 1801 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-1.lisp.gz" :UNCOMPRESSED-BYTES 5556 :UNCOMPRESSED-SHA256
    "edb47aa60e4cf294e33271d45e62e70fa82fa150daf4f7f8c0cfa7b9d63b4916"
    :COMPRESSED-BYTES 1491 :COMPRESSED-SHA256
    "b3953475d417686ede5dd89e1bfd1aa0f610a715c76f1081dd0d0106c280ee8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/59-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5062 :STORED-BYTES 1676 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-0.lisp.gz" :UNCOMPRESSED-BYTES 5062 :UNCOMPRESSED-SHA256
    "ad2394ba4d7ebd63e584a5aca729f9374ff388915c739d4b719aa68d7f0648f9"
    :COMPRESSED-BYTES 1366 :COMPRESSED-SHA256
    "41e3c1bf88eb81d14c99fd3db9f1944af2284a0437ef958fe6acb1ef74a97389"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/56-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30125 :STORED-BYTES 10469 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-4.lisp.gz" :UNCOMPRESSED-BYTES 30125 :UNCOMPRESSED-SHA256
    "1190f99a16d57a99a31b5159ecd92e161ab057d089adf8767a66ff31b95a9f92"
    :COMPRESSED-BYTES 10157 :COMPRESSED-SHA256
    "e9cd74d4c6337603d51151deefb2f9b66a47a51e705fe022848a58dffa2575fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/56-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29087 :STORED-BYTES 10452 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-3.lisp.gz" :UNCOMPRESSED-BYTES 29087 :UNCOMPRESSED-SHA256
    "022e2f3af90c8e64483067105eb36cb297d92b2bbd2aa46917fb87a5007fd5cd"
    :COMPRESSED-BYTES 10140 :COMPRESSED-SHA256
    "964ef8cba301f9635348d12001be8c32bb4487bf55b9565fccdf1b8fdc7778bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/56-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29514 :STORED-BYTES 10589 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-2.lisp.gz" :UNCOMPRESSED-BYTES 29514 :UNCOMPRESSED-SHA256
    "585acbcf23d4025523fc5e873d832d147653e57fba3ff1577551b57f4eadf775"
    :COMPRESSED-BYTES 10277 :COMPRESSED-SHA256
    "666c4bfae64e730205be065da109e705abe4667ef4ca021201b938514fc7d7e4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/56-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28875 :STORED-BYTES 10475 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-1.lisp.gz" :UNCOMPRESSED-BYTES 28875 :UNCOMPRESSED-SHA256
    "bd6c86fe0f9b67eb2988d94272d3cccf3e45b2ef082ee9259f42b51dd9aef74e"
    :COMPRESSED-BYTES 10163 :COMPRESSED-SHA256
    "a52b11806521bcd0890c502757acbb72f82c5fa356250d32be0563b5c9fe7027"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/56-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28245 :STORED-BYTES 10891 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-0.lisp.gz" :UNCOMPRESSED-BYTES 28245 :UNCOMPRESSED-SHA256
    "7ea7053e3f98c2b31e4a5f8e90a0e1ffa26b7012d4ba185b094814c2de751b4a"
    :COMPRESSED-BYTES 10579 :COMPRESSED-SHA256
    "065ab777725be34220f0cd4f924cfcad76bf1f5d15e37eded9cccc0e65d2b38b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/55-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21634 :STORED-BYTES 5466 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-4.lisp.gz" :UNCOMPRESSED-BYTES 21634 :UNCOMPRESSED-SHA256
    "3648ffd5f98a49e844ae8f426498016e1dfaa7a1dd044360353bca93ed1ebca1"
    :COMPRESSED-BYTES 5155 :COMPRESSED-SHA256
    "d604d9d07005e97c72afe349934614b7f9fa160dd10682c54531c9fb9d18bfc3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/55-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21546 :STORED-BYTES 5674 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-3.lisp.gz" :UNCOMPRESSED-BYTES 21546 :UNCOMPRESSED-SHA256
    "1b8a208535294dff7cdfbb73db88f1a23b16fb069c549a925fb18ae1573256e7"
    :COMPRESSED-BYTES 5363 :COMPRESSED-SHA256
    "9e07a5a2587a28a544bdf84aabb8d4cb3dde3a997805bbfb3f01d72e19da0ee5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/55-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21324 :STORED-BYTES 5752 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-2.lisp.gz" :UNCOMPRESSED-BYTES 21324 :UNCOMPRESSED-SHA256
    "4bfb7368a2c788ca2d8e25ef2b5fdfc0413ce8753e7f7fb8bed5e6eb091f92ce"
    :COMPRESSED-BYTES 5441 :COMPRESSED-SHA256
    "ceec04de3284de6bb876044ec9088f7341addfbe8760b7296a44f2bdcde19e1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/55-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21531 :STORED-BYTES 5597 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-1.lisp.gz" :UNCOMPRESSED-BYTES 21531 :UNCOMPRESSED-SHA256
    "019072ddd98327d7d3d058ddeea26a10577f9aa383a2987df2810fe64e6ce674"
    :COMPRESSED-BYTES 5286 :COMPRESSED-SHA256
    "b896ea886dba5e8f0d265ffb9b64c8a9833980eb98db0b1cd0d57cbcd565d229"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/55-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21425 :STORED-BYTES 5479 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-0.lisp.gz" :UNCOMPRESSED-BYTES 21425 :UNCOMPRESSED-SHA256
    "75d17b1ef29dc391ce351a831ba2002dc1da88844e9555d8bd6df4a5b45d8b5b"
    :COMPRESSED-BYTES 5168 :COMPRESSED-SHA256
    "f946974bef9e7ef81a12918082406906ed8a330e9b401e43656ce364f4c36e37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/54-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14464 :STORED-BYTES 5502 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-4.lisp.gz" :UNCOMPRESSED-BYTES 14464 :UNCOMPRESSED-SHA256
    "2f4b9708873a875ad6a0eb2e21eb5739df51a27ee69983474e77df5bc860937b"
    :COMPRESSED-BYTES 5191 :COMPRESSED-SHA256
    "56bbb96627ff8ea9b191c27c63f903a45819d6cdf7e6d95c0eab1d8f3fc75084"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/54-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14468 :STORED-BYTES 5447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-3.lisp.gz" :UNCOMPRESSED-BYTES 14468 :UNCOMPRESSED-SHA256
    "c768f0550ec77eb9be88cc21dc4d189c6afe40ee988f3b6c1137c56ba14a3209"
    :COMPRESSED-BYTES 5136 :COMPRESSED-SHA256
    "3401340dd93b0071ab063f5cbf7a328d6c596baf9c46db9206c964559876c8f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/54-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14469 :STORED-BYTES 5146 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-2.lisp.gz" :UNCOMPRESSED-BYTES 14469 :UNCOMPRESSED-SHA256
    "fda836f28d0b3ba0ebc7720b50c502b1c039d93e3216c5474fd293a6d1c5d794"
    :COMPRESSED-BYTES 4835 :COMPRESSED-SHA256
    "385a80a12f58d2f42653e26ce4ca23e41a6ecedbf097c7078cc8d026b8cd5009"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/54-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14300 :STORED-BYTES 5705 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-1.lisp.gz" :UNCOMPRESSED-BYTES 14300 :UNCOMPRESSED-SHA256
    "5856254bd68db926096cf6f6dc941b8189b9b10786d3bc5811dd189a65278f5b"
    :COMPRESSED-BYTES 5394 :COMPRESSED-SHA256
    "426f340b03bbdd385fed7eeffbf8b22b19eda4ff7ade0f0e8e023c4e7b450bab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/54-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13608 :STORED-BYTES 5426 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-0.lisp.gz" :UNCOMPRESSED-BYTES 13608 :UNCOMPRESSED-SHA256
    "e0fc8d8ff71f87de5447be6e8d1cfc7dfc3af89637fd1c1812658117bf88c91c"
    :COMPRESSED-BYTES 5115 :COMPRESSED-SHA256
    "0587a3b7828ae99de9368c8e8d10e0850dd83f4070bcecb0f0bae918f6c5e8eb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/53-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9638 :STORED-BYTES 2461 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-4.lisp.gz" :UNCOMPRESSED-BYTES 9638 :UNCOMPRESSED-SHA256
    "8fd791dc0764fe8ddbfe84bda258313ec5ca8f7c1bf398ccd7172655caff203f"
    :COMPRESSED-BYTES 2151 :COMPRESSED-SHA256
    "697694c9769a157c0bee24271836ae47392bf499e32e6b351f0eb43f610b7b04"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/53-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9644 :STORED-BYTES 2418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-3.lisp.gz" :UNCOMPRESSED-BYTES 9644 :UNCOMPRESSED-SHA256
    "4e6d73d696c9ab61e82e738de27df65f35f84be3cde86245bd28de4c928f31d6"
    :COMPRESSED-BYTES 2108 :COMPRESSED-SHA256
    "aef0d194689f5a2427c7847d330e155b415a95059fb935cc0b087151857bd87d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/53-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9654 :STORED-BYTES 2541 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-2.lisp.gz" :UNCOMPRESSED-BYTES 9654 :UNCOMPRESSED-SHA256
    "fb5fb256716352ee1f34f28b5b4e1a9addab5948823d5d1fefc7af614e069ce0"
    :COMPRESSED-BYTES 2231 :COMPRESSED-SHA256
    "cca20ec881cc74ddfa7c23d4fe9d22839d78b15012e1f3af09c8fbda4ff8636f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/53-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9644 :STORED-BYTES 2439 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-1.lisp.gz" :UNCOMPRESSED-BYTES 9644 :UNCOMPRESSED-SHA256
    "db0c291f08580b9d85482b4b86baee2ac129646c72657d3aea396c42a3bb16cf"
    :COMPRESSED-BYTES 2129 :COMPRESSED-SHA256
    "25be9689cfc9b716ca5e0b5263a943d80b62c93b91d7631fa36b3999e3e25396"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/53-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9587 :STORED-BYTES 2509 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-0.lisp.gz" :UNCOMPRESSED-BYTES 9587 :UNCOMPRESSED-SHA256
    "4826b01741ab3515dc0a514d7d8320e44f153c5cf811e07367453bbfeb97e040"
    :COMPRESSED-BYTES 2199 :COMPRESSED-SHA256
    "bea625bd48412e66289fad4e1b6fc564144c9beded5e37e52ee43b21b98affce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/52-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7406 :STORED-BYTES 3068 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-4.lisp.gz" :UNCOMPRESSED-BYTES 7406 :UNCOMPRESSED-SHA256
    "1ea98311ed6f34b7d52266d69dc39b076494f88a7e834ddf1145b267c8b1e241"
    :COMPRESSED-BYTES 2758 :COMPRESSED-SHA256
    "120061389ffd075c34a291cc56700de675cfa7741a1704400cedc17cdec13a97"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/52-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7414 :STORED-BYTES 2900 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-3.lisp.gz" :UNCOMPRESSED-BYTES 7414 :UNCOMPRESSED-SHA256
    "5e36a2f4b71f9d30e4140818d3a968cbe2bdf59c5a5b7cca4b904602e0915aed"
    :COMPRESSED-BYTES 2590 :COMPRESSED-SHA256
    "baa697ff3b11eb971d1c6fd6034c4c5d08b717d6c5349a3d7dcae5a0dde65852"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/52-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7222 :STORED-BYTES 2991 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-2.lisp.gz" :UNCOMPRESSED-BYTES 7222 :UNCOMPRESSED-SHA256
    "b4cb0336cf61b39b4a5191bf841e0e3c12476e28c52bb70156aab0281779c718"
    :COMPRESSED-BYTES 2681 :COMPRESSED-SHA256
    "32b2d1178d6cb759a4c2f7f474f71f675c1abaf5544cdf17a399d4f6b4faf8b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/52-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7006 :STORED-BYTES 2997 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-1.lisp.gz" :UNCOMPRESSED-BYTES 7006 :UNCOMPRESSED-SHA256
    "1ea0d7eb0659ea7a9fc98110ed4d389f4011b18ff1f19091698db7b78ffdc066"
    :COMPRESSED-BYTES 2687 :COMPRESSED-SHA256
    "0176ae5fadbcbab430069f58bd38cbb1ec15165c419d6feb062b006c169553fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/52-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6920 :STORED-BYTES 3099 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-0.lisp.gz" :UNCOMPRESSED-BYTES 6920 :UNCOMPRESSED-SHA256
    "f819f97142771b03f75d6fcabbaed22e9e9d62d304db9cbcdbfe5b2ef579b229"
    :COMPRESSED-BYTES 2789 :COMPRESSED-SHA256
    "bb60d9a762a87a013a379561b7776e4e13b3b9c08e21c5307b0be0160a2651f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/51-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5077 :STORED-BYTES 1479 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-4.lisp.gz" :UNCOMPRESSED-BYTES 5077 :UNCOMPRESSED-SHA256
    "83cec5af898c9624cf8eea1241fb3bf9419f36cd5c5f2c31d0073c68c758bce0"
    :COMPRESSED-BYTES 1169 :COMPRESSED-SHA256
    "d264aa0a0daabf3dea8bd13e38cbc4210f9e7048be1e72b12d14b90a15e4c8db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/51-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5083 :STORED-BYTES 1478 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-3.lisp.gz" :UNCOMPRESSED-BYTES 5083 :UNCOMPRESSED-SHA256
    "1d74908dd3f893644d51bf497fca67a1cd104803a247a599fd41b21ec84e744e"
    :COMPRESSED-BYTES 1168 :COMPRESSED-SHA256
    "8c4861de65de4111e8e23dec1c00ce543105c8b8f44514127d02402bc754026c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/51-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5071 :STORED-BYTES 1451 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-2.lisp.gz" :UNCOMPRESSED-BYTES 5071 :UNCOMPRESSED-SHA256
    "510a8367c4f2947abd1941c3765322b3affff3ff6677d81896c5881a8306dfb7"
    :COMPRESSED-BYTES 1141 :COMPRESSED-SHA256
    "c4292ad8a59b7929ebfec206e6bc23ec8971c9ae407aa8d5d3edf02834f62841"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/51-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5035 :STORED-BYTES 1469 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-1.lisp.gz" :UNCOMPRESSED-BYTES 5035 :UNCOMPRESSED-SHA256
    "7baa9ebab83577076762eb2f680f3b297c0b40fc42abd37e2e655b951406f2b8"
    :COMPRESSED-BYTES 1159 :COMPRESSED-SHA256
    "fa9a643244a1336a4754721bbebb1e58ad531905e7f23fa0cad0ba8b18d4de47"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/51-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5035 :STORED-BYTES 1459 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-0.lisp.gz" :UNCOMPRESSED-BYTES 5035 :UNCOMPRESSED-SHA256
    "91411d5fa40573fe4108ae1263836d68c558e5d152b4f6ababfdc573de1fd31a"
    :COMPRESSED-BYTES 1149 :COMPRESSED-SHA256
    "2e85e705380d73ae02df4afbed2a3f423f7ba08cdf032265ce7460c6e3e62a7e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/48-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20050 :STORED-BYTES 3850 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-4.lisp.gz" :UNCOMPRESSED-BYTES 20050 :UNCOMPRESSED-SHA256
    "1c71fdbe3440b0b707faa6141b87d914981bcf5b0e097af268fc6dbac1f29aa9"
    :COMPRESSED-BYTES 3539 :COMPRESSED-SHA256
    "38b47207739d87827e9f6dd9268ee9a06d0379b574baaaa69577995203ea8eff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/48-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20055 :STORED-BYTES 3490 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-3.lisp.gz" :UNCOMPRESSED-BYTES 20055 :UNCOMPRESSED-SHA256
    "420bcdcb104e3de8e31ac2efd04479f9080c09a938eea2c35ee92efd4678e078"
    :COMPRESSED-BYTES 3179 :COMPRESSED-SHA256
    "d3f31372d811522bb6d34f5462892794daa407662d3ec2335f4e15c783731579"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/48-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20055 :STORED-BYTES 3424 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-2.lisp.gz" :UNCOMPRESSED-BYTES 20055 :UNCOMPRESSED-SHA256
    "d601d9cbf2e88614e4054fc5c366f76b513996ab224a156ba40096d43ed36d61"
    :COMPRESSED-BYTES 3113 :COMPRESSED-SHA256
    "1be98f75bc91e05ae8b44353051319b166829d1d64f3968556423031307d3a74"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/48-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3422 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-1.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "b2770051285343d43e4546187a5fc6be306b58420662caef97c04278ba2a9641"
    :COMPRESSED-BYTES 3111 :COMPRESSED-SHA256
    "0d43802aa3b8e807d7f1765cd7e1ac640bb609e64ed054c73343f7e287745e17"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/48-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20059 :STORED-BYTES 3868 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-0.lisp.gz" :UNCOMPRESSED-BYTES 20059 :UNCOMPRESSED-SHA256
    "20fb8efa8e5ac5cd087ac4a7ef09a3cc15fd742468fe4e8031ff82fb41cb49d9"
    :COMPRESSED-BYTES 3557 :COMPRESSED-SHA256
    "a036b9a985cc95c309f46b9dd5c026bf1ef85e35b4d55b9ce3d43d2751ddbf3f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/47-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2156 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-4.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "2dec45c6e7a86f5b71d516b04ed532036d17bf2f9c2ac97e5a40d7d7fdbd1fa8"
    :COMPRESSED-BYTES 1845 :COMPRESSED-SHA256
    "fb3ce2cd58aa6cddd6ffe3d5a885b66e705aebf5f749df1880020a916eeebc25"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/47-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2048 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-3.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "6cdcf048db25a04d513663db63d8df5ecddd5615ca469643f809f69b0343d310"
    :COMPRESSED-BYTES 1737 :COMPRESSED-SHA256
    "bca605a1ddc08bd170b9c4340f7480e33157acdb3c6d18030c0f1ddb1d93ff50"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/47-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2114 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-2.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "f4468f3dcf265484b7d1eae461b3f6b0fc8d566e1fd91edfb5b71ce9cf09278d"
    :COMPRESSED-BYTES 1803 :COMPRESSED-SHA256
    "6183cd6808d1919f27a028fe02295129cd93cf9c329ddbf8247027478e611b20"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/47-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10442 :STORED-BYTES 2159 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-1.lisp.gz" :UNCOMPRESSED-BYTES 10442 :UNCOMPRESSED-SHA256
    "22237142f7a4bb0bbdc622a0062bf8b4080196ddf790f157d10faa324b7be87d"
    :COMPRESSED-BYTES 1848 :COMPRESSED-SHA256
    "a6005bfb823845cb437e0d38216c305fe3764936d63b7d6e3af236b7c2054718"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/47-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2481 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-0.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "6aec35d6305c316bfbf4c496fe2c42110d7d25650308c1b74c75fb929a2d334c"
    :COMPRESSED-BYTES 2170 :COMPRESSED-SHA256
    "23c8f2bb4ab750bd9659f10a9ff0a0fd780a16ed2e21a75b78fb016c095156fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/46-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1632 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-4.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "25d3ec36f74cb4aff7131894446168299af369c5da14edff62180fa306772be3"
    :COMPRESSED-BYTES 1322 :COMPRESSED-SHA256
    "2f07ee8d9ea771038c042c8de916d2ddd3c4eb565a96751b8e147ca5de3554a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/46-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1609 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-3.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "614fbf443792a2aecddc0eae2c576dae29d3e0e89f2a5763b48954fd27f4e832"
    :COMPRESSED-BYTES 1299 :COMPRESSED-SHA256
    "8e9fa1fee97923b517a4eea80bf369e888585a5c89f7d7d1892729a80dbd68aa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/46-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1449 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-2.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "715a5646b454531411c9cc78097be5f8006ca58e867e920c15b4cdd5e15abb66"
    :COMPRESSED-BYTES 1139 :COMPRESSED-SHA256
    "baf5fa212d7272381473f3f798c4a74d13c3c46681f927587d97c7253c5ba534"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/46-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1443 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-1.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "38a8017defd92b42148a3fafc8b3e06f0ee31a7626357eec76c7363ee067f033"
    :COMPRESSED-BYTES 1133 :COMPRESSED-SHA256
    "bf0cd14529c5732e1cf17542d685dc33033fe8d945d882abc0118f05dd5f6153"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/46-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1668 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-0.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "57f793b819b51b604148235daae1baf022801c84cd4488787590396e71289f0a"
    :COMPRESSED-BYTES 1358 :COMPRESSED-SHA256
    "d3587f739b72d30ae5426e771dce12272e741befe7837fcb013a8f3fc0092c33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/44-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 3014 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-4.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "e78e8006b75bd4b24b64b7336594984d4f0b6754672327c9cdd66cd39fe3090e"
    :COMPRESSED-BYTES 2703 :COMPRESSED-SHA256
    "4f07c56049b995552e4265b78d99809e4d8470c0b96838d41b68e4f901bdd7c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/44-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 2983 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-3.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "3220e5303676fa79bbda8526362296fac89c9b5e407f520a03beb396abec531f"
    :COMPRESSED-BYTES 2672 :COMPRESSED-SHA256
    "4fac4a01888a8c57895d8334c49815810e8ee8194aac8b612d17569936f45b5a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/44-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 3036 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-2.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "16c4a89d0db54dd87c6da2b5ae21ad4331ec8d49b728690e34757e0bed6d86aa"
    :COMPRESSED-BYTES 2725 :COMPRESSED-SHA256
    "50a4bcd09ce0a25c7f19045c17fa45ddea10a580321b6f0cbd2fac417261c8f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/44-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20023 :STORED-BYTES 3360 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-1.lisp.gz" :UNCOMPRESSED-BYTES 20023 :UNCOMPRESSED-SHA256
    "c3f91172bf7339b4f0612de667d2ae4575b054748e0296f482c2574544204f0f"
    :COMPRESSED-BYTES 3049 :COMPRESSED-SHA256
    "e53a67a9e928653719f689e08ffa11f26577c97c7b2c80bf0a73084fdd73eb95"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/44-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20038 :STORED-BYTES 3996 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-0.lisp.gz" :UNCOMPRESSED-BYTES 20038 :UNCOMPRESSED-SHA256
    "13a0503a6c4d587aa4d81f7b4b250135bff1210b3c040a07751826e1ee098b86"
    :COMPRESSED-BYTES 3685 :COMPRESSED-SHA256
    "b7c6d7e838484da7d343edb2f8ead3606ce83a04c1a93e6277f1ad314e5b2d6c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/43-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-4.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "216e230adbf969dac442648bd665301b0262cd823ecd686348203d9e2b813659"
    :COMPRESSED-BYTES 1449 :COMPRESSED-SHA256
    "1333e2c02cff7427db3a8024d204c24dd205a19dd4eb1f7cb54cd8cf953c36c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/43-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8819 :STORED-BYTES 1743 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-3.lisp.gz" :UNCOMPRESSED-BYTES 8819 :UNCOMPRESSED-SHA256
    "8b77f8254e2b95a60cace58a01297d952efa22e7b4cb2c376b03d1f82d338185"
    :COMPRESSED-BYTES 1433 :COMPRESSED-SHA256
    "a3c73fb3d1af6bc1e72c43f50ebc53cc0be949b529e8b277c36f73047f5b7c04"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/43-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8825 :STORED-BYTES 1832 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-2.lisp.gz" :UNCOMPRESSED-BYTES 8825 :UNCOMPRESSED-SHA256
    "ea6f8ea51286ef71e8c03ab0108fd94f522b4f64864375eac9ac7a43e0e4b801"
    :COMPRESSED-BYTES 1522 :COMPRESSED-SHA256
    "1a4f9bc1a3bde1af1b86ce1ccd91e100f353cc16b4e9a6a9e996e7562e5fa374"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/43-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8825 :STORED-BYTES 1739 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-1.lisp.gz" :UNCOMPRESSED-BYTES 8825 :UNCOMPRESSED-SHA256
    "357fa79dac5f71207a85d63106e89a912f5573de5cd525ba5d8b7d1a371f0d41"
    :COMPRESSED-BYTES 1429 :COMPRESSED-SHA256
    "67a8d3d22fe53623a76b1f309453cc5386e670d11274b1174a732c9dbb781bce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/43-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1807 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-0.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "b57c10b093f5ae257828c245a3a8fa7a1b48b16672d27143e3911430310d9d1f"
    :COMPRESSED-BYTES 1497 :COMPRESSED-SHA256
    "5916aaea6777762aa1d0157520e630615435f018577f221aac8e6fa4bdf98237"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/42-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1246 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "5139ac0b2a01a40f95fc34bb163a2c17e79db6f5f2a3d1fbdfcb2666920ea872"
    :COMPRESSED-BYTES 937 :COMPRESSED-SHA256
    "8b82e16fdcf53fbfce8c176de562c9476d228a5c5d278a34a2d32bf5efeb2e3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/42-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1210 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "59e8b17d7d3c015b09ea99329683a36dd18393e762172d84b6d4e0f8a97e20d8"
    :COMPRESSED-BYTES 901 :COMPRESSED-SHA256
    "7e473d84ec059aaf7c92a94a585d7079cffd18c65efd938e2de6b433e517aec7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/42-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1227 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "3a51228438b955d18b02b20fc327562a19fa4d426a425841ac5660b17aac742d"
    :COMPRESSED-BYTES 918 :COMPRESSED-SHA256
    "559398c0f7193e45b85bff44e88cac17b24178b91fa01a64276eade01473b3f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/42-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1232 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "a9e2f9655d4c07e1a0edabbb9ecfb09f903c4bc0e6fb6cdc5c4187e8817314dd"
    :COMPRESSED-BYTES 923 :COMPRESSED-SHA256
    "5c305e2a36e193e8ef7a5602f98af7060eeee5808e3f549f442e0c1edd307dea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/42-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1222 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "bd8b242eea5d65908e80b22d8d1e0dbbbc6d5bb9977b827f473ad5959e30682f"
    :COMPRESSED-BYTES 913 :COMPRESSED-SHA256
    "baf7b43f3a5b0fc6a125bd2c2bc15290aa8102eec13d430737281dbd49a0d364"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/40-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19924 :STORED-BYTES 2511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-4.lisp.gz" :UNCOMPRESSED-BYTES 19924 :UNCOMPRESSED-SHA256
    "c0ab8267ef54d9482601a8c5e1572988206b0b1e44191f85ff9112d8ed823806"
    :COMPRESSED-BYTES 2200 :COMPRESSED-SHA256
    "7dcf9a535d766935f60bc4edd154c12dd4c1eb7e0eda93d2e85f119760777db5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/40-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19930 :STORED-BYTES 2517 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-3.lisp.gz" :UNCOMPRESSED-BYTES 19930 :UNCOMPRESSED-SHA256
    "9f8465d5a1f218b0985a80cf152b4172f3c8b04bf11638750c6b38b06a496fe0"
    :COMPRESSED-BYTES 2206 :COMPRESSED-SHA256
    "c37bace3c13be85b25150beaeb1656684d673bc4617b7367366b6a7304f80e28"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/40-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19911 :STORED-BYTES 2490 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-2.lisp.gz" :UNCOMPRESSED-BYTES 19911 :UNCOMPRESSED-SHA256
    "eaed6ea4d683a0e0963d410fabdebc2b6fddf38d97a63db603533a83f36e5def"
    :COMPRESSED-BYTES 2179 :COMPRESSED-SHA256
    "63c11f3f924af01852f2d7cc7f282d5f6763970198f7181586664706c5bdeeae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/40-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-1.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "36501344a093bce904cb834639874effae42556519e9a07b047ddd8e8decde92"
    :COMPRESSED-BYTES 2146 :COMPRESSED-SHA256
    "af38d4588a3617f5a8e1003f26294183ad4f199e1ff5fc0adc39deb39e993523"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/40-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2773 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-0.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "790d3ddc87793c3dd64229da6976866c62273549bbd112d748bfa8336b64fc50"
    :COMPRESSED-BYTES 2462 :COMPRESSED-SHA256
    "e4335cb37f7e967d600c0d22b7f35ceb45886894832a35582cf9abaf21e9daa2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17925 :STORED-BYTES 2706 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 17925 :UNCOMPRESSED-SHA256
    "c2c806cbc243b5ab17acdabc457464d13d7e401170e802276b05dcbb2635f128"
    :COMPRESSED-BYTES 2396 :COMPRESSED-SHA256
    "421c81c5b8b069104e49a7c21dd76c325cc5cf50dcf90db291f05201a86e17cd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19483 :STORED-BYTES 3280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 19483 :UNCOMPRESSED-SHA256
    "767af0fecf8ea304180bb410a9dc178468a5bd4b963ada8cdc5c46289b68282d"
    :COMPRESSED-BYTES 2970 :COMPRESSED-SHA256
    "9f2f8e1dce297b5633d2b420de1811cd663be0bc7cb90b47f389d4373cb979df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18533 :STORED-BYTES 3051 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 18533 :UNCOMPRESSED-SHA256
    "0f47ef2c2858d07feabead96fe006366493436255cf5994e9f29b9759c6b5a02"
    :COMPRESSED-BYTES 2741 :COMPRESSED-SHA256
    "243ea25ae5bc24a13f488d91fb23e97701cc8b6afd6e149573baedcc50c78efd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17523 :STORED-BYTES 2662 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 17523 :UNCOMPRESSED-SHA256
    "e62f37759cebf2988b669ad78f85b8286bba6b08ea8e3063a19cc835ba0091ac"
    :COMPRESSED-BYTES 2352 :COMPRESSED-SHA256
    "73b283497bda06a9c468fb3d2068b7740d2d1c7088a1081ffc6a11c52677a993"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18062 :STORED-BYTES 2763 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 18062 :UNCOMPRESSED-SHA256
    "0dd6a51bf1f3803c887dfe6bdf990f1bd89883ce128a27e0794e2aed538c8605"
    :COMPRESSED-BYTES 2453 :COMPRESSED-SHA256
    "d5d101f8a71f37767bcf3578e5a05cd6df72771bd8deda27dbc92c9d652308db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/39-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1593 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-4.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "b8792f7b496e6fe0e7f3755e535e5ba6cd9e9895d890da0835597c9b079b0a3d"
    :COMPRESSED-BYTES 1283 :COMPRESSED-SHA256
    "18ad914bf6ba0d81bfbd88fd7b181025a36a58eb464a9ec71aaebf995f0d09ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/39-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1639 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-3.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "95d7998affe21fa1bd9656d1a123ec76bf7c6f60880bfc2e8bca6ccc2c589d80"
    :COMPRESSED-BYTES 1329 :COMPRESSED-SHA256
    "8c07e4ab01fdc3cbdbaca32957ba412857fff70a290619f4dd9596be882969c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/39-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1678 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-2.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "892785fead1a3b9dde5232bad3c0fc397330cd92068a3d9f2d3a128e22950c3f"
    :COMPRESSED-BYTES 1368 :COMPRESSED-SHA256
    "d559197000083c535f7b22e76ac4fcc373cb049f1d93b55c5763fa2f2e671f42"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/39-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1703 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-1.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "db91cd8386e2185df811a374902ac672eee5b946a087be090c6691cd1924881b"
    :COMPRESSED-BYTES 1393 :COMPRESSED-SHA256
    "e2a4698e440ad8dfadfdbfe0bf7e1a428e68394fd165e62f02755cd4a1eefe54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/39-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1703 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-0.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "38a803b092be65d2142285f5b481b047211060e215ddc980553eae221d0d9e7e"
    :COMPRESSED-BYTES 1393 :COMPRESSED-SHA256
    "1f939457ae78cb3be0fe74c47b1d3807a55c13e5bdb40ad753e099c41eb7e6ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/38-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1210 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-4.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "34d2845a0c05d52d38e9bcdf2e99d1e3a086e58ba498398bacc6364874d44682"
    :COMPRESSED-BYTES 901 :COMPRESSED-SHA256
    "f4481c484756395245bc25fb62dc0e88e40ea713edf04a24487ed09efb9f8085"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/38-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1157 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-3.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "9822f651c5fe62d731f6383e23d9bb6a004607f15bc20d2d0d20002494ba915d"
    :COMPRESSED-BYTES 848 :COMPRESSED-SHA256
    "002c9831258ec103ddf9e7a38e5fe2664b08a2eb05a5b32f3d0ac45efa6a1499"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/38-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1147 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-2.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "1f3da6dc73426c67a5d073b0f2f723923e7dc179b4ea52af99184244ae63f465"
    :COMPRESSED-BYTES 838 :COMPRESSED-SHA256
    "354dcc3002b08a273eec66108eba66c90c52fa39aacf45bf1d535e50aec9ac0f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/38-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1207 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-1.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "97a93e3a78a42e0109a666f595ef6d3812a0a3f3933403f2ec64c756ee977150"
    :COMPRESSED-BYTES 898 :COMPRESSED-SHA256
    "cfe23876c03fbed9e3befebe0651f9a58dd68535b5658775330a981c62504058"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/38-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-0.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "647d56d2dd1f35cd2b720fdf23dcac408e007cb4715fd0803d259ef9eb6fadf4"
    :COMPRESSED-BYTES 865 :COMPRESSED-SHA256
    "2e2d92350546e276582d6e153739f72bc8a8ff9bf3125beda18dc16a1ab4b4fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/36-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20055 :STORED-BYTES 3624 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-4.lisp.gz" :UNCOMPRESSED-BYTES 20055 :UNCOMPRESSED-SHA256
    "297b232c89d0aa07dbf5dfa7ba1db0b36804a9497422b950c43f4d0e4da1616f"
    :COMPRESSED-BYTES 3313 :COMPRESSED-SHA256
    "ed2a7c0cf40b06393fe6776ea87d0c1a30f482789a35a0eff00b7966f5674342"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/36-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20058 :STORED-BYTES 3519 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-3.lisp.gz" :UNCOMPRESSED-BYTES 20058 :UNCOMPRESSED-SHA256
    "d8ec8da18298ccde1c37df721a9c32563c334efa39f9c743d199e1cbfc8044ac"
    :COMPRESSED-BYTES 3208 :COMPRESSED-SHA256
    "0c46a6dfdf3de938213f0af2c7c09e7146a0b58977fda2c238346f74f7f967f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/36-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20050 :STORED-BYTES 3493 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-2.lisp.gz" :UNCOMPRESSED-BYTES 20050 :UNCOMPRESSED-SHA256
    "1600ab5f4dfad6f27ae97723cf06ed5f2bd17dbeebeaa6e0a5bd83ec10097578"
    :COMPRESSED-BYTES 3182 :COMPRESSED-SHA256
    "f84aa0f0ea630bf460f901e240e327c854400a5420c88ea74a25ad18916ade5a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/36-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3594 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-1.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "e06b240ae6f2bbbe024553c4b9597e35b3cf8e4bb4be00815054f046e714925c"
    :COMPRESSED-BYTES 3283 :COMPRESSED-SHA256
    "da5069b83a1d9bf235085e339c13cae60785e19b4fc4ec6167c066be560c2c8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/36-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20063 :STORED-BYTES 4163 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-0.lisp.gz" :UNCOMPRESSED-BYTES 20063 :UNCOMPRESSED-SHA256
    "6fa7aed707cc3f3400c966223a76b09cca9c71371195bfe887a594576d1ea28d"
    :COMPRESSED-BYTES 3852 :COMPRESSED-SHA256
    "5c8b955428d0e86ab95f0173c2c8948de12c361175e60647786d842ecef4f16c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/35-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2071 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-4.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "8598336f424b80aff21979a6892021e3b625c9c0ddbf269bb835a9ca2cb884c9"
    :COMPRESSED-BYTES 1760 :COMPRESSED-SHA256
    "06d72e533167f033a0259aebda40305f5de746cf481e993f5603fcd04d8e7d70"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/35-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2047 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-3.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "1d0bdff1e58bab1d00689f7d87b2679924ba6b488706b6a4b8cb4b8198e4be9c"
    :COMPRESSED-BYTES 1736 :COMPRESSED-SHA256
    "778fe22a2f9925c16c0a8170a1a02e854edb3ee51877ec16b621465fafb8ff87"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/35-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10439 :STORED-BYTES 1995 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-2.lisp.gz" :UNCOMPRESSED-BYTES 10439 :UNCOMPRESSED-SHA256
    "38de3cb3bb10ed8ebec3aa09d91f51b40ba34401c9253d9afda030c491604ed9"
    :COMPRESSED-BYTES 1684 :COMPRESSED-SHA256
    "4916475c4b88f98bed30ec688dc9a56196c7400a2a506d66a7b91d6c9a2410d6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/35-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 2062 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-1.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "18370021ecae4876d141586f214a4e70ded8b45e0f9addec5e6790cea1f3a434"
    :COMPRESSED-BYTES 1751 :COMPRESSED-SHA256
    "23dbf7dd7baab548ab54798981bed0879a5db4641a20723f8a0f0d60c9725467"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/35-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 2363 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-0.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "f8e1db4887c417849a80cacb5c7bb1f54b393e5aeee731495bd296fba4fb44eb"
    :COMPRESSED-BYTES 2052 :COMPRESSED-SHA256
    "d4a9a8f17502b24826e369d19e64e4dda4f7bf67cf5e7c97f865d5fc367ae7e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/34-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1396 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-4.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "418ec8cc65ab3eb81da4f09021fbc3124c7ba17d9746119adf40eb8ab3c35a07"
    :COMPRESSED-BYTES 1086 :COMPRESSED-SHA256
    "8c366627b4d7bf89994d53c3874023d6614b56d6ef6d32132bbc9f8351253a10"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/34-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1339 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-3.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "28ce207d716bd1d59fb5c872709c15d84af7adf41e558a3ca73fbce0ea9a2b9a"
    :COMPRESSED-BYTES 1029 :COMPRESSED-SHA256
    "27cbb162aba2bc1d1ccf6b65c221b04720bbcee8c89366efc52aec2f79c974b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/34-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1360 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-2.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "88e5afa2dd9adcbf61696fa481bdce8663e3ff9d996f0d766ec358d3e9baa79e"
    :COMPRESSED-BYTES 1050 :COMPRESSED-SHA256
    "bd1d65b7dd6098f961e6eb1acab4c13f0a3dad9180ad0561d1508d992a6e55b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/34-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1363 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-1.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "c035f55bbe9567f28afe018c57cc6c3c16c0d6d443c4e71ac166eab8e617dfdf"
    :COMPRESSED-BYTES 1053 :COMPRESSED-SHA256
    "f40b42efc0957a5347af9824f1ba89cd580525a7968666692f4487b5c5c4a93c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/34-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1545 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-0.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "f86f47f3ab503dd4f2d8d627783989156dea9f3a1bc34fcd1f338c56b85fd251"
    :COMPRESSED-BYTES 1235 :COMPRESSED-SHA256
    "2758d86d94c8259c6dc74bec3f978bd5f0e5d88acea8ed3d926ff2a68e0f8eb0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/32-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17810 :STORED-BYTES 2668 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-4.lisp.gz" :UNCOMPRESSED-BYTES 17810 :UNCOMPRESSED-SHA256
    "f4b68c020dc0c9255173381e0155d7e18d3eae7cac90ddea6b52f812b5390fa0"
    :COMPRESSED-BYTES 2357 :COMPRESSED-SHA256
    "f29823eb42bd3b6ba296812b3f90ae36bdb31b7cbcee226578ce198cb4c78ca2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/32-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17843 :STORED-BYTES 2707 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-3.lisp.gz" :UNCOMPRESSED-BYTES 17843 :UNCOMPRESSED-SHA256
    "d986b337b6a8e3045854ac0751bf914455813498d15a00d4895f2b650ff77a02"
    :COMPRESSED-BYTES 2396 :COMPRESSED-SHA256
    "9a4ab81c52ea4695d438d8483b777e2a68302ceaa45ce701ed66e98a2a57d73d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/32-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17826 :STORED-BYTES 2694 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-2.lisp.gz" :UNCOMPRESSED-BYTES 17826 :UNCOMPRESSED-SHA256
    "a01d0bd57f9e638e87b624c3d3d629d682205ce4d2fafee7a3433377739b613b"
    :COMPRESSED-BYTES 2383 :COMPRESSED-SHA256
    "33f9ace6c23107b32946485959c78d1bd8c18bc52c0c8821f37e1053dd01a71c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/32-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18061 :STORED-BYTES 2769 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-1.lisp.gz" :UNCOMPRESSED-BYTES 18061 :UNCOMPRESSED-SHA256
    "efc76d742df4f92aa13e634c218d93d264831c70a8b4ffe0a75024a57b7b9a36"
    :COMPRESSED-BYTES 2458 :COMPRESSED-SHA256
    "9ecab79c634c339b05df2dd7197a149844326311d4789e4a865a091a96bc3c31"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/32-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18574 :STORED-BYTES 3004 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-0.lisp.gz" :UNCOMPRESSED-BYTES 18574 :UNCOMPRESSED-SHA256
    "01942141107c5b1577312c94e628d743e76a88f67a50af34deffaf14cc87b24f"
    :COMPRESSED-BYTES 2693 :COMPRESSED-SHA256
    "21330bf6f771e4a44cbfed50d82edf2370d533ec843468d6444f5d5ece671540"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/31-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8842 :STORED-BYTES 1766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-4.lisp.gz" :UNCOMPRESSED-BYTES 8842 :UNCOMPRESSED-SHA256
    "cc5d9ec620b871a9e4c3aab27440c936170f2a399cc2ed98635e30ca88225bb4"
    :COMPRESSED-BYTES 1456 :COMPRESSED-SHA256
    "e118bb72178c81f62dbf3c0f50f3fe3c087342e9d6106ea3fef2e944a25798e7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/31-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8827 :STORED-BYTES 1777 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-3.lisp.gz" :UNCOMPRESSED-BYTES 8827 :UNCOMPRESSED-SHA256
    "09ed4c07b530497b0b830047fed890f20efefac99f69e25645147e6f3db9ed2e"
    :COMPRESSED-BYTES 1467 :COMPRESSED-SHA256
    "d7776cae9b7f4cb182f9740cb92c84922e6534fd8ba408ddad3cb2cd12100d33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/31-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-2.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "d4de67bfbb64caf89bfdbc0181cd1bedf9888ecb3c35629a8bc6fe874a4fc12e"
    :COMPRESSED-BYTES 1425 :COMPRESSED-SHA256
    "f3ece21fd978fd6e65845bcf50ed35dcadff18c2bcd6a31df0a823abc48dbbd8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/31-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-1.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "ca1f2d3f2a118b13e0da0e7ad62c3f97016c3899f659e3983d6e759fd4cb5195"
    :COMPRESSED-BYTES 1413 :COMPRESSED-SHA256
    "6eaa4e4881ffb9462d2bcf2fd6ce8643bfc4b853e95b18703d13a4e7622ea4e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/31-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8832 :STORED-BYTES 1734 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-0.lisp.gz" :UNCOMPRESSED-BYTES 8832 :UNCOMPRESSED-SHA256
    "3a02d2efe9a2ab59d244eac6dd928c3ba93ab6f49caa78129dac186740935e76"
    :COMPRESSED-BYTES 1424 :COMPRESSED-SHA256
    "c5aaf418eb58a66629d30b5d8bdc2ed4f506e79a2930852085036dffdb6a48ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/30-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "f8b6eba6d987fb8d7b1b534226f1f86fe23b28ff4f6c56e7882897a89adced67"
    :COMPRESSED-BYTES 806 :COMPRESSED-SHA256
    "37a5516c3022444e04fe1597e3aab9d6b6f8718b390901cbb44903b3f2aeffe5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/30-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1207 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "54b70e5db584bc43ec599dad79efa8b0767216f27dca81a3bb50533ee06bc030"
    :COMPRESSED-BYTES 898 :COMPRESSED-SHA256
    "aa968d65580a36f2b63bf86c7d9b8a1069edc6aea93c1b37396ffdd53cdd55f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/30-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1191 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "4716a1f3f67d0e2ca914c15d6a7225e97049976fc3d2e3aae1834063d71d3724"
    :COMPRESSED-BYTES 882 :COMPRESSED-SHA256
    "09584184a1e93f718d981856af54c001fb5627aebb49f61b1d59cba92e6ace11"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/30-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1189 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-1.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "b156f52566098a90eb420f890202ab22b318863a43346e09c8ac0ed8fe5153e1"
    :COMPRESSED-BYTES 880 :COMPRESSED-SHA256
    "3b36b0a275ff9e23a960095b17915a173bd2a3c42cc49730d2641e83c11999cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/30-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1170 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-0.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "5bcd420af21c278fc9c4115b33aa45d83ff4a834a203b17dc2ea234f66f341f0"
    :COMPRESSED-BYTES 861 :COMPRESSED-SHA256
    "d743bb8b22700fd4950f727201937c40afd2a9bb641eb5cea101d9d92a7b2292"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1503 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "fbd0c7900a5e0f5a7df4e90a224d1478ee411dafdb136bf6175bd79675e6fe45"
    :COMPRESSED-BYTES 1194 :COMPRESSED-SHA256
    "f2a1a7240152961afdb1a5ff6911d3410aec748cc730834b0ef93a3b4963505d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1584 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "0ee766f9ccf0d3ef36d12455a5490d02603845b481eb4504fee5e70421a539d5"
    :COMPRESSED-BYTES 1275 :COMPRESSED-SHA256
    "e7b27fcac4c532d73f03154180eb54a2084bbbca3c7b68ef1107f484dc7cb3a8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1515 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "55d845f85b4a34f8a2d2727b0ee0e41e32f918ca2639d839fa88215d84d43fe3"
    :COMPRESSED-BYTES 1206 :COMPRESSED-SHA256
    "fa12b33a47e0484a62f4f8f267bac85509aed6c2ec93cc88df0eb912b7532eb5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1553 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "af11845bff11978d34d252716a74cdf8b2396a3d549a05bd8973ae38b5d8e262"
    :COMPRESSED-BYTES 1244 :COMPRESSED-SHA256
    "3a44f03a0738dca30bbeb0dcb2d790649e1baff9b6448cffa510bd498db6683e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "99e521db99a6e8e295dc8ebe25df3e9a0976e38692140139dc8141ce3e3f87dd"
    :COMPRESSED-BYTES 1148 :COMPRESSED-SHA256
    "308d0f88763d326c00272e7c4850836bf07db5ac32624b317021d87121bb0564"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/28-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16874 :STORED-BYTES 2274 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-4.lisp.gz" :UNCOMPRESSED-BYTES 16874 :UNCOMPRESSED-SHA256
    "3e0ae34c832dc9ee4dc8c18158c28a84855f8ac548597e0945154036d88c59ab"
    :COMPRESSED-BYTES 1963 :COMPRESSED-SHA256
    "c154895b8737c6b01d1c36fd01198131d613ef2b831d0dec69e7b058c980d2a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/28-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16892 :STORED-BYTES 2311 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-3.lisp.gz" :UNCOMPRESSED-BYTES 16892 :UNCOMPRESSED-SHA256
    "b1eb608c78838ba4ca2fd208f54e858c4c1675955e506e21c535f9d1cd1b3808"
    :COMPRESSED-BYTES 2000 :COMPRESSED-SHA256
    "6083ed8e9642b866a7efc13b5f1438fb57ab75b1fc90e6a363429cc626f44c8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/28-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16912 :STORED-BYTES 2343 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-2.lisp.gz" :UNCOMPRESSED-BYTES 16912 :UNCOMPRESSED-SHA256
    "52f74ff2bc3a6a708a165eb29d4b32c264386598a0e9bd771e50ed081d1332ea"
    :COMPRESSED-BYTES 2032 :COMPRESSED-SHA256
    "6f6e24469c57b57a846280a6c7d2ffac6deab34554b5d3ed7774579396fa5d96"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/28-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16886 :STORED-BYTES 2221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-1.lisp.gz" :UNCOMPRESSED-BYTES 16886 :UNCOMPRESSED-SHA256
    "a9fc1a417b11795ea2fccb5218a2aedf691956c517ceea75a983bb19907093e4"
    :COMPRESSED-BYTES 1910 :COMPRESSED-SHA256
    "6d54936a50493eee1cf745b27da61d60c0a64fed192b5d6a54224733be996f95"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/28-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17950 :STORED-BYTES 2535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-0.lisp.gz" :UNCOMPRESSED-BYTES 17950 :UNCOMPRESSED-SHA256
    "502c5b4153a5affd40ef6a387534fc30b5e9df62b9459659706a3f04fadee22d"
    :COMPRESSED-BYTES 2224 :COMPRESSED-SHA256
    "4272e137c2d86674b8180b02fa4f946cf82a7d01496305ebe789f9033d8d492e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/27-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1485 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-4.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "e3381f8dd85384bf9bbe28f97161522989c716f2ff04d349fe0f3efe5aaf8744"
    :COMPRESSED-BYTES 1175 :COMPRESSED-SHA256
    "f1b147c9e51178b3ae11ad8514ebf86a5b4cf96213bf0c4c605b39cba9c07afe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/27-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1551 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-3.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "4261c52a84c60c88e1e3e21a6d138f785ff45e59d2e2033dd381dca759a61da9"
    :COMPRESSED-BYTES 1241 :COMPRESSED-SHA256
    "f698acd75dcba64e13a4c8606fbf037508bee6117b445229be9f92e6b3ab2058"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/27-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-2.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "12be5f51a31fcbaab7c155cbdcf0dcab8476057dfb3ad84a6654035a5ef06df6"
    :COMPRESSED-BYTES 1131 :COMPRESSED-SHA256
    "8194ed44f1dd5e2459a8f2371d89b2bfde56964d9f613ca3de5df056460ef7da"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/27-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-1.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "8bce40c622f7f18db8d8b281e86905e908acea701931c54f119363a8fbad2026"
    :COMPRESSED-BYTES 1225 :COMPRESSED-SHA256
    "bed780268b05679d7d30389f362dd25e9a69c9cbc9381210994475c091b73783"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/27-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1514 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-0.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "cfde8bbbc8e4aed0bd49e015f0a10b8f42b9277df4aca929188951e8cf477daf"
    :COMPRESSED-BYTES 1204 :COMPRESSED-SHA256
    "32367995fecd62eb5b406cee51c8f41ca66bcc8260c631a475995b0ff0370e72"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/26-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1040 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "1222edf8fdb5839caadb2ead02000ac31ba5642a51dea8ab104fdb48e9761503"
    :COMPRESSED-BYTES 731 :COMPRESSED-SHA256
    "15e8de858b3b616ac1ed9e08b364e231635a7e3ae3bedcbe40e1ca71ce02d3fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/26-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1104 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "8ff131b041df2844e9dddf39d617c6a961c4117f361873506a8ba9e5b7786e39"
    :COMPRESSED-BYTES 795 :COMPRESSED-SHA256
    "3766c35c04a03d2eb9aecd589b6780b4611d7436c22aa2f7711ffa0c78efb7a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/26-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1148 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "2cc89ac41aa90d371a39a9de585738200b72fa6ebd2fb333b19883970b266031"
    :COMPRESSED-BYTES 839 :COMPRESSED-SHA256
    "73f250c88cbdcc6dfebde0d593d4de3daa20d691c55b279b992137b232483137"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/26-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1091 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "109e2ff185bad6c70052e137881e48056a265ee85df45f2b6d4e7e3a9bb7c368"
    :COMPRESSED-BYTES 782 :COMPRESSED-SHA256
    "d7e3cfa366c22318e69e8922781a989fa4617240132313d81e655c27a810ef23"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/26-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1141 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "257d268117a0334eeb71a2dd54fae8fb1d9815c6708ce070f3d1477a62720442"
    :COMPRESSED-BYTES 832 :COMPRESSED-SHA256
    "68c61bcaaecafc90865f81ca576487fcab04885398d00454334ed5379b1e3e1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/24-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20051 :STORED-BYTES 3675 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-4.lisp.gz" :UNCOMPRESSED-BYTES 20051 :UNCOMPRESSED-SHA256
    "1aa6e9c1a89192e5a443f9f4d12b845da4f5ef2e35b3faf2be2f2e43229b109e"
    :COMPRESSED-BYTES 3364 :COMPRESSED-SHA256
    "1b08d5b057b48de4d5043bd85d1617cf62e3e9c3ff64e9699469cdf88dfc85c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/24-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20051 :STORED-BYTES 3643 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-3.lisp.gz" :UNCOMPRESSED-BYTES 20051 :UNCOMPRESSED-SHA256
    "48260c2ef87bd4c1e213b7475ea23b7c6668a486467412e6a079b8a11a93a463"
    :COMPRESSED-BYTES 3332 :COMPRESSED-SHA256
    "651e8702d557fab4d2e24371a5811f394342220b5e7b72de475baba1201e906c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/24-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20050 :STORED-BYTES 3616 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-2.lisp.gz" :UNCOMPRESSED-BYTES 20050 :UNCOMPRESSED-SHA256
    "a2d76ed8874bf6f7c3d02b0242727f4b618b4f386a040aceda16b55691b23acb"
    :COMPRESSED-BYTES 3305 :COMPRESSED-SHA256
    "465aef9f669433997b6bbd766052c0619b5d723b1769228216d79e4ebe8ea632"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/24-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20055 :STORED-BYTES 3621 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-1.lisp.gz" :UNCOMPRESSED-BYTES 20055 :UNCOMPRESSED-SHA256
    "9cd93188baec1f00de1d183726f8a9ef9157dcbcf3ff7fa9dd58ebc2e7b6bcf2"
    :COMPRESSED-BYTES 3310 :COMPRESSED-SHA256
    "688d74ed55eb050485c87f0056a8705ec1f28954c6f76e2a445d2554cd2ac813"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/24-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20062 :STORED-BYTES 4303 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-0.lisp.gz" :UNCOMPRESSED-BYTES 20062 :UNCOMPRESSED-SHA256
    "871cb5f7391dd8e41f049585ff7adf2349657994016bebeaad3f2543dacbf83d"
    :COMPRESSED-BYTES 3992 :COMPRESSED-SHA256
    "d326251b8b4a22991ef72024c41ae3c99fedcb187ed3610fb1ac9ba3752336f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/23-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2145 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-4.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "2421a0073efacf4ad811a5632cc9d2fbf8273c49cd5007378da2c26ad68fb0bf"
    :COMPRESSED-BYTES 1834 :COMPRESSED-SHA256
    "021666b5b3d7b84de547c50b0c6974bff4bb760a127efaa1ad90973cab41b110"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/23-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10436 :STORED-BYTES 2064 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-3.lisp.gz" :UNCOMPRESSED-BYTES 10436 :UNCOMPRESSED-SHA256
    "d36c753fc24b5c50dc7227f36f8250c6a92551999f6688dd4ef3f6cff943c241"
    :COMPRESSED-BYTES 1753 :COMPRESSED-SHA256
    "29075d46331d82659f7373a03c7db7a832845e63b60c565e399f5922984e82bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/23-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2058 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-2.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "27795bc0025854585f4ea0ad44791ab6971cdbbf4b3e865301d4e8d352fabc65"
    :COMPRESSED-BYTES 1747 :COMPRESSED-SHA256
    "4a2fecf45c3fde0c5c9928e1dfb83259402a32c5d18e9dd1b00ab8141b79d69f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/23-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2061 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-1.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "aa6581435dad49dd9549233e61926ebc083e59002fc375fae18cbae1c986c730"
    :COMPRESSED-BYTES 1750 :COMPRESSED-SHA256
    "7b26a812f535bfb042af266e8b8892daa65931be69efe4266219bd1235e1b3c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/23-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2264 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-0.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "81fb65df3f7250560542df05a0586ffb7c35e31f9f166dc69824a10f7033112e"
    :COMPRESSED-BYTES 1953 :COMPRESSED-SHA256
    "19656c59a67ba05f81094b6b4671faad41320fa4b778f5f3c548731985de90d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/22-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-4.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "5cad4cc0201ac789af5095ca71e34e9b4256943c85171894684591317ac80c6a"
    :COMPRESSED-BYTES 1108 :COMPRESSED-SHA256
    "089ec2df5a387cf5fa6d8db3f7d783afa586c4bcdd67bed8a14cf1174199be49"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/22-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1368 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-3.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "dae3c5f551070a0259e5f8902f41037a2cbf4e6c9bd9f503b8f48be5d8974f37"
    :COMPRESSED-BYTES 1058 :COMPRESSED-SHA256
    "c06f8224ba22ba3e0959e4f0d41a3324ab9a4b8cb3f43453ea6dfb1d4333e7e3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/22-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1387 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-2.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "2df96a04e07b3f1a486cb90207d027eddc5573d92e62ce772589ebdfa38e87c0"
    :COMPRESSED-BYTES 1077 :COMPRESSED-SHA256
    "5fbc51d68d9ca70993a5c1a0691858a65808a71e8517d4c3d1e754624ce0838a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/22-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1584 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-1.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "ba420673862654d67928700fda01d54ce36d0c5b1a4e1871d4bb663d9394befb"
    :COMPRESSED-BYTES 1274 :COMPRESSED-SHA256
    "9bbe2ca21cc4191bb268502b12f23057364876c4e99bb35906b7c1fb7e283923"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/22-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5629 :STORED-BYTES 1707 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-0.lisp.gz" :UNCOMPRESSED-BYTES 5629 :UNCOMPRESSED-SHA256
    "76c69096c908b3eb1127689b6fe3293572861d513a1f4b5f768dd24d5da18216"
    :COMPRESSED-BYTES 1397 :COMPRESSED-SHA256
    "e3bc51dfc8e0a10e6ef2107e21491238025f5a87611bf7652761f5aeb07523dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/20-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20001 :STORED-BYTES 2770 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-4.lisp.gz" :UNCOMPRESSED-BYTES 20001 :UNCOMPRESSED-SHA256
    "b904f11bc0f754c2a59d4f8be79f9c371c2dd3289dfe4d035e589a04b2f04475"
    :COMPRESSED-BYTES 2459 :COMPRESSED-SHA256
    "d2c6a0e283b3f882b0fdd6ff67c18fe45eb496b60e960cde3bf63cf99a349486"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/20-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19997 :STORED-BYTES 2733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-3.lisp.gz" :UNCOMPRESSED-BYTES 19997 :UNCOMPRESSED-SHA256
    "ef32ce5a5c0104d1f0e0b03edcbcd97c2e147e48b276bbe913e6d9a495b55f73"
    :COMPRESSED-BYTES 2422 :COMPRESSED-SHA256
    "103ff61a81f3414122d7e38744163efbb2d8294e774d3c142043e0380b1f8409"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/20-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20005 :STORED-BYTES 2698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-2.lisp.gz" :UNCOMPRESSED-BYTES 20005 :UNCOMPRESSED-SHA256
    "768c5e3a261e8e13d13164eb768409c4d6251a95dc935561f1933994fd5e22fd"
    :COMPRESSED-BYTES 2387 :COMPRESSED-SHA256
    "897fd4a6f8911cda0792edaa1bf04ab685eb6df8b49531fb5d5d84e028916e44"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/20-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 2680 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-1.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "0c79d77b1d1bf452374cde6f2869eec4f77e8e030b46025487cc8fa271c8852c"
    :COMPRESSED-BYTES 2369 :COMPRESSED-SHA256
    "393260bd116f1645000cb573526a60966e8803afc878b5d565598cdaf71ce173"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/20-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20019 :STORED-BYTES 3004 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-0.lisp.gz" :UNCOMPRESSED-BYTES 20019 :UNCOMPRESSED-SHA256
    "bc154551eb8595c5784548f5f1d7c41c0de92912c91e0b35cf7923b7e8e3c62e"
    :COMPRESSED-BYTES 2693 :COMPRESSED-SHA256
    "c224da97e160b93c8ceeee9b39cb5554cf96bf566f93daf18e9c335372288727"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1122 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "34ebab8238e61c1d3320a1b8251b975f1a65f9b821c62620ade5f2ed3d67d96a"
    :COMPRESSED-BYTES 814 :COMPRESSED-SHA256
    "bc48b53442d2f960598d0be6a658ee63b10ff67d5d5845d95441f8d607ea7527"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1048 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "df512bf3d1a3520c1b955478e9e12e857db2973cee39c7ca962617c0b3c55a8c"
    :COMPRESSED-BYTES 740 :COMPRESSED-SHA256
    "2e3d7a921b40c0cc9084e2a01bbc505971f88e84d6c88d54253b95f26d9f6680"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1078 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "a95f58a1abc0314f8c220fd9155b97913aad3002b896f2110486220b74f8e42e"
    :COMPRESSED-BYTES 770 :COMPRESSED-SHA256
    "c5966d757b22d43d05b4177f726c9abf3353ab543926ff24912490fe9fd6e421"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1142 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "6a4e843a22471fa87fac3f3a7ce27341cbd7eaa310f165d386fd82aea791057c"
    :COMPRESSED-BYTES 834 :COMPRESSED-SHA256
    "979817d55994f45eff1ed3ed9c813b877d201e0ac95adceda45a39902dc44677"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1118 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "b69be1accf544c268fc7889831dbdfd8c9f98a05937797e84e862e184e739fbb"
    :COMPRESSED-BYTES 810 :COMPRESSED-SHA256
    "4dff4007059137163f7869654b855d9475d9ce9011c9ae4f4cddb87201845d5e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/19-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-4.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "1f66cc18060d1bbbaf6986db1236750191f92287fd2195c988c5182536b8665b"
    :COMPRESSED-BYTES 1428 :COMPRESSED-SHA256
    "a2e306612859660f4a66927719e9e859b27e335f0adc8b01af04c2256508e9ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/19-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1710 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-3.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "556cf4fc07ad0930d0360ac8147dad402d7a8b2b502152e4f1b60157609611ab"
    :COMPRESSED-BYTES 1400 :COMPRESSED-SHA256
    "d83e1c0e7aa42da16b0bee7b0451ce1917a48ae093036bb3eb600644d5514b09"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/19-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-2.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "f2838da41174c643d37b5ade090d636ef6118a916669315c2ea1d97d257c525c"
    :COMPRESSED-BYTES 1449 :COMPRESSED-SHA256
    "e7323fa78ab8ab4fa29f0a793338f38fa2dc96fd14ef0cf0d61e17b0f51d5934"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/19-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1741 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-1.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "c34986892d7ec1adf2b1f8fee17f5b37de51e925e1d17b9293f0b83d1ff4e626"
    :COMPRESSED-BYTES 1431 :COMPRESSED-SHA256
    "1f82a818904484117dda9ff9b34a78db767e59c7f1899fed723a8ed8cf54bb65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/19-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8838 :STORED-BYTES 1886 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-0.lisp.gz" :UNCOMPRESSED-BYTES 8838 :UNCOMPRESSED-SHA256
    "d73339055c5f1cb5300ea4a48a90c033c58089dde506453fe560df48693b4019"
    :COMPRESSED-BYTES 1576 :COMPRESSED-SHA256
    "f047f7a149e5732fc6d0c2b0de6f23130828cfe411bdd4dd06bf6119beddae6d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/18-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4819 :STORED-BYTES 1316 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-4.lisp.gz" :UNCOMPRESSED-BYTES 4819 :UNCOMPRESSED-SHA256
    "3e5865323d40bcff3c8129d674fc6b659604fb277981ea895f7267d19a56715c"
    :COMPRESSED-BYTES 1006 :COMPRESSED-SHA256
    "3eafc9eca0d82dc80f04bf68ca795e00483e69c05eefc9ba721646b24d25ee15"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/18-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4815 :STORED-BYTES 1302 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-3.lisp.gz" :UNCOMPRESSED-BYTES 4815 :UNCOMPRESSED-SHA256
    "e420d36ea2b2b1ee1b5d1390e8c4a00af6497dfb72ff9d7325afd4d60bf99df0"
    :COMPRESSED-BYTES 993 :COMPRESSED-SHA256
    "099f9a5d4f3dbaaf2e5d3fdd401855b291c4b8ded884c5f422ac178c96b93aa7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/18-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1257 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "fd369d18926934a91d90be9c927d30ff2b787d9f70688d008548c7fade0b3d01"
    :COMPRESSED-BYTES 948 :COMPRESSED-SHA256
    "c07078c86c1fbdadfe4133f75c5c3bc93acff166f4d143690b599fa3a9dc8458"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/18-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1261 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "e83e117b769645796e33fdc6df6fe53e094a86d3e169a202b39acadd1d903b38"
    :COMPRESSED-BYTES 952 :COMPRESSED-SHA256
    "3c78493910b520acda355fb95a1b92aa77f49861ae8fd927395bb65f36628021"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/18-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1217 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "a6d826302a4b1a373f38aa0e1de522784949fe3af22f4efb6ec7cf41cd537f83"
    :COMPRESSED-BYTES 908 :COMPRESSED-SHA256
    "762ddb19073bc5b6f4a8177d6bc06e251ded39a9840ee4e19148e2746313c3a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/16-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19928 :STORED-BYTES 2599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-4.lisp.gz" :UNCOMPRESSED-BYTES 19928 :UNCOMPRESSED-SHA256
    "d4c4e077ae6953a9a6472f9cc3ffd23111d3ba60baca9536549add1adb9209bc"
    :COMPRESSED-BYTES 2288 :COMPRESSED-SHA256
    "038e68afd8a8650ba4cc1984bdb73de939f464b685c69188074b6096937054fb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/16-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19814 :STORED-BYTES 2517 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-3.lisp.gz" :UNCOMPRESSED-BYTES 19814 :UNCOMPRESSED-SHA256
    "0b3b90495beb48b4ea4caf8e259a0aeac5556cb51024dd3b9d3b53d720f45ea7"
    :COMPRESSED-BYTES 2206 :COMPRESSED-SHA256
    "0c485249f49d8abfe208b35140e88a299181f18d09cb64536e51acd2db8335ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/16-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19931 :STORED-BYTES 2581 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-2.lisp.gz" :UNCOMPRESSED-BYTES 19931 :UNCOMPRESSED-SHA256
    "b3b18312113199150f832988be1d6c9db03408a5bf1bb7ad9c55cdb6aeafe4b3"
    :COMPRESSED-BYTES 2270 :COMPRESSED-SHA256
    "27489462b6c6efaab4c79b9dd8e8d4a3b1ea65cba78e102fadc9e4dbca5c3755"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/16-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19941 :STORED-BYTES 2508 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-1.lisp.gz" :UNCOMPRESSED-BYTES 19941 :UNCOMPRESSED-SHA256
    "9f53df3ea845f6e741e360bb9d23433f9ae80c5b4313cc75f46b9cefa6404556"
    :COMPRESSED-BYTES 2197 :COMPRESSED-SHA256
    "9ded2923d4465572eb2787833d7f14638ecbde554b2e1fc37bd89c73edb2e2e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/16-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2764 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-0.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "78554842cbbacc6e28457526111b1a58f51afd6a9b85aa4d3c8649c4612c4e47"
    :COMPRESSED-BYTES 2453 :COMPRESSED-SHA256
    "bbf29415f91b1abc5d883f0d67837b3cd3dba2cacdc22d67a352b4851d6f2acb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/15-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-4.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "8c03c241063c97113e29536775013b5543728f7d0095e5f4ad19741bd90e8852"
    :COMPRESSED-BYTES 1289 :COMPRESSED-SHA256
    "2048e10266f1ffd44368c1f539185d5db2b121b282e4a946493ce333e0619dfe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/15-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1705 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-3.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "6157c31c81b2813f0a3abec91a501fd72ef9cb18ae47fcbe5c785481c2a1451f"
    :COMPRESSED-BYTES 1395 :COMPRESSED-SHA256
    "af8838cfc55a42cd8533c2efeab0ed4abe3a6c16a4f44d9e2066fb5daa2f7595"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/15-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-2.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "144785373b3b0ffa560f1f0a47127b192e9d7302935db5182c6769059ae1e4ca"
    :COMPRESSED-BYTES 1394 :COMPRESSED-SHA256
    "bfecf3b97d434188207a08c5b000315f7eb14e880fc6bacab315e76caeb571c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/15-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1680 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-1.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "75dbc8465e11baf3fe83c8bb8fa0be4bf3111886d8bc53aa5fb32bb7b9fd972c"
    :COMPRESSED-BYTES 1370 :COMPRESSED-SHA256
    "1337e57d5fd475dc8b3a49e6b165b87f38a02952645f01470bdeca8542e89328"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/15-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8815 :STORED-BYTES 1651 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-0.lisp.gz" :UNCOMPRESSED-BYTES 8815 :UNCOMPRESSED-SHA256
    "95d7dd643eff891758fc66e95eb7e911a3d7e365d7c415ea2f481b18f9d9be3b"
    :COMPRESSED-BYTES 1341 :COMPRESSED-SHA256
    "f400058293d2e65905fda6a9e3d80ebdf4596f474e46e00479f9012d92190f07"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/14-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4824 :STORED-BYTES 1319 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-4.lisp.gz" :UNCOMPRESSED-BYTES 4824 :UNCOMPRESSED-SHA256
    "9c0cd43bfe415576c01b9c669835bbd1383aaa9b0740d8afb0a7ef567f9a4670"
    :COMPRESSED-BYTES 1009 :COMPRESSED-SHA256
    "48ae11c7eeadccddd9cccc9ed0d9a58e60c12b8b214d380694bbdf88bffb1304"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/14-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1159 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-3.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "9e57e6bab8e6d3dbb9c544de038bd8d26790e5df49e7aa5e44cd7fdc941fdadf"
    :COMPRESSED-BYTES 850 :COMPRESSED-SHA256
    "e3bf9ca2c3d448181b6e49de4d15e39eefe1cb120a60436c68463930d47a775d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/14-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1141 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-2.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "6e0c976c4aef245c73c70394e6f9ca39d273a44acf6f29a461dfdae16a681cd1"
    :COMPRESSED-BYTES 832 :COMPRESSED-SHA256
    "04adff55ef6e3e2d658ac78a5ad7e3d59e19e9b3f80df077c192f46472426d66"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/14-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1118 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-1.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "19a83e9358be421a9fe6a5810bbe9d62b6bc71216cf1873d9111cce1e6592d69"
    :COMPRESSED-BYTES 809 :COMPRESSED-SHA256
    "1925621c1af570cb250149725e9fb773238f6d5272fb5bedc28349257a2ca769"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/14-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1100 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-0.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "e697253dc0c838cd5948a4ff0adf8580aec793dc7f5aaf25c4f7a2361b23882b"
    :COMPRESSED-BYTES 791 :COMPRESSED-SHA256
    "7b80e748be68d6b79c3245d48f331ed4956d5b867bbfb6764f3e713d843baaa8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20074 :STORED-BYTES 4030 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 20074 :UNCOMPRESSED-SHA256
    "3836ea8971f6e0c8f20cda7992cb437d51ddf8932761f439d85242261289282a"
    :COMPRESSED-BYTES 3719 :COMPRESSED-SHA256
    "b5127d060f861addc1f1bec7d51e83829f3065b698b0282157ee217410adc97a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20056 :STORED-BYTES 3868 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 20056 :UNCOMPRESSED-SHA256
    "6a295d60cea7a5f727c7616bb7ef5d680561bf79c18644defda81ea47fc81c41"
    :COMPRESSED-BYTES 3557 :COMPRESSED-SHA256
    "f999692aef6db389b3042c105111e52184af97d724f6d0a89f83823f4181ae2d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20059 :STORED-BYTES 3529 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 20059 :UNCOMPRESSED-SHA256
    "4127f14ba45e4e2b2af866dfd4d2bfc56f6850a13f1e823d5d3dfd126ea02481"
    :COMPRESSED-BYTES 3218 :COMPRESSED-SHA256
    "4520e227ce245e971d02dbd064f24f0918bf78307497acc30140ebac554a2697"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20066 :STORED-BYTES 3696 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 20066 :UNCOMPRESSED-SHA256
    "93d77ab66eb0b714f41dc01371827f4100501fc67a06c0939c6c39e7d6a8b50d"
    :COMPRESSED-BYTES 3385 :COMPRESSED-SHA256
    "6107c4289fb260ce5723632261d62fa64015ecd6c8e2369510844865d458eee9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20066 :STORED-BYTES 4247 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 20066 :UNCOMPRESSED-SHA256
    "6102643fb47bc04c84e00472421c631dd0b4ed5c4b00681192d5c1b486c92c1f"
    :COMPRESSED-BYTES 3936 :COMPRESSED-SHA256
    "925ef8d03a479ae267ff4b39ee1eacdf3c3c34779ea3c09d0ecfc9b3b98002c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10445 :STORED-BYTES 2096 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 10445 :UNCOMPRESSED-SHA256
    "213f1b9021650a3c68781de432b0aeaf7b85a41d9165db83e8f45726a92eb369"
    :COMPRESSED-BYTES 1785 :COMPRESSED-SHA256
    "1a8ce85270a7c137becbf8a40b257e7f46031e5cc6676d8d404db2e61d5f73a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2010 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "622575e9ccf559777c242a86eb2c0e1e259397bf9f6c79a2a9909bcb8455251d"
    :COMPRESSED-BYTES 1699 :COMPRESSED-SHA256
    "c1f09846b376a65573dfa0d885e70bd0168137634ede7cae800804150eedd69e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2163 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "1fc460cd943e3d2963c9ec5da38e20dbb36d762f43a69249771eec5576ae8eb4"
    :COMPRESSED-BYTES 1852 :COMPRESSED-SHA256
    "f8093d7e30623e3e23bda7d9af36364a450d49c33f31def1d0598ac505c32646"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2170 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "36b3b718f2e66ec82d75fdb896136eb2983bf94b29be8edde685bd9960f11f1f"
    :COMPRESSED-BYTES 1859 :COMPRESSED-SHA256
    "f253d30000d14597c8acde53a848669d3674b2bcf731ca58b89f352362d18e74"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2427 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "6868d0c72035643c9fdee44162099aa49a330343e41116bc303f46cdff06820b"
    :COMPRESSED-BYTES 2116 :COMPRESSED-SHA256
    "84270c36d7c3a16bedf0a05d6344d8c38e9f7b88ec14c15d893dbe004a6e5ee4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1338 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "6dfd44ea9bb029f967993c0a5151c09945b5fa70bff3254087b3465c06ae9868"
    :COMPRESSED-BYTES 1028 :COMPRESSED-SHA256
    "2d052b4494e8a3c272d3ce885fdfaf1a86bb76a18b12c178c15f62504fea6554"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1307 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "a32c01b033560f2064071bc22d353f65d88761c177d82a9e0822803c37f06b72"
    :COMPRESSED-BYTES 998 :COMPRESSED-SHA256
    "7941d6755b14fe19294216477b12776ed0ba12c7b8a2a9a90e7ab1084323b70e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1316 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "bd680d547602744045185724a2a8c09843f07879e4e0c9b037a360961114605d"
    :COMPRESSED-BYTES 1006 :COMPRESSED-SHA256
    "28f25ebca678212ca52b3de5565ab3f440886b8c5591ff02c80c02dfe59d7299"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5632 :STORED-BYTES 1304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 5632 :UNCOMPRESSED-SHA256
    "a748dae447e86e66acb7a31812329578fac6d4fecef1afbc5099b2b957ef1deb"
    :COMPRESSED-BYTES 995 :COMPRESSED-SHA256
    "d57a5dc228f3ce752dc639444dc70616d1902758d1c2508dc120ac8e09ecc0f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/final/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1544 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "7c439747e9f8eed1825f6921b7bb37ea3edfa3851c5b3669eb5808f4f8ed6d4d"
    :COMPRESSED-BYTES 1234 :COMPRESSED-SHA256
    "258663868b5961756c8a89ea00c8f302b338aa501a27ba6d14936a7e180b45dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/focused-01-variant/socket-buffer.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8011 :STORED-BYTES 2280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "socket-buffer.lisp.gz" :UNCOMPRESSED-BYTES 8011 :UNCOMPRESSED-SHA256
    "96a1f8b314fa33a4887c984abe03390e3004e5b6fed862183ee778ddcc586d31"
    :COMPRESSED-BYTES 1961 :COMPRESSED-SHA256
    "590f17b445bcbf207dc47b0c25c39ee6278c4ce5477b99fb3fd3940a2615146f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/focused-01-variant/native.lisp"
   :STATUS :OK :ORIGINAL-BYTES 54283 :STORED-BYTES 11810 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "native.lisp.gz" :UNCOMPRESSED-BYTES 54283 :UNCOMPRESSED-SHA256
    "5a2a7314faf88388faf740c05f4b9c213b4bfb1ec339540aede6606e1f3952f3"
    :COMPRESSED-BYTES 11496 :COMPRESSED-SHA256
    "5347d62dfafbab545e21c566e2dc46eb4eb3ddbd267ca2acb24415471c5399cd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 52031 :STORED-BYTES 7723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 52031 :UNCOMPRESSED-SHA256
    "4450441c43b3b3d76270d70bd1df91dc790976cda432559c6258909c9bf5b2df"
    :COMPRESSED-BYTES 7407 :COMPRESSED-SHA256
    "7c54d98f531b8a72573739e61fe6f2c41de59977ec827ac6c43de5fd3bdfb52f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 51842 :STORED-BYTES 7580 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 51842 :UNCOMPRESSED-SHA256
    "a5ab5919c09c65110b77e3325a134557934073d45c7d8a665473c1130f40a559"
    :COMPRESSED-BYTES 7261 :COMPRESSED-SHA256
    "0ef809315b0c1e2a580a52c15a2f417b26d48c1773bc982a9ffe1b266a82ab78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/066-latency-66.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2726 :STORED-BYTES 884 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "066-latency-66.stderr.gz" :UNCOMPRESSED-BYTES 2726 :UNCOMPRESSED-SHA256
    "148667f7337287f2861c7ee11c87ba588e0e91dea0d3959ad7df5edb3e4efd8f"
    :COMPRESSED-BYTES 563 :COMPRESSED-SHA256
    "ba4b6c4c05c7d5ff67086fe7be6f4510ac0243cbf222d7a66981687c68bae638"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/065-latency-65.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2690 :STORED-BYTES 800 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "065-latency-65.stderr.gz" :UNCOMPRESSED-BYTES 2690 :UNCOMPRESSED-SHA256
    "714165bb327745f38cc2c0592d1f01f6fbe04375372e6ec4054020a51cbd4fa1"
    :COMPRESSED-BYTES 479 :COMPRESSED-SHA256
    "cfb571ddff5f87042814c19e00a340c3843b97a599931b28fe1f18fe74f84576"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/064-latency-64.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2716 :STORED-BYTES 879 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "064-latency-64.stderr.gz" :UNCOMPRESSED-BYTES 2716 :UNCOMPRESSED-SHA256
    "01531c94d159064089c84b2cc1288b15a012b1b9d9e682769ac01da3a7a3e36f"
    :COMPRESSED-BYTES 558 :COMPRESSED-SHA256
    "155409eef1b92ef1904ff3524efae979775b038e879d24d20b08d00e3cf4d399"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/063-latency-63.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2689 :STORED-BYTES 857 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "063-latency-63.stderr.gz" :UNCOMPRESSED-BYTES 2689 :UNCOMPRESSED-SHA256
    "a9c8423e2ade199ebe4287d6f3e03660452d34ee07b4ebd72cd32f98bb740944"
    :COMPRESSED-BYTES 536 :COMPRESSED-SHA256
    "9afcb4e430a6eb8586d6f3dafca8560cb46b656f9d8a03aab92e731c021509e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/062-latency-62.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2697 :STORED-BYTES 873 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "062-latency-62.stderr.gz" :UNCOMPRESSED-BYTES 2697 :UNCOMPRESSED-SHA256
    "ab1b21e6b21ecf592384ce1dc0ed489479c9db3773f78b53304a4ba3e9c597aa"
    :COMPRESSED-BYTES 552 :COMPRESSED-SHA256
    "7bedc021e60b5e1d493d35bf85d14d83fa266a9865f87071cc2856cd7c3f08b0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/061-latency-61.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2651 :STORED-BYTES 840 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "061-latency-61.stderr.gz" :UNCOMPRESSED-BYTES 2651 :UNCOMPRESSED-SHA256
    "045c86704f8e806c3b0a23087406500ff0cce2595b6d3c29ae575733d8095366"
    :COMPRESSED-BYTES 519 :COMPRESSED-SHA256
    "ff92c717fdb7cdc781ef056741216e7d9290a9379d2741ab9e669c47a4b09e9c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/060-latency-60.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2680 :STORED-BYTES 857 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "060-latency-60.stderr.gz" :UNCOMPRESSED-BYTES 2680 :UNCOMPRESSED-SHA256
    "79fe777bc029ad2126649211bf013c51a5b7e5f6403b6f0ca034a92d5250d74f"
    :COMPRESSED-BYTES 536 :COMPRESSED-SHA256
    "8791bc5ba3f0747048d192d638ead71772412f6a7717481c0b6e320ab115dc66"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/059-latency-59.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 831 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "059-latency-59.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "756ba3b4817740e8da0296c2aea91424ace7e70ec5cf9b4f5b238570d9f6cc37"
    :COMPRESSED-BYTES 510 :COMPRESSED-SHA256
    "976490cf8f1f045034b285db275ff2ca9b3af64d7c45e43f694bc5ccb29ac24a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/058-latency-58.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2653 :STORED-BYTES 837 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "058-latency-58.stderr.gz" :UNCOMPRESSED-BYTES 2653 :UNCOMPRESSED-SHA256
    "3e7afc991979d02a18143c3615550a77ef7f08051d6b04e30eb3ff658c6d1f41"
    :COMPRESSED-BYTES 516 :COMPRESSED-SHA256
    "ec66bfc551bf9d6698515d760611167c603f4bb215fb5e9880083a581501914f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/057-latency-57.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2613 :STORED-BYTES 827 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "057-latency-57.stderr.gz" :UNCOMPRESSED-BYTES 2613 :UNCOMPRESSED-SHA256
    "9b5b46d0766be1f38695625d43937c9adac06d6d511f54f060ff2682aacac01b"
    :COMPRESSED-BYTES 506 :COMPRESSED-SHA256
    "69d7cce61a08b480710ab169992be3761495d564fa75ff19ca21a3147d7daa33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/056-latency-56.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2685 :STORED-BYTES 797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "056-latency-56.stderr.gz" :UNCOMPRESSED-BYTES 2685 :UNCOMPRESSED-SHA256
    "0382d78e24b66d0a7a5787b54739d46aad50e82d1458d4eb7b43ab2b45f0f375"
    :COMPRESSED-BYTES 476 :COMPRESSED-SHA256
    "7ec29d8786aad1bbd7b8915f5beb5ab336c84a0bd70ef6eb3807a1eb42f82711"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/055-latency-55.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2655 :STORED-BYTES 773 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "055-latency-55.stderr.gz" :UNCOMPRESSED-BYTES 2655 :UNCOMPRESSED-SHA256
    "388fb737cc1ac07db5a77f8b174c3fd1ca212a9dfd1313f6704048acdae244c6"
    :COMPRESSED-BYTES 452 :COMPRESSED-SHA256
    "4db8b86333d0b63dc9dc2c85ccf16d195798d92cc87f415656411da98f83fca0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/054-latency-54.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2666 :STORED-BYTES 787 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "054-latency-54.stderr.gz" :UNCOMPRESSED-BYTES 2666 :UNCOMPRESSED-SHA256
    "769bbc53f3d8c4230377a00ec02371046a8b69800dea882ee1621843b9849ffb"
    :COMPRESSED-BYTES 466 :COMPRESSED-SHA256
    "c4662d48ae5b2c5aedee73239216f677d54cd2497029b22e79b14d06db89c166"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/053-latency-53.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2635 :STORED-BYTES 766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "053-latency-53.stderr.gz" :UNCOMPRESSED-BYTES 2635 :UNCOMPRESSED-SHA256
    "e0bc13b93b034e39ed1a587646e40b31c263b9fe5c20aba1daf82eeea88fe835"
    :COMPRESSED-BYTES 445 :COMPRESSED-SHA256
    "6db5e18679b0bb4b8fd3c65700ef2d1884042ef3576963aacac338b567c1f1e4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/052-latency-52.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2656 :STORED-BYTES 785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "052-latency-52.stderr.gz" :UNCOMPRESSED-BYTES 2656 :UNCOMPRESSED-SHA256
    "c82507017d290e755561d307c6c85369367f5866927dfdb8a52bde1d08978524"
    :COMPRESSED-BYTES 464 :COMPRESSED-SHA256
    "046f98215410bc69701b08c93035d677228bf88b6e692ca4956690df7ce57b2e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/051-latency-51.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2631 :STORED-BYTES 766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "051-latency-51.stderr.gz" :UNCOMPRESSED-BYTES 2631 :UNCOMPRESSED-SHA256
    "b0a0f7360b42f0a51c52f9ace00d4a439a2f41bd56f463c74949690dd2fef3f8"
    :COMPRESSED-BYTES 445 :COMPRESSED-SHA256
    "963f146c99670d87a29a1f6c840562b4cbaad9c370d4349e958ad4d3c83c8b37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/050-latency-50.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2642 :STORED-BYTES 760 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "050-latency-50.stderr.gz" :UNCOMPRESSED-BYTES 2642 :UNCOMPRESSED-SHA256
    "60425448497dbaa1867fbfd910d530a8262a787adf3ad610ca4ec5ff3b9d81fe"
    :COMPRESSED-BYTES 439 :COMPRESSED-SHA256
    "2b35635ffbc32da40ad279c3ae5555396f752fde6f35b9961a9ebce2ac29aebf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/049-latency-49.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2617 :STORED-BYTES 763 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "049-latency-49.stderr.gz" :UNCOMPRESSED-BYTES 2617 :UNCOMPRESSED-SHA256
    "22292c277f4613b3e4c5b393c488ca7e700ddf8ae25e84c7bd4e1fa29144d166"
    :COMPRESSED-BYTES 442 :COMPRESSED-SHA256
    "f57f8aacf4bd113bea03b73c590fcfa95dc23fc1292b1eebb73a246717477128"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/048-latency-48.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 794 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "048-latency-48.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "09ecf690e7fcf96ba7498d8160ec78679459078cd54bbb87a0d9f5a24a95fba1"
    :COMPRESSED-BYTES 473 :COMPRESSED-SHA256
    "6f9673c0f7d980aa6061834989eb35f485fbb5056639be4aa53c2dfc95e02322"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/047-latency-47.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 744 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "047-latency-47.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "f89a2d68ff87b972dd8f96022fcdf32660eb88659bfff69cf4bbfa4b3ecc673a"
    :COMPRESSED-BYTES 423 :COMPRESSED-SHA256
    "2d3b83c06fbe334f5873940db29bcc1bf0d90c1506dd5ca984297ad8a83f5dea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/046-latency-46.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "046-latency-46.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "0b4507f7b3ec34b403c982593256261dff7b701a07f1e1fd69681a2512543b17"
    :COMPRESSED-BYTES 425 :COMPRESSED-SHA256
    "9180456332323638e052bfae0dc20a79f544567814b0ff80081e584e356158ba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/045-latency-45.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2575 :STORED-BYTES 737 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "045-latency-45.stderr.gz" :UNCOMPRESSED-BYTES 2575 :UNCOMPRESSED-SHA256
    "6c97b34eacdfb5ef17eafed0d193a62c0e1e80137161d1c69d964b26a1c24da8"
    :COMPRESSED-BYTES 416 :COMPRESSED-SHA256
    "ccba8fc2a4be5ac74c3e9a7fcfa4958a8666f73471e398a80de910d0f9908792"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/044-latency-44.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 784 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "044-latency-44.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "ad9fe9542c35e3f937df2f790cffe848c6c651bd6c53984c6da542af200417a3"
    :COMPRESSED-BYTES 463 :COMPRESSED-SHA256
    "bf033c8800dddaaad25cf8f809da5dbdd31c279a2192c3ffcbef93031782717b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/043-latency-43.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "043-latency-43.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "d676ebd54915b612199f92153b677c338ac733c42dc458ce23261f05e138bfe4"
    :COMPRESSED-BYTES 428 :COMPRESSED-SHA256
    "961f4b0e6418ea998120b30b0585998596c6b551061652c9264d166670e2ce78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/042-latency-42.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "042-latency-42.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "09b2627053906ca97d1c2a923ca1f97f9c0cf864d81e9b71941bfad018bbed6c"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "072569b05eb2fadc17c9bd111b7d8b76ab6476bbf8e6edab71c0331c774b3391"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/041-latency-41.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2570 :STORED-BYTES 731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "041-latency-41.stderr.gz" :UNCOMPRESSED-BYTES 2570 :UNCOMPRESSED-SHA256
    "77a76dc760fec31e2ef58e48327341c6f84d47b8a6a31c5b26dca8e6b5981dcd"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "d9015078157d0d6e2f879986534919f027d8c58db899972fc03dcc50a524b8a8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/040-latency-40.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "040-latency-40.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "7d4fce7337930244423c2f60c43325bb4aac188d061cdfec511323e3aeff47fa"
    :COMPRESSED-BYTES 460 :COMPRESSED-SHA256
    "510e5d094d9a0d1efce8c25bb964d4b401883dc0b061e17f88163d41719dee52"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/039-latency-39.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 751 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "039-latency-39.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "2ecec0b587a09711e960c42a6b0171a0b2253622fd525abb2c858377b830f12a"
    :COMPRESSED-BYTES 430 :COMPRESSED-SHA256
    "85c81a5d674ea74d923528a7d59122a39cd921ba595a09e984bf62ff4cfe65ac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/038-latency-38.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "038-latency-38.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "7a990ee0c314627acb7a8b1971167054f7c9aeaaff948ad796e4077405126671"
    :COMPRESSED-BYTES 426 :COMPRESSED-SHA256
    "b4b5c0e45f299e9081883ff921dcda1c11f796debef7953b6a93f606b54d25bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/037-latency-37.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2568 :STORED-BYTES 739 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "037-latency-37.stderr.gz" :UNCOMPRESSED-BYTES 2568 :UNCOMPRESSED-SHA256
    "d8772bb32b54c44530d89c4a39568cd64476da65822e98216f3833d6894c2142"
    :COMPRESSED-BYTES 418 :COMPRESSED-SHA256
    "4be87112e7eff067110201629ffd7fcb51c95cee9cd00ae9d6b20fe8a06a3492"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/036-latency-36.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2629 :STORED-BYTES 737 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "036-latency-36.stderr.gz" :UNCOMPRESSED-BYTES 2629 :UNCOMPRESSED-SHA256
    "74024f4cad669bb81e4d851fff6134940caa597e9aa73180a7ddb1c82fdb8d64"
    :COMPRESSED-BYTES 416 :COMPRESSED-SHA256
    "9e545c518a63b4587891bfe73271c082a08251bddd237caec473e391d3fe7ced"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/035-latency-35.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2615 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "035-latency-35.stderr.gz" :UNCOMPRESSED-BYTES 2615 :UNCOMPRESSED-SHA256
    "a03b5a475f3167aeb341facdae9aaf2c0bc1160811415359792035ff7c7d85c1"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "85acb49be69e6bc3920955eb326a5371ea1620e084fd2778c63e2b34b3283217"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/034-latency-34.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "034-latency-34.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "7ed772a880b02b96d1ece0a3bf039c529eea1e45f8aece6fc71be223ec69c8b7"
    :COMPRESSED-BYTES 402 :COMPRESSED-SHA256
    "79d9bdfad9c85adf55e561baec5a209426dbbe236a8f0f843d4614fc8f9ff683"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/033-latency-33.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2595 :STORED-BYTES 718 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "033-latency-33.stderr.gz" :UNCOMPRESSED-BYTES 2595 :UNCOMPRESSED-SHA256
    "e2aa3327194c4e9329ac5fe86d02601d50e333f9ae5f0087221ed223aeba6f6c"
    :COMPRESSED-BYTES 397 :COMPRESSED-SHA256
    "218606e93c6945aed38b791d455c3a82b91888a855d8bd183de179164dbe37cc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/032-latency-32.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "032-latency-32.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "defcda103966f882fdb1cb42eef469e22d93c2a919c79f596afff4a2fe6b17b2"
    :COMPRESSED-BYTES 412 :COMPRESSED-SHA256
    "939c975da633b98d54d2f55967c3a2f5b3c62fe09a3ef14afb3b20508b73cd73"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/031-latency-31.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 729 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "031-latency-31.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "04aa3cb693f3e6926a9c932f320a9721b12053487fa72180b732aa809060c422"
    :COMPRESSED-BYTES 408 :COMPRESSED-SHA256
    "22437d0621f7bab38cad08bd108dd6224470dc4553972889648c3c02ab239e30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/030-latency-30.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "030-latency-30.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "6e518d1d7e35cfc47acf4905821c41cfe03e11813cdd302ebb4c41f260118e06"
    :COMPRESSED-BYTES 400 :COMPRESSED-SHA256
    "050bc01b305eed99c86d9db55801959d0630f9bc1a86f828e47667689a117828"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/029-latency-29.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2586 :STORED-BYTES 721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "029-latency-29.stderr.gz" :UNCOMPRESSED-BYTES 2586 :UNCOMPRESSED-SHA256
    "74b36356ac30f9f54018678ad9048b937996779ce1a98a3a444ac322e06471bc"
    :COMPRESSED-BYTES 400 :COMPRESSED-SHA256
    "c731a7b53529656e945b7e00cf78d86c5971a42fa5182e6c4df3b2725028efab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/028-latency-28.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 724 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "028-latency-28.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "157ea59faba9a45e901695239706825987f628488c196c2c411096331a5a4a69"
    :COMPRESSED-BYTES 403 :COMPRESSED-SHA256
    "b218ae5e5b89d1eddff270e44d8592bf92ab0b36f5a79824dc5163574d0e8e53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/027-latency-27.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 727 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "027-latency-27.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "57aeccf39318b44644a2f50f4ebb443daf6cf07dd6afad93df9c99ac2c341cbe"
    :COMPRESSED-BYTES 406 :COMPRESSED-SHA256
    "128a8af54b8c938bac357a0ee5c70c5ff04727500f5a1c6415520f128f129b20"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/026-latency-26.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 717 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "026-latency-26.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "2affa9ee2f922bb78477669bbcc87a28c7561fcae3c93e4439dde1682cc5c875"
    :COMPRESSED-BYTES 396 :COMPRESSED-SHA256
    "a798a976b0d379b75d74aac4e2820d0dabfc122f9682897701898f3770829fae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/025-latency-25.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2585 :STORED-BYTES 713 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "025-latency-25.stderr.gz" :UNCOMPRESSED-BYTES 2585 :UNCOMPRESSED-SHA256
    "2a85fdc79cf616871804c7c906018dc9aaba0a981c743b552d0f7a0e75da5b70"
    :COMPRESSED-BYTES 392 :COMPRESSED-SHA256
    "cd3529a4d9aeeedc4f747ebd7c5931c5b41caddf2ed9e1826ade9f7b6a47d2d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/024-latency-24.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 793 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "024-latency-24.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "e3f56a68d9ce3d6dd0c1cb6b5114c263c2c11e73215ef9901385f8fc445303a5"
    :COMPRESSED-BYTES 472 :COMPRESSED-SHA256
    "c89cb6e88b4550b09bf75cbc747c6d6becd142eaa7ad6c43ba7bcb01debf6822"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/023-latency-23.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "023-latency-23.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "5b455e730c12d9d8a4d45469081bac459d7b2b2b2003dc0ffaf7e3bd2d6eaaec"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "ef8c4edc4774f9e7008f6d9fcc184fe93ce822e8cffa28ca632213f0117a6b9f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/022-latency-22.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2604 :STORED-BYTES 743 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "022-latency-22.stderr.gz" :UNCOMPRESSED-BYTES 2604 :UNCOMPRESSED-SHA256
    "60f0665fae12b26d5f3e76d20e5b73116e0a0a554e226bbb2cdfe08be1b16b7f"
    :COMPRESSED-BYTES 422 :COMPRESSED-SHA256
    "f60fd0ae3c5769f1ecfdbae260224afc0bd1feb92660df9357eba6bcab648af3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/021-latency-21.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2575 :STORED-BYTES 738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "021-latency-21.stderr.gz" :UNCOMPRESSED-BYTES 2575 :UNCOMPRESSED-SHA256
    "b93eabdb7e8a839d6730b72a813496e707aa984fedb0b5195c83e583516187ee"
    :COMPRESSED-BYTES 417 :COMPRESSED-SHA256
    "58b700229addd6e05fa83eaa0d9e5e2fa264f06e7bdfc6c16ff8ccb8090b7313"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/020-latency-20.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 787 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "020-latency-20.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "365e205deb404687ac1b4f83be1277196cd0159880054756d38b2bf05d585e87"
    :COMPRESSED-BYTES 466 :COMPRESSED-SHA256
    "9d6c016f743392ac81241a43f250649ada5ddca6502b475c493175b141992dbb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/019-latency-19.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "019-latency-19.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "7855ec7ead0bffdca9dd21dc688bdfdb910abed80db1cc78083df5bea2ba8604"
    :COMPRESSED-BYTES 425 :COMPRESSED-SHA256
    "b89be56770b2cc081fff0ee921c23ff708d1c1223dcbafd27281a2e0a745f068"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/018-latency-18.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "018-latency-18.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "b343588e6a4b5a43cbd6248e28e4b6d3da9757fa6bcd933c41c5697cc4e929d3"
    :COMPRESSED-BYTES 421 :COMPRESSED-SHA256
    "14f1b1ee4ce51382ac819f7d252870814e1d54dd72c2f3995013c490705c8d4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/017-latency-17.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2571 :STORED-BYTES 740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "017-latency-17.stderr.gz" :UNCOMPRESSED-BYTES 2571 :UNCOMPRESSED-SHA256
    "af43d018637a50c6be3f59054e418cd075dc6493470d9a629caa2d1d20d29401"
    :COMPRESSED-BYTES 419 :COMPRESSED-SHA256
    "8e2895c03701a2bc266f8f80d274e50092cd421b8c86a1ff46df4750fb550ca6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/016-latency-16.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2640 :STORED-BYTES 795 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "016-latency-16.stderr.gz" :UNCOMPRESSED-BYTES 2640 :UNCOMPRESSED-SHA256
    "87b3b2efef243fdc4312ef54fc815ed5653c0975d5ec476b7736bdff367ad28f"
    :COMPRESSED-BYTES 474 :COMPRESSED-SHA256
    "4b9e189461138faa41d0f90193c08cdd445ed0461469cd50ff56870b0f7e8455"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/015-latency-15.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2605 :STORED-BYTES 749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "015-latency-15.stderr.gz" :UNCOMPRESSED-BYTES 2605 :UNCOMPRESSED-SHA256
    "715f72583e8e965d813ab815bb8fac3ffcc74799e1abd2169b46826f3890bf53"
    :COMPRESSED-BYTES 428 :COMPRESSED-SHA256
    "fb61732a6aa1d449947b403a935739301aa6c7f0513d1850bb2439a90786cd8c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/014-latency-14.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2603 :STORED-BYTES 746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "014-latency-14.stderr.gz" :UNCOMPRESSED-BYTES 2603 :UNCOMPRESSED-SHA256
    "7e5b7875107bbc9098c5d1b4ef9b5e2a6a796ac3d38b6ece074d95b9bd69c4a9"
    :COMPRESSED-BYTES 425 :COMPRESSED-SHA256
    "6f0b2411e1a9655b7008534d7da265737349b017ba67abb8be0821497818f30c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/013-latency-13.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2565 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "013-latency-13.stderr.gz" :UNCOMPRESSED-BYTES 2565 :UNCOMPRESSED-SHA256
    "0ffbaaac0ef156d273a408e14b81da38e107741d1dcaa6715097dcff0258fda6"
    :COMPRESSED-BYTES 414 :COMPRESSED-SHA256
    "5887aeb313fe061508beb042acbca951efba9bf2349ab3e062f532ef31673c2a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2630 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 2630 :UNCOMPRESSED-SHA256
    "48c3c72d12e96b8ab85757c13df9e9295b41c70094920a34c3e6902bdbbe0dad"
    :COMPRESSED-BYTES 414 :COMPRESSED-SHA256
    "ab1796f5180b90eeeab84abb11a0a87c7f0353ebfb0479a76a74581d84b45e5e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2615 :STORED-BYTES 728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 2615 :UNCOMPRESSED-SHA256
    "4fea37362b064da4191936e948451c2177716b8cb6a411194556b43f6c455ff0"
    :COMPRESSED-BYTES 407 :COMPRESSED-SHA256
    "3e64bc2900a3f922b66d854b5f41fa8af28b24c8b8c539208d78edceafdf5bdb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "011c323984116934731248fdee5a28fa5405d0348e8f81d97c945d4d639efe1e"
    :COMPRESSED-BYTES 400 :COMPRESSED-SHA256
    "0c3e7fb2d86e4bb06ee83d3a59b4cf50ac0cbbb19858de9d2c311be2a15918c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2595 :STORED-BYTES 717 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 2595 :UNCOMPRESSED-SHA256
    "5d149b4163b6fd2ee5a2a41901b6b85eae63f6952e5f814dd5c2b556a6b24d14"
    :COMPRESSED-BYTES 397 :COMPRESSED-SHA256
    "469954713db90df3d496dfc7bbafe5d253d41fc8288ac166813bdfe8ca7f0297"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 729 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "8598c299553866c1a1bf5de92728cab6e7bfa208e2fb0f105b5245ea3a4e6db2"
    :COMPRESSED-BYTES 409 :COMPRESSED-SHA256
    "47ed9a5d342559c64cc9fac584e2d869c6471bfdad5c97476628c8e82fd6914d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "4e79c313a6d8e8090423e256a9446b1094657ee224f4ce171991c6aca340bb1c"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "28f10e5929befc37d287485104a6b8924469395c2b1cac3818059298aaf1cc3b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "d9a37e0bfdd2f304b98726168ca8e1b41d7f4193cfb1cffe48fff02ad7398746"
    :COMPRESSED-BYTES 410 :COMPRESSED-SHA256
    "d2ee28cfb8de1ef3fcabd9d6f9e1b32b67fb9b59f9a20635dab0a9a103b50513"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2585 :STORED-BYTES 718 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2585 :UNCOMPRESSED-SHA256
    "24dc3187cf452fa503a6c950b977dc68c871c8c2d0f3bcc9557488736bcb0346"
    :COMPRESSED-BYTES 398 :COMPRESSED-SHA256
    "099a5ab54d343881954ca01d66dcc0512f1b31fba7ff50966d437cda4983f64f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2620 :STORED-BYTES 735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 2620 :UNCOMPRESSED-SHA256
    "f026367eda9b5789524f1c2dfa67defd42c21495f0d9a2283795f72d98fe3e5d"
    :COMPRESSED-BYTES 415 :COMPRESSED-SHA256
    "a7989925b3b50008506d34e52acf519c3adad7825835834e1e93461c772eb477"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 729 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "b6a43d8bda56a84e9442f646be9ebf4e9ceabf778d58ca2916b7931408b25c0c"
    :COMPRESSED-BYTES 409 :COMPRESSED-SHA256
    "dac82ab9057e207548bbd80e3aaede862fd9f5d91b834de25474440ecf05d0bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2610 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 2610 :UNCOMPRESSED-SHA256
    "a9873e9e30d3bbba70e2a149d55f43db0da85c5efdc43c2d1e43a89f56eeda17"
    :COMPRESSED-BYTES 400 :COMPRESSED-SHA256
    "cc80bea3cac16dd7615246eed6328259e452b5e1fb9ae55780ba75b81c712090"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2589 :STORED-BYTES 732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2589 :UNCOMPRESSED-SHA256
    "f072c699c624ffc005412ec190ab2c98fe585dd7ff90330a71f5f88a8b303e1f"
    :COMPRESSED-BYTES 412 :COMPRESSED-SHA256
    "3121a322f848eafef05090adc05f5974ec8e252fd4b9679cec71bd98ad551132"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18028 :STORED-BYTES 2570 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 18028 :UNCOMPRESSED-SHA256
    "23d380762a60143598898521e4b1929ace518caad675b1e577d270e2a706a874"
    :COMPRESSED-BYTES 2260 :COMPRESSED-SHA256
    "0f2db33030ec784922dc3e64094f85816c8e0e32dc4951169c2a1bf686b3bf54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17936 :STORED-BYTES 2552 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 17936 :UNCOMPRESSED-SHA256
    "40343cd4a5dce263be56e76dc62ac4f3e6ffe315c0ce1e9c278b41d03c962dd3"
    :COMPRESSED-BYTES 2242 :COMPRESSED-SHA256
    "f84dc1264c3c0cb25d1fef455707ceb695ab9e42f25cf38ae7002b935d32e042"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18031 :STORED-BYTES 2614 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 18031 :UNCOMPRESSED-SHA256
    "0a62f4813e69f968060a5c135281ffacbc93e97348c72e6b59aa77c9a7eb909b"
    :COMPRESSED-BYTES 2304 :COMPRESSED-SHA256
    "2e9959c9ae64383bd8fd54dd824c3ec1b2597d1741496aff29f87107007e8a21"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18227 :STORED-BYTES 2537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 18227 :UNCOMPRESSED-SHA256
    "d0306952d302c6e577815c8c106879a8e7944d8b15a9f7ce548b21301fa8b084"
    :COMPRESSED-BYTES 2227 :COMPRESSED-SHA256
    "d92ea01c6274c3e5790f96fb72767e4604d26ad4a110cb63ccc4245e692494a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18572 :STORED-BYTES 2902 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 18572 :UNCOMPRESSED-SHA256
    "76d228c0eb33807b4bd42709ae3d45fdb65c4033570058c03320baa432f581b0"
    :COMPRESSED-BYTES 2592 :COMPRESSED-SHA256
    "2c75aaeee5d5a8a6de4008c1ec889c9fc70aa91aec01dc22945228ffee98cbb4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1772 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "4338caa92ce25b74582b1988db2c1521080c0d9df13b791a4b599ae1271bd6a4"
    :COMPRESSED-BYTES 1463 :COMPRESSED-SHA256
    "588e29d801548393c8161f9ea426d5ddb9e58a6e8a900bcf1dd817e2fdad3ff4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8827 :STORED-BYTES 1672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 8827 :UNCOMPRESSED-SHA256
    "93213ac8c2d3013dfec71a34b5d10d5fbb152fb5d5a37e24a1c907c9765a4f12"
    :COMPRESSED-BYTES 1363 :COMPRESSED-SHA256
    "f2a36610e3099529975989c011c370aac4e4460ed21254166350ea8a6454764d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1706 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "26b52334a76f11065d750a6aad2ad1dc0958943c44cce3411b8e88e09c2232a9"
    :COMPRESSED-BYTES 1397 :COMPRESSED-SHA256
    "49c9ad5303375f8c827402affe02e98e168d14b0f8f6775bbcd5c457f9893343"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1663 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "84448ef174efec6478d855d58c1a182cf5c8a4801da9b025e4f932869a545669"
    :COMPRESSED-BYTES 1354 :COMPRESSED-SHA256
    "cb60901be3a923e5b553c1c0bc5a6f6b56e9f55e530ec8abc441e137a297d416"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8828 :STORED-BYTES 1686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 8828 :UNCOMPRESSED-SHA256
    "1d42403609a37ebce925996197735f9900582ad1f4a10674ae3ed1fcfaaf2fa5"
    :COMPRESSED-BYTES 1377 :COMPRESSED-SHA256
    "5d5697b44e4c47dc9e786284e8159505aed1d3ef44ed8970d4e4398f7bec3360"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/66-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30046 :STORED-BYTES 11497 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-4.lisp.gz" :UNCOMPRESSED-BYTES 30046 :UNCOMPRESSED-SHA256
    "f2c4fd810f7cf27ac922fe4debda16873d747dbfc349b812ec2827e8af184219"
    :COMPRESSED-BYTES 11185 :COMPRESSED-SHA256
    "8ea591bdd1e573989019589cc4809b9220cacfa684fbfae6b428824c8b39d171"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/66-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30172 :STORED-BYTES 11555 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-3.lisp.gz" :UNCOMPRESSED-BYTES 30172 :UNCOMPRESSED-SHA256
    "1a8bb54a30e9df71c107f2367fd4dc0e3310e795e9188ca832a6ce14c4989de9"
    :COMPRESSED-BYTES 11243 :COMPRESSED-SHA256
    "bde32d7d1ce7f6207aba6cb3470b198a99cb2d7c98d44812b53eddd29bcfd60a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/66-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30258 :STORED-BYTES 11661 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-2.lisp.gz" :UNCOMPRESSED-BYTES 30258 :UNCOMPRESSED-SHA256
    "fd2d7409a678efc1f9730ebc49a8137e80c850a84cd54e535b68ab8a88356f3d"
    :COMPRESSED-BYTES 11349 :COMPRESSED-SHA256
    "eaec78624a7ae3bd77b6d9b9210ff7d3915664209063ca32d3a87ba6cd2047c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/66-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30440 :STORED-BYTES 11522 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-1.lisp.gz" :UNCOMPRESSED-BYTES 30440 :UNCOMPRESSED-SHA256
    "cc9c82ad1514def465bcb94aa951759db6f28a940f41a68de1ff4b74ba199cbe"
    :COMPRESSED-BYTES 11210 :COMPRESSED-SHA256
    "c6545e93df3f75e86b59e3ff4487bb16e84fc5696ba57602279250ff90e6a7fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/66-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29530 :STORED-BYTES 11411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "66-0.lisp.gz" :UNCOMPRESSED-BYTES 29530 :UNCOMPRESSED-SHA256
    "e9fd3fb7e8e3f30af196dd924c34042b93538d70159729526aff9959cb671137"
    :COMPRESSED-BYTES 11099 :COMPRESSED-SHA256
    "9603b3fafbacfe4799d6ca78cbf153eaa7274a2ab85c42af638d6d7ca3618baa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/65-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29642 :STORED-BYTES 11994 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-4.lisp.gz" :UNCOMPRESSED-BYTES 29642 :UNCOMPRESSED-SHA256
    "c32e72a87bcf224a8cf2af0aa0e5e5035722aa4be8ae58263cee23b0c61194ad"
    :COMPRESSED-BYTES 11682 :COMPRESSED-SHA256
    "dca6386ea268eab800bb8b54fc7fc7826f2b235419435736fca902d9abf15397"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/65-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30018 :STORED-BYTES 11326 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-3.lisp.gz" :UNCOMPRESSED-BYTES 30018 :UNCOMPRESSED-SHA256
    "14d0712bc19ec9aac5917aa71860852766aedd44dcf7b9b093608b06150c63db"
    :COMPRESSED-BYTES 11014 :COMPRESSED-SHA256
    "1d8cc718bf851df601285be12e89c87775ffba6d047e7c65bec5021e1bdec02b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/65-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30235 :STORED-BYTES 11252 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-2.lisp.gz" :UNCOMPRESSED-BYTES 30235 :UNCOMPRESSED-SHA256
    "292599808521a07596265cabd7eba412b34dbeee4b863de82091a7d9b5bfd50b"
    :COMPRESSED-BYTES 10940 :COMPRESSED-SHA256
    "f808b6d97cd022d6c327c174beae354e4e65958f4ff7db5fd364313d589238fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/65-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30255 :STORED-BYTES 11210 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-1.lisp.gz" :UNCOMPRESSED-BYTES 30255 :UNCOMPRESSED-SHA256
    "756c2906db1588f03abac1deb8d8642914865e33ffe2fbc63f11e6a0e116d744"
    :COMPRESSED-BYTES 10898 :COMPRESSED-SHA256
    "754e26c1ef5bdb0b18210cd780320d8bb1980fd156754dc53ef238d154c51853"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/65-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29080 :STORED-BYTES 11326 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "65-0.lisp.gz" :UNCOMPRESSED-BYTES 29080 :UNCOMPRESSED-SHA256
    "4a0946106f11bee7f89a3e8708329d3c4e1d0ca3a3505110e1794f0c76002379"
    :COMPRESSED-BYTES 11014 :COMPRESSED-SHA256
    "9bd752a8729b445fe7c0b10ede4c784c68621c3fb63bf175e535733fdb560a8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/64-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30620 :STORED-BYTES 10459 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-4.lisp.gz" :UNCOMPRESSED-BYTES 30620 :UNCOMPRESSED-SHA256
    "cf9c35e87049174e9d84583b3adcc62af2d59a385dccc202032501ba42e6f3f7"
    :COMPRESSED-BYTES 10147 :COMPRESSED-SHA256
    "b8137acebb510194cde827e3b3ea764d980d09f1dc4d9153fb73495e1aea5415"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/64-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28851 :STORED-BYTES 11085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-3.lisp.gz" :UNCOMPRESSED-BYTES 28851 :UNCOMPRESSED-SHA256
    "7d3b80e788cc4841950c13de0d4646da71fa99ec3a4d435a491b2d754caa034a"
    :COMPRESSED-BYTES 10773 :COMPRESSED-SHA256
    "643071e5e44b7f5a5b636c267c41eae35093b227cdcfdb4e29ea8f4ee127e014"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/64-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28724 :STORED-BYTES 10932 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-2.lisp.gz" :UNCOMPRESSED-BYTES 28724 :UNCOMPRESSED-SHA256
    "3c3ee6ab5707ce1c695b3a83568f45e63f5743661e33fe992d7a5803b4763cec"
    :COMPRESSED-BYTES 10620 :COMPRESSED-SHA256
    "cf060f347c1a6325a06f0873fa05af44ea91eaad2a57580f56c0e839d6d59512"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/64-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28917 :STORED-BYTES 11263 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-1.lisp.gz" :UNCOMPRESSED-BYTES 28917 :UNCOMPRESSED-SHA256
    "73eebd6f312148d2d98017074b8583a83ae75ed2f9c676ce7a21f0f7c66898b8"
    :COMPRESSED-BYTES 10951 :COMPRESSED-SHA256
    "506587865e9bd0a562dbdca6c340484e2097f3ebf47c62a523f97f1d3d879750"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/64-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28692 :STORED-BYTES 11449 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "64-0.lisp.gz" :UNCOMPRESSED-BYTES 28692 :UNCOMPRESSED-SHA256
    "e6559f79fc8ebcc3253b91f433e2ae974ee0b2faafe0d62b702d4cc8208d9232"
    :COMPRESSED-BYTES 11137 :COMPRESSED-SHA256
    "30d75baf6ff7a5eeaa0415ea3a919336c669206bf8e08775ef32df332e4cc912"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/63-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21589 :STORED-BYTES 5624 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-4.lisp.gz" :UNCOMPRESSED-BYTES 21589 :UNCOMPRESSED-SHA256
    "a0f83d19c082305b24d81c4e629b8c3228f38a7cee7980060704f39432230feb"
    :COMPRESSED-BYTES 5313 :COMPRESSED-SHA256
    "a65c46a5233ac9d8018a5d902fd31901a69ab4697950f27ea030e84a0af6b3fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/63-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21389 :STORED-BYTES 6008 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-3.lisp.gz" :UNCOMPRESSED-BYTES 21389 :UNCOMPRESSED-SHA256
    "74fdc9b37bf00be1b1a779db9c42ff6d78b9f8042f3782b00fb1df7889e49e28"
    :COMPRESSED-BYTES 5697 :COMPRESSED-SHA256
    "fa2e89b4fd667494f2c4c50a920aa855ea8543de7f56a5abe34085c8629f69e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/63-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21511 :STORED-BYTES 5747 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-2.lisp.gz" :UNCOMPRESSED-BYTES 21511 :UNCOMPRESSED-SHA256
    "9eceff61e59d4f585496d5975b30ab2e4399fd686b27c939143a1ec9be42ec5d"
    :COMPRESSED-BYTES 5436 :COMPRESSED-SHA256
    "b9e9db13e4f716fc9a01df75d8b934d00dce68297d9e78fc1d428d49dfd08836"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/63-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21564 :STORED-BYTES 5631 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-1.lisp.gz" :UNCOMPRESSED-BYTES 21564 :UNCOMPRESSED-SHA256
    "959008001fd0618f4005dfae18c3904e7eabba4011937c5034744b17abb1d27b"
    :COMPRESSED-BYTES 5320 :COMPRESSED-SHA256
    "006bfcaa4c1ed6bab19feca0b59211362bdd7425a9af8c9af816cd5e4242dc24"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/63-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21518 :STORED-BYTES 5856 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "63-0.lisp.gz" :UNCOMPRESSED-BYTES 21518 :UNCOMPRESSED-SHA256
    "c0b41ad8b4217d073dc07fe5e27266fcda8b9c1b96ae319082f00a185e7c91de"
    :COMPRESSED-BYTES 5545 :COMPRESSED-SHA256
    "0647d77db73ecd96d1c43b75c9eaa6c73370f2f8d1a8088bbd90d3badf343c9e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/62-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14466 :STORED-BYTES 5632 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-4.lisp.gz" :UNCOMPRESSED-BYTES 14466 :UNCOMPRESSED-SHA256
    "fd24ddc1af23e630a2cf9ffea74f29f82472e22d1e55e869d933172ade36692e"
    :COMPRESSED-BYTES 5321 :COMPRESSED-SHA256
    "f01a03e460a07506070f48ce5cdf910570ed023f909f9d13260d51b4925afc60"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/62-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14476 :STORED-BYTES 5588 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-3.lisp.gz" :UNCOMPRESSED-BYTES 14476 :UNCOMPRESSED-SHA256
    "b04f2010db1a1cbd56bc64f5a2b43e0ff3e5ab1990934d9dcdfc08f1e3b01a1c"
    :COMPRESSED-BYTES 5277 :COMPRESSED-SHA256
    "bd6e74e352b7f9ad560df31d55ac04e005fa83c8e6694ed2cc002888e6c2acb5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/62-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14483 :STORED-BYTES 5677 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-2.lisp.gz" :UNCOMPRESSED-BYTES 14483 :UNCOMPRESSED-SHA256
    "772d8882358ec0a2cbdc5cd76ebe17bfdd9f183dff636144077736314e29c6ec"
    :COMPRESSED-BYTES 5366 :COMPRESSED-SHA256
    "517f26a2279a561028f4d833ce41399cb3341fdf3d642c6f59bb61b4191b583e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/62-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14302 :STORED-BYTES 5924 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-1.lisp.gz" :UNCOMPRESSED-BYTES 14302 :UNCOMPRESSED-SHA256
    "8a7a45fdc913ea14dfbf3161814bfe0256e3a6c8b861aae0aef6b9ea083d1fd7"
    :COMPRESSED-BYTES 5613 :COMPRESSED-SHA256
    "c1cca2fefe89f906cdba04c7c4f57dd2cb2a117c43bfd9c022f9cdd86afacc0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/62-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13623 :STORED-BYTES 5941 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "62-0.lisp.gz" :UNCOMPRESSED-BYTES 13623 :UNCOMPRESSED-SHA256
    "3298c742e4e594083535f53a33baa906fbf469855615db76545ef982ecf71a4a"
    :COMPRESSED-BYTES 5630 :COMPRESSED-SHA256
    "9aea1f466e34f7ec7684b6be03299d784a09d30239891fa6d90784740b6f8345"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/61-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9683 :STORED-BYTES 2803 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-4.lisp.gz" :UNCOMPRESSED-BYTES 9683 :UNCOMPRESSED-SHA256
    "e9ffbc526074309db1996ffa15c21b5326ca36fc4a4173f2824ff6acd7eb8927"
    :COMPRESSED-BYTES 2493 :COMPRESSED-SHA256
    "253cfbc20c013629fe39b6522f4255ba0432cfe8ea16c6157cecf0546f180663"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/61-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10078 :STORED-BYTES 3085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-3.lisp.gz" :UNCOMPRESSED-BYTES 10078 :UNCOMPRESSED-SHA256
    "b6619645d8163390cbf81022a41adb9ac46ac5ecdf9cef8af3b0bfb932f6eea5"
    :COMPRESSED-BYTES 2774 :COMPRESSED-SHA256
    "01eb43354f2cc8b8b6e2cd1d6e68adfd42aea1ed799da3791353afb83df72679"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/61-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10634 :STORED-BYTES 3229 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-2.lisp.gz" :UNCOMPRESSED-BYTES 10634 :UNCOMPRESSED-SHA256
    "2760c71687787bc2841d0f1c5d464c98cc93c6704f8a309950f1b14de9640d21"
    :COMPRESSED-BYTES 2918 :COMPRESSED-SHA256
    "84ca69912512e8d3f46ceac31be9f11bf5b54386963808b7527e207be9916f06"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/61-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10834 :STORED-BYTES 3214 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-1.lisp.gz" :UNCOMPRESSED-BYTES 10834 :UNCOMPRESSED-SHA256
    "13dd820a2db52d5ce7e20f0028450c50e09589eb4a705555153c7e4036a059f3"
    :COMPRESSED-BYTES 2903 :COMPRESSED-SHA256
    "edc8ec0a4cc8196493d6717198a33e0b8a349623ff10f5c078a227ab5fc9505b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/61-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10439 :STORED-BYTES 3113 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "61-0.lisp.gz" :UNCOMPRESSED-BYTES 10439 :UNCOMPRESSED-SHA256
    "86cad0ad3d460b075283df75c979814b5d7b69e494b2fa70a69fbe0ce18b55e3"
    :COMPRESSED-BYTES 2802 :COMPRESSED-SHA256
    "e69bb637d08527f3d84d7b118bfe0c96aa8aca709522ba81c504ddbde525fda4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/60-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7506 :STORED-BYTES 3247 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-4.lisp.gz" :UNCOMPRESSED-BYTES 7506 :UNCOMPRESSED-SHA256
    "9d76a73ac9f2aa583e1adb397a8a49b1379f98f038a4d6154ec9dcf924d94d92"
    :COMPRESSED-BYTES 2937 :COMPRESSED-SHA256
    "79278925ffa815d907e1e7fc30137d9e56bec78fd1b87177ca0b168557d399f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/60-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7483 :STORED-BYTES 3210 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-3.lisp.gz" :UNCOMPRESSED-BYTES 7483 :UNCOMPRESSED-SHA256
    "fbde57e7b2c020572259a2235253ae841cc2ee98977dd49417927912c3cfdc49"
    :COMPRESSED-BYTES 2900 :COMPRESSED-SHA256
    "8acf5504c20efd6a457d6a817727c136b2ac8ca490e0ec3af2a9d99fa3efd2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/60-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7344 :STORED-BYTES 3155 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-2.lisp.gz" :UNCOMPRESSED-BYTES 7344 :UNCOMPRESSED-SHA256
    "5a3df2cb0ced3e8ec594370fc55a759b286b00d83c853f4ba44535d28d391bd6"
    :COMPRESSED-BYTES 2845 :COMPRESSED-SHA256
    "e5e7bea7e8ac55d2fe6b57cf50cf098b56a81a374e7d426425bb855ca96214d6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/60-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7120 :STORED-BYTES 3174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-1.lisp.gz" :UNCOMPRESSED-BYTES 7120 :UNCOMPRESSED-SHA256
    "4be7a0fd5f406ade73dd721b1461887e86c7cfca418cb36a72d8c9138804d78f"
    :COMPRESSED-BYTES 2864 :COMPRESSED-SHA256
    "de483dea0ea2233f7d138098f9a7252ddd5516e22fc9ae17cd843dd75d63b4c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/60-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7034 :STORED-BYTES 3155 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "60-0.lisp.gz" :UNCOMPRESSED-BYTES 7034 :UNCOMPRESSED-SHA256
    "3e8c5dd369f39642238ce83e72ee8ae1c7c0196f1e866506a92df5f34710755d"
    :COMPRESSED-BYTES 2845 :COMPRESSED-SHA256
    "e0094a0456a46d2ae48f77ef2e4e07eb42c8224b725fa8f81c5920154577c076"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1123 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "8408ccd0f8393964dfed825112a420915900131a5731af4f5e9f2d006cd1e2f5"
    :COMPRESSED-BYTES 815 :COMPRESSED-SHA256
    "57674296531796364123c5ae23d6ce2d51c7a95b9459fdf05aae588cfa81f2b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1183 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "f0c8ac43aa049d7624d056c516c15d587ee6f562efc8ead1ed7569edbc754c8f"
    :COMPRESSED-BYTES 875 :COMPRESSED-SHA256
    "6aa3f46dc79e83ce3ee9b21901371d03ad2593e851574d47592c1810701ce3c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1142 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "742626d27bc228a92275b5ed8eef40a9c6b154440232057909450076e71291bb"
    :COMPRESSED-BYTES 834 :COMPRESSED-SHA256
    "c00e41152afd0fc80d1094eb518e2cb41ce420976f356e6e4d16bef599b61af2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1190 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "aef839ce17f6f9960db51d9a45d060503971e9e28beea92589a06013bbd0807f"
    :COMPRESSED-BYTES 882 :COMPRESSED-SHA256
    "6b2718d5539938eb51a70eaf44e0524869960f3762de6399597bd3ca6f3cad2d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "eea5637027817bc67da7d12201a56c46b9b5d2154cdc49f2b23b475ecf45859a"
    :COMPRESSED-BYTES 913 :COMPRESSED-SHA256
    "4d1347ea221cd38d3e224f24d242c315d29ada74e6bd1c849dfea413db01f84b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/59-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5330 :STORED-BYTES 1837 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-4.lisp.gz" :UNCOMPRESSED-BYTES 5330 :UNCOMPRESSED-SHA256
    "a5c40562ea56cfe7ffee531374aaa0ecd47a3ac7d715a417d897026cef6f440b"
    :COMPRESSED-BYTES 1527 :COMPRESSED-SHA256
    "db0fb6e5d003ef8329b6a0870454afcf14d69c33b10ef60e0d7643d72f75b3d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/59-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5107 :STORED-BYTES 1738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-3.lisp.gz" :UNCOMPRESSED-BYTES 5107 :UNCOMPRESSED-SHA256
    "11939b39a71c765251983cb6e9b2dbeba79b3bfee8bc69298bfeadbc68fcfcec"
    :COMPRESSED-BYTES 1428 :COMPRESSED-SHA256
    "716a6eb8a40ba2a2553f80f5fce0f439cd8005d051c0f593d8e07442a8ea989f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/59-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5070 :STORED-BYTES 1669 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-2.lisp.gz" :UNCOMPRESSED-BYTES 5070 :UNCOMPRESSED-SHA256
    "1c6e5c7d0d3bdb013968edeb60b7e33dd32e43e6f4d44a66aef4b4c549932420"
    :COMPRESSED-BYTES 1359 :COMPRESSED-SHA256
    "172cacda6a003f48900355052f44023584fd5bc7a1fea392833fddeb9d3b65bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/59-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5279 :STORED-BYTES 1812 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-1.lisp.gz" :UNCOMPRESSED-BYTES 5279 :UNCOMPRESSED-SHA256
    "538c9a22785821dcd5471f4441708a097dc163b73a461d68ce19478e242c1348"
    :COMPRESSED-BYTES 1502 :COMPRESSED-SHA256
    "2245c9e64d19fd552cc6da00f0a400b1e8c9cb8663fcbe96b2b083c7bf659f27"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/59-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5032 :STORED-BYTES 1616 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "59-0.lisp.gz" :UNCOMPRESSED-BYTES 5032 :UNCOMPRESSED-SHA256
    "d0a94bc06ec6eef32e1dc1940a5622ad987795cc291eb013011690be31c6fb9b"
    :COMPRESSED-BYTES 1306 :COMPRESSED-SHA256
    "0bed84faed54070a375e0b490816f71fa4676af928b8c175f360150832b5d3ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/56-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29537 :STORED-BYTES 11431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-4.lisp.gz" :UNCOMPRESSED-BYTES 29537 :UNCOMPRESSED-SHA256
    "6d2f99554a2fa854478b6aa2390716a66fd48aa2f4c089d91b2b51d6a7595847"
    :COMPRESSED-BYTES 11119 :COMPRESSED-SHA256
    "f8b440265e47a4d7995a9e21ca069d8329f777e2c40b629bd6e98eae5a255242"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/56-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30389 :STORED-BYTES 11138 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-3.lisp.gz" :UNCOMPRESSED-BYTES 30389 :UNCOMPRESSED-SHA256
    "f4cc90c0cd092b9bdf6194103b7e4e669fe2f48e2cb3c6aeadb1c31365975bf9"
    :COMPRESSED-BYTES 10826 :COMPRESSED-SHA256
    "26aba585b6ef87cf802ec8cd2f9db9eee313a08b8161daf84788b515f3cec804"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/56-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 30330 :STORED-BYTES 11567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-2.lisp.gz" :UNCOMPRESSED-BYTES 30330 :UNCOMPRESSED-SHA256
    "abcbf9f6f15f168f0d1563d0cbfd0c59b3094faeb966cf94f0aed2cdfe115493"
    :COMPRESSED-BYTES 11255 :COMPRESSED-SHA256
    "b6f4ed0af2a4a8355a89051a46afb66ffa03e7ed0b983d68ea3c06a754f33f67"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/56-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 29921 :STORED-BYTES 11577 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-1.lisp.gz" :UNCOMPRESSED-BYTES 29921 :UNCOMPRESSED-SHA256
    "7ea0a82457f80f05e8bec0fc10c75e8bedca9f8b83adb1a35683e71494149bb4"
    :COMPRESSED-BYTES 11265 :COMPRESSED-SHA256
    "af1f7c936f606a00b1ecfa3782d9fb5d9d8d8b684b88a146d883a5ac05230417"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/56-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28365 :STORED-BYTES 10692 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "56-0.lisp.gz" :UNCOMPRESSED-BYTES 28365 :UNCOMPRESSED-SHA256
    "e687628db10ba5cfab04165450eee3587c798501026a726d41036ee0a22e986c"
    :COMPRESSED-BYTES 10380 :COMPRESSED-SHA256
    "39a29a2d67e5a774b9a833cce852c03914dde89b54799e82d049bda8be1d09a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/55-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19407 :STORED-BYTES 4614 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-4.lisp.gz" :UNCOMPRESSED-BYTES 19407 :UNCOMPRESSED-SHA256
    "5e472c8008902b0684eafa21bf14e0de96577c6e54a0625b8533269192ada89f"
    :COMPRESSED-BYTES 4303 :COMPRESSED-SHA256
    "a26b97a570ef7e081eb0d7ea8e8f7129505aac071bd0330e6b884b625863d7dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/55-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19486 :STORED-BYTES 4686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-3.lisp.gz" :UNCOMPRESSED-BYTES 19486 :UNCOMPRESSED-SHA256
    "0eb1788d2b9592cd3e1782034e05ef99a733f977b52afe126d4d9624afe06362"
    :COMPRESSED-BYTES 4375 :COMPRESSED-SHA256
    "7f48c5054ade334d59c00b2c37629c11050649f14e500eddaf0605f84c6a0bff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/55-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19485 :STORED-BYTES 4562 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-2.lisp.gz" :UNCOMPRESSED-BYTES 19485 :UNCOMPRESSED-SHA256
    "e1d7209e8e02188e242b9945cf9aeffae34bc7036160f90da7fa53581dd21dee"
    :COMPRESSED-BYTES 4251 :COMPRESSED-SHA256
    "6e8272db28264153d2844803ba4a0600b3fc571828867a4f4cd9d291356ead8c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/55-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19385 :STORED-BYTES 4532 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-1.lisp.gz" :UNCOMPRESSED-BYTES 19385 :UNCOMPRESSED-SHA256
    "ef86addce90dda00370349b14b2ce74298c5dca47266355596f3c7b7d0fbf5a6"
    :COMPRESSED-BYTES 4221 :COMPRESSED-SHA256
    "4b593e072a344f13e13ec0f43598d6e2bac1e09aa19c9b2dbd14c8d5140d4a82"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/55-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19358 :STORED-BYTES 4614 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "55-0.lisp.gz" :UNCOMPRESSED-BYTES 19358 :UNCOMPRESSED-SHA256
    "11ec8ba443e3d3534aca6cc55ec98426a012778e92bfbdef5b2f6b36b3291fc4"
    :COMPRESSED-BYTES 4303 :COMPRESSED-SHA256
    "e42bfd95bd715ec4e07c709f5bc19b471f0cb97966c8bc2384580d3f4b4b16dd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/54-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14469 :STORED-BYTES 5432 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-4.lisp.gz" :UNCOMPRESSED-BYTES 14469 :UNCOMPRESSED-SHA256
    "df0d5c6af98cd19e1dafaf0cfb38b474780e1d271f6fd7cc31ebc99e56c9170f"
    :COMPRESSED-BYTES 5121 :COMPRESSED-SHA256
    "065ae0adf9650ef3c2cde617ad3cdf71a84aed6fd45b5963eaafbbf9c1a8031a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/54-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14458 :STORED-BYTES 5417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-3.lisp.gz" :UNCOMPRESSED-BYTES 14458 :UNCOMPRESSED-SHA256
    "fee69a8ddca897115508c67e33f619829ca5d57441c312f59f17df44372687c3"
    :COMPRESSED-BYTES 5106 :COMPRESSED-SHA256
    "40f1b51e61f5e1d485b19d7753d3c2a5f952d0a6cdd3f7fb87aff07e874e984d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/54-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14466 :STORED-BYTES 5688 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-2.lisp.gz" :UNCOMPRESSED-BYTES 14466 :UNCOMPRESSED-SHA256
    "e01b58e4573e7e9292b151715473699462c297c63c5482e1fd9c11cc3a7d36a9"
    :COMPRESSED-BYTES 5377 :COMPRESSED-SHA256
    "192feeeaa340b44399c387acd6fd94bd5297e5f2d7a4984c83b7008688efd83f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/54-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14298 :STORED-BYTES 5582 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-1.lisp.gz" :UNCOMPRESSED-BYTES 14298 :UNCOMPRESSED-SHA256
    "09e20b7f1380ab6ea281604ffa9fdb6881a5b4d290839012e2b70029dbfda71a"
    :COMPRESSED-BYTES 5271 :COMPRESSED-SHA256
    "964d6a797c7ef0b00efaa3b9778fcc8d7539b3c52aa0a5b5ef713f352063b350"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/54-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13600 :STORED-BYTES 5547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "54-0.lisp.gz" :UNCOMPRESSED-BYTES 13600 :UNCOMPRESSED-SHA256
    "1583f7bfd8af9e00be1a00e7d1b7d8413de7f11909d706a84e2a159eb05d15d8"
    :COMPRESSED-BYTES 5236 :COMPRESSED-SHA256
    "65a18a7ef1d764a98cabad0415e9fa20c004b7eee7be6ea91939b5bf2ef1527d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/53-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10162 :STORED-BYTES 2844 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-4.lisp.gz" :UNCOMPRESSED-BYTES 10162 :UNCOMPRESSED-SHA256
    "a0ab2b2c95925ab8bb3e15f7b75a0c9154ae5ac14dded65035ee8258d9f243cc"
    :COMPRESSED-BYTES 2533 :COMPRESSED-SHA256
    "f520621ae4946ee38b223359f49c53072856cbd5293676fae8a26d52d4e4271b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/53-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10525 :STORED-BYTES 2901 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-3.lisp.gz" :UNCOMPRESSED-BYTES 10525 :UNCOMPRESSED-SHA256
    "0b389fa800f12446e2d2ff93df8e39f73fbb52f6d98e0b85529b1b7a3a409c45"
    :COMPRESSED-BYTES 2590 :COMPRESSED-SHA256
    "ef600ed2e85c2e223d89626a67281f111443ae612f3e30050dc548b1b87418c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/53-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10652 :STORED-BYTES 2966 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-2.lisp.gz" :UNCOMPRESSED-BYTES 10652 :UNCOMPRESSED-SHA256
    "8cb7f8927ad83d42b940ef9d6d204285ff17c31c7518741702cab8de859c9073"
    :COMPRESSED-BYTES 2655 :COMPRESSED-SHA256
    "16712142b95beda53d80a424787309d9cf2c779377d8c0c873e31abb44ff39ce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/53-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10636 :STORED-BYTES 2867 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-1.lisp.gz" :UNCOMPRESSED-BYTES 10636 :UNCOMPRESSED-SHA256
    "3aaa4d38c59d21616ace65bcdc15e1dc24ccf43e46e0f0643d3e458abfc165c7"
    :COMPRESSED-BYTES 2556 :COMPRESSED-SHA256
    "27c4c52792068064735cba47889120b73932288b99e45aa6d0b88ba73415fee3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/53-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10245 :STORED-BYTES 2919 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "53-0.lisp.gz" :UNCOMPRESSED-BYTES 10245 :UNCOMPRESSED-SHA256
    "1db5b066e85bb7bb6eacab9e8bde9f0690e7cf4c531b14318a2ed9df00e1c09f"
    :COMPRESSED-BYTES 2608 :COMPRESSED-SHA256
    "020a4c3618f952ba87da891bd56c347521f2fe54238ef6ca02afbcc8ad30796d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/52-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7527 :STORED-BYTES 3139 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-4.lisp.gz" :UNCOMPRESSED-BYTES 7527 :UNCOMPRESSED-SHA256
    "384db10a6f0d2746cb6f8c92566c6982702585cada2a7248dbbd43dda406aa55"
    :COMPRESSED-BYTES 2829 :COMPRESSED-SHA256
    "42e518a6ae3669df59d23705b24b6e971bd579ebce1a00299ab7d8d6bd644bad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/52-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7482 :STORED-BYTES 3120 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-3.lisp.gz" :UNCOMPRESSED-BYTES 7482 :UNCOMPRESSED-SHA256
    "f03b3a0a47ca82f87ce6d9daccc110f556f4065090d380eb2b6c170cd0e4af11"
    :COMPRESSED-BYTES 2810 :COMPRESSED-SHA256
    "fb5bed4d962d31ad4bf23852332a27cac051c4094dd4db4e88a4abe21edffb9a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/52-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7314 :STORED-BYTES 3156 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-2.lisp.gz" :UNCOMPRESSED-BYTES 7314 :UNCOMPRESSED-SHA256
    "a1a3528da1bfa674c2df1e9ed59641e4009f5dfa3fcd51f0fd7bf8215858e5f2"
    :COMPRESSED-BYTES 2846 :COMPRESSED-SHA256
    "a078f1d70a7685e1ecd4f50a5016a117d483c591f0576dec35a34a46db9cdda9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/52-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7103 :STORED-BYTES 3101 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-1.lisp.gz" :UNCOMPRESSED-BYTES 7103 :UNCOMPRESSED-SHA256
    "7743619582856d42f629072728eb61312382f6d8a5dcdd126cd110c64f82d239"
    :COMPRESSED-BYTES 2791 :COMPRESSED-SHA256
    "ca4f185ea13b7a480692e745f03d658b6e7970c3a00cb9b9991f9739fff41dad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/52-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7019 :STORED-BYTES 3082 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "52-0.lisp.gz" :UNCOMPRESSED-BYTES 7019 :UNCOMPRESSED-SHA256
    "d2e57d0fc6b36e85ec89de21f9a39a809ab8af8152cc841f8032afad10137481"
    :COMPRESSED-BYTES 2772 :COMPRESSED-SHA256
    "7ebf0c203b5da91aa57739ceb71bbb98c405d1b3e46f9a2f0c128184275cfb49"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/51-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5340 :STORED-BYTES 1731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-4.lisp.gz" :UNCOMPRESSED-BYTES 5340 :UNCOMPRESSED-SHA256
    "0994f6a1de4ac2f65163a90d9e3c9297c558c47d3308d15f8386de1ed5af9938"
    :COMPRESSED-BYTES 1421 :COMPRESSED-SHA256
    "f026edc7928c4bd7824c0c90482002b103e946dc583e0a7615782d83cef5d28d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/51-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5350 :STORED-BYTES 1755 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-3.lisp.gz" :UNCOMPRESSED-BYTES 5350 :UNCOMPRESSED-SHA256
    "f79596cc4b8cf22fd06fe978cdd0e3ab06ce14d2e53158e3d1989ed728267e49"
    :COMPRESSED-BYTES 1445 :COMPRESSED-SHA256
    "269c6ee20a70034f19aafc113f0ef8c94d98465d3920bc64a9d9b50c39652ea1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/51-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5369 :STORED-BYTES 1749 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-2.lisp.gz" :UNCOMPRESSED-BYTES 5369 :UNCOMPRESSED-SHA256
    "f1579ad4c86837c0a5264218dd4003f2b9ec4e78487de59f30984cd45a1caf2b"
    :COMPRESSED-BYTES 1439 :COMPRESSED-SHA256
    "1940a3375fcfeaf729c44c55ace29e65cb0c03dd7734c6515747e4f4c18b02d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/51-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5277 :STORED-BYTES 1777 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-1.lisp.gz" :UNCOMPRESSED-BYTES 5277 :UNCOMPRESSED-SHA256
    "645381490680e204879e59199dbf2cefc236d88ce379b074163d8397b37e5890"
    :COMPRESSED-BYTES 1467 :COMPRESSED-SHA256
    "d500857f6ce1c7f7e2b9bbe8070bdc21bd76a7d241894ac21676429f9eef7767"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/51-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5076 :STORED-BYTES 1664 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "51-0.lisp.gz" :UNCOMPRESSED-BYTES 5076 :UNCOMPRESSED-SHA256
    "1dcd55f3d0632044b9192ad393c54450714de22e180b5e098f420d7e2a0d57f5"
    :COMPRESSED-BYTES 1354 :COMPRESSED-SHA256
    "1ca47b3ca57019acf6c96afb2ba8992c56cca013d0fd87535aaf3397456f97e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/48-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20059 :STORED-BYTES 3681 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-4.lisp.gz" :UNCOMPRESSED-BYTES 20059 :UNCOMPRESSED-SHA256
    "dbbfd6db03ddf7362722832bef67c2ad3773e52249765b197c25b3f8354452df"
    :COMPRESSED-BYTES 3370 :COMPRESSED-SHA256
    "85d0d65491dcf4e7c9f57c2babcffbced80592761770b1c31607999ba5b9abd2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/48-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20056 :STORED-BYTES 3603 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-3.lisp.gz" :UNCOMPRESSED-BYTES 20056 :UNCOMPRESSED-SHA256
    "386102b3ee26c7c9381d9341c7d193ca978365f52bb42f8f1e9e115efff33b26"
    :COMPRESSED-BYTES 3292 :COMPRESSED-SHA256
    "f3466ff3f1c95b34af63e9cce831f1b2e7571b64f27dd595f7bd8399e56af7fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/48-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20063 :STORED-BYTES 3518 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-2.lisp.gz" :UNCOMPRESSED-BYTES 20063 :UNCOMPRESSED-SHA256
    "14074d0dd65c5392dd9c8018ce89b6cea7145e0769efaa6c223fcea8654bb540"
    :COMPRESSED-BYTES 3207 :COMPRESSED-SHA256
    "e37d455315fea0744bbe42d0af440b0625119bab964ab684050bc7e095fc6dd9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/48-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20063 :STORED-BYTES 3477 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-1.lisp.gz" :UNCOMPRESSED-BYTES 20063 :UNCOMPRESSED-SHA256
    "49b9a78548171ac380df7905767f851629c4165bbfd38a64de6a0cc903cc53e3"
    :COMPRESSED-BYTES 3166 :COMPRESSED-SHA256
    "a48df02ca01fe7ff3801aa82ae0032b7db5f00f680a64ca01635936cb23636d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/48-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20073 :STORED-BYTES 4188 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "48-0.lisp.gz" :UNCOMPRESSED-BYTES 20073 :UNCOMPRESSED-SHA256
    "59761e62450bdc14adbb84134dd54c75f54581e820b7d27f7573aa8df5f8d557"
    :COMPRESSED-BYTES 3877 :COMPRESSED-SHA256
    "305cbad89eb64df02b57113c62bfdfee59683205767cb4ecd5bc867639ae4765"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/47-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2166 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-4.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "a3131bc963cd91e54a3caf104b6f46dbb850cbe05cc2ad168260b39ccfdcd981"
    :COMPRESSED-BYTES 1855 :COMPRESSED-SHA256
    "4d4815185d483df69ba1d488af64dbc12d87d2a89d7bd8f826cc99aa7f14649d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/47-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2091 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-3.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "b7cb8d09919ffc112350253ef8e9191975a699e968e693242ab3e6b290f88ce0"
    :COMPRESSED-BYTES 1780 :COMPRESSED-SHA256
    "43423a7307dfd9cd8a40412c7743361b1f3f8ad79508666b04b7279d59805fae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/47-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2173 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-2.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "76d0ed8950cfb38cbc64a0a1b2f5d93cd22f2f6c95f6b4ece8db2ad7b3a13214"
    :COMPRESSED-BYTES 1862 :COMPRESSED-SHA256
    "22957b140f523558532abd9e8b64afc7b04f67258a96cf71d2469abea3edc437"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/47-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2056 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-1.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "1b7a98234c76a96398d87a7005d5a787b0c00a6a5f6d2a7f5973da5cfeffa0d3"
    :COMPRESSED-BYTES 1745 :COMPRESSED-SHA256
    "a0a97ade86002f59a7aed9dccae3827682c1ec0f393aeffaba6129ef786b6f9b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/47-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2468 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "47-0.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "6c23ebd8e68040ed5e780aee3930b0c2ebce28736d70448232a24f6885d4f772"
    :COMPRESSED-BYTES 2157 :COMPRESSED-SHA256
    "8e5b794e3989c13cd8a4b7b9347963ed0f643e8b9ca50b51257874b9c9153029"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/46-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5629 :STORED-BYTES 1377 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-4.lisp.gz" :UNCOMPRESSED-BYTES 5629 :UNCOMPRESSED-SHA256
    "08416829a8eafdd00153f6a56581467211dc5405ee446c22fd17f722afc04cca"
    :COMPRESSED-BYTES 1067 :COMPRESSED-SHA256
    "03a68429c173bbb04f790540ebbff8f66caea288190010f7338148630e961fa7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/46-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1458 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-3.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "7f074aaefd0c6d6531abaac10a6c04064a871256aacfed83d73e3d07428115bd"
    :COMPRESSED-BYTES 1148 :COMPRESSED-SHA256
    "0fe0e0eb20e7d0b33d4f00fb7217630dc68cd563bc2a8e60863a834c8d63b433"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/46-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1339 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-2.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "0ad6a53013afea8a2178318c7b4f84438878060fbb9fbf9253129038911d60c2"
    :COMPRESSED-BYTES 1029 :COMPRESSED-SHA256
    "d99514410d04776cd950b601aebac539c0af858cc746a27142727119ec7ca321"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/46-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1401 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-1.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "7baa87a020ae57c72e675c97d23e06234c3b453fc86e9b622b68cb2c8d24ed1c"
    :COMPRESSED-BYTES 1091 :COMPRESSED-SHA256
    "d01c38aaa8164d4a5872aa46a18985b600092ebfb833bb81754f1bc1688b90f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/46-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5635 :STORED-BYTES 1566 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "46-0.lisp.gz" :UNCOMPRESSED-BYTES 5635 :UNCOMPRESSED-SHA256
    "3148c49781160cc1fcbe43dea6832a6f56769368188624e0cd93e36c6d816dd2"
    :COMPRESSED-BYTES 1256 :COMPRESSED-SHA256
    "ae6ba702a44ef8c4bd93978c1114e861fc63df4939030241be6e7d589d6fe1db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/44-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20004 :STORED-BYTES 2685 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-4.lisp.gz" :UNCOMPRESSED-BYTES 20004 :UNCOMPRESSED-SHA256
    "cdf44d35d511c5d6f56549fc11e1c87e16da20c936c5d27ddab01bcd56df4d19"
    :COMPRESSED-BYTES 2374 :COMPRESSED-SHA256
    "a9ca2dccabc70b3478918402d49fb3278a82c50bbeb470658fe2b9d6b18d21f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/44-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 2563 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-3.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "6eacd88de96b8724368849a18467b50565ab41c10bcf230daa2ae8bd05d14197"
    :COMPRESSED-BYTES 2252 :COMPRESSED-SHA256
    "f16d731481561099dfb46045a6216d79fc573d6ad8af8eb4ffd61af552221556"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/44-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20008 :STORED-BYTES 2668 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-2.lisp.gz" :UNCOMPRESSED-BYTES 20008 :UNCOMPRESSED-SHA256
    "219dfc3116ac3300308febf6afa95a49cdef5cdd17931e6ef3f8cb6b289e135f"
    :COMPRESSED-BYTES 2357 :COMPRESSED-SHA256
    "574484dd4da1d809b8a837f8c15f4ae5f5bfec53ad05f83012955302cd4e07f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/44-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 2622 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-1.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "9b410acc9cb21307b986442768bf52025cf49daa0576446bd6abcb18fc0fde47"
    :COMPRESSED-BYTES 2311 :COMPRESSED-SHA256
    "10c5c8d36c2f665dc961de85f6e35dfbc9314c9cb94ff4652a8c8b753dea9a4e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/44-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20014 :STORED-BYTES 3047 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "44-0.lisp.gz" :UNCOMPRESSED-BYTES 20014 :UNCOMPRESSED-SHA256
    "31912a281911e09fb9720316900f42eb39feb4afbfe481b09eee4c52ca8d320f"
    :COMPRESSED-BYTES 2736 :COMPRESSED-SHA256
    "ff2f2cd65e6fae60827349ac5464098a8289a2c74c6643a8761dd02047f4b21e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/43-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8823 :STORED-BYTES 1732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-4.lisp.gz" :UNCOMPRESSED-BYTES 8823 :UNCOMPRESSED-SHA256
    "290d4d21910951145495c454d5e63311a73cf90b7de8f8fab1f575a18d632390"
    :COMPRESSED-BYTES 1422 :COMPRESSED-SHA256
    "3eb8dd0f0ffcc7547e6feac4d7a422b3cc24ca85ba759fd9367eca86f1585691"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/43-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-3.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "a925be14272f000f67f713aa83bb687cca17a263e34b1c22a50efd8c83b779a8"
    :COMPRESSED-BYTES 1415 :COMPRESSED-SHA256
    "33877e1473458181cc4f8dd80002725af348345ded7ffe2e4ce14f24c9f787e4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/43-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8832 :STORED-BYTES 1770 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-2.lisp.gz" :UNCOMPRESSED-BYTES 8832 :UNCOMPRESSED-SHA256
    "d21099623bdd176a9f683754490612056eef10ad95541ad0d6c170d41e882f9e"
    :COMPRESSED-BYTES 1460 :COMPRESSED-SHA256
    "225c2ba7b7d599b596a57e14ecc52ec94110832ae4d7011dc6e74904e9d50331"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/43-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1762 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-1.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "7aa9ebc787c164ffc2a722c8045e2f4992da98c879c698a877309d94bcb58202"
    :COMPRESSED-BYTES 1452 :COMPRESSED-SHA256
    "634d2a5b1a4e925bfa09291b084ce3ca2f10e7b05d0b959645fb042bc92b20db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/43-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8823 :STORED-BYTES 1781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "43-0.lisp.gz" :UNCOMPRESSED-BYTES 8823 :UNCOMPRESSED-SHA256
    "b89a4dc13eca6879607904a792751149d693e0bb9cb83b61c0344e1bd1302977"
    :COMPRESSED-BYTES 1471 :COMPRESSED-SHA256
    "fea25943bdb7456f0511a629f21925b63c910de5028f48a6b4571623cbae80f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/42-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1215 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "4988a442a2292b33422ec60e9481f6dcea01783b30c512954272f3d748a76fae"
    :COMPRESSED-BYTES 906 :COMPRESSED-SHA256
    "75cc92b20956b8603e98210584fb75685801dc18e7f4a74d9246a6b5edc5aefb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/42-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1173 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "b781893cd8ac62a82d369e087b1ab85afe625d4d68132632e321e769e38c6295"
    :COMPRESSED-BYTES 864 :COMPRESSED-SHA256
    "e32c2c1cf18d58702c7f506e0785c241992eec93e1d98878616a357b5099c772"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/42-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1206 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "068fbde8eae70ef63606e45451bc25350c616e6efa09c585b2bf7259c6651c37"
    :COMPRESSED-BYTES 897 :COMPRESSED-SHA256
    "5788dec6fa43859dfe381e8d80cf1dc467b6e56421457e760957324967c4dcb4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/42-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4816 :STORED-BYTES 1206 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-1.lisp.gz" :UNCOMPRESSED-BYTES 4816 :UNCOMPRESSED-SHA256
    "bc30fbb450f8e63a8d2ea861a1338727f3a7626d3293489fcabc9ba466a2d0cd"
    :COMPRESSED-BYTES 897 :COMPRESSED-SHA256
    "f338b2feb4153cf9d5ca6805e191912cd2e59e1597a88702f778dffd0194c28c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/42-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "42-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "70703a99aae427aaded9218758587ad0d000b72672cb6f8d80a11a97e9b4dce1"
    :COMPRESSED-BYTES 912 :COMPRESSED-SHA256
    "8b8163e0e5a1e214f70f267b73d209892da52707e0ffa3610f0a9cf966558784"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/40-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19959 :STORED-BYTES 2644 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-4.lisp.gz" :UNCOMPRESSED-BYTES 19959 :UNCOMPRESSED-SHA256
    "0c52630e66376b210869dd2258e57c6d8560c07f579ff6e2cbafb7a90e596ebb"
    :COMPRESSED-BYTES 2333 :COMPRESSED-SHA256
    "ef0e021db9e2e5344c6fefc8dbcc0658943f44dbef6cc51b2f496954b1049d76"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/40-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19966 :STORED-BYTES 2606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-3.lisp.gz" :UNCOMPRESSED-BYTES 19966 :UNCOMPRESSED-SHA256
    "d3f7e5c2d7b8f71cc26573db07ff5e9354da325e783f2c5b48c39db9f382736e"
    :COMPRESSED-BYTES 2295 :COMPRESSED-SHA256
    "ff1199b7f7fa9315129034491c31691f1e6075850e974ae58fdc0af40c08f02a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/40-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19963 :STORED-BYTES 2658 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-2.lisp.gz" :UNCOMPRESSED-BYTES 19963 :UNCOMPRESSED-SHA256
    "9b641dc3ce26f6a301dcb31074052b22e6e9a1faacaf5b5db971b3625a850ce4"
    :COMPRESSED-BYTES 2347 :COMPRESSED-SHA256
    "ff9fe1cfb127b5618a84a9832c05397b319b0b5e6760e393fa40fdb7ba725fa3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/40-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20026 :STORED-BYTES 2510 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-1.lisp.gz" :UNCOMPRESSED-BYTES 20026 :UNCOMPRESSED-SHA256
    "02f3858e406f5c3ad6fa4c409558f4423e65e48b9fc12eb5085f87f82354cc15"
    :COMPRESSED-BYTES 2199 :COMPRESSED-SHA256
    "51ae9db735330f030b256ea447e293a52219e3c0519affc3eef6eb77cedcb310"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/40-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20036 :STORED-BYTES 2898 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "40-0.lisp.gz" :UNCOMPRESSED-BYTES 20036 :UNCOMPRESSED-SHA256
    "727a9af30be45c85767931ca295d8af3ecfc5fdbeb2bd7fedc1a42567648ffaf"
    :COMPRESSED-BYTES 2587 :COMPRESSED-SHA256
    "c992c45ebc120c52bd1a6bc18cb191211289f00b8c121a437f4ae745fa983e48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17063 :STORED-BYTES 2306 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 17063 :UNCOMPRESSED-SHA256
    "a4fc49e0f2f03b48d6461c5e5d4b264f49b7e3a2560989bd9b015c0d6f2dc3cc"
    :COMPRESSED-BYTES 1996 :COMPRESSED-SHA256
    "b1528acbce5eb47313f4b4c1c3c83cf73633e55645eb920818b8e746fcbb9e8e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19291 :STORED-BYTES 3227 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 19291 :UNCOMPRESSED-SHA256
    "a72e4dfede62bf81edcd59f8df601a42fa66710e91672f6c211a4eadfeac6fd0"
    :COMPRESSED-BYTES 2917 :COMPRESSED-SHA256
    "f67de2072aa5fac7c675ec9917029d51f0ac8cffebd88eadb4c61fecf5f3edeb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17559 :STORED-BYTES 2635 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 17559 :UNCOMPRESSED-SHA256
    "539d9c26756d2f818f315bbac23f5e0ed65c83fd70fd68d5132f40d4bfcb6cee"
    :COMPRESSED-BYTES 2325 :COMPRESSED-SHA256
    "6283c45f632362a77e202b7048f3342db38f50b771e572b5f5eb5166aca8271a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19018 :STORED-BYTES 3087 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 19018 :UNCOMPRESSED-SHA256
    "4d3b4c1f83df27576c0b5fd5746ce2a665df7bbb81ddb2e7735d6ed5c883f0e4"
    :COMPRESSED-BYTES 2777 :COMPRESSED-SHA256
    "62e90e7600069fc24501bed7edd6c10739f74233093f95054ce0370984a9e31a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17978 :STORED-BYTES 2564 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 17978 :UNCOMPRESSED-SHA256
    "c08ee216ffea27347799304f665f68d80b6b02ac07e966b26e8eb6030e9a6ca4"
    :COMPRESSED-BYTES 2254 :COMPRESSED-SHA256
    "74a7d84a2dbd65eb70a49ad6d1f3b5e42ef49e14160af3f818427b5abcc980dd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/39-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-4.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "7b402dac40024bddc387ccab7e42bb6bc518c283ce8d627cdf9587eba0b66598"
    :COMPRESSED-BYTES 1327 :COMPRESSED-SHA256
    "fd52829f728375467c612f344a5b91469577f3cf99a022939dc9376686e0840c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/39-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8821 :STORED-BYTES 1730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-3.lisp.gz" :UNCOMPRESSED-BYTES 8821 :UNCOMPRESSED-SHA256
    "e4212dd77e87ac73c5ea4c9ad986b809ad7a13550bcc4c15358fcff1402d5b70"
    :COMPRESSED-BYTES 1420 :COMPRESSED-SHA256
    "ebf47bceec2c7c56550bc576cdc16a9a6d0f6e2ec9853327866a255d18b62023"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/39-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1671 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-2.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "6addd5fed407be5bdc1b869e5bf00a0c98022a614610b3ce1d35d26af556f3e3"
    :COMPRESSED-BYTES 1361 :COMPRESSED-SHA256
    "62f8a2d84510351551d0cfbb665c7fb9c6b1d62b0314967372f3bf301700384b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/39-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1665 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-1.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "2025cedfa8f1f22dcc06154a8d3af428f23ae94d39d1beef1f4140173b97069a"
    :COMPRESSED-BYTES 1355 :COMPRESSED-SHA256
    "5a32176b6566bc6a4928c1c6e6b003e7a53cc936bbda5d5319d073474cd0c776"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/39-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8821 :STORED-BYTES 1725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "39-0.lisp.gz" :UNCOMPRESSED-BYTES 8821 :UNCOMPRESSED-SHA256
    "792302105c5b6abe6d95b2488db9e6570fa9d30a6778558221d761c01cd61504"
    :COMPRESSED-BYTES 1415 :COMPRESSED-SHA256
    "2b38c1929f95879f1cff39fcfe3f20ee32eefb22e86eb5420c24b07b470c0475"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/38-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1123 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-4.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "50e92411fac9c077586a1ccb819c5129ae5cb4f21a30c62ebf1e2dd6d424272f"
    :COMPRESSED-BYTES 814 :COMPRESSED-SHA256
    "981c7667e939409cd49ea3d4d25d450d74b9dbc5ac51c09adc39ce64db26955d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/38-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1168 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-3.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "cecaa642e7fc429a85fc8be828b87f41b57ccd2c388ea63ca12d89c740d9364c"
    :COMPRESSED-BYTES 859 :COMPRESSED-SHA256
    "e3394ad4744edb104760fb8b9f5ac5f050f671282d99e56d49464c15b1ea7878"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/38-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1154 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-2.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "2f8d4637e470b36d0cc013dde9ce5263609ef09d6852162b167fa837c78c8c55"
    :COMPRESSED-BYTES 845 :COMPRESSED-SHA256
    "b5601516061782c0e6accb368c2d45fefa4c802484800c0623c01f8f049336e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/38-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-1.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "cfb64e0fd11881d82794df67023ec7e02c1550aedf2e77727c94075ac2a361ee"
    :COMPRESSED-BYTES 855 :COMPRESSED-SHA256
    "409964f8001c9e60c67c226e94b74dc65c76247e36d661462bdc8ac379e6776f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/38-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1182 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "38-0.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "2549a6dbbb8f8d02bfb0bcc1b095de33f139083eb326ccbea5a68b5f34d24ec9"
    :COMPRESSED-BYTES 873 :COMPRESSED-SHA256
    "4bed23fe342353c78f33e5f1b8731d31b85fd4feac48e3464eef7c50736cd5f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/36-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20062 :STORED-BYTES 3663 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-4.lisp.gz" :UNCOMPRESSED-BYTES 20062 :UNCOMPRESSED-SHA256
    "f0f96fcb814764a4e6653b478381c427d2ce657c51853602f882fa06d9ce91b9"
    :COMPRESSED-BYTES 3352 :COMPRESSED-SHA256
    "fd245e7d3d09759370b7a32cc944c6e5e445cf7428c71c477092c17447ace3ca"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/36-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20065 :STORED-BYTES 3527 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-3.lisp.gz" :UNCOMPRESSED-BYTES 20065 :UNCOMPRESSED-SHA256
    "fefaa0b30c27be312e2b55e4e10d4ec1b06d3bba440358d2012f67886a6ea25d"
    :COMPRESSED-BYTES 3216 :COMPRESSED-SHA256
    "012b29b18e19bbc0508e3c936c3d401ad7d286c9e149a56f4e32661696b59cba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/36-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20066 :STORED-BYTES 3569 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-2.lisp.gz" :UNCOMPRESSED-BYTES 20066 :UNCOMPRESSED-SHA256
    "cb0403ac1c9f31993ac89cc663f75c5be277b310112f63f2ec4f8f3fd8eb34e5"
    :COMPRESSED-BYTES 3258 :COMPRESSED-SHA256
    "1c0b5b53ae8f184df9b7c017ddaf8ed3bd2051cbdbeaafbabdde0072ad3d5824"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/36-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20060 :STORED-BYTES 3558 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-1.lisp.gz" :UNCOMPRESSED-BYTES 20060 :UNCOMPRESSED-SHA256
    "4e39fb9f2383a9ea915a3d3c57d49a3e17653c2cc5c093412ab8627e14370d3a"
    :COMPRESSED-BYTES 3247 :COMPRESSED-SHA256
    "54872c727911985646e1d92c948e1e067629796185f58d50b0dc00a5b8a018a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/36-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20067 :STORED-BYTES 4277 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "36-0.lisp.gz" :UNCOMPRESSED-BYTES 20067 :UNCOMPRESSED-SHA256
    "2926bc49a8f73e780d0d20b0b5122e6ae748c15d8982feb9a9e2498e5dea2625"
    :COMPRESSED-BYTES 3966 :COMPRESSED-SHA256
    "7d5c0a8704a4ac8375fb45919964775fa5d9a04eb3d86f88277f74502e740317"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/35-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 2029 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-4.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "6b53f9309b9d8267cf238bdecb3bb6038840a263d6f6de3709ee82bc5fed6a82"
    :COMPRESSED-BYTES 1718 :COMPRESSED-SHA256
    "fca437d5a0b4eb14a0a758e727c70225787aaaa5ff117069b1a7fa5bada068cd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/35-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 2056 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-3.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "c632640f02ba56d953620cdeeb94586bf17a10990033a2bd2f58b5a3d901dd51"
    :COMPRESSED-BYTES 1745 :COMPRESSED-SHA256
    "d2e8dbc708f616c39302bf76b85ab21685aecbea5ead0ba0f8887844e4660413"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/35-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 1999 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-2.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "d339fe7afc15174657ef71882918317d0a7067a3dc42134e0b05253b7ca82ce3"
    :COMPRESSED-BYTES 1688 :COMPRESSED-SHA256
    "61a92d8c17613a549d91a711c4c932bc900ede0635aeb65a53f18b87eee21c21"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/35-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2073 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-1.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "9d732c83c84e49992a5724b1672c2c1efd89cd46ad18ca0e01a38729c74f93a0"
    :COMPRESSED-BYTES 1762 :COMPRESSED-SHA256
    "63a95457bf39cb8dbf25044bcd2b49dbcf284779098c0177e937c5f1ab99cb5a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/35-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10444 :STORED-BYTES 2352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "35-0.lisp.gz" :UNCOMPRESSED-BYTES 10444 :UNCOMPRESSED-SHA256
    "84066ecd53530377633fa0162ca6e73a408d5f4e3c40942501b1003a85a7f1cc"
    :COMPRESSED-BYTES 2041 :COMPRESSED-SHA256
    "df323340948e7afe71e236eb8522ae684be37188bc50334dae7fde54ae49075f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/34-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1328 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-4.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "be8e4cb79917e5edec5c943469b58c57f967a353e77eca0f971d66e53413a28b"
    :COMPRESSED-BYTES 1018 :COMPRESSED-SHA256
    "59cd3b3209de76ca814d90f5f4b54aa3206fdde7bdd436987abcdb1942a6ea06"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/34-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1346 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-3.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "aab6cfd493ca836a79eca5aa3ff76e6094fd68b181ad5bf78fc915ed06a45822"
    :COMPRESSED-BYTES 1036 :COMPRESSED-SHA256
    "ed8d27a946135e3072b7e37dd025e3c327a859df2b7060e05a574e778637835d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/34-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1396 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-2.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "38c36f7b0448338aa8ce1eccb754215a97ea555769c39c16d98798b40323a5d6"
    :COMPRESSED-BYTES 1086 :COMPRESSED-SHA256
    "818b6929cc2d2b17789ac0576009f70195979e734c2f75d312dd1023bb16f892"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/34-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-1.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "12788def1d551d00a90ff72576db0874589e1223f4a7fe02d3a7f74f9a318eba"
    :COMPRESSED-BYTES 1062 :COMPRESSED-SHA256
    "d29c0264383a4af7d72843ac4eacbe839788845c842295b5e3f163e2d4e58f11"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/34-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5637 :STORED-BYTES 1536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "34-0.lisp.gz" :UNCOMPRESSED-BYTES 5637 :UNCOMPRESSED-SHA256
    "cc5630aa5cfc0e63cdcc699f29209dbd49e0ab436671285256df42aa1b9d3139"
    :COMPRESSED-BYTES 1226 :COMPRESSED-SHA256
    "8734d7457b8ed34f271dbb396f8591b643c25b8c168fc2bd51ef5f6664f3bd0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/32-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17779 :STORED-BYTES 2520 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-4.lisp.gz" :UNCOMPRESSED-BYTES 17779 :UNCOMPRESSED-SHA256
    "23c32207039c04040b985f0b36bf6ce12b363065cb494849284e42d132af198c"
    :COMPRESSED-BYTES 2209 :COMPRESSED-SHA256
    "e87b99cec4c9de9acc56b2c7d05a4ce3fcc29ef52cc70d8b85ec677e148affbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/32-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17744 :STORED-BYTES 2555 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-3.lisp.gz" :UNCOMPRESSED-BYTES 17744 :UNCOMPRESSED-SHA256
    "7473fc76d42ca79a838c66211c10f1a2d901c1784ec15195356c2d75e11e0a2a"
    :COMPRESSED-BYTES 2244 :COMPRESSED-SHA256
    "97635a621113d45603181f29524b3e6a0731a60be9a7747bf21671792d2e6f35"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/32-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17712 :STORED-BYTES 2804 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-2.lisp.gz" :UNCOMPRESSED-BYTES 17712 :UNCOMPRESSED-SHA256
    "f27af634c30750d756fcedb551e45cb9cc5d837e829ed85eca59e56d8018fa1b"
    :COMPRESSED-BYTES 2493 :COMPRESSED-SHA256
    "64e791f5875ac88e62c794687e37b2548ce089cca8ff735f7c071f43f696890d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/32-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18242 :STORED-BYTES 2668 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-1.lisp.gz" :UNCOMPRESSED-BYTES 18242 :UNCOMPRESSED-SHA256
    "9dc6b0e2a45849c1f87db4d9994c9e0f90c415bba3f1c98dffa4ccfe4fe7dc9b"
    :COMPRESSED-BYTES 2357 :COMPRESSED-SHA256
    "5eb34e0a83298cd4db63a34eea242f500e67c989c686c63af7b126fa25f0a72f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/32-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18530 :STORED-BYTES 2831 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "32-0.lisp.gz" :UNCOMPRESSED-BYTES 18530 :UNCOMPRESSED-SHA256
    "38c254ab003ba68f251942c07616511343bd229a90434554097228138cc1ba1b"
    :COMPRESSED-BYTES 2520 :COMPRESSED-SHA256
    "68274d998583e4beea338bde0a899c3d0fecca54eb4ba19e619acaed4a4c12ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/31-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1558 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-4.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "f99a4b72608044db7343af2d4ba05c7c7d8c6e6fea9221086e010a414593d871"
    :COMPRESSED-BYTES 1248 :COMPRESSED-SHA256
    "7f721eefedf8d2bc5a324aeeaa78c911cef24cab777b979804cffdcc439b4f30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/31-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1702 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-3.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "e26ead6fe4af6ec65630dd58f8b649fa78ca417ba2864e37e38ffe8ab933c879"
    :COMPRESSED-BYTES 1392 :COMPRESSED-SHA256
    "b21ede5fa761e6fd82f11d690587cef2302eb8013e22f7fed2dc7da251633aa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/31-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1655 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-2.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "8e478f6ce559b2c38913f5d12caeb20531b74ec2adf110e9ae44b1e380a296c1"
    :COMPRESSED-BYTES 1345 :COMPRESSED-SHA256
    "619cf0b249f127d2031922d16e5ac214bf9cd89e4f77d211cb95808bdfcf9283"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/31-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1696 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-1.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "69c7bb58d17c960464000026ebdf49eeba700b3e0133ae1b9a3ec8729c749fcc"
    :COMPRESSED-BYTES 1386 :COMPRESSED-SHA256
    "ba9a71ebce5653cbd169a862e0c74be18f055747b111282c4c58b314ef22f58c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/31-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8820 :STORED-BYTES 1698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "31-0.lisp.gz" :UNCOMPRESSED-BYTES 8820 :UNCOMPRESSED-SHA256
    "1543ddfa7957f75cf3fed726b6874d238416c7c8821a364a6e34526129059aa9"
    :COMPRESSED-BYTES 1388 :COMPRESSED-SHA256
    "dd2432be231eb3b29f718f1265b7e6fd7fe147226c177dec46457c471916c804"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/30-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1205 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "eb0104467e3dc5b6d858a778df78a70546e07d43c7cd6696f26fdeddda61db83"
    :COMPRESSED-BYTES 896 :COMPRESSED-SHA256
    "eb088e33b5d5bda7df728a7bfd8814f02a3e502b4a7ea7d8eae910da873634fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/30-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1142 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "a1b619d937160cd9aacb99127fd20843fb9350c07c50a0fa24e4e510b8540040"
    :COMPRESSED-BYTES 833 :COMPRESSED-SHA256
    "cf482cec4376f1386e7b3ebc0cfc3e414a0c3fe92958e1669575a5d478991f39"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/30-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1133 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-2.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "554bea4975fbf69fdc4c3324d344e96212089990ff1198c47db35c942d94f2da"
    :COMPRESSED-BYTES 824 :COMPRESSED-SHA256
    "180c5bcce39617584866ab33f99b3b6518a4135b68619eb14d9b34280d13c00e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/30-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-1.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "501f9ebdc5f68340c500f6cc90ceb47398df065ce090fc1d75af9835d5ce4db2"
    :COMPRESSED-BYTES 856 :COMPRESSED-SHA256
    "94c39ba25128f3e6dc7fb453e1b20a2421abb233a574e3653439a3a1532629dd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/30-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1183 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "30-0.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "88f37463aed486e551f06ad8c86ff865d22dcb92645757132ff3654e8412f20e"
    :COMPRESSED-BYTES 874 :COMPRESSED-SHA256
    "ebfc6a543d027cb753847546e986c9cf77c3607895803dbc3b6d579f4d632297"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1724 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "5b257bf60f9d61c52fa481b8f7dae359ea4ba39631873a899e008dc03bfaf30c"
    :COMPRESSED-BYTES 1415 :COMPRESSED-SHA256
    "19795459de9186aa82a28ae5cbecef2d58c1b0b8c1b9cbfbed4798d996070299"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1496 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "b0dc7de88ae7643eab22b1e55a02007e5bfafefc96232b30065ae272a574edaa"
    :COMPRESSED-BYTES 1187 :COMPRESSED-SHA256
    "b818d3d04995abe1a3d679844947c2e2c2f6a380a093bb65bc310e6a51c63be3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1524 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "f7fa86d780fa336f50ef34aebb9c7579419c65dcc66eda69fa93b2365d0a366e"
    :COMPRESSED-BYTES 1215 :COMPRESSED-SHA256
    "cfd3434b6d953f2081fa9337897053f9f945b9595f08e3280191b36692229d8c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1455 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "e5f30c46a4b6bd3a9b8b81d57a2c25b1d456fa1b627a36fd233ed6f529c67aba"
    :COMPRESSED-BYTES 1146 :COMPRESSED-SHA256
    "05628345e0f44d414cbfe270532d0829edf040c23cdba412e293379672bd1753"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "92693c975b772ba7785d402f9b8156e09c758a09d7a70ad38e816e37ac4fb5b7"
    :COMPRESSED-BYTES 1231 :COMPRESSED-SHA256
    "a71353f7b6ac34f0129804b879ebb76c7ef941a89f2769d328553401ab484cbb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/28-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16900 :STORED-BYTES 2333 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-4.lisp.gz" :UNCOMPRESSED-BYTES 16900 :UNCOMPRESSED-SHA256
    "7433df057f558c2a62eb23611016ba13d2315f55fa22456a7f24adab43c91571"
    :COMPRESSED-BYTES 2022 :COMPRESSED-SHA256
    "8c6f3b22ce3596ab3c075dca5061dff3ecfa4f4a493b43d5b79926ffb2355d5b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/28-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16896 :STORED-BYTES 2304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-3.lisp.gz" :UNCOMPRESSED-BYTES 16896 :UNCOMPRESSED-SHA256
    "b8a713b1a3dcbc05e323038ebfaa291cf96c2e5c09426d28f940acfe9a11dbca"
    :COMPRESSED-BYTES 1993 :COMPRESSED-SHA256
    "29fdcc95a90bc65ac094e8d8090cb1f45a28d9a918277acb24ff82311fc36116"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/28-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16967 :STORED-BYTES 2340 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-2.lisp.gz" :UNCOMPRESSED-BYTES 16967 :UNCOMPRESSED-SHA256
    "b3d9c77dd70ab17c05a49e8d4a716d4e179694c44cb831290eb253212baee6ef"
    :COMPRESSED-BYTES 2029 :COMPRESSED-SHA256
    "3aee349aa5953785e8f8a1c7456fab0b9fa0b2a0d38774bd845113aac7aba7dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/28-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16910 :STORED-BYTES 2219 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-1.lisp.gz" :UNCOMPRESSED-BYTES 16910 :UNCOMPRESSED-SHA256
    "ce12b80e80dad09a3cbd90f9a2006302a95441604fb969f010e992d3460109c8"
    :COMPRESSED-BYTES 1908 :COMPRESSED-SHA256
    "f0523bfa4d474e183bc52ea1892f475d02411c163ef77e371235c3935b07edf1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/28-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17984 :STORED-BYTES 2524 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "28-0.lisp.gz" :UNCOMPRESSED-BYTES 17984 :UNCOMPRESSED-SHA256
    "c03a6254e8dd2ee0c895474db545959f0abb982ee2b3e08cf702ccd335f1e5e2"
    :COMPRESSED-BYTES 2213 :COMPRESSED-SHA256
    "d3a4301650f304abe2c8df870315de236e76e64871d1ee8721be17cc601cf741"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/27-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1518 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-4.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "23502cf4da280c53e02b992d4d462f2b9e81121a41960d70cf7a65eca11aeb20"
    :COMPRESSED-BYTES 1208 :COMPRESSED-SHA256
    "df8f0fdb81b646bae974b3a29c8417a33898b01b42a44486e5f01259c8294b30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/27-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-3.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "de9807451735127d7db0956e886c5cb39b2829557b80647e66e94162f864acc3"
    :COMPRESSED-BYTES 1237 :COMPRESSED-SHA256
    "3edafae45f58f9253cf2f8468fe6ad3871a6e8c63b19d511ab4d32d186e76c63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/27-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1460 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-2.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "cfd801e20b62284e2349ed81a94b8114e6f2e75d4a41ff674213157b4b043328"
    :COMPRESSED-BYTES 1150 :COMPRESSED-SHA256
    "560688c5f06d88f1ab6be33f721a1cd7c5eb50b9d20c07187415041b9dca80bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/27-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8816 :STORED-BYTES 1564 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-1.lisp.gz" :UNCOMPRESSED-BYTES 8816 :UNCOMPRESSED-SHA256
    "0a9510ba61e4b666ae0e827258662d1b7aeff45a9c809c473629cc032c29ad36"
    :COMPRESSED-BYTES 1254 :COMPRESSED-SHA256
    "0586a40ca03b358c65534ff22c4efa4d2463d9f40d88b755102f4e62a65f8b26"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/27-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8823 :STORED-BYTES 1500 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "27-0.lisp.gz" :UNCOMPRESSED-BYTES 8823 :UNCOMPRESSED-SHA256
    "aae9ae52bc42f111065436a2d7476706ca7b1455a1063c71cc1b1280941f3fc9"
    :COMPRESSED-BYTES 1190 :COMPRESSED-SHA256
    "a5b21e817758bd39de80bc013a47deb4742454b08209b8e8725807a678c3bb48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/26-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "ee240ec940abf48d9e0e4582609d6e4910d9afe1fe0ae50037fea33fa5c23379"
    :COMPRESSED-BYTES 776 :COMPRESSED-SHA256
    "c4be2c803ccfb63025ecd4cc9121898d62a8aff1289f77bd3d7b693ac3444b3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/26-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1064 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "d60d17c895cb96e8df5283de9314661ab980d0b7eeff155dbacff441b030e12d"
    :COMPRESSED-BYTES 755 :COMPRESSED-SHA256
    "e324388164368d7ffd7bca1f313b830c675df4b6ea28fbf53f5aff1637c61deb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/26-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1087 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "e9da5cac0db2b1abdb3d40a2b5f495825921a5cf6ca872a839a04227d5e6bcc4"
    :COMPRESSED-BYTES 778 :COMPRESSED-SHA256
    "247954bdeff4ce3783c616693000210836131b75531683413cfc308d8cbf1416"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/26-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1079 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "1450ac3835c2074f4038b1a2eac5a1ab043e5e1c21c6eed31dcd84a8705b493c"
    :COMPRESSED-BYTES 770 :COMPRESSED-SHA256
    "b34157becc3e45275d393bfff966efba104e8ae340da4196a70571fa1a81b15e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/26-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1104 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "26-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "4d1f831fd752b602809a16f2c148c300c8a51095a6d7dd8c18be44cc62c519cf"
    :COMPRESSED-BYTES 795 :COMPRESSED-SHA256
    "78649dcf5d646ed9a671c6f17bcfb861ce12ccbbe44a78f4a03efc0a8fd0bbfd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/24-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3634 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-4.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "7c1e1b2c4df1199fc97315623cae32f8eda0b73149f904fda9eb6348d296135a"
    :COMPRESSED-BYTES 3323 :COMPRESSED-SHA256
    "521de31e06316f16f790df28a9080aaee07a39bc1d4640d7673885655bff63db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/24-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20059 :STORED-BYTES 3772 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-3.lisp.gz" :UNCOMPRESSED-BYTES 20059 :UNCOMPRESSED-SHA256
    "7805d5ffdecfa7d5a800deb6b21da84433ac7598a5db70a5cdc295df81663c8b"
    :COMPRESSED-BYTES 3461 :COMPRESSED-SHA256
    "abbe70510b1e781dc7a30922814258a169a9650e3261e007931af9ca81d1b47b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/24-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20059 :STORED-BYTES 3611 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-2.lisp.gz" :UNCOMPRESSED-BYTES 20059 :UNCOMPRESSED-SHA256
    "f19f8f151a9e6f061e3826b51e6c9ad4ff30c7df342ef794fab8927c67fb5fbc"
    :COMPRESSED-BYTES 3300 :COMPRESSED-SHA256
    "360651840a3b11e4b429286695e9d669819e1c411b734ce4fc5fc841be5c3713"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/24-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20056 :STORED-BYTES 3686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-1.lisp.gz" :UNCOMPRESSED-BYTES 20056 :UNCOMPRESSED-SHA256
    "242d9bb28a7b67086efc93093750143a9040e19877f22915e87c038e3c6b7c98"
    :COMPRESSED-BYTES 3375 :COMPRESSED-SHA256
    "fe024d95f1582ec30b06ec1bd998e81d4c7dc71ec6a844a59a861e8e421dff1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/24-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20070 :STORED-BYTES 4149 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "24-0.lisp.gz" :UNCOMPRESSED-BYTES 20070 :UNCOMPRESSED-SHA256
    "b44fd8b3279825c8e122115f855fbe2fc221b7818dba36c6a983796eaefd41a3"
    :COMPRESSED-BYTES 3838 :COMPRESSED-SHA256
    "d1593bd9d24477e901b734d90e64e358e8327675079087ef4479d45a171bc97b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/23-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2065 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-4.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "2cbe361bc3cb51486869531727a03718e5ea10921512bbfe6f7b9f804cfc2e2e"
    :COMPRESSED-BYTES 1754 :COMPRESSED-SHA256
    "b4d90f46ee977f7711da2f9aa1ae8bbf2a4a44ffa9e9c93a75d73c13d657fdc5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/23-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2084 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-3.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "529c6517d39b3ceb672e27529c2c988f8b61d10743e3b161490c2d37338399fd"
    :COMPRESSED-BYTES 1773 :COMPRESSED-SHA256
    "b40017913875edb4fd0fdaf9b8462cf8b2d06a46c5a6e053f14cc1de6b245a7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/23-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10441 :STORED-BYTES 2057 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-2.lisp.gz" :UNCOMPRESSED-BYTES 10441 :UNCOMPRESSED-SHA256
    "5d30e3c2836792a508182b574d843aac52f77652847bde9fa01174221a9d5a6c"
    :COMPRESSED-BYTES 1746 :COMPRESSED-SHA256
    "9b3f3e0b2e53e47e572c4744e81c16352a5018b23f7bbe8aa76e10f1e2564e86"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/23-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10440 :STORED-BYTES 2038 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-1.lisp.gz" :UNCOMPRESSED-BYTES 10440 :UNCOMPRESSED-SHA256
    "e32ee010ab7e258465c13677b69fe7370299fca0655394dc3e7d5f45a2822d6a"
    :COMPRESSED-BYTES 1727 :COMPRESSED-SHA256
    "a185a1e9f9ef1ae82def8baf3375bcf537dd4fd0b458cb80e8070a61b3f3300f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/23-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10443 :STORED-BYTES 2463 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "23-0.lisp.gz" :UNCOMPRESSED-BYTES 10443 :UNCOMPRESSED-SHA256
    "6eb3662f0958101bfd344216d47727aa7feb435aa58c411626bb6f4d0a456120"
    :COMPRESSED-BYTES 2152 :COMPRESSED-SHA256
    "842b9c0178bc73b3bbcf36032d207ed716dbb3e2c80d909763f12ec16c001779"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/22-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5634 :STORED-BYTES 1391 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-4.lisp.gz" :UNCOMPRESSED-BYTES 5634 :UNCOMPRESSED-SHA256
    "15e9d08d830fe5c02496ddc1c2599bfd33002c3551842be14ece3b5355ec632a"
    :COMPRESSED-BYTES 1081 :COMPRESSED-SHA256
    "450568d38a14de4bfaeb7199605aba698d0ca43237625662ca4c27ddea00b3f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/22-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5634 :STORED-BYTES 1381 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-3.lisp.gz" :UNCOMPRESSED-BYTES 5634 :UNCOMPRESSED-SHA256
    "d502e96203392466e877e92c3cd202c8cf4b1b6817eb47901ef414232e8cc89f"
    :COMPRESSED-BYTES 1071 :COMPRESSED-SHA256
    "11187334b1301b703251f98c1f68eb128477e814f158a47ff8ac9b4e386bdadc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/22-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5634 :STORED-BYTES 1482 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-2.lisp.gz" :UNCOMPRESSED-BYTES 5634 :UNCOMPRESSED-SHA256
    "456d01e51f0611c1a6dcac0136cfa81da5aa71ab2a7481e1bdf520fbcd68b0e0"
    :COMPRESSED-BYTES 1172 :COMPRESSED-SHA256
    "ed6315b5df5ac16cc54461827cf8ba5e7bcdd78bbb9a74df7f75c29387f8c3c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/22-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5634 :STORED-BYTES 1599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-1.lisp.gz" :UNCOMPRESSED-BYTES 5634 :UNCOMPRESSED-SHA256
    "566e4dfac002a56c70571e208832adca1652db53056893ff86f6ced28a4307c4"
    :COMPRESSED-BYTES 1289 :COMPRESSED-SHA256
    "d52c692cb7a70fe5d67078671d4d5b66ef4fc73a5c63bc7ce55b20fa210c54e9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/22-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5641 :STORED-BYTES 1633 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "22-0.lisp.gz" :UNCOMPRESSED-BYTES 5641 :UNCOMPRESSED-SHA256
    "bda343fdcb85e617a536375ee6ea6c5bc1d2be0cd027aeabb6f2d69934aa18e4"
    :COMPRESSED-BYTES 1323 :COMPRESSED-SHA256
    "a02b928f91a66cbea90959320fc6fbe3430d4e03dec719862803edc881ce52bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/20-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20014 :STORED-BYTES 2636 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-4.lisp.gz" :UNCOMPRESSED-BYTES 20014 :UNCOMPRESSED-SHA256
    "ac2dfd11bafd535e2fc7582bf3083e678baf26e68fbf2009f67f998774631367"
    :COMPRESSED-BYTES 2325 :COMPRESSED-SHA256
    "5953331535bd2017b9794a20a437e2b8700c15406ba24bb65ad4507bf0a7d2a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/20-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20015 :STORED-BYTES 2636 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-3.lisp.gz" :UNCOMPRESSED-BYTES 20015 :UNCOMPRESSED-SHA256
    "fc053f8f5648636bce00c84ea571dbe0ef687a3735d729e2032e949caa26b4bc"
    :COMPRESSED-BYTES 2325 :COMPRESSED-SHA256
    "b34d830b9abd2e6f6a6b861fc53d728faf8a956de9d9509a5d663a7db461b728"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/20-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19987 :STORED-BYTES 2652 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-2.lisp.gz" :UNCOMPRESSED-BYTES 19987 :UNCOMPRESSED-SHA256
    "633d1f0eca43c11d74391ee561e732ac16083a9538776783d72a62e3dce4ce01"
    :COMPRESSED-BYTES 2341 :COMPRESSED-SHA256
    "669683f2323359493ef6fe2356725e00a2d592693e29875f1117e0a16088ec53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/20-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20030 :STORED-BYTES 2601 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-1.lisp.gz" :UNCOMPRESSED-BYTES 20030 :UNCOMPRESSED-SHA256
    "92d29c7f0029d192dba47c0197636ebe98009aabad523af7893b4e5d96d8d7d7"
    :COMPRESSED-BYTES 2290 :COMPRESSED-SHA256
    "d297e54b8ae5da189467bfa0b7757b998b4d2ed7c3f5736ba74747a94c85c329"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/20-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20021 :STORED-BYTES 2978 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "20-0.lisp.gz" :UNCOMPRESSED-BYTES 20021 :UNCOMPRESSED-SHA256
    "966269736ef52462d75d8640b6045d99a691bf89139582d075237134491dd27c"
    :COMPRESSED-BYTES 2667 :COMPRESSED-SHA256
    "535299015bb09d0e392b8c7717ee00b8b1d5dbfc3446601a501b87f61135417b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1156 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "f17eeba655a2f5ee674b22833a798dea1eec85d17da3daaed896ca22a51c0de8"
    :COMPRESSED-BYTES 848 :COMPRESSED-SHA256
    "f2671d8c5faf012611a9294c36439e3ee18d9c3327163735f406150114c69bf9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1093 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "7ad2ca1c5871d672dcdcb410285d8d42120a6b02083ca1152f6c629be42f1c0f"
    :COMPRESSED-BYTES 785 :COMPRESSED-SHA256
    "4962dafdd0bdc73e375725df45449c2789e76ba113656d43a3874e7ef1410609"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1127 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "24277cf55fb2c6a46b2b7fbceeb14013b6fa633fafdb32bb14068d1e3a7221b4"
    :COMPRESSED-BYTES 819 :COMPRESSED-SHA256
    "4499998056187cf849d42304b340ca5cf1bf28807fa584ab34b3025cfffb7ca0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4816 :STORED-BYTES 1033 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 4816 :UNCOMPRESSED-SHA256
    "d43d84c3afc60a8ef5ae54ec3e8825363c5f611d4042153db3793025f2ef543d"
    :COMPRESSED-BYTES 725 :COMPRESSED-SHA256
    "9368a08e44e489d997ac3d7dd1a2c7a34f53b756187122ad977fe8908c9c6d63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1084 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "aebc0c7ff07e29eb483b1749b3406a2986c3139d410a1b16e46042aa60e602f2"
    :COMPRESSED-BYTES 776 :COMPRESSED-SHA256
    "8026bacdc1fceb6505b21c5b29dff7322e5d90e7cb6882445babfe8abbebebc9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/19-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8825 :STORED-BYTES 1753 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-4.lisp.gz" :UNCOMPRESSED-BYTES 8825 :UNCOMPRESSED-SHA256
    "07a5bdf7194e2af5534066963a4f0cb3fdf28200f96be6a58c83ef8afa7a3ae2"
    :COMPRESSED-BYTES 1443 :COMPRESSED-SHA256
    "6151025c5a20adc56d98d53b40b3004a98543d5a0743c01c90910d7a3c100da1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/19-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8823 :STORED-BYTES 1739 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-3.lisp.gz" :UNCOMPRESSED-BYTES 8823 :UNCOMPRESSED-SHA256
    "e4781a00261104a9c97472c389877d1cc3309974079a92878047a0a7e6970a5f"
    :COMPRESSED-BYTES 1429 :COMPRESSED-SHA256
    "d9b054456b09f340f1c987b95c7ee2d9f00a5219e6d750cb4b9f615dc36ca872"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/19-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8829 :STORED-BYTES 1754 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-2.lisp.gz" :UNCOMPRESSED-BYTES 8829 :UNCOMPRESSED-SHA256
    "97f8dfd687dd32926aa2fa01d4f176c8a9f7edfa7cd4b233990edc038fc517db"
    :COMPRESSED-BYTES 1444 :COMPRESSED-SHA256
    "01386e2142abcd4e1c6fa9137ecb84b1ce5136e5e2ef1ab9d41a1e21e4a9fffa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/19-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8823 :STORED-BYTES 1704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-1.lisp.gz" :UNCOMPRESSED-BYTES 8823 :UNCOMPRESSED-SHA256
    "7c7fa68a047a2b5c46037e899b3276509acd3eb2c26ea73ac6bf905ee030b4fe"
    :COMPRESSED-BYTES 1394 :COMPRESSED-SHA256
    "496679b7a89ea1531fa85318b1295cf5b2dffe020cbe838ff00d07cf293e9b4f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/19-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8817 :STORED-BYTES 1785 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "19-0.lisp.gz" :UNCOMPRESSED-BYTES 8817 :UNCOMPRESSED-SHA256
    "3bc43a7b881397ec2f7d1916b04c8579a20eeaa1d8576b6ea32090ce37989fd7"
    :COMPRESSED-BYTES 1475 :COMPRESSED-SHA256
    "026b83f0443ed8414ace813eb80af76c8a14639a7194596fcb9aff2fce8119ff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/18-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1223 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-4.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "b03b3af67bf16be180ad666b83d2e6dc9f2c0430e0e3b8767d692d0e6e1364f5"
    :COMPRESSED-BYTES 914 :COMPRESSED-SHA256
    "53e485de677a3c1c5f67ceda99137a93da0cb1a9c496c2719ea7f4ad5967ed52"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/18-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1214 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-3.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "1a300376b67541a1480260394fdd6d9f9d48bf8e8236f15118a12309fd54f965"
    :COMPRESSED-BYTES 905 :COMPRESSED-SHA256
    "4ae4cfc96f3f3c61500acdd64aca8a3b73cd50e1f2a1d1f41d04afdbe8382144"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/18-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1225 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-2.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "48e0e784e898dca1df20d9e4ab8116d297aceae227fdf02a0e3deecbf0a82886"
    :COMPRESSED-BYTES 916 :COMPRESSED-SHA256
    "e7c6238f29ab812c67ddaca81d234fd734fbffaf50b29a1e4586f9533c6f15aa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/18-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1260 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-1.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "cdcea3f12dd30524fad506a440b9f77c30d7adcd9c1210eb535a3f573616245c"
    :COMPRESSED-BYTES 951 :COMPRESSED-SHA256
    "d7b65005e6dbe836e04d3c9d48607f92203d6cc402c16244696e9c682e4c1780"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/18-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4810 :STORED-BYTES 1266 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "18-0.lisp.gz" :UNCOMPRESSED-BYTES 4810 :UNCOMPRESSED-SHA256
    "cac8affe1b69d749218fb64116c4ea6d2801d4af51376aebdba79fc0e884fea4"
    :COMPRESSED-BYTES 957 :COMPRESSED-SHA256
    "d973bdaa76491689578f3f8527c955b8cec915891244edfd54b6ebc77128726d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/16-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19872 :STORED-BYTES 2563 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-4.lisp.gz" :UNCOMPRESSED-BYTES 19872 :UNCOMPRESSED-SHA256
    "35396e3545ca81f08c2ce9da538eed563c05607090c1fb66ef6fb544881308ec"
    :COMPRESSED-BYTES 2252 :COMPRESSED-SHA256
    "236053e9f1fc973a81563f29378a21029973ba6530f8f4b356bc9356de5ea871"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/16-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19873 :STORED-BYTES 2695 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-3.lisp.gz" :UNCOMPRESSED-BYTES 19873 :UNCOMPRESSED-SHA256
    "d58e21d4a13377ab6c308e3127b0f8be62dc2aafcf6a1ef73552146f965728b4"
    :COMPRESSED-BYTES 2384 :COMPRESSED-SHA256
    "764ab4d52168a7520fdb142be42c678415c169c20edaaa1994e1057378076757"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/16-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19948 :STORED-BYTES 2721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-2.lisp.gz" :UNCOMPRESSED-BYTES 19948 :UNCOMPRESSED-SHA256
    "0d3b9c7dcce79e87f95840dbabff0d27d65f9b4c3a0dc0827ae37228fe762b7b"
    :COMPRESSED-BYTES 2410 :COMPRESSED-SHA256
    "b34b93753bebd1d513946294a37be1bb4da818a2e67fdd852e5053367cf35a06"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/16-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19957 :STORED-BYTES 2692 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-1.lisp.gz" :UNCOMPRESSED-BYTES 19957 :UNCOMPRESSED-SHA256
    "f0fc273163a6deaddc062a23697802b84259d7fa83a8d509aaa02bc13aaf4aa1"
    :COMPRESSED-BYTES 2381 :COMPRESSED-SHA256
    "ed568eca83e8963c414f4ccf4367a2d2a9f3be6d3c68dfdd1daa36639bd8cb8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/16-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20024 :STORED-BYTES 3039 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "16-0.lisp.gz" :UNCOMPRESSED-BYTES 20024 :UNCOMPRESSED-SHA256
    "068883ec799b7dd7f6d804f60b04bc0c9b227dc51dc22fb1dda0ece4dc393cf4"
    :COMPRESSED-BYTES 2728 :COMPRESSED-SHA256
    "5dd80ada87ede3a1f149c322b5bc928723405fe78add3475135ed8fdc9bf1a7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/15-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1755 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-4.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "825bfe782b079a545f3affc0b4f25d5278ceef13f7ea331e35999dec7d83e0d8"
    :COMPRESSED-BYTES 1445 :COMPRESSED-SHA256
    "5e6ea3f5b30f0750fa44e4f5ddd6196d733504d1da52370f7f5cf88aad43fbe1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/15-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-3.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "0f26667d8ef07becffdb748048400f6a2b2258ec1a703abeb9e5ed0f065fd5e7"
    :COMPRESSED-BYTES 1394 :COMPRESSED-SHA256
    "bdb9263b371c962d2a2cdc5365adf2bbeab26a093da8d1579ccf09e472685e70"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/15-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-2.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "59faf0589a228b2c2a35045ecf62c7ff33ef4a9cecf8386565f609b5872bd8de"
    :COMPRESSED-BYTES 1376 :COMPRESSED-SHA256
    "01a02b47164c74a9bcededb329416974e320270f04663c6612e3f6798e79bc1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/15-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1683 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-1.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "152cdd6f3ff1404f0c70e1418cb0c2d0ccb78746be6cd9e836cdfc09f76360e7"
    :COMPRESSED-BYTES 1373 :COMPRESSED-SHA256
    "bb4abd172b9fe2c58fef7f56ae6eacc7272fefaa5a75c45953e4a34501609a17"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/15-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8813 :STORED-BYTES 1659 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "15-0.lisp.gz" :UNCOMPRESSED-BYTES 8813 :UNCOMPRESSED-SHA256
    "8e2a14f26a4fbb7e44e0d2edbacd6d2dcfe79c0ebcd5943b676663acf6bba47f"
    :COMPRESSED-BYTES 1349 :COMPRESSED-SHA256
    "8fe4d9a2a398454050be8b06f5d009f5a2515bf4b907c522fa505f5f702cca9d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/14-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-4.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "09e48b4428d22c5fa154977a3b7b5b1bea6f1534f07f0395a6de9b88443c9a2c"
    :COMPRESSED-BYTES 855 :COMPRESSED-SHA256
    "93017af5d12caf6c25eedd4f327f9b24c0a0eb1acd5dc0110edfe6fe80339aaa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/14-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1223 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-3.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "acf75775fb6eb78598328f800e97298977a92ab5a517e6cb7bec787fc9fb5d05"
    :COMPRESSED-BYTES 914 :COMPRESSED-SHA256
    "bfd82ea355e53c6ae270a69d524b81cb59296b060001abe93507530b0a551760"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/14-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1187 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-2.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "491e4585988f166ed2638d526d58ca8ed495652bcdb48d416f8a401aa0830a00"
    :COMPRESSED-BYTES 878 :COMPRESSED-SHA256
    "83258617b0a65e14b87815cde608b9db51a649f05e002f2351389ca566beced8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/14-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4813 :STORED-BYTES 1158 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-1.lisp.gz" :UNCOMPRESSED-BYTES 4813 :UNCOMPRESSED-SHA256
    "241617d59183e9831564c2a6a4edcd22987f6a7974ade5394c1986fe7dbfecd4"
    :COMPRESSED-BYTES 849 :COMPRESSED-SHA256
    "d729c942a3146558367772a591a9bfb3b74cdd0b418059eadfd4f473088c3f76"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/14-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4807 :STORED-BYTES 1117 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "14-0.lisp.gz" :UNCOMPRESSED-BYTES 4807 :UNCOMPRESSED-SHA256
    "b910a4ad043c585ad2ee8cb364f0e8cf2a28cfb8b91dc80b316cce24112c64a0"
    :COMPRESSED-BYTES 808 :COMPRESSED-SHA256
    "aaf16e3f7af0776d757c26b3cd4fe43ad716c01ac36b1b8b53ef8df4b80aa4a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20050 :STORED-BYTES 3637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 20050 :UNCOMPRESSED-SHA256
    "72a23c4c44aff0afda80a2e85cb5413a9fc7b2e9fcb9bad39d16c695f5f175df"
    :COMPRESSED-BYTES 3326 :COMPRESSED-SHA256
    "030682dc32e276865f40d31a43db30f4aec5be7d70a5106fb15339943cb92899"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20054 :STORED-BYTES 3577 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 20054 :UNCOMPRESSED-SHA256
    "21b928ee86c177e41555b1d0afa3131ef745996473acce9f7edf1d458b6b45d5"
    :COMPRESSED-BYTES 3266 :COMPRESSED-SHA256
    "a588d657f64e51ab890b4d317b9590d8fb58d14e19826e179b4d656564f1b26b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3575 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "141420b067be519cb89a9e0f43b271644ace889c91c36a5254b3a5ebc11bc42c"
    :COMPRESSED-BYTES 3264 :COMPRESSED-SHA256
    "fef7a795550d1e090814d9dc056ea282d662ad1cfed75d9ebedd9f51f730ae64"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20056 :STORED-BYTES 3577 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 20056 :UNCOMPRESSED-SHA256
    "9cba89dd4fd30255d1a43287ce9135cbdb62eadd63e58df39f56c561bf391d1a"
    :COMPRESSED-BYTES 3266 :COMPRESSED-SHA256
    "e765dcd6702b22e48c0393d625305c956c3e0b932439cc278a89adc2347495c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20067 :STORED-BYTES 4271 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 20067 :UNCOMPRESSED-SHA256
    "b02667193151b578d2d7fc60c091a4a2a25ac08fc373ea5d97db3df059daa08a"
    :COMPRESSED-BYTES 3960 :COMPRESSED-SHA256
    "76d495f142d89c526e5d4067aee171187fe57982757eca91f3ea1eb70c686d54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10448 :STORED-BYTES 2105 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 10448 :UNCOMPRESSED-SHA256
    "775e07edb364371a6f3a3663788da83abb61e865a570baa49b63f59145854381"
    :COMPRESSED-BYTES 1794 :COMPRESSED-SHA256
    "6261c432fdd5af003902d16620fed8e1f54e04fe008cb95363050355878417ae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10448 :STORED-BYTES 2071 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 10448 :UNCOMPRESSED-SHA256
    "444d8d710896c199929a72e71f7a2184f99dcfc567ddb71c0e5dbae8f6a8bb78"
    :COMPRESSED-BYTES 1760 :COMPRESSED-SHA256
    "a1caf9b2ccd3cc42b613717996642992b6d733543244745b2cb7223afb2a909d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10445 :STORED-BYTES 2058 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 10445 :UNCOMPRESSED-SHA256
    "af7e54b397ae0bcca65bb34410073cd83e72e386ce5f06649dcad0dd6011840f"
    :COMPRESSED-BYTES 1747 :COMPRESSED-SHA256
    "498f8f9dedbffc5623e9648edebb3715f5c2d8df50c41149961aba9a556d5727"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2031 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "53517c4c34826c4868e46e84a391627194bb4a86f1654b2a1a1376c0d8353608"
    :COMPRESSED-BYTES 1720 :COMPRESSED-SHA256
    "9a3200c490305de3eca73a171d5fe4974fc2be65e880af7e31f6f5d4fc1ed24d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10446 :STORED-BYTES 2473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 10446 :UNCOMPRESSED-SHA256
    "271b1fd09f33d5aa1f363e9ba58b5679622e3413bffc0d680ad20bf3c23c0b2f"
    :COMPRESSED-BYTES 2162 :COMPRESSED-SHA256
    "d3d60fd1e81c12084687ffeff017ff87993c40b462396a10f9564dff2264b670"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1359 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "66253f552d42f92a7cb661e83d5bcb8f7a1b21911a10ea605686129f29b4d290"
    :COMPRESSED-BYTES 1049 :COMPRESSED-SHA256
    "a39514693efb5471781411b06820919cd8c7c634c8773acde5d92f9135ed109a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1330 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "9fd16d6412c08c40c770a0abde6a2a1596ee3d6b3aa5a569d488d3be3d40c9a0"
    :COMPRESSED-BYTES 1020 :COMPRESSED-SHA256
    "d7ce416267aaa2562965bfa79437850e759fe969f5f00e7e034647a41d91408c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1373 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "fea442c1ae0a2b179f829eeb7b0f6f424cdd971e8c8252f1d5702e1ac57a920e"
    :COMPRESSED-BYTES 1063 :COMPRESSED-SHA256
    "4bc88366ab6d99357fbec9ed23e98a08b6818c6383d494e6d08e1358ee7f05e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1376 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "95e3a2af1f24d4248ab515429094a58486f9862aabc515eb3fe9ef81dd6753e4"
    :COMPRESSED-BYTES 1066 :COMPRESSED-SHA256
    "e98c9c2bc808b9ccf0585c5f6d293678e801fb45d306987fbdb85cb0730eab8e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/integrated/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 1571 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 5638 :UNCOMPRESSED-SHA256
    "a2b1b46ae066a316fcdb58f7f2774d9f3fb1e1b92047c8b037b73da9316018c2"
    :COMPRESSED-BYTES 1261 :COMPRESSED-SHA256
    "4e136dc06bd8c46a81923e1093e614657992e39ad0d2243da794071d036e1672"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-01/server.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7770 :STORED-BYTES 2735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server.lisp.gz" :UNCOMPRESSED-BYTES 7770 :UNCOMPRESSED-SHA256
    "306f88fa7c765e63aeca9851f0fab87f89aea8f1fb80706a1cec5c20236ac9e7"
    :COMPRESSED-BYTES 2423 :COMPRESSED-SHA256
    "156e1f6a09885af65af2011ceec46a9c14040d7fc2bd4cf1a5c28e7a042dd163"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-01/bench-variant.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13119 :STORED-BYTES 4198 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench-variant.lisp.gz" :UNCOMPRESSED-BYTES 13119 :UNCOMPRESSED-SHA256
    "ffb9505260fb65c7a76d79418c6d2b3958cefbe5eac18cbbdc953e7e5434abb9"
    :COMPRESSED-BYTES 3878 :COMPRESSED-SHA256
    "445e8af45c70dfcd705727ef24f5bee7f9ffba9f7253e378444cb2c9431b86b9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-02/server.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7770 :STORED-BYTES 2735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server.lisp.gz" :UNCOMPRESSED-BYTES 7770 :UNCOMPRESSED-SHA256
    "306f88fa7c765e63aeca9851f0fab87f89aea8f1fb80706a1cec5c20236ac9e7"
    :COMPRESSED-BYTES 2423 :COMPRESSED-SHA256
    "156e1f6a09885af65af2011ceec46a9c14040d7fc2bd4cf1a5c28e7a042dd163"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-02/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13160 :STORED-BYTES 4212 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 13160 :UNCOMPRESSED-SHA256
    "5aa094237242a6abdf7d958da453e2e8176537efe4daf9284ec0ab0fcccca699"
    :COMPRESSED-BYTES 3900 :COMPRESSED-SHA256
    "58192b740d5e2109dd7f8637dc61501733d83aa4845d3c3531b80fec7ced155b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-02/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4745 :STORED-BYTES 1644 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 4745 :UNCOMPRESSED-SHA256
    "cfe972ccdb1a3206bfa9e8d404f7d1e65f6d359b19874d2d7fe1e8fad71e2534"
    :COMPRESSED-BYTES 1323 :COMPRESSED-SHA256
    "49238d15dffde60907aa3608e3af0b609520a28aff11ff1216de13ace197a2d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-03/server.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7819 :STORED-BYTES 2738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server.lisp.gz" :UNCOMPRESSED-BYTES 7819 :UNCOMPRESSED-SHA256
    "8453be24245ada40f62356c0524b266472827f319b9d5e47665578128ca1c2b7"
    :COMPRESSED-BYTES 2426 :COMPRESSED-SHA256
    "1985257c36b538d4f049d107216d35ca19a46c461028d853c9ab4d8c527dd207"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-03/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13160 :STORED-BYTES 4212 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 13160 :UNCOMPRESSED-SHA256
    "5aa094237242a6abdf7d958da453e2e8176537efe4daf9284ec0ab0fcccca699"
    :COMPRESSED-BYTES 3900 :COMPRESSED-SHA256
    "58192b740d5e2109dd7f8637dc61501733d83aa4845d3c3531b80fec7ced155b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-03/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3632 :STORED-BYTES 1309 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 3632 :UNCOMPRESSED-SHA256
    "acf5e0ad0c0c1335459adf42edd9e53dedf23c043b1ce5865ae070247a5a3d1a"
    :COMPRESSED-BYTES 989 :COMPRESSED-SHA256
    "327cef048ad92ef60b92284d7c30c179f5cdc8213490e58a57310b4fdfb0b30b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-04/server.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7821 :STORED-BYTES 2738 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server.lisp.gz" :UNCOMPRESSED-BYTES 7821 :UNCOMPRESSED-SHA256
    "98c1264f8a9a340bd9ae8b1da2cf1178fdcd86669e8b3349a61be910fa3bda5c"
    :COMPRESSED-BYTES 2426 :COMPRESSED-SHA256
    "89c3be7ffba227347da0af50c2473a71ef95df48b535abb2e5bd3a636ae1015b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-04/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13160 :STORED-BYTES 4212 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 13160 :UNCOMPRESSED-SHA256
    "5aa094237242a6abdf7d958da453e2e8176537efe4daf9284ec0ab0fcccca699"
    :COMPRESSED-BYTES 3900 :COMPRESSED-SHA256
    "58192b740d5e2109dd7f8637dc61501733d83aa4845d3c3531b80fec7ced155b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-04/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3636 :STORED-BYTES 1313 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 3636 :UNCOMPRESSED-SHA256
    "8fba3100306d5464ba7ec690b22aeebaaa270d6941cc7aac9da6dc7987cbaeba"
    :COMPRESSED-BYTES 993 :COMPRESSED-SHA256
    "9f5e881646fe63e0f437b486119a4420da7d7b25aa530b553dcd946debbe7217"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-05/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3733 :STORED-BYTES 1042 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 3733 :UNCOMPRESSED-SHA256
    "d52d20865da63ce87b2c0f6ec837a29d3ccfb6e21d56d1da5e57c0f55714ebb0"
    :COMPRESSED-BYTES 722 :COMPRESSED-SHA256
    "75af79eadebd210439a96846cd67bed0c3b1e1c411bb9f3dd79770feafb290f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/smoke-05/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 3672 :STORED-BYTES 960 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 3672 :UNCOMPRESSED-SHA256
    "7c4cd48d96d0c471b7707da9a3f1c6e756dd254bc4de9c88d582169158239596"
    :COMPRESSED-BYTES 640 :COMPRESSED-SHA256
    "f0cd941944f3cfd448bd3cc219f69ed92c74065f91591309beacb74b3b79fe21"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8344 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "3fa77c65da87be47c29b734767eb86935e8c7266e8a65ac8eb03b0612a274f37"
    :COMPRESSED-BYTES 8031 :COMPRESSED-SHA256
    "ab7714fcbbe69efa210f00b436b85c8e0a4993db8fa293ef50fea9bab250c1ea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22977 :STORED-BYTES 4606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22977 :UNCOMPRESSED-SHA256
    "44868e896b9f8a208b9d5ae88f3514adf8a8354d28f3f22c5b7856082bfc013f"
    :COMPRESSED-BYTES 4293 :COMPRESSED-SHA256
    "32efdf2e259c2d4c82e240a8309aabcc7bc369e29fbcae4be7f379dc75475b7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331092 :STORED-BYTES 45768 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331092 :UNCOMPRESSED-SHA256
    "8b09b46ea85306752202cac72154e862f88d848548827e37f21fcae57e1bcdc7"
    :COMPRESSED-BYTES 45453 :COMPRESSED-SHA256
    "12be5787b99356fa00c4763b9ddb2543f8e6877f792b2e2da23069e75d8ec340"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24096 :STORED-BYTES 4286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24096 :UNCOMPRESSED-SHA256
    "adaa8765002e94e05750025760b9a32f23c9713ba57b407e43f852e4ac0d0a5a"
    :COMPRESSED-BYTES 3973 :COMPRESSED-SHA256
    "842d82e71e23a35c02b611a5cecfffcee1bbe6adada1388534042e49ee247e20"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10143 :STORED-BYTES 2235 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10143 :UNCOMPRESSED-SHA256
    "490973ce973e1ecd6c53dc14e09bac70ccb87e33965ecc420cefd5e4bd23e341"
    :COMPRESSED-BYTES 1922 :COMPRESSED-SHA256
    "1a6d59169b2bbc893849ed2d1878dd55dcce456063dee8eafecf7391238c0015"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1924 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "6eb748381d6751a664bbbdd5882505ee66ad74b386961e40fa08ca7d8510c2a4"
    :COMPRESSED-BYTES 1612 :COMPRESSED-SHA256
    "73a153e4f68e02d50582a8197c7127f6c4d289887dab0dd07cf5605a83dbcf9e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/4002530559-check-55391-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27227 :STORED-BYTES 3191 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27227 :UNCOMPRESSED-SHA256
    "8f461d3379fd30ce6042986e59b1a897e0d8533b563934582e9b867b88b3414f"
    :COMPRESSED-BYTES 2878 :COMPRESSED-SHA256
    "8db90e871b9387f4ac009cd2d81e2889638b7d817f123e89d6041cd434e2cd9c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/ci/selftest-1793541812-55833/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/ci/selftest-unix-integrated-20261101/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-unix-service-latency/support/command-archive-collector-self-test-6sLCeB/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "913921ded6442140d5937629faf8016a4378bb9bfc760b2c2410f720df395cce"
    :COMPRESSED-BYTES 3214 :COMPRESSED-SHA256
    "b97a6047b6346befa8104a56d8c75b16f60f0e6d370b002c2f19546f9b4b98db")))
 :DRIVER-SHA256
 "6157e3c7860175fb2162873f7fdbbd192a2ec407f9e36e3f875782e246d4ff5c" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :RAW-BYTE-HASHES :VERIFIED-LOSSLESS-EXPANSION
  :NO-NEGATIVE-FIXTURE-QUALIFICATION))
