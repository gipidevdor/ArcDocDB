(:KIND :ENGINE-CONDITIONAL-EVIDENCE-CLOSURE :STATUS :PASSED :VERIFIED-FILES 526
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 197842 :STORED-BYTES 59538 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 197842 :UNCOMPRESSED-SHA256
    "2dc5a138dfd51aba0d603f0599014947b7755115a2ed4b30d5a7e318906a26df"
    :COMPRESSED-BYTES 59214 :COMPRESSED-SHA256
    "51103eec2094dee995954d431d110fa884c77d708b49221d26d95481e3d35952"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/archive-data.lisp"
   :STATUS :OK :ORIGINAL-BYTES 220019 :STORED-BYTES 20858 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "archive-data.lisp.gz" :UNCOMPRESSED-BYTES 220019 :UNCOMPRESSED-SHA256
    "c08ce50648518154a6bfe844d74b595d36dac42ae901812aec785c6dbd791682"
    :COMPRESSED-BYTES 20537 :COMPRESSED-SHA256
    "8eb7cd69826fec60ee812c591ab7eb79dd14dcae4e1fead03dfae2973fc89028"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/4002632603-command-57808-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365028 :STORED-BYTES 117110 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365028 :UNCOMPRESSED-SHA256
    "7a66062ba3855796bdbe630bd7cf4e7c056f712e57fd3199f6331658e447b935"
    :COMPRESSED-BYTES 116794 :COMPRESSED-SHA256
    "91d4d5a58a59480f711f1582c4af0ab907bea50ef0615d4d3c98309dc9c15b20"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-allocation-sbcl10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370766 :STORED-BYTES 117280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370766 :UNCOMPRESSED-SHA256
    "4500d9c1327e046476b20c467163709087101f9a8dd079ff5f2385ba97930a05"
    :COMPRESSED-BYTES 116964 :COMPRESSED-SHA256
    "e2f2d632cf527209d5d14034a5f5d20ef51a65dc0973a9e95e1b3b70cfb12100"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-allocation-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370739 :STORED-BYTES 117283 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370739 :UNCOMPRESSED-SHA256
    "ce2fe6e5b021c3fe5bb79ba6afe0e991740f1aa79f6abad354436454e6bd159a"
    :COMPRESSED-BYTES 116967 :COMPRESSED-SHA256
    "551ae747c73f7b5cf7e425914c7bf6c702ead309559450f7b79daaee0b1bfcec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-archive-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364429 :STORED-BYTES 116964 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364429 :UNCOMPRESSED-SHA256
    "0a15c06902759d235c4e6b65e756c138404edd036568711d070ac69e8301f9ce"
    :COMPRESSED-BYTES 116648 :COMPRESSED-SHA256
    "2b9869497651c07a4fd23ce5d910b4494551eb903e69369531ec74b1c6a0bd48"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364478 :STORED-BYTES 117005 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364478 :UNCOMPRESSED-SHA256
    "2b0e8369311c9a73eb707554c34b99654a6e7992791270556fef9f13805366b1"
    :COMPRESSED-BYTES 116689 :COMPRESSED-SHA256
    "bd8af21dc6852a9514f4334f51518c107a71aba940ead27bdcb8c95e10cf0554"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-cleanup-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364432 :STORED-BYTES 116969 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364432 :UNCOMPRESSED-SHA256
    "1564dca18a6a07f8d57628cd4afb59be6cab3715ebf3bdce750bf31df87766a3"
    :COMPRESSED-BYTES 116653 :COMPRESSED-SHA256
    "aca6a7913e8b154b3b5e1ec341d50ddcf46d50b32f2fcb46b525cd0e03495339"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-close-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364421 :STORED-BYTES 116948 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364421 :UNCOMPRESSED-SHA256
    "e9b9682e060c7198c75a831a7419de0f30a8b6357e65c46dcf043e61465c4159"
    :COMPRESSED-BYTES 116632 :COMPRESSED-SHA256
    "52c154737c2ccbbe219248b3e3fcd687df0fb7a5f64f5420e4bffd2ff074075a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-docs/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370508 :STORED-BYTES 118351 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370508 :UNCOMPRESSED-SHA256
    "00108d406e6622be6785d98367b6b57181a3bc1a2b34cf8fb4641e830c2879f6"
    :COMPRESSED-BYTES 118035 :COMPRESSED-SHA256
    "cb8646624195737ad6b6f4995a48e7fcf3229b30c39c2706a2454834f91e0d38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368925 :STORED-BYTES 118432 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368925 :UNCOMPRESSED-SHA256
    "d5a98bf286b84aa95d4966b3867bfb6376ca39f35cb48635d38e723728d28e09"
    :COMPRESSED-BYTES 118116 :COMPRESSED-SHA256
    "a6a2145df6a9fc62c258a3667f0f6bb04c6d8233211c12e0b8d4e23338120628"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-focused-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369009 :STORED-BYTES 118447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369009 :UNCOMPRESSED-SHA256
    "bc1e5a6774706ab3890809bb93fdb7fa8f5b566c5ca4d42cb5d3074aac4d6f67"
    :COMPRESSED-BYTES 118131 :COMPRESSED-SHA256
    "949cb0a7953b9912a10162a197d0804bb1bfdb26fbeaaa3e9bc993d4493349ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-ledger-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364446 :STORED-BYTES 116977 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364446 :UNCOMPRESSED-SHA256
    "2f6ff154d71a3d72e28647e631510cbd4454547ca83d316de03e35bec0d53998"
    :COMPRESSED-BYTES 116661 :COMPRESSED-SHA256
    "28d0dbeb02962972d17c0b22eaed683a9aa69a983e563b6a6683787b225011ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-qualification-sbcl10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 390172 :STORED-BYTES 119849 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 390172 :UNCOMPRESSED-SHA256
    "945644cab3a7930f8fa792712bf7cf8bf877d4e0b06e054b019f46c52ef38970"
    :COMPRESSED-BYTES 119533 :COMPRESSED-SHA256
    "ed3970d7cf447452c1cb21b8172021cb27e2166e70d54528e4d7d960c6fbc0fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-qualification-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 390147 :STORED-BYTES 119848 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 390147 :UNCOMPRESSED-SHA256
    "76b7bebb6f187985d7f42e981b5b87759b8ecedb2c95691ec865bb79bc51dbe0"
    :COMPRESSED-BYTES 119532 :COMPRESSED-SHA256
    "aed7f62d6722eddae5108466721a5c564c6435cc52891952655e4768ff6bf5ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-static/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364650 :STORED-BYTES 117008 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364650 :UNCOMPRESSED-SHA256
    "7f2b14016bf57d6bea0b1bd23cae623f35dd8487f3f83aaeade254ceb7eb3e26"
    :COMPRESSED-BYTES 116692 :COMPRESSED-SHA256
    "0dd3ec65a6132cc9b45801a9dd88e7f4118989f2efc47c80a1062847c4eef2b4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-verifier-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364407 :STORED-BYTES 116948 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364407 :UNCOMPRESSED-SHA256
    "b3899cfdc7d3ed63950ea63901e81d89dcb6ad5836ea5587461dc3643b22d284"
    :COMPRESSED-BYTES 116632 :COMPRESSED-SHA256
    "d993dc79596f7e2ef04c192a69cac00299db6b9346713f2bda855d2266085305"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/commands/engine-if-verify/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364427 :STORED-BYTES 116969 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364427 :UNCOMPRESSED-SHA256
    "e249fc29044609d95e89b0530fd54369bf9590a7e23ec1d4ddddf3d77bf3f748"
    :COMPRESSED-BYTES 116653 :COMPRESSED-SHA256
    "49ba937fc45d1da58f31b7124e358bdb769fb0465809e1fc16c7d58ef9feaabb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-01/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 255430 :STORED-BYTES 42445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 255430 :UNCOMPRESSED-SHA256
    "1abfd160709a19cfaed8a59c59dd6550f2af749a15e7a85f7e8c37670f78a145"
    :COMPRESSED-BYTES 42129 :COMPRESSED-SHA256
    "ff2ff44cdb9c1593db7cd30ce0315e22114fc50b29e2b58e4b909ab746b13b2d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-01/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13333 :STORED-BYTES 1816 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 13333 :UNCOMPRESSED-SHA256
    "ef475a41b87f3ff322e07122540cab3d343fdc99873eb015ceb3e92cee56974e"
    :COMPRESSED-BYTES 1503 :COMPRESSED-SHA256
    "6f45e351ebe0fdc013c71354707490956d4597ca436e614616ced318df4b3d79"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-01/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5641 :STORED-BYTES 1594 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5641 :UNCOMPRESSED-SHA256
    "ef1b80fd39c5f2b9f6059898b2b92f78a134c803a2423432cb38abedeeb7e566"
    :COMPRESSED-BYTES 1279 :COMPRESSED-SHA256
    "d85cc110cfe19033f64c1cffac44a0bd75369f7789a2ad772d1f75ef883e6dfb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-final/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 255530 :STORED-BYTES 42461 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 255530 :UNCOMPRESSED-SHA256
    "0a573a78e4082b7473f4aef9be332fd1b5aed654cf9676d11ed1b7448474bec4"
    :COMPRESSED-BYTES 42145 :COMPRESSED-SHA256
    "77f61d9e19f612d62dab71cf8816cf8053c44acfc8f2bb17fbb3505afd54e184"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-final/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13576 :STORED-BYTES 1839 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 13576 :UNCOMPRESSED-SHA256
    "ff3018f42a2a88915e9438c92df7926a3aa30f0d62b2edc4e86a57f0ba2f596c"
    :COMPRESSED-BYTES 1526 :COMPRESSED-SHA256
    "d2134763e0e37e019d101a984f07cd98e51c3e26af791db5ea14ec1e521b6ca8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/focused-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5741 :STORED-BYTES 1612 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5741 :UNCOMPRESSED-SHA256
    "7a3c8df365fdcef7b0fc5f62fe3049918a6b0dc08c0356c0f4963bd063408222"
    :COMPRESSED-BYTES 1297 :COMPRESSED-SHA256
    "17d31014b427d056aedbefd0bd983c83ae519e73c534b70fb0ed9a507ebb40dd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl10/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 255531 :STORED-BYTES 42474 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 255531 :UNCOMPRESSED-SHA256
    "49c40e4e6344b3620ef8f2934e44d1678d630fa9d25a8adb04de13c308e9b661"
    :COMPRESSED-BYTES 42158 :COMPRESSED-SHA256
    "1907b8ea459d1e32c20d0f2397c0a305e987be0f7840bb13289394f8f768a5d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl10/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14104 :STORED-BYTES 1891 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 14104 :UNCOMPRESSED-SHA256
    "6b9daa89ee492b1aadaff8ad24f51c189c46657c3cbd923b172cf5c26d9afd98"
    :COMPRESSED-BYTES 1578 :COMPRESSED-SHA256
    "4e743231ff5312d8082aba723d3191c0bea15ed9a54e6dac01323754bff11609"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl10/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5963 :STORED-BYTES 1661 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5963 :UNCOMPRESSED-SHA256
    "276440fde85222762cd4a505a5497c6a7914a05b8896df2e472e8e4795e2505c"
    :COMPRESSED-BYTES 1346 :COMPRESSED-SHA256
    "c0c6344a8b5d7f42be25af0bb1ffee144bf2a7042286ef5cf88cb1f2def13016"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl9/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 255530 :STORED-BYTES 42473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 255530 :UNCOMPRESSED-SHA256
    "6070ae59472dfd6e5f583a0fcf48e8bd3ca0647f0ecd4283e7fd0e1551f97d32"
    :COMPRESSED-BYTES 42157 :COMPRESSED-SHA256
    "9243326314dda03a3f191d7c0651e117c5df15d0d1198b9a74c5eea12df9c901"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl9/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14104 :STORED-BYTES 1891 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 14104 :UNCOMPRESSED-SHA256
    "6b9daa89ee492b1aadaff8ad24f51c189c46657c3cbd923b172cf5c26d9afd98"
    :COMPRESSED-BYTES 1578 :COMPRESSED-SHA256
    "4e743231ff5312d8082aba723d3191c0bea15ed9a54e6dac01323754bff11609"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/qualification-sbcl9/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5962 :STORED-BYTES 1660 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5962 :UNCOMPRESSED-SHA256
    "304f650e9d7d03ef88d2811bd7a594c15cd7bf365fd5652a97f731e1bf353fc8"
    :COMPRESSED-BYTES 1345 :COMPRESSED-SHA256
    "98b0a57c60a986df7b22d8c5f76b32ff7bad57c549f7746240ec8ed56e65cc44"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8338 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "1a64cc1e916b93791a284a8bd56b997e0ed31bb819b2f05a34dc9c718dd56d2a"
    :COMPRESSED-BYTES 8025 :COMPRESSED-SHA256
    "1378a07e6802bfb776de524e4003f493b5c7805a3471ec24ebb335d33f234078"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22977 :STORED-BYTES 4614 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22977 :UNCOMPRESSED-SHA256
    "265b5d5f41dbb6d0b018b8eec4e9894318920b1b3f56f7fdbc2bd0fe8b417b15"
    :COMPRESSED-BYTES 4301 :COMPRESSED-SHA256
    "697dc4fc6100e250d5a1c2a94b7938014fbf5df6a90572f0e14d27f3b1b6a3be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331092 :STORED-BYTES 45767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331092 :UNCOMPRESSED-SHA256
    "84e3422dec198618b6fbd737cb9d0ecd29e13028cb79057b1287f91d010006cd"
    :COMPRESSED-BYTES 45452 :COMPRESSED-SHA256
    "e89756a2249834000d9dc173e0db96c06cd7bbe7e49bc8a3a9ebcbaadfd62d91"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24155 :STORED-BYTES 4253 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24155 :UNCOMPRESSED-SHA256
    "99a7f629c2a577203caae69534a5271ce7985799b7081c3b6c677420cd0bd8dc"
    :COMPRESSED-BYTES 3940 :COMPRESSED-SHA256
    "f1cd84f2acfbcc71018c5d75fe8a7dab2e59a854e8f3347642bd604d886bfd37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10145 :STORED-BYTES 2225 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10145 :UNCOMPRESSED-SHA256
    "d567b38b522fc2d0310f24cdcc127c055d54ec4957de04d1db6d80509b30b920"
    :COMPRESSED-BYTES 1912 :COMPRESSED-SHA256
    "d8cc21e0b9f388444dabebbb1bc0656181e9009d5d6ed8dcb7024c00dad7282e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "ab39fc0f4d390ed396d56c8af7c67f6c375c76d7f79642c6bc098e23dc431fa9"
    :COMPRESSED-BYTES 1611 :COMPRESSED-SHA256
    "4a77d133f62143d21710434d93ff06b63711387ae75923b0cdc2ad6075a253f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/4002632555-check-56995-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3190 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "9481219b8f48fa3e06c0be967f30638441e0c142ba6f21e84a99cc9f62c40967"
    :COMPRESSED-BYTES 2877 :COMPRESSED-SHA256
    "d197876e9e19c21f8999ef26748cbee90c7488642a4e2a16efe81877dde34846"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/ci/selftest-1793643803-57807/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-engine-conditional-groups/support/command-archive-collector-self-test-jqqVMU/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3538 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "c6bbee18500fa4c56167279814c7febc57fc19159d969de16cffa50994692620"
    :COMPRESSED-BYTES 3215 :COMPRESSED-SHA256
    "31e85259cef8847d38945a341e9e43e48d7212e083c01cfb0051e3a29a68c7e2")))
 :DRIVER-SHA256
 "4e0990318e29f5662cd621dca179ab4683b4fe047362e6bf838e7a79f78566fd" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :LOSSLESS-ORIGINAL-BYTE-HASHES
  :ALL-COPIED-COMMAND-AND-CHILD-LOGS))
