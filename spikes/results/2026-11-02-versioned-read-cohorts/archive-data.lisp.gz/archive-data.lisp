(:KIND :VERSIONED-READ-COHORT-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "4002635437-command-80909-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "4002636793-command-93440-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-allocation-sbcl10" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-allocation-sbcl10-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-allocation-sbcl9" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-allocation-sbcl9-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-analysis-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-archive" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-candidate" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-candidate-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-checks" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-docs" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-focused-01" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-focused-02" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-focused-03" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-qualification-sbcl10-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-qualification-sbcl9" :STATUS :FAILED
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-qualification-sbcl9-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-selftest-archive" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-selftest-archive-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-selftest-cleanup-worktree" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-selftest-cleanup-worktree-final" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-selftest-close" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-selftest-qualify" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-selftest-verify" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-selftest-verify-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "version-cohort-static" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-static-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "version-cohort-verify" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :RETAINED-VERIFIED-P3-ROOTS
 ("/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/"
  "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/"
  "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/")
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
   :BYTES 27784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/tests.lisp"
   :SHA256 "72d8ca8f69a6df2de0109bffa94908d4d6e32d4b899bad224a91d9e25814a51c"
   :BYTES 2463)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/report.lisp"
   :SHA256 "1ae97ae4103f11530749a8627e2ba2cc908579dc933ba091a1eafd94a48a5125"
   :BYTES 632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c"
   :BYTES 2041)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2"
   :BYTES 3214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f"
   :BYTES 663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793647992-93439/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23"
   :BYTES 976)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-fy5eEG/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/command-archive-collector-self-test-fy5eEG/self-test-report.lisp"
   :SHA256 "62d671be2c6b8ddfe18bdea4851440c1b8201870e639bc66f9f2c4f47835986c"
   :BYTES 28790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636464-command-86816-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636464-command-86816-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002635437-command-80909-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002635437-command-80909-0/conservazione.lisp"
   :SHA256 "4c64e92d2b2a5d27e30b06bdb215ac46d772958e4dd9921a6ee160e35ad4772f"
   :BYTES 1776)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002635437-command-80909-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002635437-command-80909-0/report.lisp"
   :SHA256 "89260a993e746283794a4e2ddfbefc5a5e4a188783f22525f16d7157617560f6"
   :BYTES 317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002635437-command-80909-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002635437-command-80909-0/report.lisp.gz"
   :SHA256 "f7578300641cc24969a665d0a89260a18baa89c00adbf33939d827450e00a011"
   :BYTES 399545)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636793-command-93440-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002636793-command-93440-0/conservazione.lisp"
   :SHA256 "389b465ce18bc75db2f5ec55f9b8be28e7995b04528d32300d9c2cbc61d85b17"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636793-command-93440-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002636793-command-93440-0/report.lisp"
   :SHA256 "e8772b06981421fcbe0df4ced16cbe319bc8beaedb3b7a33c991547ad392c276"
   :BYTES 365537)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl10-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10-final/conservazione.lisp"
   :SHA256 "d97abf606074db82d20cddf59c6a384a4a25cd59f1a7f7ee68214adfca7cbabe"
   :BYTES 1208)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl10-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10-final/report.lisp"
   :SHA256 "138f6c05551ec260f9b4ec71e0a2e268e1d4444c35510be66a4ddb5b18de7191"
   :BYTES 366406)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10/conservazione.lisp"
   :SHA256 "c980190604d7f510d0cba3734f2100599f548915d5bfce23660807e344fb6cc2"
   :BYTES 1196)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10/report.lisp"
   :SHA256 "cf6e545815645de6ca4539f5a135fb4a77bc391d27e0d56b71ffdb25074cfac9"
   :BYTES 366407)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl9-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9-final/conservazione.lisp"
   :SHA256 "545e8a2327a12de4c407305bf6bb74b682cbdc433ecdb153069b5b5cc8c1cf34"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl9-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9-final/report.lisp"
   :SHA256 "d008dc9a8ac207ea98e35182967ec78af9b2b573e9a4ce59197a5a7f8f40735a"
   :BYTES 366379)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9/conservazione.lisp"
   :SHA256 "d818ae39a521af9730c344a13a2d034778b1093050a38bcd72de9686d191e5ca"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-allocation-sbcl9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9/report.lisp"
   :SHA256 "4506e597037406b1b77d3fe4468828660ed8fc65342dd83754827e69b0219715"
   :BYTES 366379)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-analysis-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis-final/conservazione.lisp"
   :SHA256 "23b34b6e834533d0fa38aec6dc44f72d772aa5c51c72ba6978cdfd88343c1532"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-analysis-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis-final/report.lisp"
   :SHA256 "4034e4ea08ca1cef362eac8aef401b59d5b946dcc92afd72a0d653bd5df47ba2"
   :BYTES 364995)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis/conservazione.lisp"
   :SHA256 "c618a26213726c50b8962e2b188441cad6bc1f5d163c07734fdc96964cfc86af"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis/report.lisp"
   :SHA256 "4933b0783dda6a31219f6390895ccf7ee19ba78f4a6aac8ac58742b7ea0f8ff2"
   :BYTES 364995)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-archive/conservazione.lisp"
   :SHA256 "82e41288bde4ba7e2bebb560954f8e7694ad80f071ccbe914def42202ae3bf51"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-archive/report.lisp"
   :SHA256 "96f1cf3d0d0f398f15a242c0e089634240bd703956d6ca05c1d8fbf2818930d7"
   :BYTES 379964)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-baseline/conservazione.lisp"
   :SHA256 "25e46aa783748da16d558fb24ae639b2aa0bd2d7a0f7da98449593e498db643e"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-baseline/report.lisp"
   :SHA256 "b2b069bc2f09da83609c67392cec74d67bfae5eb0a267e75a7e274062c075424"
   :BYTES 364191)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-candidate-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate-final/conservazione.lisp"
   :SHA256 "f378c16af7b2e874ae37abeebd702f603d6c8aa3676510ca142d3ea4532b206e"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-candidate-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate-final/report.lisp"
   :SHA256 "6265768cb4f1f4a6777270a4417b010fb5cdd539c21ee8a3ebad98dd9a83b14f"
   :BYTES 365096)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-candidate/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate/conservazione.lisp"
   :SHA256 "05dbdb08ef519c18285c2777dc3e9780f7b8076498ef1d3847d32d19e337f53b"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-candidate/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate/report.lisp"
   :SHA256 "922c3994b13e0d1b0a74e0622c227bf985d21619bc367523e4dc0b639a0c3000"
   :BYTES 365090)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-checks/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-checks/conservazione.lisp"
   :SHA256 "5b2aa2ab1d6236dd5a2d23260fdbaca2bf473ec09daa2f7d31e25f673bd7cba6"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-checks/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-checks/report.lisp"
   :SHA256 "5b8c38a3a492bde7392a26b6face1c7075bd22bb3063e61af68117d09f106ad0"
   :BYTES 364988)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-docs/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-docs/conservazione.lisp"
   :SHA256 "1175112400e6fa6f2b0bfb517ca55ee388ec4ae5367e469831a72e5871e4dbbf"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-docs/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-docs/report.lisp"
   :SHA256 "729d2cc860b3f05b8715dbdebce9c4bf155a07a7a173c3bc96c991a30ce565f2"
   :BYTES 371018)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-01/conservazione.lisp"
   :SHA256 "5a184e4ac51a4c1846d71edea64badf2713dd4da59877cb9cefa22ba0d7afa41"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-01/report.lisp"
   :SHA256 "4f09f3d919b6a131fdd579c5f348f61cc779cd1bcaab732d42e5744b5c4fd62b"
   :BYTES 373162)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-02/conservazione.lisp"
   :SHA256 "295c8f62a4a6a45c878b885a8f761236e40c77b47d8c0e2173ed80d91dabd833"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-02/report.lisp"
   :SHA256 "2b601f338bcc1116d65664c435440ba16b4ffddf4032e14f6d3525785c746642"
   :BYTES 385370)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-03/conservazione.lisp"
   :SHA256 "08aab6bbe743e214006a10f89050e02b795c0593d63d692dbd16bce8c15dfd34"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-focused-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-03/report.lisp"
   :SHA256 "da6828488ec1f2e5d6d980ed6e8e09830ab96ac9d492f7023b4a8d4729127240"
   :BYTES 368784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl10-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl10-final/conservazione.lisp"
   :SHA256 "4b55822b5e5861ec151b8077a5cd0208cae0b1f62d2e34dae9f25fa64cfd4fd5"
   :BYTES 1214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl10-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl10-final/report.lisp"
   :SHA256 "4eedd757ee309bb812a92403e880a57f2301ebde1b8da243173ea64a31bd837c"
   :BYTES 427586)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/048-v2-server-1034.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/048-v2-server-1034.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/048-v2-server-1034.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/048-v2-server-1034.stdout"
   :SHA256 "9b2bbcd5ac4a5f5372e37b4c7c55278bf382456a9796cc8b83484e4cd5da5345"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/047-v2-server-1033.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/047-v2-server-1033.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/047-v2-server-1033.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/047-v2-server-1033.stdout"
   :SHA256 "3ac3cadc0157faf8a0e8d8e7c6fe0c8688db3b2c56ffe61c8bc711c746ba5a65"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/046-v2-server-1032.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/046-v2-server-1032.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/046-v2-server-1032.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/046-v2-server-1032.stdout"
   :SHA256 "8cc9120a7e18d955cf0da8e6121966cca7e67577fccdd804da94d723797ff8e9"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/045-v2-server-1031.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/045-v2-server-1031.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/045-v2-server-1031.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/045-v2-server-1031.stdout"
   :SHA256 "d520542f04e5acb7dc61275442deb64c4aaca457c5639dfaeff56a0309b919e5"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/044-v2-server-1030.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/044-v2-server-1030.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/044-v2-server-1030.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/044-v2-server-1030.stdout"
   :SHA256 "ed04a8366c7cea761eb1b8025a0201273bf5e444518152c2d1232512e9405c8b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/043-v2-server-1029.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/043-v2-server-1029.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/043-v2-server-1029.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/043-v2-server-1029.stdout"
   :SHA256 "8df84952487d67cb8ea4e4eb3688cc083434a8999a7170977fe7921151902e35"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/042-v2-server-1028.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/042-v2-server-1028.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/042-v2-server-1028.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/042-v2-server-1028.stdout"
   :SHA256 "c8163c6069d1e2e54de2eccad04934eeab640c24d04a9ba521ac443795fbbb2b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/041-v2-server-1027.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/041-v2-server-1027.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/041-v2-server-1027.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/041-v2-server-1027.stdout"
   :SHA256 "fcf3d2fbd693d0d574d0b60a67b75549ac562dbb792550df93aea43a547a1ead"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/040-v2-server-1026.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/040-v2-server-1026.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/040-v2-server-1026.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/040-v2-server-1026.stdout"
   :SHA256 "33bfc06cc7ba90a5b522a52008a8d5e26321943d71faafeb3dd9bca4375093fa"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/039-v2-server-1025.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/039-v2-server-1025.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/039-v2-server-1025.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/039-v2-server-1025.stdout"
   :SHA256 "3b37c824c15d6543f640e84622a61a138598a0fcadb2ad75c8329461e7b726a1"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/038-v2-server-1024.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/038-v2-server-1024.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/038-v2-server-1024.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/038-v2-server-1024.stdout"
   :SHA256 "66d214be65e3d24ab04ad1cf454daa09c31d43fb712be8d315f6057824df662a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/037-v2-server-1023.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/037-v2-server-1023.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/037-v2-server-1023.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/037-v2-server-1023.stdout"
   :SHA256 "bda2030ae2a613491d81bf40c7ef13d463a2135bc1baa882b1aeebbb9731660a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/036-v1-server-1022.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/036-v1-server-1022.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/036-v1-server-1022.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/036-v1-server-1022.stdout"
   :SHA256 "b8e2bcb8d17b642db3714f4b7c8c5eb59c66dcd4deeef22f7b8adfb1f069f49b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/035-v1-server-1021.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/035-v1-server-1021.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/035-v1-server-1021.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/035-v1-server-1021.stdout"
   :SHA256 "db1476b8e9d212b81f00433edd10a44a056b5badb3b2a5a87bfe1a5b7b62e8f8"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/034-v1-server-1020.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/034-v1-server-1020.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/034-v1-server-1020.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/034-v1-server-1020.stdout"
   :SHA256 "ec0b054f216589b1dfec3513e3787adb86a6356767d832b8f712f02c25e5f668"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/033-v1-server-1019.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/033-v1-server-1019.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/033-v1-server-1019.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/033-v1-server-1019.stdout"
   :SHA256 "f1d5ac775268177b6f8320199a9bb5c94714429f218fd6d5fab876583feff956"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/032-v1-server-1018.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/032-v1-server-1018.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/032-v1-server-1018.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/032-v1-server-1018.stdout"
   :SHA256 "18b17c2d44bf3b9b26bd290d6fc7eccec6688ce4280d64a3b1ca506257734a09"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/031-v1-server-1017.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/031-v1-server-1017.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/031-v1-server-1017.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/031-v1-server-1017.stdout"
   :SHA256 "723615e1c8e74d6225e69df3950be2656755212bedf3234fced48164ad263a5a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/030-v1-server-1016.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/030-v1-server-1016.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/030-v1-server-1016.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/030-v1-server-1016.stdout"
   :SHA256 "18430d1c6733fe6b0135c17fdcfe472932612b80c4168a977d4d222df85da9de"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/029-v1-server-1015.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/029-v1-server-1015.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/029-v1-server-1015.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/029-v1-server-1015.stdout"
   :SHA256 "b74a986780dc8b0b72037f0f780204d3dc091edfc769d781f2f5d0e418604c97"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/028-v1-server-1014.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/028-v1-server-1014.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/028-v1-server-1014.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/028-v1-server-1014.stdout"
   :SHA256 "40dfccdd499eb308cb102bde7133947baf3d372b88928df960b0d23840b17a00"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/027-v1-server-1013.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/027-v1-server-1013.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/027-v1-server-1013.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/027-v1-server-1013.stdout"
   :SHA256 "f717e8fa5aa025a1c243743d78f510d8366115ed4ea81132e08e98f15bb9c722"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/026-v1-server-1012.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/026-v1-server-1012.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/026-v1-server-1012.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/026-v1-server-1012.stdout"
   :SHA256 "c880cd55b171fab635782d7e5716562e0dc125396b8ae193e148a5ae3db99934"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/025-v1-server-1011.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/025-v1-server-1011.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/025-v1-server-1011.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/025-v1-server-1011.stdout"
   :SHA256 "d31f5b88c44c5dd8cb83d88e22bdc49bbc2b56492d76a63b5e49d462680433d3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/024-v2-server-834.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/024-v2-server-834.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/024-v2-server-834.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/024-v2-server-834.stdout"
   :SHA256 "1c8eca98db36c02cb0d887715b1e170f11579a5c6e7843d16e28228571cad94f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/023-v2-server-833.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/023-v2-server-833.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/023-v2-server-833.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/023-v2-server-833.stdout"
   :SHA256 "8d37d797810ae0dcc3693d4ef024d192a175657b45015850c7b678d1381c6b96"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/022-v2-server-832.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/022-v2-server-832.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/022-v2-server-832.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/022-v2-server-832.stdout"
   :SHA256 "c58c759195bf126da22665c5a5deba21f6f79b9cc361dfe7446aaca06e26a6a7"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/021-v2-server-831.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/021-v2-server-831.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/021-v2-server-831.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/021-v2-server-831.stdout"
   :SHA256 "dca65f1719104b7efac48bbccd8d6279b9eb16363144fa945d00caafa3fc5289"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/020-v2-server-830.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/020-v2-server-830.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/020-v2-server-830.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/020-v2-server-830.stdout"
   :SHA256 "0ea44c98db6cdb3df94de2df8ab7fa8930976251ba9793946fb14bc59f2393b9"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/019-v2-server-829.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/019-v2-server-829.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/019-v2-server-829.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/019-v2-server-829.stdout"
   :SHA256 "8706a5cb6235334416d0a4234276ef5a81061844ab7fd4b7c1e4dc2979cb734b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/018-v2-server-828.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/018-v2-server-828.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/018-v2-server-828.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/018-v2-server-828.stdout"
   :SHA256 "04aa3c5d56797225a0365723f7fbe65cbfa7b11a3ffd11775021c20081c53f69"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/017-v2-server-827.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/017-v2-server-827.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/017-v2-server-827.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/017-v2-server-827.stdout"
   :SHA256 "fcd041be2682d1d60f76a43d9f3b9ff3ab3ec273e3337bcfff51df044d2c53d3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/016-v2-server-826.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/016-v2-server-826.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/016-v2-server-826.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/016-v2-server-826.stdout"
   :SHA256 "61fb1d1b32a93e7c16c44cb597b8c082e61300939b10142adb0147432159a8dc"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/015-v2-server-825.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/015-v2-server-825.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/015-v2-server-825.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/015-v2-server-825.stdout"
   :SHA256 "bf2428df8756524a171e294b6ae9a5c9b63eaed7fd3ef64d5ec5c78e3c4b1c82"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/014-v2-server-824.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/014-v2-server-824.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/014-v2-server-824.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/014-v2-server-824.stdout"
   :SHA256 "664d8c629470b3f4862f57156e8e592dfbe789cce7d5a6a502e9a047f8c95872"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/013-v2-server-823.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/013-v2-server-823.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/013-v2-server-823.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/013-v2-server-823.stdout"
   :SHA256 "3ee5aa12b85b7d48d76f0a4c04ac6bd2394d20f04e039e26feea3943d8030110"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/012-v1-server-822.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/012-v1-server-822.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/012-v1-server-822.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/012-v1-server-822.stdout"
   :SHA256 "67d70f29f14727675c180547a8f3640351cfc71301aa05099f2cfd9669b6fbc0"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/011-v1-server-821.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/011-v1-server-821.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/011-v1-server-821.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/011-v1-server-821.stdout"
   :SHA256 "52a050bc9f17edddc65ea5055b57b78825bb352b34f04a5abe89b5c31fc27474"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/010-v1-server-820.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/010-v1-server-820.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/010-v1-server-820.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/010-v1-server-820.stdout"
   :SHA256 "f59586a97f9d9be318a3cc56abca80584881b8f456453f8b19de4cf5352f2167"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/009-v1-server-819.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/009-v1-server-819.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/009-v1-server-819.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/009-v1-server-819.stdout"
   :SHA256 "c5e3d18d9afeb45940f7752d2b06b5833e62461946b77c599fd5de18aa736b6a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/008-v1-server-818.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/008-v1-server-818.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/008-v1-server-818.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/008-v1-server-818.stdout"
   :SHA256 "aacd6965c378033de97c849e77fd3ee5ac595209bfe7f8ae1a6bf24c6c7b6342"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/007-v1-server-817.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/007-v1-server-817.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/007-v1-server-817.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/007-v1-server-817.stdout"
   :SHA256 "3570460823980441719aa16796af691af73a2fc67e1a548fb458de19260334b5"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/006-v1-server-816.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/006-v1-server-816.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/006-v1-server-816.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/006-v1-server-816.stdout"
   :SHA256 "122ede5185422093bca5fc47c85a2f967bc94d0155e1eedd7bf17272f9cbe743"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/005-v1-server-815.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/005-v1-server-815.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/005-v1-server-815.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/005-v1-server-815.stdout"
   :SHA256 "0482fbe296c35c358364538941fd33095cd6115baa85908b8504b3cf5ea2ce8a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/004-v1-server-814.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/004-v1-server-814.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/004-v1-server-814.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/004-v1-server-814.stdout"
   :SHA256 "830d12a48ea694e72c10f39b8fcda89d3af47df5848297b5528b33f61dc3e874"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/003-v1-server-813.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/003-v1-server-813.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/003-v1-server-813.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/003-v1-server-813.stdout"
   :SHA256 "08bae1191e7290a644add669fec42c8633a9065dc82c9ecf9e34395df56bf93e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/002-v1-server-812.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/002-v1-server-812.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/002-v1-server-812.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/002-v1-server-812.stdout"
   :SHA256 "c0ac518999a248f8cd0f2994721356c685088b7563951daded74d753240f68b3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/001-v1-server-811.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/001-v1-server-811.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D7Z-1OQ6-0/001-v1-server-811.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D7Z-1OQ6-0/001-v1-server-811.stdout"
   :SHA256 "8d391b64654e9f1ab258c26c4116b8d306fed5cd090807f80a0ca6ab6392a68d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl9-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9-final/conservazione.lisp"
   :SHA256 "255ccdf287d4a4cf2746f83670e07f48393449bfed9ee13f967d35089c9c7005"
   :BYTES 1212)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl9-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9-final/report.lisp"
   :SHA256 "cef44022676ebadce1c5bd9b4a0d155260a7886b83b1d0a0d6644254814e1513"
   :BYTES 427558)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/048-v2-server-1034.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/048-v2-server-1034.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/048-v2-server-1034.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/048-v2-server-1034.stdout"
   :SHA256 "105127387bb0a002b24e1e28010e61ce30410fa404ea3904c61bb8fad1333996"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/047-v2-server-1033.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/047-v2-server-1033.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/047-v2-server-1033.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/047-v2-server-1033.stdout"
   :SHA256 "364c87049591e111b3a639d24ed0e67b31768347a48a212d4f3852ac8dde7c5f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/046-v2-server-1032.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/046-v2-server-1032.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/046-v2-server-1032.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/046-v2-server-1032.stdout"
   :SHA256 "7e88a05ca8d12d4910f0738d629abb93fbc5a4b91251234cd33d93d58cb66afd"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/045-v2-server-1031.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/045-v2-server-1031.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/045-v2-server-1031.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/045-v2-server-1031.stdout"
   :SHA256 "b9ac4bda48761f716f6cece47306be2255ffb93c1daaff7678d897dbf9ff1b85"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/044-v2-server-1030.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/044-v2-server-1030.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/044-v2-server-1030.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/044-v2-server-1030.stdout"
   :SHA256 "d42ba8cf34e46c0bee55dfc266f62a14660def5d4c50c257c8a63e995dda96ca"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/043-v2-server-1029.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/043-v2-server-1029.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/043-v2-server-1029.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/043-v2-server-1029.stdout"
   :SHA256 "434e7ba172f6f0456ea9875ce0e796e88d65b6ea4e38a66e7ebf2790769a66e8"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/042-v2-server-1028.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/042-v2-server-1028.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/042-v2-server-1028.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/042-v2-server-1028.stdout"
   :SHA256 "2a6c309638a682f465c4425a5adbfe9ea8fac747c8622fadc3335c3d21d4f726"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/041-v2-server-1027.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/041-v2-server-1027.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/041-v2-server-1027.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/041-v2-server-1027.stdout"
   :SHA256 "4f68abb5bc94f84ec67d749f0c830a9eb339e6a7b4d2bd6baefc77742abecd9f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/040-v2-server-1026.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/040-v2-server-1026.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/040-v2-server-1026.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/040-v2-server-1026.stdout"
   :SHA256 "0daee62524a22450adb23e22fb0efebd6665783e364c8e118a3802cc055abd65"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/039-v2-server-1025.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/039-v2-server-1025.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/039-v2-server-1025.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/039-v2-server-1025.stdout"
   :SHA256 "a5033b650d0502b6e390c8451d43304b851a3f415bfbf757083a7c91a7b20082"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/038-v2-server-1024.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/038-v2-server-1024.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/038-v2-server-1024.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/038-v2-server-1024.stdout"
   :SHA256 "f228a5924cd86933a4a0c2c98456ff88042d5a53024e728eeb14f9e43c3341ce"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/037-v2-server-1023.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/037-v2-server-1023.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/037-v2-server-1023.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/037-v2-server-1023.stdout"
   :SHA256 "4e9be5579c6169f6d0c1d681c18bca007a60bb0b072d610a7e914a32da3e438c"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/036-v1-server-1022.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/036-v1-server-1022.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/036-v1-server-1022.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/036-v1-server-1022.stdout"
   :SHA256 "2d37c80b28c3caf3ebf71090d5f6f08e7ee7362c8f81bec7ff61e9aab34c1a80"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/035-v1-server-1021.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/035-v1-server-1021.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/035-v1-server-1021.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/035-v1-server-1021.stdout"
   :SHA256 "f9a9906fdbe84809510a258cca94f5951c7707f225c63c67a3f04475df061d58"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/034-v1-server-1020.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/034-v1-server-1020.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/034-v1-server-1020.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/034-v1-server-1020.stdout"
   :SHA256 "ebe40aa4ff49be765d17a2fd34bd38f2511068b7414ea2d7bca393f1355a106b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/033-v1-server-1019.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/033-v1-server-1019.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/033-v1-server-1019.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/033-v1-server-1019.stdout"
   :SHA256 "d2cb28143dd4f9e909e57a322be97795cf4f1fcb6485ed1a53b20341198ff9ec"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/032-v1-server-1018.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/032-v1-server-1018.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/032-v1-server-1018.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/032-v1-server-1018.stdout"
   :SHA256 "7453426b57f49778dc1d919b8e922c2982546d43cdfcaf39bbebec2d9be9a4c1"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/031-v1-server-1017.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/031-v1-server-1017.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/031-v1-server-1017.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/031-v1-server-1017.stdout"
   :SHA256 "dfbc29a3535ffe0916231f9f182503f5d1bf32258cbb137dbab71c98e680f67e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/030-v1-server-1016.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/030-v1-server-1016.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/030-v1-server-1016.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/030-v1-server-1016.stdout"
   :SHA256 "90222d9bac8a5f14a16d4faee567e47c7a8a9ea1e915794f59b3e4be44efd1ed"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/029-v1-server-1015.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/029-v1-server-1015.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/029-v1-server-1015.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/029-v1-server-1015.stdout"
   :SHA256 "2f2e33f0e49a63268625df1e16fd02bdbf49cdf4425d5103c8fa5e6464005766"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/028-v1-server-1014.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/028-v1-server-1014.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/028-v1-server-1014.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/028-v1-server-1014.stdout"
   :SHA256 "5f080830bf1f8036041b4b79b2e6edd3599247695ca6bf8e5f68de169f84cbe2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/027-v1-server-1013.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/027-v1-server-1013.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/027-v1-server-1013.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/027-v1-server-1013.stdout"
   :SHA256 "5071d0b0b7957f62d4ee9515b5eeda11aa3a318a863a223825b280a7c82935cd"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/026-v1-server-1012.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/026-v1-server-1012.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/026-v1-server-1012.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/026-v1-server-1012.stdout"
   :SHA256 "123747fc9b335a686cd76f61fa62180f2ce857e2cf00b34f09f3c96aac3ae381"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/025-v1-server-1011.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/025-v1-server-1011.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/025-v1-server-1011.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/025-v1-server-1011.stdout"
   :SHA256 "d5a7ae8ef80c074f4f0d9b4e97eac87d184c2940fbb58c9bc3efb06662793884"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/024-v2-server-834.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/024-v2-server-834.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/024-v2-server-834.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/024-v2-server-834.stdout"
   :SHA256 "abdb067a474696b72cdd3209e985533b83b7677694b3753b7f4635b717be50db"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/023-v2-server-833.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/023-v2-server-833.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/023-v2-server-833.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/023-v2-server-833.stdout"
   :SHA256 "972b22c58ad64bca0957a976a1f3882206e6e80d2a81b1d7c0f8af80558de632"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/022-v2-server-832.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/022-v2-server-832.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/022-v2-server-832.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/022-v2-server-832.stdout"
   :SHA256 "ca760a5f90a48e52060f78e21121434dc6362bdc97bd4551e97eda046059c589"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/021-v2-server-831.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/021-v2-server-831.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/021-v2-server-831.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/021-v2-server-831.stdout"
   :SHA256 "5a6c4724f112c1bd47d04f5fbaedc4933d2eb0582f159bd4b30428fd47c9edff"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/020-v2-server-830.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/020-v2-server-830.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/020-v2-server-830.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/020-v2-server-830.stdout"
   :SHA256 "70630b2584348feeae7c1728f1fd86b3d89730b1b1e7a0b47764d1e93c55925e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/019-v2-server-829.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/019-v2-server-829.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/019-v2-server-829.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/019-v2-server-829.stdout"
   :SHA256 "b69e84a6a968fc4821e7cfe5d10eda4d255473a7e02662afa5e384fcae2ca502"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/018-v2-server-828.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/018-v2-server-828.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/018-v2-server-828.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/018-v2-server-828.stdout"
   :SHA256 "239366ab0ee3dab928feabfbb4b669bd123349439d1be5fd3672693b916015ff"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/017-v2-server-827.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/017-v2-server-827.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/017-v2-server-827.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/017-v2-server-827.stdout"
   :SHA256 "10b21e7dfbec5fa7c654a6905d1b19cfc3f50eff2c0634ada3b7d7193ced5226"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/016-v2-server-826.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/016-v2-server-826.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/016-v2-server-826.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/016-v2-server-826.stdout"
   :SHA256 "7a6ccd1d2f63ce373049c12ab22cb4877460b43c89c90f55ffcbbb10b5d278df"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/015-v2-server-825.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/015-v2-server-825.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/015-v2-server-825.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/015-v2-server-825.stdout"
   :SHA256 "bec27f223116ae4c5f9288561e4f8b7980df669180052d6a85989964d9e94ea9"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/014-v2-server-824.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/014-v2-server-824.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/014-v2-server-824.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/014-v2-server-824.stdout"
   :SHA256 "193d6e324d2ffc362907de42d00ddedbef235fdc9517c4f74545ff549fcdab19"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/013-v2-server-823.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/013-v2-server-823.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/013-v2-server-823.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/013-v2-server-823.stdout"
   :SHA256 "d9547e6273c5c3b3a0fd1fdbedb191bd9cfa18b5ecc729ba89af3ecba8ac8482"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/012-v1-server-822.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/012-v1-server-822.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/012-v1-server-822.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/012-v1-server-822.stdout"
   :SHA256 "21aa3c611d9c060f45aa95ff6c0b3b1c607f95785596e8b3654797d0c7fd6845"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/011-v1-server-821.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/011-v1-server-821.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/011-v1-server-821.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/011-v1-server-821.stdout"
   :SHA256 "6ba15837f0f7504b94db427aae6e5556475daf5954e47dfd12c3803fbc9797fe"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/010-v1-server-820.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/010-v1-server-820.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/010-v1-server-820.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/010-v1-server-820.stdout"
   :SHA256 "e0b5cf1f45bd95a8397c3816e63f3acb373ed8d397345ebea9087975f9747767"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/009-v1-server-819.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/009-v1-server-819.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/009-v1-server-819.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/009-v1-server-819.stdout"
   :SHA256 "7622ae43e26c33732571d979abe3695aa928a8a8c4b415667a04737f4cef0251"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/008-v1-server-818.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/008-v1-server-818.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/008-v1-server-818.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/008-v1-server-818.stdout"
   :SHA256 "952ca920ed8cbcf535bd390b73c64bf0496232cdba2ca67e2173829b43f28dcc"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/007-v1-server-817.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/007-v1-server-817.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/007-v1-server-817.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/007-v1-server-817.stdout"
   :SHA256 "d579adcc23fe4a5e0ef4fedf6b11fb925a36fca1aece6bac136ed2ef4744f99a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/006-v1-server-816.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/006-v1-server-816.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/006-v1-server-816.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/006-v1-server-816.stdout"
   :SHA256 "b04a75ef54bdd2c08e9fb2483fb1b9ea6b736581568986cd5e2e4b762dafbacf"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/005-v1-server-815.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/005-v1-server-815.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/005-v1-server-815.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/005-v1-server-815.stdout"
   :SHA256 "817311bb8a2b029c3e9bd3e00e2f0f71f94206ea56cc6f0557622214de7052ae"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/004-v1-server-814.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/004-v1-server-814.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/004-v1-server-814.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/004-v1-server-814.stdout"
   :SHA256 "7f38271d66877127c3ab6baa3cb4a9f9ef70d43477e00f0dcbd8b68e7d6e6650"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/003-v1-server-813.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/003-v1-server-813.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/003-v1-server-813.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/003-v1-server-813.stdout"
   :SHA256 "f48d29b02bbcdceea1692cbd002aa32c7710da954a43b3012588f99ddbd59d16"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/002-v1-server-812.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/002-v1-server-812.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/002-v1-server-812.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/002-v1-server-812.stdout"
   :SHA256 "c53da43c64ec4a6e8511b066bceab50378d3cd44c2d655cf8863ca8e4af8e614"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/001-v1-server-811.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/001-v1-server-811.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D87-1OQ5-0/001-v1-server-811.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/child-logs/1U72D87-1OQ5-0/001-v1-server-811.stdout"
   :SHA256 "dd45d26fe1d3a67e739a60994aff941267e5901d3e146f71ae04bb219a6def57"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9/conservazione.lisp"
   :SHA256 "4bd84be55b79f062c5498af610524c22fd587d275910e1634442e697a75c266e"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-qualification-sbcl9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9/report.lisp"
   :SHA256 "9512d7023e6257a64be9cfb7433b2ac00566720e9aa9e7972938b73fbafe3808"
   :BYTES 414613)
  (:SOURCE "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/" :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/socket-nodes.lisp"
   :KIND :SOCKET-METADATA :SHA256
   "4f2fe47954e7b64e15625c86c7905e4398932b16e5eff92cfa84f1297c4b8442" :BYTES
   762)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/001-v1-server-811.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/001-v1-server-811.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/001-v1-server-811.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/001-v1-server-811.stdout"
   :SHA256 "4f6dfafafe87d4866281eb312238f7eabb35a13cf32c1639917fcac32b6b1e3d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/002-v1-server-812.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/002-v1-server-812.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/002-v1-server-812.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/002-v1-server-812.stdout"
   :SHA256 "9d788f83648ce2f24080c811219caeed5cb2c761de74587acd82cc3a9de151cc"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/003-v1-server-813.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/003-v1-server-813.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/003-v1-server-813.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/003-v1-server-813.stdout"
   :SHA256 "b581ca620a12c9e1250005016e57a2ce9e4743c69e3212ee0b96927180c47e96"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/004-v1-server-814.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/004-v1-server-814.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/004-v1-server-814.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/004-v1-server-814.stdout"
   :SHA256 "c255e8702fe0601ba7d796981522d7a84ba54bb2fd296dd2ac98528bacbca281"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/005-v1-server-815.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/005-v1-server-815.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/005-v1-server-815.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/005-v1-server-815.stdout"
   :SHA256 "39285609dc402ac29358d6114bae7acd9f49d83da255047ecf5422b8cbb8f111"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/006-v1-server-816.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/006-v1-server-816.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/006-v1-server-816.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/006-v1-server-816.stdout"
   :SHA256 "ce5327d12801f763f91002f9526a1182219c2a30a4535c6584abc076677a7162"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/007-v1-server-817.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/007-v1-server-817.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/007-v1-server-817.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/007-v1-server-817.stdout"
   :SHA256 "5aabfdd77e1269c3def18e2828168e163ce1bc516d8da75c8134ab56b9b27994"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/008-v1-server-818.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/008-v1-server-818.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/008-v1-server-818.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/008-v1-server-818.stdout"
   :SHA256 "2c12283e04085fb3bbbdfb06983817bd1316aea45564255803f17814124c120b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/009-v1-server-819.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/009-v1-server-819.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/009-v1-server-819.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/009-v1-server-819.stdout"
   :SHA256 "3b97ee795c3e628222321a25cea4c9b42238f6a4b063e058332de4cc251241df"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/010-v1-server-820.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/010-v1-server-820.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/010-v1-server-820.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/010-v1-server-820.stdout"
   :SHA256 "0a6704c5fb19bed29dd1da36b2034005d148b9d7370b247835c85cce29a11a55"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/011-v1-server-821.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/011-v1-server-821.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/011-v1-server-821.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/011-v1-server-821.stdout"
   :SHA256 "f44acfba4c1f93d1a29cede76529cd9add5b0cb0cd6ab0c5452074f6a22c639f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/012-v1-server-822.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/012-v1-server-822.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/012-v1-server-822.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/012-v1-server-822.stdout"
   :SHA256 "23c1b727f5a0c9207c7e562cc6a4176bfee710f80e699ba18f6f56ae4d64547e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/013-v2-server-823.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/013-v2-server-823.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/013-v2-server-823.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/013-v2-server-823.stdout"
   :SHA256 "403cb76124a22c1a9fa51d0dd3d840d166aa9efb88a05968d2f3c5c6612bcf0e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/014-v2-server-824.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/014-v2-server-824.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/014-v2-server-824.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/014-v2-server-824.stdout"
   :SHA256 "7397ae6f20d0bcf314e3648eca13e688f9be796e40448598ac785d4a75ad7822"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/015-v2-server-825.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/015-v2-server-825.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/015-v2-server-825.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/015-v2-server-825.stdout"
   :SHA256 "c933f7091d54ecaa521f37ad184fa04c3d2816863f47020d6256d391710e472d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/016-v2-server-826.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/016-v2-server-826.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/016-v2-server-826.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/016-v2-server-826.stdout"
   :SHA256 "ed1f27b53bf6016f71516b0e98793f9c0bc9fdbe489c9fe6da737c1429e1a9c5"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/017-v2-server-827.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/017-v2-server-827.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/017-v2-server-827.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/017-v2-server-827.stdout"
   :SHA256 "e6fa3a10dd3e0f242af6c25572ed2f6bf59ea2b560164ff54622387ac87407e3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/018-v2-server-828.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/018-v2-server-828.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/018-v2-server-828.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/018-v2-server-828.stdout"
   :SHA256 "5e8c2574f13fbefdd70a64fc24b6ff2ddd80bb2dd64627c8a0cd0c787d8a9bfc"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/019-v2-server-829.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/019-v2-server-829.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/019-v2-server-829.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/019-v2-server-829.stdout"
   :SHA256 "8fd97493c675746c697133ccef5de666e17b63cdf01e9f8eebaef51e0d339798"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/020-v2-server-830.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/020-v2-server-830.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/020-v2-server-830.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/020-v2-server-830.stdout"
   :SHA256 "410018dc261cf0843eacbb3debd858fabc968d5dc0842103a1cc716fc21172ba"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/021-v2-server-831.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/021-v2-server-831.stderr"
   :SHA256 "85fa4ac62b144766cc573a643a9e043e6f5e64c9ce99e0d77e3533701a681204"
   :BYTES 53)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/021-v2-server-831.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/021-v2-server-831.stdout"
   :SHA256 "759b6536ecbf0e4c734b773ee941e5f177d5a585f8e48f20fdae734b1dabb948"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/022-v2-server-832.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/022-v2-server-832.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/022-v2-server-832.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/022-v2-server-832.stdout"
   :SHA256 "4683274bb60495b3c77d76d3b7e6c093d200491f99d1c3a30a7f2b3e680b9f88"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/023-v2-server-833.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/023-v2-server-833.stderr"
   :SHA256 "4d75503d2c42846c48bd08b5611b009a93af3d3c22556b42b3df0a3945b59d2b"
   :BYTES 70)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/023-v2-server-833.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/023-v2-server-833.stdout"
   :SHA256 "152529ed0f7400a313e0eb56a11db240cb4ed096555c4293309ff6d96b7066c2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/024-v2-server-834.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/024-v2-server-834.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/024-v2-server-834.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/024-v2-server-834.stdout"
   :SHA256 "9b73431737fcd31833f6c92408529410ad365b2195e6429a246a093ad1274c02"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-AFTER/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-BEFORE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-PAGED-NONE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-AFTER/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-BEFORE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-AFTER/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-BEFORE/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-PAGED-NONE/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-AFTER/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-BEFORE/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000002.seg"
   :SHA256 "0177084d25304119476f0fca87c1a59d519a9a31150407e7785d0a7d6a200156"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/0000000000000003.seg"
   :SHA256 "48cd44d60490e6a135f18609844ba58b8a7cf26a2b7410cc8237fa4e3a88cc41"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/control.log"
   :SHA256 "80cb91c1597e2109c3ca380b2b80a3d2ddde92c6559936caa28145f0805cb66a"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/failed-fixtures/1U72D2P-1MLT-0/disjoint-v2-RESIDENT-NONE/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-archive-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive-final/conservazione.lisp"
   :SHA256 "305cc61c028c06d0ad56624c9ed1d5b6c66d1ddc8bde58890b91ce8ffbe4e623"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-archive-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive-final/report.lisp"
   :SHA256 "adc519336d19d2ebe8d99ec611d3006f3cbfa161dd231040d45f811688ca8d1f"
   :BYTES 364939)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive/conservazione.lisp"
   :SHA256 "b200de3a46091196f8de67349e02752359eef5aa8b84403cb7dc3770c6aa2988"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive/report.lisp"
   :SHA256 "7a3e3c7136511178d20a2ccfcfe8a1998be3535081dbe1e391d61c4f3dc2da44"
   :BYTES 364939)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-cleanup-worktree-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree-final/conservazione.lisp"
   :SHA256 "d9a447414d3ed2449423e135cf77bb7e829695888dcb1f6fe7d0290cccecaacb"
   :BYTES 1224)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-cleanup-worktree-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree-final/report.lisp"
   :SHA256 "2468d39768726dcd441fa70f87fafac70023ae299e8f91207f78dd700f2d2199"
   :BYTES 364943)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-cleanup-worktree/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree/conservazione.lisp"
   :SHA256 "771ab57715ba44d28134481559fc2c26dd94903392c1381965ef1f2ed9dc3044"
   :BYTES 1212)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-cleanup-worktree/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree/report.lisp"
   :SHA256 "08d39f81ece115b301158e2cae2fe08cf68da01748faaf29d37f53b52de55908"
   :BYTES 364943)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-close/conservazione.lisp"
   :SHA256 "9be17546222f77490adc9ad3532b906f438cd4964114ea463f48cd928155d3ab"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-close/report.lisp"
   :SHA256 "e7a71dc16c7641200ef5077b7bd0f41e92fd90ad048cd51130d4842f00e8bfcf"
   :BYTES 364931)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-qualify/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-qualify/conservazione.lisp"
   :SHA256 "592c021d297be141d4254ddf2b2eaa5cc75ad0ba320372a323f476bbe5d2098f"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-qualify/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-qualify/report.lisp"
   :SHA256 "ae68785b39e66490663d0f55486ca57908e0e485f42fbc18fa311869e1405f7d"
   :BYTES 364955)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-verify-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify-final/conservazione.lisp"
   :SHA256 "6f86eb33b422959085654aeb6a888a5043558adc92515743df76bbd9fa7c6a3a"
   :BYTES 1204)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-verify-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify-final/report.lisp"
   :SHA256 "f70270ffda28f82b6c57acca12fe50c7bd9914e38fb4da9df98f7fc882c5b768"
   :BYTES 364917)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-verify/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify/conservazione.lisp"
   :SHA256 "302ad8d6182f22f68c2deba12274925a89621d72a7eecde4871971125c488fa8"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-selftest-verify/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify/report.lisp"
   :SHA256 "c3814636a505428ff81c584c6d245d6bdf17f07d857b7f8591a5b82789e65911"
   :BYTES 364917)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-static-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static-final/conservazione.lisp"
   :SHA256 "a0c2cffb49bebe4be93e650bb9c76f6ae016c4b45aa50a025cacf20d89bab0f9"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-static-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static-final/report.lisp"
   :SHA256 "8e77c3dd4061cd4e345d944ab2fb6c13a709b4a451c5044df923af3804c54099"
   :BYTES 364960)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-static/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static/conservazione.lisp"
   :SHA256 "f876e3cd2a31e7eeda0a5970cca126dd51c9b0a6252e564b59f5818a77c7c07c"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-static/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static/report.lisp"
   :SHA256 "2c1407667b85c89279b5a7eefd1b3d124f93f2820ed9dedfbbf90cab3cde8bc6"
   :BYTES 364960)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-verify/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-verify/conservazione.lisp"
   :SHA256 "e811d806585b32a6d0a2b0e4c64c269ccf90f02932f41268f20e5cdef6f79ce4"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/version-cohort-verify/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-verify/report.lisp"
   :SHA256 "83476ba49cfd95442b12afeb944e9da9cc180674482e0ee4d3d27930496c6108"
   :BYTES 364939)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-01.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-01.lisp"
   :SHA256 "bf767b64455e0ff7bb7bbffe61758008d617788c4cce296782a0091ab6eb4a81"
   :BYTES 27228)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-02.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-02.lisp"
   :SHA256 "2a203422239355d32a786cfa067469348b92f72b096b6503ab81263f0cb4fb4b"
   :BYTES 1607)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-03.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-03.lisp"
   :SHA256 "e26e4d088af2076336fdc5e7141a0ace5dda9f0fa9b88b4dfb52f102934ec460"
   :BYTES 3663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-04.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-04.lisp"
   :SHA256 "48336e43d1b051e24800ffe9e3827e186da5cbebb12861775bc7be40c109ec1e"
   :BYTES 6752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-05.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-05.lisp"
   :SHA256 "0563d08d4c0339a15e08a45ff3a2a9c569b239172fbd07ea618f053369790e47"
   :BYTES 10168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-06.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-06.lisp"
   :SHA256 "912638645a652bbd896dbe797fbac677c42672066978fe2dfa7e75779b2315dc"
   :BYTES 24124)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-07.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-07.lisp"
   :SHA256 "f9e09ff1cda26bc790e3abd10522f20dd0960701d201bff864f1dbd457042811"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-07.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-07.lisp.gz"
   :SHA256 "9682569c9d3c1253b115425a4280cf49475cd41b7775c1d25d8c32ecbd7ea43d"
   :BYTES 411736)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-08.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-08.lisp"
   :SHA256 "52034dc8bf2f35ccd47d87b3cdd47d50bafdf1ed9ed1b06644851021b6271e4f"
   :BYTES 331091)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-09.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-09.lisp"
   :SHA256 "fcfde9d0b082db97dece686d5555532b44840bd02c1b324adf4450e7e7f76027"
   :BYTES 2472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-10.lisp"
   :SHA256 "2ff6dc526bcc1320a4a8fe7f3e38efa33891ef6089890addbaae8549548a388a"
   :BYTES 22975)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/SPK-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-11.lisp"
   :SHA256 "9bd814e4a9e16c03cc96abe4eee3ca3aabadf4f0a0f39217cdfb5539da272bef"
   :BYTES 74130)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/conservazione.lisp"
   :SHA256 "7d089e752fb8b908a24475b59a51dad1a5487bad1ac2f7a1fa4cc30b80703bdd"
   :BYTES 2352)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/report.lisp"
   :SHA256 "f77473f3de95fb78ef07cabbe5b7896aaafb3f415561506105cd7c16ddfffb29"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002636740-check-92789-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/report.lisp.gz"
   :SHA256 "9494eb46efb58ee4fd662180c372eb8b3c794dae60a5f7066d8ac9f831b287fb"
   :BYTES 483961)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/scan-27.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/scan-27.lisp"
   :SHA256 "dccc3dfc5e2a2f80472e4101488ce256da5cf825b776f62a9c4fa4420433a065"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/scan-27.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/scan-27.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/scan-27.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/scan-27.stdout.log"
   :SHA256 "3896d29e7d444060c974cbadb2c318610a7b2a29780956c7e5d0b8c40d677e6a"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/session.pid"
   :SHA256 "a890f1fc3146babe6b1e88f34f3b8ab43fe2e01e8057ddfe2fad36524500296f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1J4RLy/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1J4RLy/0/stdout.lisp"
   :SHA256 "ddfc9a222330a26dd7d94bf84884c99ea1dfad6a8b23a435333594a7d670065e"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/scan-32.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/scan-32.lisp"
   :SHA256 "cdb9e1e7462c7fec7feeaaba2b9da1323db2332b24ea906afbb463280ae87cb2"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/scan-32.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/scan-32.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/scan-32.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/scan-32.stdout.log"
   :SHA256 "6c803a3528646f1d639b1b68f157c514cb5aa6c387447203ec072c593beab111"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/session.pid"
   :SHA256 "8c0ed743c2fb86105aa90a47dae49be41f71f75bea1db8a245b757581dff04cb"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/0/stdout.lisp"
   :SHA256 "eb8626788318217ab2f23dd2700b3f6db7db126005edffab42acc614e1e76d09"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/scan-31.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/scan-31.lisp"
   :SHA256 "f302c57f8ae0de6b168e614a1843125e38a72f7d5c98ad9ecf8faf69ffdf8059"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/scan-31.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/scan-31.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/scan-31.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/scan-31.stdout.log"
   :SHA256 "eef29a9b024f662ca8b20bbcea661d5b9dc3b93d5e5c901fcd6ed38b667c515b"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/session.pid"
   :SHA256 "eb00ad59766fd2d68fef1ca4dfe901811447e30fc9609adea55edfe558f3b6ad"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/1/stdout.lisp"
   :SHA256 "eaf67f76db4fcd438e4876f6d44bf72186a07a15a232b6f38189e5ece3578295"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/scan-33.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/scan-33.lisp"
   :SHA256 "78563c04bd29530f07481a3b0171c413a576239ec4e83c7347851a1ad552a49d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/scan-33.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/scan-33.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/scan-33.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/scan-33.stdout.log"
   :SHA256 "bd69dc57fcf1a5fde58ed4a0998b3ce866792aae433accea73e90638b631a791"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/session.pid"
   :SHA256 "d5f5d8b4ad634213e7acd4c802c957081404d99db8b3e252387351a76ed115d3"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/2/stdout.lisp"
   :SHA256 "4225d2c7d0571c603795d8ba32731e36dfab8f5861c023a15030c8a5bcc3d664"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/scan-34.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/scan-34.lisp"
   :SHA256 "a9bbefb58280a24b11b90abfb907e5492c1daa796efcb017a4524d5ae15ed607"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/scan-34.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/scan-34.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/scan-34.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/scan-34.stdout.log"
   :SHA256 "708a62783d8b34059dd3810b55b3b0f89f0f3f982830297299a8ff3a01cfabe4"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/session.pid"
   :SHA256 "03501b99347fe1834df44c39029440bbe8cb6e1fddf2feb9a3fe4c9757f3a546"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1sAvH4/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-1sAvH4/3/stdout.lisp"
   :SHA256 "41e683891f295389e1a628013bb18f42e093ef272da0f392576272236e65de99"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/scan-28.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/scan-28.lisp"
   :SHA256 "511cbee80a68ceeffb556e62913dbc7fc1f450f3b09fdfed5427ca99fa1e3f7d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/scan-28.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/scan-28.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/scan-28.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/scan-28.stdout.log"
   :SHA256 "9099d76213a127263a6a15e57a6d574911a93edc3851776c46162dd3d823177e"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/session.pid"
   :SHA256 "88cc1f43bb97c947d75a84323056e4ec8896cec79f0d7abe3acc6427a2d7f6e4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4ZHEzc/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-4ZHEzc/0/stdout.lisp"
   :SHA256 "ddfc9a222330a26dd7d94bf84884c99ea1dfad6a8b23a435333594a7d670065e"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/0/stdout.lisp"
   :SHA256 "36d3a115f7fa58bd44d07fa559e9d205f886b6267cab83c85c8739b99114e6f6"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/1/stdout.lisp"
   :SHA256 "fc6ff93429331ab5b25a6f4367da3211fd99f1e3473a79190ec0945779d4a97c"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/2/stdout.lisp"
   :SHA256 "462604c11c86e6cb4f124009acfd40e5036d0969151377d229f7a77a333ef16d"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-72R8Kf/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-72R8Kf/3/stdout.lisp"
   :SHA256 "f6375ab9495874d1a7acf36f8eff865d003ffbdf9230b86687711d003373f4ad"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/scan-20.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/scan-20.lisp"
   :SHA256 "3a959c82337da725b5b79b73276f0a2752ea53fe57849f51a3ffd64e78fbdf45"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/scan-20.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/scan-20.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/scan-20.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/scan-20.stdout.log"
   :SHA256 "dd3d2c027b07d252c37603704df889af9806c76c1d67fb77ac741dab2226749e"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/session.pid"
   :SHA256 "87db99c0cf68d583d56dab6384d121f53b3314e5501b8ff3dab48478c19762b5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DkuPIA/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DkuPIA/0/stdout.lisp"
   :SHA256 "e06a0c9b4bd10377559ce7f3f27c9ffe8486c51bbba9fff938d84bfb7ac7c2ea"
   :BYTES 472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/0/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/1/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/2/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DyqDZj/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-DyqDZj/3/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/scan-30.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/scan-30.lisp"
   :SHA256 "750737f2d48c663f1bd51f6ff91b16b18702c7b9817d4e1753639b076828ff1d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/scan-30.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/scan-30.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/scan-30.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/scan-30.stdout.log"
   :SHA256 "c905e17e4f15ebc5c48fa5ab30eb401572c276910d56a24ce0ec05844d95fa7c"
   :BYTES 4530)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/session.pid"
   :SHA256 "93a27adbab982fcbd94292506b9dcb1c845ed220425265a7acfa00e9fed44fa2"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-E8Q62n/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-E8Q62n/0/stdout.lisp"
   :SHA256 "124470bd884791b61866c29e7e4d98513fa8d031dc879a1738d991f6c82c064c"
   :BYTES 927)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/scan-14.lisp"
   :SHA256 "2a8dc7196ac0a5f5582e51b69cfd20cb05268afd15b48f244c6ad184623a7136"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/scan-14.stdout.log"
   :SHA256 "f1465d5876abea4c5312bd00c3cfacb15de8ba29808eb076a1835085eb7b4618"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/session.pid"
   :SHA256 "ebeeb624c5f82055056e93d1045b41271a73cb7cfa96404ea25b4b55e5b726ca"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FpIFDN/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-FpIFDN/0/stdout.lisp"
   :SHA256 "399d0e3f422027d94bf238fd3b9a99082e03284c3fabcd5ddc663703bacb2536"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/scan-4.lisp"
   :SHA256 "c89c3a60287bcb83af17394f9895a6bcb28a6fc5a465a4ce41c8dbe37af97ef1"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/scan-4.stdout.log"
   :SHA256 "ee01f4da3c837a6b6fdb106d99df5d4186981460bc9cc0ca9fa4f4933377a4e4"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/session.pid"
   :SHA256 "f2341e71ceee73187fb223dade4c1ff09ec9955b22bf7d40d157391b57c03a6f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed"
   :BYTES 220)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/scan-1.lisp"
   :SHA256 "6325d2d7edf0d0bcb3067576f8a4e348dc96b0aeae33d01bc71ef3e4942c9c5c"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/scan-1.stdout.log"
   :SHA256 "840be13636219c45b0e973270bb8702602ee5aaac83351c6334e06ca351a66bd"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/session.pid"
   :SHA256 "0141c8d860177f55aa934f6381fe8c664d96d37ec7b379ab91223e5dff75fc8b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/scan-11.lisp"
   :SHA256 "c5ad7faf5e83765a9579f3926100b1cb6bf6b58645d5917554cbf30f06d723f4"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/scan-11.stdout.log"
   :SHA256 "34348db5fef78ba5b0332a7a9fce0fbda4214e1a9c8a8123ac8329f8400f6889"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/session.pid"
   :SHA256 "102d6a0a1b4cd564bf5a25d3d6c7a4e626782ca9efc5b8a8bd8d3b9db287234b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/10/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/10/stdout.lisp"
   :SHA256 "b41750084e5f40f0277ebeb497e481080e7fe941baa7d744125d2c371e440c85"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/scan-12.lisp"
   :SHA256 "bda8d1c5cb031f980f579c624d301b0480e27ac8e014be6504e362947ff2243f"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/scan-12.stdout.log"
   :SHA256 "7ced2a45b1384ecfabc0de2f0f8ea0c039745c01248bf0f9b8a8608289721f38"
   :BYTES 4566)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/session.pid"
   :SHA256 "88e79dbbce98926f7e8b262ff625a42369f80e55769e4aa6c557f5939dc8df3c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/11/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/11/stdout.lisp"
   :SHA256 "e73c108e307445a6e4194c203f4b1ccd50a0f8bcf263d48fe3f388de1923c5b4"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/scan-13.lisp"
   :SHA256 "cfd62ecb3cd951397ad6116c29a935f87862689d16864c79b6414f2e42cbac16"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/scan-13.stdout.log"
   :SHA256 "c4512e7f87cb952c3ac8f36b50f594885c63bad67c848d069adf3ea34515f646"
   :BYTES 4560)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/session.pid"
   :SHA256 "25b11ba9dbb5cc62a4793bec64b287c70921ae44e9f7060b054d7ab3e70ef384"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/12/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/12/stdout.lisp"
   :SHA256 "a502520708b2fd9a0b2abcd2f7fc2c040042c9249c3a9966193a4cc08b941c3b"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/scan-14.lisp"
   :SHA256 "60a96fc52a204a8de95301f6c1610639d5a9cee394fbb04fb6cfb9ac6a8bd7bc"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/scan-14.stdout.log"
   :SHA256 "4826acf2ae21b106b807c918bb66cd8408b5c20755ad1664ccd5bb71a18a6170"
   :BYTES 4554)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/session.pid"
   :SHA256 "0b91451ccf8af931782479806420a981d65f258a86686c71a210cd7b1706d6e6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/13/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/13/stdout.lisp"
   :SHA256 "4e98678e376e4a4625750ede03b73fcc8e9408333e83c8de7972982f0e35eddf"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/scan-3.lisp"
   :SHA256 "b01ab7dae5ba9cfb2a4d0e9ac23249227c7a3673bc176f93a14e93fbe34fa701"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/scan-3.stdout.log"
   :SHA256 "5070061ff4b1f01fdb37d5f1be5897ad116fad81f0aec008402159cf68bf7382"
   :BYTES 4566)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/session.pid"
   :SHA256 "54dab1353b7309d5854ed9e2f1b4434d85a7f01eb923391bc7ed81253fee31c1"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/scan-2.lisp"
   :SHA256 "439be442daa8253e49c6d36815600f228e45260cb38186290bafc80ff03adae2"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/scan-2.stdout.log"
   :SHA256 "df0a412a1e13e5d2bd03c3c29074a37eddb6ba74e6ce68e0820bfd536a6f9639"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/session.pid"
   :SHA256 "722c5da9d67b00311766ba9c8e4aeb2264c59f6fcb8027d7e472b4996013627a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d"
   :BYTES 232)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/scan-5.lisp"
   :SHA256 "e37633826958a4ee451026727c2c9ba83442cd3fb94989473d3c898116e74721"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/scan-5.stdout.log"
   :SHA256 "ae00a7a39d30715f385e1655b1bf775e03415eb08358f24e5a5f7c221a240244"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/session.pid"
   :SHA256 "558257a035b0c5f100dc872906be7bacf39b3b43e82953e366d7e3ef7787c955"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/scan-6.lisp"
   :SHA256 "bdd849698109bd2a6c944b949b1bd62ea58b659638385df6921912af439ac6f8"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/scan-6.stdout.log"
   :SHA256 "6b3691a4e0164531ce098219f8653b6e093b801732e9cefc6be614bc1254ea63"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/session.pid"
   :SHA256 "84d542f1e1b78870d43687016e0c6fc245a79ab823f5ea039906e1968f28e47b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea"
   :BYTES 234)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/scan-7.lisp"
   :SHA256 "ee526d551a1ca100783f348fb63017372166737bfcadedec3d05d3925809cb7f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/scan-7.stdout.log"
   :SHA256 "e635e4fd62c42879875cad00bdac52958850376e1e8fbefa438957f502aea39a"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/session.pid"
   :SHA256 "0b61a69b64054c2b2f1e2920f03ef3d7a7778e90b20044e5a2897aea44bc94ea"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/scan-8.lisp"
   :SHA256 "97291b8f6e95e75314099ffef5a78ee61fec254169f3b8a922fec0f14f9ba7d5"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/scan-8.stdout.log"
   :SHA256 "2b8a75efdba5f1f580dd16b2f9b49d9a9756c42b8d08781bb2972c98bed60b19"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/session.pid"
   :SHA256 "d508f9987c8b70a5c9646b47d47d3c1f90176e59737684d0e3c2efb2b5093363"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598"
   :BYTES 226)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/scan-9.lisp"
   :SHA256 "57dba4f0264c58ac6520e8ea6f71c0a4151ae7cfae6abca0ae41954f2ca8fe38"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/scan-9.stdout.log"
   :SHA256 "835063a574f54805024ae4fad6a53a7c41e40c97ec7b2ee25414cb357663ee68"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/session.pid"
   :SHA256 "b2bfb55fa6ca4a71978646a857f1bc6cbcae90b46180220235336a393998cd5b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/scan-10.lisp"
   :SHA256 "08e2eb5a38b9002c13183e8b89028a16e0d31b2388c480ba87237770aebe59d9"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/scan-10.stdout.log"
   :SHA256 "e91ef89ca74a6b688ba7bed6adf128599553c4edc52357b41ae9ee09022205ca"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/session.pid"
   :SHA256 "09900b43ddf925b29293495744f7c801cc5c6a5b7eec12a69c4b86fabdc9a73a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GNqWri/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-GNqWri/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/1/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/2/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-InljCA/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-InljCA/3/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/scan-13.lisp"
   :SHA256 "2aac2baf13308eecdb1e4b3aaa68d2a0fce92fe79cd3830b56ebd5252cf56ccd"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/scan-13.stdout.log"
   :SHA256 "eea05535cf6cc9aec5fd3b261dc51c7dbac32d0447a144b8440e54656138e999"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/session.pid"
   :SHA256 "c6db69989b41a27395cbb56671e055a1c98144b1629d16316d7bcfbb265d8273"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OJTwfn/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-OJTwfn/0/stdout.lisp"
   :SHA256 "f31681c3e15d057b84680d9f6496e1bd33183880a9306750259465b710d82921"
   :BYTES 307)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/scan-1.lisp"
   :SHA256 "7b212907fcfbc625aa337cae47b058a35035596c14b5d5b2f73ab2036b16dcd9"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/scan-1.stdout.log"
   :SHA256 "10c54952be02282c196e40e43027cbbae1d36c59d2d3e6168bced4c507956fe6"
   :BYTES 4536)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/session.pid"
   :SHA256 "94888c66742a944424fa75cf29eca43640b0c1ad4391a1827bc55b1e120079e0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/0/stdout.lisp"
   :SHA256 "62f2756275b73dd19569918b2dea4eb9cd39a118b2e7077df651e6bf6803cfd3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/scan-2.lisp"
   :SHA256 "6c8c3f652483f0bcbb909292a01d2f82b777f7894fe375b15e9bd9bc40fd3dd5"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/scan-2.stdout.log"
   :SHA256 "edc1f668ed82603d0af1dcb16b399c1e634d95a4a3a77d70b9f5a4dd8b4523c0"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/session.pid"
   :SHA256 "c55f95ed4114bbabe20cf43b51e69fc7f37bb6814e50a52cb5b171c8b60769e0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/1/stdout.lisp"
   :SHA256 "950b3161975f3298ca7b48f5868587ac01f7bcd0eb7ffcc21ef32bec49217961"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/scan-3.lisp"
   :SHA256 "434a97633f33c4a44c17747c2dec2e7f32036f3cdbc1063589e4b29f48a697f7"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/scan-3.stdout.log"
   :SHA256 "5e919bc0a3dde918b2f0adc274a98bf724b543766bc93661e23c17e47eab7089"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/session.pid"
   :SHA256 "4859e1509063b658d99fe3719a211315c9784d9cdb3010eee312aceed814b88a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/2/stdout.lisp"
   :SHA256 "a1a7d51ed17f9c5054a4e477f444d85068581e27d5774277838f2dd97548b53c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/scan-4.lisp"
   :SHA256 "8149dd7a3f4b93c2549701255b9ded74a9afc1513a49f6d65ee6baf741ce2162"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/scan-4.stdout.log"
   :SHA256 "3712e351fd5ca128e64589cd0871818ddf12d6a82052261c503ea9a37b88c39f"
   :BYTES 4536)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/session.pid"
   :SHA256 "093172ffa92c44ddac6741f564fe0b7099f7b2a4c5c7188eed1a8794927e70a7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-QG6dlx/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-QG6dlx/3/stdout.lisp"
   :SHA256 "c748a9537bf836fba701bd5fc0ceadbd2279085e8079a8359c6a2c41c418ca9e"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-39.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-39.lisp"
   :SHA256 "b6eebc3f1af8878206bee070ba84e84b7193564de03399968b74bea74fa53e9e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-39.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-39.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-39.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-39.stdout.log"
   :SHA256 "9dc8f93b0e5210a389e8f20839f49ea4d5efbd116d784d4dd6844b55cf9453ad"
   :BYTES 4554)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-40.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-40.lisp"
   :SHA256 "aa1f0b0fece7c9631f8484f3d643fdfc48e499d7b3af816875cf9338915c0d5b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-40.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-40.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/scan-40.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/scan-40.stdout.log"
   :SHA256 "7a27c8cd5ddcc9d0359358e31580f2cb69e6d4cc8a8204f0a8a0ec8c120eddb7"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/session.pid"
   :SHA256 "cd2cb62887e32155d2d9e9dd1f1208e7789996a205bb1ce2f745fc5a52f9ac4c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RAM3yO/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-RAM3yO/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/0/stdout.lisp"
   :SHA256 "6d9e7eecf0a700a8d6d52e07c6e8432f1b3d10b7a2622568e7cbd538619e230e"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/1/stdout.lisp"
   :SHA256 "21ba30e2d641579a8109369f1efdb7296a18ac8b9b721e7653ee90b61932517e"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/2/stdout.lisp"
   :SHA256 "eb7605016a8e855906ed492e526e69c6961675ea93c7906d75a0e0cb05c60ebe"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TOiCt8/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-TOiCt8/3/stdout.lisp"
   :SHA256 "cce32a744e6996b49d6f38282522a3f03818d76e5578e9a1906b1cb887ac77dc"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/scan-25.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/scan-25.lisp"
   :SHA256 "c9490c49e4d155dae4f36cbd157ca336b54821e3077dde41586ef07d6721f47b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/scan-25.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/scan-25.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/scan-25.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/scan-25.stdout.log"
   :SHA256 "d7f48430ccf70b171ca15fbe688a6a571fe5c4be8d2546e3c9783351e2e781ea"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/session.pid"
   :SHA256 "844914185b42bc684306b36a12b2626664a2e7b1efc332ab8afbe11f42ce8060"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WPudtq/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-WPudtq/0/stdout.lisp"
   :SHA256 "61dc138a808472dac2e9d7f32bd6e1517b022458c0a739ec15d7762f781df5a7"
   :BYTES 563)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/0/stdout.lisp"
   :SHA256 "3cc412b45741142a8eebf60f12ce13fbadd7028eed7ca965407252ad1391824e"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/1/stdout.lisp"
   :SHA256 "3cc412b45741142a8eebf60f12ce13fbadd7028eed7ca965407252ad1391824e"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/2/stdout.lisp"
   :SHA256 "3cc412b45741142a8eebf60f12ce13fbadd7028eed7ca965407252ad1391824e"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-evMjf6/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-evMjf6/3/stdout.lisp"
   :SHA256 "3cc412b45741142a8eebf60f12ce13fbadd7028eed7ca965407252ad1391824e"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/scan-5.lisp"
   :SHA256 "4c301d7c2d2781ab2c45e4cf105d1d8d6b05552cdcaad13be91b760bcd5257eb"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/scan-5.stdout.log"
   :SHA256 "7889b06dac073c00e22b5c965ea082b6b196cff9ca7ae3493e36394ce82d9055"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/session.pid"
   :SHA256 "08ed678e65c1f4a8738ee59c9d0d0ec481ec881d4874cc84d41df2389cf1ef9d"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/0/stdout.lisp"
   :SHA256 "62f2756275b73dd19569918b2dea4eb9cd39a118b2e7077df651e6bf6803cfd3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/scan-6.lisp"
   :SHA256 "31e712991eb5e9266884f14414819b246ccfacef9e1bbe097f83413f98667438"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/scan-6.stdout.log"
   :SHA256 "686079ec92d5e832f77ad0545a148ba3a521b42423475b9e6ce3d3a48f688fe7"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/session.pid"
   :SHA256 "79e0a5cd8b51045d1ec824613bc2b7ea9fc3ad89102df03ac897808138aec967"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/1/stdout.lisp"
   :SHA256 "950b3161975f3298ca7b48f5868587ac01f7bcd0eb7ffcc21ef32bec49217961"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/scan-8.lisp"
   :SHA256 "46ef0df22dc7883141d51b9c1c9a25199d5e7c88b9bbe0dff54cd544ee217b20"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/scan-8.stdout.log"
   :SHA256 "59c3dce92d580d65eaea5dfb00aecdf3a22c6efdf0700cfab882c6d385c29099"
   :BYTES 4536)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/session.pid"
   :SHA256 "2715df89aed9bf30863ed3391f5db301ef42bb5b152387f9ce917b6b2834ece4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/2/stdout.lisp"
   :SHA256 "a1a7d51ed17f9c5054a4e477f444d85068581e27d5774277838f2dd97548b53c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/scan-7.lisp"
   :SHA256 "9da88f39ebc315300a2945d6bec16fc0be1852af722b581780acaf5ab6fb2522"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/scan-7.stdout.log"
   :SHA256 "e995503f00eabc373a0a9cefc5882f54ea87e3333fbcb28658c4c8043b32a3d8"
   :BYTES 4536)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/session.pid"
   :SHA256 "d713d88c2dbfa966b4727155891a3e4f3596cc7caa9f1c9e6030ae22a4e1a440"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fR9DeK/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fR9DeK/3/stdout.lisp"
   :SHA256 "c748a9537bf836fba701bd5fc0ceadbd2279085e8079a8359c6a2c41c418ca9e"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/scan-1.lisp"
   :SHA256 "f47de8a4d396c2718e7e958e052fb1a35d300d7261c642b982c1456343c2ffc7"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/scan-1.stdout.log"
   :SHA256 "99253760f4b8b617c1db3eec505d34dda235a792ffd9a0d37e3c988eafab60c8"
   :BYTES 4554)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/session.pid"
   :SHA256 "45e1d324329969f01bae3b18c37a856d3feff423808f92b40b4d9da95275f70b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/0/stdout.lisp"
   :SHA256 "62f2756275b73dd19569918b2dea4eb9cd39a118b2e7077df651e6bf6803cfd3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/scan-2.lisp"
   :SHA256 "0b372033826fa0fc3d81d3b0f4244a829aeccd5a7a2a53e3da787329043077ac"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/scan-2.stdout.log"
   :SHA256 "17e2e65c0c9cd5def7262c783822f02f17f82b3cf893c8b5c588d78ad0b89016"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/session.pid"
   :SHA256 "18e1fb993d51a4c9d86fe6a69f145d871d5ca4e23ba7ae545d17b9f773e52585"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/1/stdout.lisp"
   :SHA256 "950b3161975f3298ca7b48f5868587ac01f7bcd0eb7ffcc21ef32bec49217961"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/scan-4.lisp"
   :SHA256 "1efc0849b81f322bdcf9209655453c96d9b5285614e742b06a9ddd364d1b42d6"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/scan-4.stdout.log"
   :SHA256 "bd7a441310a85086518f1a5410e7db2431e372124fd066a358c6f9834296109a"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/session.pid"
   :SHA256 "fe00483462582b6cd7b789bede6082df261f8d68d0c6e18f41468461ac4188f5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/2/stdout.lisp"
   :SHA256 "a1a7d51ed17f9c5054a4e477f444d85068581e27d5774277838f2dd97548b53c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/scan-3.lisp"
   :SHA256 "a5eaa21bff0b64d01b98e6646eed07a3a4710df296d23d92f7b4928d89e3b089"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/scan-3.stdout.log"
   :SHA256 "0f630c76aff5e063211c04effe89fe9a1b95dcc5c8f10531a3d9e0d788710807"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/session.pid"
   :SHA256 "33fc29ccb252b869cbc840464678813ad78be9292578d0e786ca8a89f4401ad3"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fTpbi8/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-fTpbi8/3/stdout.lisp"
   :SHA256 "c748a9537bf836fba701bd5fc0ceadbd2279085e8079a8359c6a2c41c418ca9e"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/scan-17.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/scan-17.lisp"
   :SHA256 "944728104d65dc9b7bf91066edbcf665e6f719ec29790427fe83e14123928ce3"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/scan-17.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/scan-17.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/scan-17.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/scan-17.stdout.log"
   :SHA256 "cb7878bdda97e8b0b59bcc4c78474969e51b99d8d2a537607c491fa9e7354fdd"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/session.pid"
   :SHA256 "7f04fbd6b4390db596472201c72d48705b11abed27c752528c7dbe92f7284424"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gZPZSt/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gZPZSt/0/stdout.lisp"
   :SHA256 "84c9aa6b7304dee55c1a4258ed7f7980612fe334e2644c9482521ea98a3f44ef"
   :BYTES 454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/scan-38.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/scan-38.lisp"
   :SHA256 "f088e64dc72e8962d93d7d06a2814e7ad7295cb6e3dfacf008ae53f7839cc77b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/scan-38.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/scan-38.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/scan-38.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/scan-38.stdout.log"
   :SHA256 "ba71542c2ded32dadb334fb7edd0b8e97a58c1229f57ad6704b5121a810e1b70"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/session.pid"
   :SHA256 "0ec7ce9b7db952c72c7ce4a3348036b8ccbaa5856ce42bc48d3eee7d840b1dab"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/0/stdout.lisp"
   :SHA256 "c435d00683e8f39596abcdbc7d853f8ba767923be9926825c131bfcf87d817d4"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/scan-37.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/scan-37.lisp"
   :SHA256 "1a9bfff58f55b0bf4be6defe7a8da8b46946da3199d343c87a6a4ce924d75f83"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/scan-37.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/scan-37.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/scan-37.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/scan-37.stdout.log"
   :SHA256 "15ad1f70bd11538845696056f5f6745ab6a62db72a46eb132ef9caf87c12261c"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/session.pid"
   :SHA256 "05a6a34bd7ba7118b53742cd8f480f5b995e38abc1753bf78f2c441243ba922b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/1/stdout.lisp"
   :SHA256 "0b890442cad70a5479c7a6fd55305afaec7635d68e441bbd452500c7f4ba7e33"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/scan-36.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/scan-36.lisp"
   :SHA256 "aca9a6e8b75f1efdf409f0c98041d2fa7c3329e4c3a3eb6373d6a61bd7a1ee68"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/scan-36.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/scan-36.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/scan-36.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/scan-36.stdout.log"
   :SHA256 "590300a1fb345d5e566263de45184d2c60ea4866955ba0e41f2cf4bab148c384"
   :BYTES 4560)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/session.pid"
   :SHA256 "75b914e6b5c2f2f3747420065c04a63e86969e7fb6239bb5141b8a6f2730c6c1"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/2/stdout.lisp"
   :SHA256 "36ea78afefc8ab21dbbe0bc5e7c6563b97be68d96f8c22bbd20374c8e733b8ca"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/scan-35.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/scan-35.lisp"
   :SHA256 "281a6b704e570f0d607d4186a744b9897045caf4a3ccade902d17b939877f1e5"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/scan-35.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/scan-35.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/scan-35.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/scan-35.stdout.log"
   :SHA256 "1e2284c21fb26bfacdd01f2d4b88aad83d1319574faadbda6639bf4112f6b497"
   :BYTES 4566)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/session.pid"
   :SHA256 "97b545175912b19e17d871321af025de56b64335e18d00cfab309585ef3e0ab9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gg573J/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-gg573J/3/stdout.lisp"
   :SHA256 "03c629529873fa06975a17f949ccbb7f429adcd38af4aacacc46f8a29578a8d6"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/scan-11.lisp"
   :SHA256 "ecc0c5f6074309b9b78d717935941e9c6671993736b3fcdf6047fc378c97893c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/scan-11.stdout.log"
   :SHA256 "15d6521a8071eb0122d9f90d7c6729aa9aaa4656108294814bd308f5ed93646b"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/session.pid"
   :SHA256 "c9527d02b8ff8fb31e5df58a139e94558ec878881ac2146c03de8b474381ae8e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hRWHLy/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-hRWHLy/0/stdout.lisp"
   :SHA256 "4887086b8046d7d9b95e6f101ae3283cd2c40cdf5932cb7e677c2f1cee35bc96"
   :BYTES 296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/scan-19.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/scan-19.lisp"
   :SHA256 "0c7246afb305bf56e9957e69e7448097cd12712a7e1241b012930975e4bd9f1e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/scan-19.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/scan-19.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/scan-19.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/scan-19.stdout.log"
   :SHA256 "c258c9c348047a6fc63d4f775cc67ff1cc53e9ce72dcbbae8ab2ac57cb97e5f6"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/session.pid"
   :SHA256 "ae0ca3f25f4d752bbe87d6b47233f7edbb3e7eae4a29b951e04523f92c48a54a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-iJfe3C/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-iJfe3C/0/stdout.lisp"
   :SHA256 "05cb7c0eea8fdc77a40bae6f5239c09e2bc65fad2aae1ceac16ff4eeb9f683b2"
   :BYTES 697)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/scan-10.lisp"
   :SHA256 "c4ee7a436554e06f00e6bd2b7bb9d5ec7037f655f33ec930e4af80f1049405c7"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/scan-10.stdout.log"
   :SHA256 "b4d3ae2a7d96562ecfead48ca2d844ad01fb77af1b4d2928aefc2af081bbc2af"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/session.pid"
   :SHA256 "98c177a3bc4443c0159899fe6259e04b5b5e068c804ffd7b48a54e614fb2bf15"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-j9yLgV/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-j9yLgV/0/stdout.lisp"
   :SHA256 "dfcdbc379eac0cf53173cc978c1edc0cfc9a0275b4e360ab2a2681202f536d97"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-41.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-41.lisp"
   :SHA256 "eec390ef104636e65b681deeb7ab6c2d451dbad8aac1d12405818aab6211f9db"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-41.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-41.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-41.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-41.stdout.log"
   :SHA256 "537e4797eddadf69fe8e6d1057b6a57489d5383a987f421ec75c2caf32d23028"
   :BYTES 4554)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-42.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-42.lisp"
   :SHA256 "c7066aa493648d83460a0c609d893e27e6e6af8524cdb6ef5747e09a454cbbae"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-42.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-42.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/scan-42.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/scan-42.stdout.log"
   :SHA256 "e3b508273d1d24d56bfdf055e02f38c5a0c220b9eb617069df82ad8441cf3f1d"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/session.pid"
   :SHA256 "8f04291762b524dfa63ccdcb85a2a9123b6c7b5fca679f06b8b480312b075745"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jI1HvR/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jI1HvR/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/0/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/1/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/2/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jphN8B/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-jphN8B/3/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/scan-21.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/scan-21.lisp"
   :SHA256 "bd564255a932c3718b8bc742a159a80e0d4d0536a6fc869ae0936be782f96099"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/scan-21.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/scan-21.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/scan-21.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/scan-21.stdout.log"
   :SHA256 "ad9513d37605a48967fe631eaffc42ef2087dda6972652cf9f6b7ed8c73b2fb2"
   :BYTES 4554)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/session.pid"
   :SHA256 "4e013123d9628b1006b20bb249a220e0b3d452399173db52c4a24d0e2ab05ad4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/0/stdout.lisp"
   :SHA256 "02a42abbe2c5429d3496bfc3a3007a0c11511ae6708bc215a87c94b4f0e67b33"
   :BYTES 750)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/scan-22.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/scan-22.lisp"
   :SHA256 "eaa70d1d61357027f533ba18fe004395ce3f587939260614fa29d7bd6e5ddc2c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/scan-22.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/scan-22.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/scan-22.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/scan-22.stdout.log"
   :SHA256 "5c72bb40004fd8419bcb76cdb0c07b570b823a8e9760d5fe4dc6576781d28ac6"
   :BYTES 4548)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/session.pid"
   :SHA256 "71b628d9b25cbfdd061b57b819da42994de9a18d788cca6f23f01255c26dc08b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/1/stdout.lisp"
   :SHA256 "8fbb33c0a816084497dfd6cfd0eab6902db561ec391de08a4e72127c7fd08e32"
   :BYTES 752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/scan-24.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/scan-24.lisp"
   :SHA256 "1c8143f4b7adf6ea38282f43b710aa2761b004dc8a47c0b667c3425d3fe744cb"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/scan-24.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/scan-24.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/scan-24.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/scan-24.stdout.log"
   :SHA256 "0e4fa93595ad15f60ee2a9a5ba39c6135937d5734b5a3aee33c9a01c8c77d585"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/session.pid"
   :SHA256 "3ceaeae9ec4de01ea5ce17ae75c6101265b492efe7b9e5c3e6c5ade7371cfe1a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/2/stdout.lisp"
   :SHA256 "10bada788d8765ac135a097ac70a0c8aeeb2f88bdc23eaf1a1577e2ceea5b8af"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/scan-23.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/scan-23.lisp"
   :SHA256 "ed61f0024fb5de87c36383e00d62079bc5d662ca680619bdf28dfee3e8c1eb07"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/scan-23.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/scan-23.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/scan-23.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/scan-23.stdout.log"
   :SHA256 "ad0c4b341eef901058424a9e8ca6371b4ad6e684d86ba7bec91f3c0cb2cb09c2"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/session.pid"
   :SHA256 "fdce01ecbebd58803cc405fe4c51e64b24bbf73e1b94139d87af0d15f100d3fb"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pyMEHe/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-pyMEHe/3/stdout.lisp"
   :SHA256 "f8436674d6f1da82fb7dcf98da5e8a5d819d2fcc32376e750b14adc3dd4dc51f"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/scan-16.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/scan-16.lisp"
   :SHA256 "7bae0d07a874856e4952582ffff5d818e978b8e211aa8eb8d745ba0a71863bcd"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/scan-16.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/scan-16.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/scan-16.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/scan-16.stdout.log"
   :SHA256 "b9c0611fc0b4ce9b0f834f6459f446792b4ed32172f7eaa0a5a5c66e3723121b"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/session.pid"
   :SHA256 "d294ab6f61381a3bbe770ffe1336a2a7b6d0d26ee57c31a71ce0830d45851ad9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFNLoG/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-rFNLoG/0/stdout.lisp"
   :SHA256 "5eeff59f6a719043d20656306189504c5c53cddb3f6c44df402b0fc52a2c93fe"
   :BYTES 452)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/scan-15.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/scan-15.lisp"
   :SHA256 "4b12c61b2b04e9e1d2eeab29dc91ab0615f28ae4dd257f628cb5130f4998edf1"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/scan-15.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/scan-15.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/scan-15.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/scan-15.stdout.log"
   :SHA256 "9b7d996203d7b6ddeac27c9f5b531e4e06dd56d152a195cedf7d0eff1b4c8a48"
   :BYTES 4530)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/session.pid"
   :SHA256 "433b109c9115cd16dc9d658bc2da6ca0e838c479a09eadf3f7ea9620703edf7a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-tuHdoI/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-tuHdoI/0/stdout.lisp"
   :SHA256 "cc2ab4ed47b7f67c0c0b90ce59b37274105fc60e437ff30f9e87c95f404f9eba"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/scan-9.lisp"
   :SHA256 "130eac1a34be6bcfe10d90497d7c77ea3fb6402fcb965dc6d1aa344c875a6712"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/scan-9.stdout.log"
   :SHA256 "4b32e76b06a0a329115937090fcc36ffbeb0836e96d257beb7adac8783e67f65"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/session.pid"
   :SHA256 "f13842c548ea42a7b4b33f576d3a0ebed65ab862e7f9ad0e843537c946e45b03"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v5Pjnc/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-v5Pjnc/0/stdout.lisp"
   :SHA256 "5c59bed51a2e2a97a56bd9a5d0cfa256a0286cc2c6a8f6cf3c31320461591c35"
   :BYTES 293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/scan-26.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/scan-26.lisp"
   :SHA256 "e33602f9cade4ac2240e62f969610cb578147e43299f58004cfe1b914740d528"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/scan-26.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/scan-26.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/scan-26.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/scan-26.stdout.log"
   :SHA256 "5448af1959b9dbdd2a26a0e2cf529e161afb76699ce3b088b61962fb83fe240e"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/session.pid"
   :SHA256 "8fae86d93cd44f9410d61044b2b0c8ca620cd63881481f5a06e1f84484b2c79e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-w1AQ3v/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-w1AQ3v/0/stdout.lisp"
   :SHA256 "fff356eb71d3e64f83175c9d1d9c8826c72a7e2114fc7f1088a2868bae9a9c97"
   :BYTES 498)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/scan-29.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/scan-29.lisp"
   :SHA256 "8bf57ec4cf401e4d3552187903262644d3b3a2dc97c76364440e1f6ef1c486d4"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/scan-29.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/scan-29.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/scan-29.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/scan-29.stdout.log"
   :SHA256 "0f783092ce1e753499b77a9c0bad7c0f511030a78d6e6a535b88e6ed3871c0fb"
   :BYTES 4542)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/session.pid"
   :SHA256 "f26ba977b4b86fb4f63efc159a8690102be5aeedd989d4c1d482faa89396b78f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wfCJ61/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-wfCJ61/0/stdout.lisp"
   :SHA256 "0a2e0825a87e51be3e4041e6f5d0cd59f45e4b349fc18ad927fe7413ba2974af"
   :BYTES 514)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/scan-12.lisp"
   :SHA256 "43cae2f0e870cc221d459e664a12d67b26d6682ee931134c2c3a2ca6f9cee5a0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/scan-12.stdout.log"
   :SHA256 "0bfd97aadcc4b6a03fd24672b110a042ebc69d1139cf126028539b7a942da506"
   :BYTES 4524)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/session.pid"
   :SHA256 "d46654492d2d5b214f1fee3ec5d1b981f2be5386bb7f6826265d4fbd32d38b11"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xJOubE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xJOubE/0/stdout.lisp"
   :SHA256 "930a25ccedb4837854d8874544e01d83e15fa29688433f75423cd16be364d32c"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/scan-18.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/scan-18.lisp"
   :SHA256 "87c7735d70c5896c679a3f1e0071a0a9c969bc74eeaabc383fcfec09b935b82b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/scan-18.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/scan-18.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/scan-18.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/scan-18.stdout.log"
   :SHA256 "f66c55ae318574cc77ab5757e57f83e02cace633b01406e408627c8acef4bb0f"
   :BYTES 4536)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/session.pid"
   :SHA256 "96efa756bed5f0f504e43a02b786a991f1ea3c321309f089e081a342f8bbf713"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xybKVG/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/evidence-check-xybKVG/0/stdout.lisp"
   :SHA256 "717cb752898cd1a5fc5cc3be5e2df3eb8f8dc6379e5d5cc32f2f530bfe490e30"
   :BYTES 474))
 :LIMITS
 (:COMPLETED-COMMANDS-ONLY :EXACT-CHILD-LOGS
  :SUCCESSFUL-STORAGE-FIXTURES-REGENERABLE
  :FAILED-FIXTURE-REGULAR-BYTES-RETAINED-VERBATIM :UNIX-SOCKETS-AS-METADATA
  :NEGATIVE-NESTED-CI-FIXTURES-EXCLUDED :NO-NEGATIVE-FIXTURE-QUALIFICATION))
