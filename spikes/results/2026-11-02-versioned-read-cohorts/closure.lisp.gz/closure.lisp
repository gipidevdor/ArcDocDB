(:KIND :VERSIONED-READ-COHORT-EVIDENCE-CLOSURE :STATUS :PASSED :VERIFIED-FILES
 791 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 187637 :STORED-BYTES 59396 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 187637 :UNCOMPRESSED-SHA256
    "6f1e20a769703344c15efc1d9819432281422167370b0c9727d18540d185855d"
    :COMPRESSED-BYTES 59072 :COMPRESSED-SHA256
    "414eac49b5f0ec4928075bc2a0254dbc685b13b6175d0b5f5fdbe35fe66b05d9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/archive-data.lisp"
   :STATUS :OK :ORIGINAL-BYTES 325181 :STORED-BYTES 29001 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "archive-data.lisp.gz" :UNCOMPRESSED-BYTES 325181 :UNCOMPRESSED-SHA256
    "c52129a55f29edd09290bfdf85d3bcfd96876feefe443b72b3ec83811c6e9937"
    :COMPRESSED-BYTES 28680 :COMPRESSED-SHA256
    "6afda1ec9bc7fc6f704d4a25c6197958c4a95c5153ca14a6a14cee2f2ffe8ba3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/4002636793-command-93440-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365537 :STORED-BYTES 117277 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365537 :UNCOMPRESSED-SHA256
    "e8772b06981421fcbe0df4ced16cbe319bc8beaedb3b7a33c991547ad392c276"
    :COMPRESSED-BYTES 116961 :COMPRESSED-SHA256
    "4dbe4c8f8ea05774e1d1ac7491ee9f10b5e71a8bced71366dafd181326edc0d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366406 :STORED-BYTES 117284 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366406 :UNCOMPRESSED-SHA256
    "138f6c05551ec260f9b4ec71e0a2e268e1d4444c35510be66a4ddb5b18de7191"
    :COMPRESSED-BYTES 116968 :COMPRESSED-SHA256
    "60449168f8a78212f71ab66539d9ea23e8514802b77f215ac8b7ca09b6bc4f4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366407 :STORED-BYTES 117292 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366407 :UNCOMPRESSED-SHA256
    "cf6e545815645de6ca4539f5a135fb4a77bc391d27e0d56b71ffdb25074cfac9"
    :COMPRESSED-BYTES 116976 :COMPRESSED-SHA256
    "50ba11990606cef089041cb6c2e9d784dcf3d4beb8f16aaf98983932be6ea40d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366379 :STORED-BYTES 117292 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366379 :UNCOMPRESSED-SHA256
    "d008dc9a8ac207ea98e35182967ec78af9b2b573e9a4ce59197a5a7f8f40735a"
    :COMPRESSED-BYTES 116976 :COMPRESSED-SHA256
    "2f0dfc2b5ed9b0437497cb0c9e816e7e265685fc8c117ddb7d3cb70b753b2c0c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-allocation-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366379 :STORED-BYTES 117295 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366379 :UNCOMPRESSED-SHA256
    "4506e597037406b1b77d3fe4468828660ed8fc65342dd83754827e69b0219715"
    :COMPRESSED-BYTES 116979 :COMPRESSED-SHA256
    "24e8bc84d022718dcf0eeeed78006d55649ebf7f2fc55e42280c2b86ae9d847e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364995 :STORED-BYTES 117167 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364995 :UNCOMPRESSED-SHA256
    "4034e4ea08ca1cef362eac8aef401b59d5b946dcc92afd72a0d653bd5df47ba2"
    :COMPRESSED-BYTES 116851 :COMPRESSED-SHA256
    "df3f48ac2c6b18d79473f7ee5ca1d11875c9604526ac0aba0f53d8b34e276418"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364995 :STORED-BYTES 117171 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364995 :UNCOMPRESSED-SHA256
    "4933b0783dda6a31219f6390895ccf7ee19ba78f4a6aac8ac58742b7ea0f8ff2"
    :COMPRESSED-BYTES 116855 :COMPRESSED-SHA256
    "69dd70141f3667993f3bb920ea57206f90b6660ab5243e42f2acf21415b1db4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 379964 :STORED-BYTES 119060 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 379964 :UNCOMPRESSED-SHA256
    "96f1cf3d0d0f398f15a242c0e089634240bd703956d6ca05c1d8fbf2818930d7"
    :COMPRESSED-BYTES 118744 :COMPRESSED-SHA256
    "8cb130d3054450a8df08aa827858f24c05687c36afc21c1ae6a12c7104d97463"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364191 :STORED-BYTES 116896 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364191 :UNCOMPRESSED-SHA256
    "b2b069bc2f09da83609c67392cec74d67bfae5eb0a267e75a7e274062c075424"
    :COMPRESSED-BYTES 116580 :COMPRESSED-SHA256
    "bb47dbf11bf0d5e18e3f0cf69b8dc21d0505f5aa93e0f109ff5b28d06f1a531a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365096 :STORED-BYTES 117179 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365096 :UNCOMPRESSED-SHA256
    "6265768cb4f1f4a6777270a4417b010fb5cdd539c21ee8a3ebad98dd9a83b14f"
    :COMPRESSED-BYTES 116863 :COMPRESSED-SHA256
    "30c281f58292b46f792f42ae8ed46ee90fc58041b9e904d279859094839c90f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-candidate/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365090 :STORED-BYTES 117178 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365090 :UNCOMPRESSED-SHA256
    "922c3994b13e0d1b0a74e0622c227bf985d21619bc367523e4dc0b639a0c3000"
    :COMPRESSED-BYTES 116862 :COMPRESSED-SHA256
    "1158e3c5478d0883ca8a37aae434aeb43d5e758606ea4c477df92268f2cea350"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364988 :STORED-BYTES 117176 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364988 :UNCOMPRESSED-SHA256
    "5b8c38a3a492bde7392a26b6face1c7075bd22bb3063e61af68117d09f106ad0"
    :COMPRESSED-BYTES 116860 :COMPRESSED-SHA256
    "c313783732d066ced1a0fea11fbc8020d9b3ca6f57dcaeb3196381930a7f1cba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-docs/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 371018 :STORED-BYTES 118514 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 371018 :UNCOMPRESSED-SHA256
    "729d2cc860b3f05b8715dbdebce9c4bf155a07a7a173c3bc96c991a30ce565f2"
    :COMPRESSED-BYTES 118198 :COMPRESSED-SHA256
    "2358a9444bb4eee513d304b4ceed2228c75818dccde81df049dbd98e0a18011c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 373162 :STORED-BYTES 119050 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 373162 :UNCOMPRESSED-SHA256
    "4f09f3d919b6a131fdd579c5f348f61cc779cd1bcaab732d42e5744b5c4fd62b"
    :COMPRESSED-BYTES 118734 :COMPRESSED-SHA256
    "7d70b40b3dc2ffa49f44310296e06c2c50685dedd6ed70a5d57466dcbc090c23"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 385370 :STORED-BYTES 120560 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 385370 :UNCOMPRESSED-SHA256
    "2b601f338bcc1116d65664c435440ba16b4ffddf4032e14f6d3525785c746642"
    :COMPRESSED-BYTES 120244 :COMPRESSED-SHA256
    "f1e56ed6c3050197d8763be8499d9c38dd877362896cbcbc9fbb0032746fbc93"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-focused-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368784 :STORED-BYTES 118342 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368784 :UNCOMPRESSED-SHA256
    "da6828488ec1f2e5d6d980ed6e8e09830ab96ac9d492f7023b4a8d4729127240"
    :COMPRESSED-BYTES 118026 :COMPRESSED-SHA256
    "a1a5e7a00a349ba5bfa18e6143ecd105b20a7b8cad62bf790b7ad5cdd99e987f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl10-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 427586 :STORED-BYTES 121342 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 427586 :UNCOMPRESSED-SHA256
    "4eedd757ee309bb812a92403e880a57f2301ebde1b8da243173ea64a31bd837c"
    :COMPRESSED-BYTES 121026 :COMPRESSED-SHA256
    "ed817cb2fc70bcbb8578b4041c157ac1d790e55ef952d10b9725e6b3f29c8a01"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 427558 :STORED-BYTES 121339 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 427558 :UNCOMPRESSED-SHA256
    "cef44022676ebadce1c5bd9b4a0d155260a7886b83b1d0a0d6644254814e1513"
    :COMPRESSED-BYTES 121023 :COMPRESSED-SHA256
    "2d4cafe826e6721f365980835c45e11e130636417865c1e3aa8bc78a59f30f70"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-qualification-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 414613 :STORED-BYTES 122203 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 414613 :UNCOMPRESSED-SHA256
    "9512d7023e6257a64be9cfb7433b2ac00566720e9aa9e7972938b73fbafe3808"
    :COMPRESSED-BYTES 121887 :COMPRESSED-SHA256
    "fde0897c2c4b69358070837919bc5f12c2bb59d59be51b9bd50c6e1d21ebca87"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364939 :STORED-BYTES 117139 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364939 :UNCOMPRESSED-SHA256
    "adc519336d19d2ebe8d99ec611d3006f3cbfa161dd231040d45f811688ca8d1f"
    :COMPRESSED-BYTES 116823 :COMPRESSED-SHA256
    "57f58cb5f8a927591b284632956f8829e78064a78c2e68c92accd967bf26a176"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364939 :STORED-BYTES 117143 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364939 :UNCOMPRESSED-SHA256
    "7a3e3c7136511178d20a2ccfcfe8a1998be3535081dbe1e391d61c4f3dc2da44"
    :COMPRESSED-BYTES 116827 :COMPRESSED-SHA256
    "1ee8193bc9efbcd1496f4fded3df34c7fa1e1f3a32473ecac9136394b125a2ea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364943 :STORED-BYTES 117150 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364943 :UNCOMPRESSED-SHA256
    "2468d39768726dcd441fa70f87fafac70023ae299e8f91207f78dd700f2d2199"
    :COMPRESSED-BYTES 116834 :COMPRESSED-SHA256
    "334a05be8c03c2b32377ffff5f90d42ad15d0f04e22c4ccdcde3fefc18466aa4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-cleanup-worktree/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364943 :STORED-BYTES 117150 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364943 :UNCOMPRESSED-SHA256
    "08d39f81ece115b301158e2cae2fe08cf68da01748faaf29d37f53b52de55908"
    :COMPRESSED-BYTES 116834 :COMPRESSED-SHA256
    "9c4809b493363b6a8213cb8bb2ea1f267664aaebccbb26878a3822957428f9b1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364931 :STORED-BYTES 117126 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364931 :UNCOMPRESSED-SHA256
    "e7a71dc16c7641200ef5077b7bd0f41e92fd90ad048cd51130d4842f00e8bfcf"
    :COMPRESSED-BYTES 116810 :COMPRESSED-SHA256
    "4ff30ffa68fb1f1c435cedce34c8145aaabd18e35e0164156afd7cb832fde29d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-qualify/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364955 :STORED-BYTES 117147 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364955 :UNCOMPRESSED-SHA256
    "ae68785b39e66490663d0f55486ca57908e0e485f42fbc18fa311869e1405f7d"
    :COMPRESSED-BYTES 116831 :COMPRESSED-SHA256
    "c332ad609b1ded6f3b2cec4ce735d95ed879a3154be2b7914841afe24e9b4c1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364917 :STORED-BYTES 117123 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364917 :UNCOMPRESSED-SHA256
    "f70270ffda28f82b6c57acca12fe50c7bd9914e38fb4da9df98f7fc882c5b768"
    :COMPRESSED-BYTES 116807 :COMPRESSED-SHA256
    "def80f80dc4806ccd76656589c0d3f5e2565bbcd4c4544be25852fb699c10ff8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-selftest-verify/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364917 :STORED-BYTES 117124 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364917 :UNCOMPRESSED-SHA256
    "c3814636a505428ff81c584c6d245d6bdf17f07d857b7f8591a5b82789e65911"
    :COMPRESSED-BYTES 116808 :COMPRESSED-SHA256
    "9134683eafcf79c2f70c82ed66cc4633ba57dbd4edf7f63a461ff06ab8651e13"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364960 :STORED-BYTES 117118 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364960 :UNCOMPRESSED-SHA256
    "8e77c3dd4061cd4e345d944ab2fb6c13a709b4a451c5044df923af3804c54099"
    :COMPRESSED-BYTES 116802 :COMPRESSED-SHA256
    "06dde60144f9367b81beee5ef22a8328bce45271d0da268ee241d7c9178d6b1d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-static/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364960 :STORED-BYTES 117126 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364960 :UNCOMPRESSED-SHA256
    "2c1407667b85c89279b5a7eefd1b3d124f93f2820ed9dedfbbf90cab3cde8bc6"
    :COMPRESSED-BYTES 116810 :COMPRESSED-SHA256
    "2b8796a7fadd04c74199225d4af3c958a8144787c623b55c11e7338be5207be6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/commands/version-cohort-verify/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364939 :STORED-BYTES 117147 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364939 :UNCOMPRESSED-SHA256
    "83476ba49cfd95442b12afeb944e9da9cc180674482e0ee4d3d27930496c6108"
    :COMPRESSED-BYTES 116831 :COMPRESSED-SHA256
    "0a2dfb0c4ce2fc5d2270b930833bb1943e3f25b71a344271f051a7835db93f65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/focused-02/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 256888 :STORED-BYTES 42569 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 256888 :UNCOMPRESSED-SHA256
    "4497051bab30550cce66f01403b76e305615cd402950838766524ae7cbdbb5a4"
    :COMPRESSED-BYTES 42253 :COMPRESSED-SHA256
    "44a2794e7d8e81ffc2ff1c82986065ad5e08c629a5eea2dfd7fe4caa6ac6681d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/focused-03/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 256888 :STORED-BYTES 42569 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 256888 :UNCOMPRESSED-SHA256
    "4497051bab30550cce66f01403b76e305615cd402950838766524ae7cbdbb5a4"
    :COMPRESSED-BYTES 42253 :COMPRESSED-SHA256
    "44a2794e7d8e81ffc2ff1c82986065ad5e08c629a5eea2dfd7fe4caa6ac6681d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/focused-03/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12200 :STORED-BYTES 1621 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 12200 :UNCOMPRESSED-SHA256
    "f30b55f0b523439a42a86bb8497863a822344214d10b4a28675ca88810cd3b85"
    :COMPRESSED-BYTES 1308 :COMPRESSED-SHA256
    "c0b6c05b32f35ef7ac50015032a3604c32ecc0d11fa7d78c8a0403f88e1e4145"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/focused-03/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5185 :STORED-BYTES 1442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5185 :UNCOMPRESSED-SHA256
    "2deadd5934c79c5739a7100c9f799bddf297bb01ad621e584122987eb8dc82bb"
    :COMPRESSED-BYTES 1127 :COMPRESSED-SHA256
    "ee214732e38aa771bf83afdb99881a9c833b341cd20cb34d14ff7c592707be25"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl10-final/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 256889 :STORED-BYTES 42587 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 256889 :UNCOMPRESSED-SHA256
    "68b6f38e5980160c4099d762e7469593f8b9c036f392252d64ceeb86e9e8b1be"
    :COMPRESSED-BYTES 42271 :COMPRESSED-SHA256
    "ca469f4a5e38c980b3b13ef92428a091d85d120c544f4397d494bc1c329dbb3b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl10-final/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12714 :STORED-BYTES 1672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 12714 :UNCOMPRESSED-SHA256
    "630f6ae297d4a353df0adbb338b46a90e34c8d5c090a8391012ea6bf8c8c3a04"
    :COMPRESSED-BYTES 1359 :COMPRESSED-SHA256
    "46df21c5c5201169447710d44a8f2f1cb278145613669ec6a7df8983187c886f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl10-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5400 :STORED-BYTES 1484 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5400 :UNCOMPRESSED-SHA256
    "c890faff08d805325335028d29ccef38debe382af02ba65439e41d22cf6b7266"
    :COMPRESSED-BYTES 1169 :COMPRESSED-SHA256
    "2957962fe7af3e56f046f83649d9d812ad8e8e92e3bc506e884c35a17e792d5f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl9-final/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 256888 :STORED-BYTES 42586 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 256888 :UNCOMPRESSED-SHA256
    "6da8b07528cefede65a8843f6012762af727bde191bc2a9ab1f2d4062d9c40c7"
    :COMPRESSED-BYTES 42270 :COMPRESSED-SHA256
    "0a2030e3a1037282264c2c73ac8efb913e5bd700bb509210db33552848c9b223"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl9-final/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12714 :STORED-BYTES 1672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 12714 :UNCOMPRESSED-SHA256
    "630f6ae297d4a353df0adbb338b46a90e34c8d5c090a8391012ea6bf8c8c3a04"
    :COMPRESSED-BYTES 1359 :COMPRESSED-SHA256
    "46df21c5c5201169447710d44a8f2f1cb278145613669ec6a7df8983187c886f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl9-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5399 :STORED-BYTES 1485 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 5399 :UNCOMPRESSED-SHA256
    "3dd6d0c359eabf8e4fc92a1f112bb198afa7e937f49156dee63300a72df10f75"
    :COMPRESSED-BYTES 1170 :COMPRESSED-SHA256
    "fd537cbbe95d3ae80c7f657f8a93be30f40a96b38fcd1dde09bb7b89b330be2c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/qualification-sbcl9/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 256888 :STORED-BYTES 42586 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 256888 :UNCOMPRESSED-SHA256
    "6da8b07528cefede65a8843f6012762af727bde191bc2a9ab1f2d4062d9c40c7"
    :COMPRESSED-BYTES 42270 :COMPRESSED-SHA256
    "0a2030e3a1037282264c2c73ac8efb913e5bd700bb509210db33552848c9b223"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8343 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "9bd814e4a9e16c03cc96abe4eee3ca3aabadf4f0a0f39217cdfb5539da272bef"
    :COMPRESSED-BYTES 8030 :COMPRESSED-SHA256
    "c244da9e80c2889fd7ff409684dbe8270a50ddb373b1cdf550a564cd2be11d21"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22975 :STORED-BYTES 4606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22975 :UNCOMPRESSED-SHA256
    "2ff6dc526bcc1320a4a8fe7f3e38efa33891ef6089890addbaae8549548a388a"
    :COMPRESSED-BYTES 4293 :COMPRESSED-SHA256
    "e30d712a05791cc1ecb431ea1a18072791ca53d3ce5971e3c81e585d3cd0ff39"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331091 :STORED-BYTES 45768 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331091 :UNCOMPRESSED-SHA256
    "52034dc8bf2f35ccd47d87b3cdd47d50bafdf1ed9ed1b06644851021b6271e4f"
    :COMPRESSED-BYTES 45453 :COMPRESSED-SHA256
    "d451b04a1f2201fd2b3be0880f94f905c34889b1e5466bb298fdf805b2fe4916"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24124 :STORED-BYTES 4386 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24124 :UNCOMPRESSED-SHA256
    "912638645a652bbd896dbe797fbac677c42672066978fe2dfa7e75779b2315dc"
    :COMPRESSED-BYTES 4073 :COMPRESSED-SHA256
    "14c9e02eb9e3da8469135bc28c5080722e8df60906f34956e84dfc3fc3061335"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10168 :STORED-BYTES 2220 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10168 :UNCOMPRESSED-SHA256
    "0563d08d4c0339a15e08a45ff3a2a9c569b239172fbd07ea618f053369790e47"
    :COMPRESSED-BYTES 1907 :COMPRESSED-SHA256
    "46c89a9a686f3dff211aea68047c4dfd0e2f353dc9511f595da3a68a33a7d5a3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1922 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "48336e43d1b051e24800ffe9e3827e186da5cbebb12861775bc7be40c109ec1e"
    :COMPRESSED-BYTES 1610 :COMPRESSED-SHA256
    "594a5902562eab18ba16700207744ec4e88c51bb018483a80b9ecdf98104e5f7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/4002636740-check-92789-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3192 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "bf767b64455e0ff7bb7bbffe61758008d617788c4cce296782a0091ab6eb4a81"
    :COMPRESSED-BYTES 2879 :COMPRESSED-SHA256
    "7b9ca6e53778a1ba1803a3a781e75aa6436094ee80b8e19578458f56e924ca47"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/ci/selftest-1793647992-93439/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-cohorts/support/command-archive-collector-self-test-fy5eEG/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "62d671be2c6b8ddfe18bdea4851440c1b8201870e639bc66f9f2c4f47835986c"
    :COMPRESSED-BYTES 3213 :COMPRESSED-SHA256
    "7cad452d1036900599b32bed3abf5d41c5d7c3ef0f8519a9f89bcab21d5010ae")))
 :DRIVER-SHA256
 "c36b6794e674876931047976b384e6a60d5612fdefc25c2969368bda4d4cef1a" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :LOSSLESS-ORIGINAL-BYTE-HASHES
  :ALL-COPIED-COMMAND-AND-CHILD-LOGS))
