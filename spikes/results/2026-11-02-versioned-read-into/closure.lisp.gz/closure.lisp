(:KIND :VERSION-INTO-EVIDENCE-CLOSURE :STATUS :PASSED :VERIFIED-FILES 1770
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 199450 :STORED-BYTES 59573 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 199450 :UNCOMPRESSED-SHA256
    "4c6b050d4da0cd399922083cfeef9cb050c6d73b430d304002c84ad3351b1343"
    :COMPRESSED-BYTES 59249 :COMPRESSED-SHA256
    "2caf00a0dd471a4689f5bda526d57d3afad88ae8d7091d73e55c990f3f9bd533"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/archive-data.lisp"
   :STATUS :OK :ORIGINAL-BYTES 672874 :STORED-BYTES 52847 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "archive-data.lisp.gz" :UNCOMPRESSED-BYTES 672874 :UNCOMPRESSED-SHA256
    "7c32e74cbfdcb748baf79923965a1de8d18ae7658ddc0abb8ea190afba801ca8"
    :COMPRESSED-BYTES 52526 :COMPRESSED-SHA256
    "b7471c4ea6d44423e520570af68d5f05243f40d3a2b2c868b3606ebf5a46d7cb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/4002627449-command-28891-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365060 :STORED-BYTES 117125 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365060 :UNCOMPRESSED-SHA256
    "f7691143d3637bb723d3c7b87f583e1e08d44366cd0bff766bc52cdd442ac945"
    :COMPRESSED-BYTES 116809 :COMPRESSED-SHA256
    "f188029797d6617516154818ebbdade08d9317c6f60530b6f9ed6eb3605b668f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-allocation-final-sbcl10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 371503 :STORED-BYTES 117307 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 371503 :UNCOMPRESSED-SHA256
    "f661b77953438fea70c40e7da40e4dda76c833e046fe00230bce99a41248c0c1"
    :COMPRESSED-BYTES 116991 :COMPRESSED-SHA256
    "5b319a8f93b390ad2d4799c37b3fa6077e05a758558db37ed870fee016b9f9a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-allocation-final-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 371475 :STORED-BYTES 117310 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 371475 :UNCOMPRESSED-SHA256
    "87c1298c973f1c3c467bec7d9d67547f51823034557ad90ec2b25f1923d96f20"
    :COMPRESSED-BYTES 116994 :COMPRESSED-SHA256
    "585a5b8c247b077d6976abb287dcf50cb43a51b3990974371746011d1bd71c99"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-allocation-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 378104 :STORED-BYTES 119049 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 378104 :UNCOMPRESSED-SHA256
    "3a859b6ee191071811785431136c8f8fa1872670adbea76fabbeae7ebf755d1e"
    :COMPRESSED-BYTES 118733 :COMPRESSED-SHA256
    "63664acaf71b6382da379804cda4996aed0f7b8be3049a0c42ec7faa3c8a3fd0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-archive-selftest-closed-scope/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364449 :STORED-BYTES 116972 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364449 :UNCOMPRESSED-SHA256
    "4471ecc6e5a4afc5835fa86b40285cceab6f608b545acc36371fb4e73ef57536"
    :COMPRESSED-BYTES 116656 :COMPRESSED-SHA256
    "4f8c58a34a11e0617fa4472feffb736a5b52c2b813a23c34d1b9de10754a30e3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-archive-selftest-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364449 :STORED-BYTES 116972 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364449 :UNCOMPRESSED-SHA256
    "d14d2ee2ac74ed2b63ea6e766f0d89ea0c69a70ebe426558caf41b4252ce0ac8"
    :COMPRESSED-BYTES 116656 :COMPRESSED-SHA256
    "dc2e7ee3184147e1cbdcddbb698a862d42cf37d4b89b7b11cac5dd559bfe92fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-archive-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 367841 :STORED-BYTES 117914 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 367841 :UNCOMPRESSED-SHA256
    "05211a97175bc752cfddcba90edd7b543f04d11ce16898f03e53370b435ff4e1"
    :COMPRESSED-BYTES 117598 :COMPRESSED-SHA256
    "7c4b4667701a66fca6d1d55eeb42a267fccd936483ebe879c83ed1c1614d9926"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364509 :STORED-BYTES 117022 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364509 :UNCOMPRESSED-SHA256
    "cffcbaa6b3c19dd8c04236e0d8e8c7f406172b07889432d6c3811bc43495fa53"
    :COMPRESSED-BYTES 116706 :COMPRESSED-SHA256
    "b171af3d64218796050e5a621494ea51a4a5b1e1ca166169f404e0b680b40e5b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-cleanup-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364452 :STORED-BYTES 116979 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364452 :UNCOMPRESSED-SHA256
    "eac82f16eed57c4b00e5932dc7f67151951c13f82448c719c9988f52893d0f01"
    :COMPRESSED-BYTES 116663 :COMPRESSED-SHA256
    "0832296975d6a3f9cd7933d9e96cc97d80db4710d0d1cecd3d6d0ebf075f24f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-close-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364441 :STORED-BYTES 116958 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364441 :UNCOMPRESSED-SHA256
    "526d90bbe0c502d89c065dc97b1c26a39fc08e57276b4ae19afd760c696271c6"
    :COMPRESSED-BYTES 116642 :COMPRESSED-SHA256
    "16e636d20b14f6fe28c6357003d759e06172342ae381f461a1a1933b4713a339"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-docs/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370540 :STORED-BYTES 118366 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370540 :UNCOMPRESSED-SHA256
    "d16d99678ec32824e219b8c4efc12c5e56cf469ff1392222c8651691de769a08"
    :COMPRESSED-BYTES 118050 :COMPRESSED-SHA256
    "9b27acc7d642218683e01ff2c612837e933d858622718574bba8081b2b2f2cf8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 379823 :STORED-BYTES 121281 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 379823 :UNCOMPRESSED-SHA256
    "a8d975c0c25e2f2f30d2a1d71c9dd630a604663f7ac44834139175472685ba90"
    :COMPRESSED-BYTES 120965 :COMPRESSED-SHA256
    "d76a77f5a635006f84942a4d0de562774e56f42608283a4fde83c58975a77a37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-ledger-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364466 :STORED-BYTES 116975 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364466 :UNCOMPRESSED-SHA256
    "8cf4d64a0b52de91ce2415a14f97c1b9471a3347b3e99179224c866ebc172ac6"
    :COMPRESSED-BYTES 116659 :COMPRESSED-SHA256
    "357869539b5936c90cd360d1162dd0cd8c51f8f5f7eb119ed9486537bf0b230b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-qualification-sbcl10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 634897 :STORED-BYTES 136662 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 634897 :UNCOMPRESSED-SHA256
    "37db6d35d27cc67dc9781f0c47a3b5a6816801acb6f1a6d66bead509534421a6"
    :COMPRESSED-BYTES 136346 :COMPRESSED-SHA256
    "4b15727f63bd5ea4993052a7ddd318d9a6af0ffbacae74120bd11bb0e521f8cb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-qualification-sbcl9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 634568 :STORED-BYTES 136733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 634568 :UNCOMPRESSED-SHA256
    "6412732f098752dd0ddae69dd66d9f1ec273e458c645e8904e3320883050b2fa"
    :COMPRESSED-BYTES 136417 :COMPRESSED-SHA256
    "c1d161b8a2ffe3942aa773877ff3e8d94da44d9c9ac48cd57082d6d8f2aa4345"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-static/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364682 :STORED-BYTES 117023 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364682 :UNCOMPRESSED-SHA256
    "f13962af489cb6999ae0bbcb39ea3e5188c562fc8c778003aba286f10430cf3e"
    :COMPRESSED-BYTES 116707 :COMPRESSED-SHA256
    "27d23fd32b203d87e20261356e619a3bdeab0770d8c218f5d98b5183f070ca13"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-verifier-selftest-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364427 :STORED-BYTES 116950 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364427 :UNCOMPRESSED-SHA256
    "eb012ad9038b7f0027f90a0776cd55cc3c4a949ca2ca685b4dbb60a3fe51c70b"
    :COMPRESSED-BYTES 116634 :COMPRESSED-SHA256
    "9f4238457ca7864d307a5dd54002ce1b418563f6e11a48d57edd295530d1751c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-verifier-selftest/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364427 :STORED-BYTES 116953 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364427 :UNCOMPRESSED-SHA256
    "3aa00587ae27fdb8362f32e90d693979792dff08dbf37fc26bc14f9812af8485"
    :COMPRESSED-BYTES 116637 :COMPRESSED-SHA256
    "f32d65692cb6e48a9dc025833be645435afdf4b57405567d037c4ec668348a6b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/commands/version-into-verify/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364439 :STORED-BYTES 116965 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364439 :UNCOMPRESSED-SHA256
    "0377d1ef6c1b7371806abd8c1a639b98939f09390698c5180401549845986121"
    :COMPRESSED-BYTES 116649 :COMPRESSED-SHA256
    "77b0172444e20cb804f37ff50ba28f7e2fb5cd7c3ffcda786a7ff333f42aeac2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/focused-01/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20481 :STORED-BYTES 4259 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 20481 :UNCOMPRESSED-SHA256
    "55e93e74f7abf40f477f4128c5e6e017dbfcf871864545581310b91b0745710c"
    :COMPRESSED-BYTES 3945 :COMPRESSED-SHA256
    "e6fe1b6a495d096bb55dcb9e671efc6fa586b3be6a743d15fe5bffb3b3324c7f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/focused-01/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 49504 :STORED-BYTES 5229 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 49504 :UNCOMPRESSED-SHA256
    "dcd70ecd3b04e72f5c9fd7f63a254b6c410824358e65b8a1992465778c22f4b9"
    :COMPRESSED-BYTES 4916 :COMPRESSED-SHA256
    "4959e67f87f6758f7bdb350d5c1ae7d04a0344514a62bdb8b3df0e009f9dc746"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/focused-01/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20400 :STORED-BYTES 4249 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 20400 :UNCOMPRESSED-SHA256
    "37b8d668e7c2cc92a25183eb7c44de914a5a11dc10dcf76bb66a4a6837dae572"
    :COMPRESSED-BYTES 3933 :COMPRESSED-SHA256
    "d6eab0ba9dcc2bf3cd87b3bafad6640663ef89297738378904c858caffafd0ac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl10/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 43624 :STORED-BYTES 7798 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 43624 :UNCOMPRESSED-SHA256
    "12be256e91e8426b61c5005fa6b256bbc02c525d98e93a4fd5dd18f693c06661"
    :COMPRESSED-BYTES 7484 :COMPRESSED-SHA256
    "9ead4868fc03a341545a0586305cce53f6c52e798aeed7b24707d9915668cfc5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl10/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 106657 :STORED-BYTES 10051 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 106657 :UNCOMPRESSED-SHA256
    "ddc457a8f5287d752d886919b30bbc9c93124611ab0a92879e1ce5b8fa5f6cc1"
    :COMPRESSED-BYTES 9737 :COMPRESSED-SHA256
    "9d34ef88e8400fbf1a7ebcf299d8da41e720c663b141428bdd4c5170e14d4b33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl10/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 43373 :STORED-BYTES 7761 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 43373 :UNCOMPRESSED-SHA256
    "d2011985a8af8b4735298e600f0868dad44de3ada7850e9ece13940924b548bd"
    :COMPRESSED-BYTES 7445 :COMPRESSED-SHA256
    "64e76837095bd45717104e3878c296d71c3001a23fbefcc2696b34117aee9643"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl9/planned.lisp"
   :STATUS :OK :ORIGINAL-BYTES 43623 :STORED-BYTES 7797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "planned.lisp.gz" :UNCOMPRESSED-BYTES 43623 :UNCOMPRESSED-SHA256
    "3201ecd557356a24b5443ac07402317389fddb0356b54db3a790fb6efbfefc02"
    :COMPRESSED-BYTES 7483 :COMPRESSED-SHA256
    "3b0dbcd69194861d2667a55eebac81f3c5cdcf2f5daa3bc9f6fe47d9898fb96f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl9/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 106657 :STORED-BYTES 10051 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 106657 :UNCOMPRESSED-SHA256
    "ddc457a8f5287d752d886919b30bbc9c93124611ab0a92879e1ce5b8fa5f6cc1"
    :COMPRESSED-BYTES 9737 :COMPRESSED-SHA256
    "9d34ef88e8400fbf1a7ebcf299d8da41e720c663b141428bdd4c5170e14d4b33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/qualification-sbcl9/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 43372 :STORED-BYTES 7760 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 43372 :UNCOMPRESSED-SHA256
    "8dd27312d6489b3e521b332fa8ba9b5caa5de6de3374ac836476881a86cce3ce"
    :COMPRESSED-BYTES 7444 :COMPRESSED-SHA256
    "b20077d98146eb1b2ddeb53a609f5dae91d50bc40117676518e71c72310c75c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8340 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "6f6d3484d3faf4c7c25af466e32730070268f59b28b0032c7a6ab93514d6849b"
    :COMPRESSED-BYTES 8027 :COMPRESSED-SHA256
    "94778b877ce0b90347b4a29a171e10cabcfb22f5bc9563813ca720e9707ee879"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22977 :STORED-BYTES 4613 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22977 :UNCOMPRESSED-SHA256
    "2db6badabc9fbb159f237c25fc21d7cc518f119674786ce8037fd21661dacdf7"
    :COMPRESSED-BYTES 4300 :COMPRESSED-SHA256
    "c2fa7fa2855a4ee72d1ee12383abf6ddae5ff30dc6954024bb1122b440b9a27e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331092 :STORED-BYTES 45770 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331092 :UNCOMPRESSED-SHA256
    "6d56d416ebe7d4018d6def3d0b9ba2ecdc8c9d398c3e0b1490d34fb4dd9694c3"
    :COMPRESSED-BYTES 45455 :COMPRESSED-SHA256
    "1721c66afda3136c66272ed6479d2da398fb63d92a81fb07397585502811c177"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24154 :STORED-BYTES 4316 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24154 :UNCOMPRESSED-SHA256
    "c4ade40ceaf1b9cae1ad13e746e5bdb61747d56d959cf5b09513666ba56e1300"
    :COMPRESSED-BYTES 4003 :COMPRESSED-SHA256
    "bd98938bfc8f88f0e440930648ae915f1e5ff4f69ef8d459e737e1cd17216204"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10163 :STORED-BYTES 2277 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10163 :UNCOMPRESSED-SHA256
    "ea1669e1e2eb227add668ac7f540992aa186ddda7079bfbe7394698fe20f2759"
    :COMPRESSED-BYTES 1964 :COMPRESSED-SHA256
    "c9639de7f1a8df8aa1efaa9c750ea466c935b48725da377e715eaf2675dfae89"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "6e39abe73067f607db1bd3c7492afc1c800c31810d41fa5128ac0b08609f0096"
    :COMPRESSED-BYTES 1611 :COMPRESSED-SHA256
    "17335caa2472dbe91bcbc0682b81cb0cf675837ca3a85dc1b0a4e413f88303d6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/4002627396-check-27850-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3190 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "5ef260e750968bace68b0a8fe2205fd8c40988e290474ed2d018b05a5a266988"
    :COMPRESSED-BYTES 2877 :COMPRESSED-SHA256
    "05884cf2159cef1f3c05cdcfce119c8e060d4949bb49a158688de1fbe2b6ece9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/ci/selftest-1793638649-28890/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-02-versioned-read-into/support/command-archive-collector-self-test-Cng1ak/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "f84e170f0e37d608880c681d1f7a6c9e570056d239e82f72c375bac83fe6fa82"
    :COMPRESSED-BYTES 3213 :COMPRESSED-SHA256
    "4cd5796db40c74fd90cb3cfee455f1b00d1d9becc75d3c5b38cde047894bc8bf")))
 :DRIVER-SHA256
 "57f7d2aebfd24e7dd592ca34a8ba30c88cfb863051b95e65fdb0f942f7ce7184" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :LOSSLESS-ORIGINAL-BYTE-HASHES
  :ALL-COPIED-COMMAND-AND-CHILD-LOGS))
