(:SCHEMA-VERSION 1 :ID "SPK-11" :COMMAND
 (#A((48) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl")
  "--dynamic-space-size" "4096" "--noinform" "--no-userinit" "--no-sysinit"
  "--script" "spikes/SPK-11-unix-socket/run.lisp"
  #A((7) BASE-CHAR . "--check"))
 :EXIT-CODE 0 :STARTED-AT-UNIVERSAL-TIME 4002627433 :FINISHED-AT-UNIVERSAL-TIME
 4002627443 :WALL-SECONDS 9.852226d0 :STATUS :OK :SOURCE-BLOBS-BEFORE
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-BLOBS-AFTER
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-CONSISTENCY :STABLE :RESULT
 (:STATUS :OK :SPIKE :SPK-11 :FRAMING
  (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
   :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
  :SESSION
  (:STATUS :OK :CASES
   ((:CASE #A((18) BASE-CHAR . "CHECK-SESSION-WIRE") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-MAPS") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-NEGOTIATION") :STATUS :OK)
    (:CASE #A((20) BASE-CHAR . "CHECK-SESSION-CREDIT") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-CORRELATION") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-TIME") :STATUS :OK)
    (:CASE #A((23) BASE-CHAR . "CHECK-SESSION-ISOLATION") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-SENSITIVITY") :STATUS :OK))
   :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
   (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
    :NO-PRODUCTION-ALLOCATION-CLAIM))
  :NATIVE-IO
  (:STATUS :OK :SCRIPTS
   (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS
    T :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
   :EMPTY-AND-CLOSED
   (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
   :SATURATION
   (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
   :ALLOCATION
   (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420889952 :SUCCESS-AFTER
    420889952 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420889952 :EMPTY-AFTER
    420889952 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
    :POSITIVE-BEFORE 420889952 :POSITIVE-MINIMUM-DETECTED 1048576
    :POSITIVE-AFTER 422943088 :POSITIVE-BYTES-CONSED 2053136
    :NATIVE-ALLOCATOR-TRACED NIL)
   :DISASSEMBLY
   ((:FUNCTION #A((16) BASE-CHAR . "NATIVE-RECV-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x8012607D78                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; D78:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; D7C:       AA0F00F9         STR R0, [CFP, #24]
; D80:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; D84:       693F0091         ADD TMP, CSP, #15
; D88:       29ED7C92         AND TMP, TMP, #18446744073709551600
; D8C:       3B410091         ADD CSP, TMP, #16
; D90:       2C1D0091         ADD R2, TMP, #7
; D94:       AB1740F9         LDR R1, [CFP, #40]
; D98:       2B3500A9         STP R1, R3, [TMP]
; D9C:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; DA0:       20400091         ADD NL0, NL1, #16
; DA4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; DA8:       003A80D2         MOVZ NL0, #464
; DAC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; DB0:       2A0000A9         STP R0, NL0, [NL1]
; DB4:       AC6A20F8         STR R2, [THREAD, NL0]
; DB8:       AA1740F9         LDR R0, [CFP, #40]
; DBC:       41050091         ADD NL1, R0, #1
; DC0:       A01B40F9         LDR NL0, [CFP, #48]
; DC4:       00FC4193         ASR NL0, NL0, #1
; DC8:       2100008B         ADD NL1, NL1, NL0
; DCC:       AA1340F9         LDR R0, [CFP, #32]
; DD0:       AD1F40F9         LDR R3, [CFP, #56]
; DD4:       041080D2         MOVZ NL4, #128
; DD8:       40FD4193         ASR NL0, R0, #1
; DDC:       A2FD4193         ASR NL2, R3, #1
; DE0:       E30304AA         MOV NL3, NL4
; DE4:       74430091         ADD R10, CSP, #16
; DE8:       D6010010         ADR LEXENV, L0
; DEC:       7D5B00A9         STP CFP, LEXENV, [CSP]
; DF0:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; DF4:       B3F7FF58         LDR R9, #x8012607CE8            ; recv
; DF8:       60023FD6         BLR R9
; DFC:       110080D2         MOVZ R7, #0
; E00:       100080D2         MOVZ R6, #0
; E04:       0F0080D2         MOVZ R5, #0
; E08:       0E0080D2         MOVZ R4, #0
; E0C:       0D0080D2         MOVZ R3, #0
; E10:       0C0080D2         MOVZ R2, #0
; E14:       0B0080D2         MOVZ R1, #0
; E18:       0A0080D2         MOVZ R0, #0
; E1C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; E20: L0:   0C0000AB         ADDS R2, NL0, NL0
; E24:       E7010054         BVC L2
; E28:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; E2C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; E30:       2C410091         ADD R2, TMP, #16
; E34:       9F011EEB         CMP R2, LR
; E38:       C8040054         BHI L5
; E3C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; E40: L1:   2C3D0091         ADD R2, TMP, #15
; E44:       3E2280D2         MOVZ LR, #273
; E48:       3E0100A9         STP LR, NL0, [TMP]
; E4C:       BF3A03D5         DMB ISHST
; E50:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; E54:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; E58:       5E0000B4         CBZ LR, L2
; E5C:       200120D4         BRK #9                          ; Pending interrupt trap
; E60: L2:   9F0900B1         CMN R2, #2
; E64:       01030054         BNE L4
; E68:       AC2300F9         STR R2, [CFP, #64]
; E6C:       7D0300F9         STR CFP, [CSP]
; E70:       96F2FF58         LDR LEXENV, #x8012607CC0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; E74:       170080D2         MOVZ NARGS, #0
; E78:       DE9240F8         LDR LR, [LEXENV, #9]
; E7C:       FD031BAA         MOV CFP, CSP
; E80:       C0033FD6         BLR LR
; E84:       AC2340F9         LDR R2, [CFP, #64]
; E88:       EB030AAA         MOV R1, R0
; E8C: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; E90:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; E94:       AA6A20F8         STR R0, [THREAD, NL0]
; E98:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; E9C:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; EA0:       EA030CAA         MOV R0, R2
; EA4:       F9031DAA         MOV OCFP, CFP
; EA8:       3B430091         ADD CSP, OCFP, #16
; EAC:       970080D2         MOVZ NARGS, #4
; EB0:       EC031AAA         MOV R2, NULL
; EB4:       ED031AAA         MOV R3, NULL
; EB8:       FF031FEB         CMP ZR, ZR
; EBC:       BD7B40A9         LDP CFP, LR, [CFP]
; EC0:       C0035FD6         RET
; EC4: L4:   0B0080D2         MOVZ R1, #0
; EC8:       F1FFFF17         B L3
; ECC:       E00120D4         BRK #15                         ; Invalid argument count trap
; ED0: L5:   090280D2         MOVZ TMP, #16
; ED4:       ECF0FF58         LDR R2, #x8012607CF0            ; SB-VM::ALLOC-TRAMP
; ED8:       80013FD6         BLR R2
; EDC:       D9FFFF17         B L1
")
    (:FUNCTION #A((16) BASE-CHAR . "NATIVE-SEND-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x8012602EF8                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 2EF8:       AA0A40F9         LDR R0, [THREAD, #16]          ; binding-stack-pointer
; 2EFC:       AA0F00F9         STR R0, [CFP, #24]
; 2F00:       ADEA40F9         LDR R3, [THREAD, #464]         ; tls: SB-VM::*PINNED-OBJECTS*
; 2F04:       693F0091         ADD TMP, CSP, #15
; 2F08:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 2F0C:       3B410091         ADD CSP, TMP, #16
; 2F10:       2C1D0091         ADD R2, TMP, #7
; 2F14:       AB1740F9         LDR R1, [CFP, #40]
; 2F18:       2B3500A9         STP R1, R3, [TMP]
; 2F1C:       A10A40F9         LDR NL1, [THREAD, #16]         ; binding-stack-pointer
; 2F20:       20400091         ADD NL0, NL1, #16
; 2F24:       A00A00F9         STR NL0, [THREAD, #16]         ; binding-stack-pointer
; 2F28:       003A80D2         MOVZ NL0, #464
; 2F2C:       AAEA40F9         LDR R0, [THREAD, #464]         ; tls: SB-VM::*PINNED-OBJECTS*
; 2F30:       2A0000A9         STP R0, NL0, [NL1]
; 2F34:       AC6A20F8         STR R2, [THREAD, NL0]
; 2F38:       AA1740F9         LDR R0, [CFP, #40]
; 2F3C:       41050091         ADD NL1, R0, #1
; 2F40:       A01B40F9         LDR NL0, [CFP, #48]
; 2F44:       00FC4193         ASR NL0, NL0, #1
; 2F48:       2100008B         ADD NL1, NL1, NL0
; 2F4C:       AA1340F9         LDR R0, [CFP, #32]
; 2F50:       AD1F40F9         LDR R3, [CFP, #56]
; 2F54:       E4036DB2         MOV NL4, #524288
; 2F58:       041080F2         MOVK NL4, #128
; 2F5C:       40FD4193         ASR NL0, R0, #1
; 2F60:       A2FD4193         ASR NL2, R3, #1
; 2F64:       E30304AA         MOV NL3, NL4
; 2F68:       74430091         ADD R10, CSP, #16
; 2F6C:       D6010010         ADR LEXENV, L0
; 2F70:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 2F74:       BB5210A9         STP CSP, R10, [THREAD, #256]   ; control-frame-pointer, control-stack-pointer
; 2F78:       93F7FF58         LDR R9, #x8012602E68           ; send
; 2F7C:       60023FD6         BLR R9
; 2F80:       110080D2         MOVZ R7, #0
; 2F84:       100080D2         MOVZ R6, #0
; 2F88:       0F0080D2         MOVZ R5, #0
; 2F8C:       0E0080D2         MOVZ R4, #0
; 2F90:       0D0080D2         MOVZ R3, #0
; 2F94:       0C0080D2         MOVZ R2, #0
; 2F98:       0B0080D2         MOVZ R1, #0
; 2F9C:       0A0080D2         MOVZ R0, #0
; 2FA0:       BF8600F9         STR ZR, [THREAD, #264]         ; control-stack-pointer
; 2FA4: L0:   0C0000AB         ADDS R2, NL0, NL0
; 2FA8:       E7010054         BVC L2
; 2FAC:       BA2A00B9         STR WNULL, [THREAD, #40]       ; pseudo-atomic-bits
; 2FB0:       A97A47A9         LDP TMP, LR, [THREAD, #112]    ; mixed-tlab.{free-pointer, end-addr}
; 2FB4:       2C410091         ADD R2, TMP, #16
; 2FB8:       9F011EEB         CMP R2, LR
; 2FBC:       C8040054         BHI L5
; 2FC0:       AC3A00F9         STR R2, [THREAD, #112]         ; mixed-tlab
; 2FC4: L1:   2C3D0091         ADD R2, TMP, #15
; 2FC8:       3E2280D2         MOVZ LR, #273
; 2FCC:       3E0100A9         STP LR, NL0, [TMP]
; 2FD0:       BF3A03D5         DMB ISHST
; 2FD4:       BF2A00B9         STR WZR, [THREAD, #40]         ; pseudo-atomic-bits
; 2FD8:       BE2E40B9         LDR WLR, [THREAD, #44]         ; pseudo-atomic-bits
; 2FDC:       5E0000B4         CBZ LR, L2
; 2FE0:       200120D4         BRK #9                         ; Pending interrupt trap
; 2FE4: L2:   9F0900B1         CMN R2, #2
; 2FE8:       01030054         BNE L4
; 2FEC:       AC2300F9         STR R2, [CFP, #64]
; 2FF0:       7D0300F9         STR CFP, [CSP]
; 2FF4:       76F2FF58         LDR LEXENV, #x8012602E40       ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 2FF8:       170080D2         MOVZ NARGS, #0
; 2FFC:       DE9240F8         LDR LR, [LEXENV, #9]
; 3000:       FD031BAA         MOV CFP, CSP
; 3004:       C0033FD6         BLR LR
; 3008:       AC2340F9         LDR R2, [CFP, #64]
; 300C:       EB030AAA         MOV R1, R0
; 3010: L3:   A10A40F9         LDR NL1, [THREAD, #16]         ; binding-stack-pointer
; 3014:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 3018:       AA6A20F8         STR R0, [THREAD, NL0]
; 301C:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 3020:       A10A00F9         STR NL1, [THREAD, #16]         ; binding-stack-pointer
; 3024:       EA030CAA         MOV R0, R2
; 3028:       F9031DAA         MOV OCFP, CFP
; 302C:       3B430091         ADD CSP, OCFP, #16
; 3030:       970080D2         MOVZ NARGS, #4
; 3034:       EC031AAA         MOV R2, NULL
; 3038:       ED031AAA         MOV R3, NULL
; 303C:       FF031FEB         CMP ZR, ZR
; 3040:       BD7B40A9         LDP CFP, LR, [CFP]
; 3044:       C0035FD6         RET
; 3048: L4:   0B0080D2         MOVZ R1, #0
; 304C:       F1FFFF17         B L3
; 3050:       E00120D4         BRK #15                        ; Invalid argument count trap
; 3054: L5:   090280D2         MOVZ TMP, #16
; 3058:       CCF0FF58         LDR R2, #x8012602E70           ; SB-VM::ALLOC-TRAMP
; 305C:       80013FD6         BLR R2
; 3060:       D9FFFF17         B L1
")
    (:FUNCTION #A((7) BASE-CHAR . "IO-STEP") :CODE
     "; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x8012606CE0                       ; ARCDOCDB.SPK11::IO-STEP
; CE0:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; CE4:       AA0F00F9         STR R0, [CFP, #24]
; CE8:       EED146F8         LDR R4, [R5, #109]
; CEC:       EAF9FF58         LDR R0, #x8012606C28            ; :ACTIVE
; CF0:       DF010AEB         CMP R4, R0
; CF4:       C0000054         BEQ L1
; CF8:       EAD146F8         LDR R0, [R5, #109]
; CFC: L0:   FB031DAA         MOV CSP, CFP
; D00:       5F0300F1         CMP NULL, #0
; D04:       BD7B40A9         LDP CFP, LR, [CFP]
; D08:       C0035FD6         RET
; D0C: L1:   E15144F8         LDR NL1, [R5, #69]
; D10:       A01340F9         LDR NL0, [CFP, #32]
; D14:       1F0001EB         CMP NL0, NL1
; D18:       4AE30091         ADD R0, NULL, #56               ; T
; D1C:       4AB38A9A         CSEL R0, NULL, R0, LT
; D20:       AF1700F9         STR R5, [CFP, #40]
; D24:       7D0300F9         STR CFP, [CSP]
; D28:       4BF8FF58         LDR R1, #x8012606C30            ; :IO-CLOCK
; D2C:       B6F6FF58         LDR LEXENV, #x8012606C00        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; D30:       970080D2         MOVZ NARGS, #4
; D34:       DE9240F8         LDR LR, [LEXENV, #9]
; D38:       FD031BAA         MOV CFP, CSP
; D3C:       C0033FD6         BLR LR
; D40:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; D44:       AF1740F9         LDR R5, [CFP, #40]
; D48:       AB1340F9         LDR R1, [CFP, #32]
; D4C:       EB5104F8         STR R1, [R5, #69]
; D50:       E1D143F8         LDR NL1, [R5, #61]
; D54:       A01340F9         LDR NL0, [CFP, #32]
; D58:       1F0001EB         CMP NL0, NL1
; D5C:       8A090054         BGE L7
; D60:       E25143F8         LDR NL2, [R5, #53]
; D64:       E35142F8         LDR NL3, [R5, #37]
; D68:       E15145F8         LDR NL1, [R5, #85]
; D6C:       610001CB         SUB NL1, NL3, NL1
; D70:       3F0002EB         CMP NL1, NL2
; D74:       21B0829A         CSEL NL1, NL1, NL2, LT
; D78:       E20301AA         MOV NL2, NL1
; D7C:       EED144F8         LDR R4, [R5, #77]
; D80:       AE061037         TBNZ WR4, #2, L5
; D84:       F6030EAA         MOV LEXENV, R4
; D88: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; D8C:       E1D145F8         LDR NL1, [R5, #93]
; D90:       210800B1         ADDS NL1, NL1, #2
; D94:       A6080054         BVS L8
; D98:       E1D105F8         STR NL1, [R5, #93]
; D9C:       EAD140F8         LDR R0, [R5, #13]
; DA0:       EB5141F8         LDR R1, [R5, #21]
; DA4:       EC5145F8         LDR R2, [R5, #85]
; DA8:       7D0300F9         STR CFP, [CSP]
; DAC:       ED0302AA         MOV R3, NL2
; DB0:       170180D2         MOVZ NARGS, #8
; DB4:       DED25FF8         LDR LR, [LEXENV, #-3]
; DB8:       FD031BAA         MOV CFP, CSP
; DBC:       C0033FD6         BLR LR
; DC0:       4B138B9A         CSEL R1, NULL, R1, NE
; DC4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; DC8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; DCC:       F0030AAA         MOV R6, R0
; DD0:       EE030BAA         MOV R4, R1
; DD4:       F0000036         TBZ WR6, #0, L3
; DD8:       010E4092         AND NL1, R6, #15
; DDC:       3F3C00F1         CMP NL1, #15
; DE0:       C1010054         BNE L4
; DE4:       01125FF8         LDR NL1, [R6, #-15]
; DE8:       3F4404F1         CMP NL1, #273
; DEC:       61010054         BNE L4
; DF0: L3:   4E010037         TBNZ WR4, #0, L4
; DF4:       EA030FAA         MOV R0, R5
; DF8:       EB0310AA         MOV R1, R6
; DFC:       EC030EAA         MOV R2, R4
; E00:       ED0302AA         MOV R3, NL2
; E04:       36F0FF58         LDR LEXENV, #x8012606C08        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; E08:       170180D2         MOVZ NARGS, #8
; E0C:       DE9240F8         LDR LR, [LEXENV, #9]
; E10:       DE130091         ADD LR, LR, #4
; E14:       C0031FD6         BR LR
; E18: L4:   AF1700F9         STR R5, [CFP, #40]
; E1C:       EAF0FF58         LDR R0, #x8012606C38            ; :FAULTED
; E20:       E97D4BD3         UBFM TMP, R5, #11, #31
; E24:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; E28:       EAD106F8         STR R0, [R5, #109]
; E2C:       7D0300F9         STR CFP, [CSP]
; E30:       8AF0FF58         LDR R0, #x8012606C40            ; 'ARCDOCDB.SPK11::REJECTION
; E34:       ABF0FF58         LDR R1, #x8012606C48            ; :REASON
; E38:       CCF0FF58         LDR R2, #x8012606C50            ; :IO-RESULT
; E3C:       29A680D2         MOVZ TMP, #1329
; E40:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; E44:       D70080D2         MOVZ NARGS, #6
; E48:       FD031BAA         MOV CFP, CSP
; E4C:       C0033FD6         BLR LR
; E50:       AF1740F9         LDR R5, [CFP, #40]
; E54: L5:   EED142F8         LDR R4, [R5, #45]
; E58:       0AF0FF58         LDR R0, #x8012606C58            ; :INPUT
; E5C:       DF010AEB         CMP R4, R0
; E60:       C0000054         BEQ L6
; E64:       6AEDFF58         LDR R0, #x8012606C10            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; E68:       561140F8         LDR LEXENV, [R0, #1]
; E6C:       DF021AEB         CMP LEXENV, NULL
; E70:       E0010054         BEQ L9
; E74:       C5FFFF17         B L2
; E78: L6:   0AEDFF58         LDR R0, #x8012606C18            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; E7C:       561140F8         LDR LEXENV, [R0, #1]
; E80:       DF021AEB         CMP LEXENV, NULL
; E84:       60010054         BEQ L10
; E88:       C0FFFF17         B L2
; E8C: L7:   AAEEFF58         LDR R0, #x8012606C60            ; :EXPIRED
; E90:       E97D4BD3         UBFM TMP, R5, #11, #31
; E94:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; E98:       EAD106F8         STR R0, [R5, #109]
; E9C:       2AEEFF58         LDR R0, #x8012606C60            ; :EXPIRED
; EA0:       97FFFF17         B L0
; EA4:       E00120D4         BRK #15                         ; Invalid argument count trap
; EA8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; EAC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; EB0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
")))
  :PROCESSES
  ((:STATUS :OK :MODE "fragmented" :SERVER-PID 28714 :CLIENT-PID 28716 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "fragmented"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((10) BASE-CHAR . \"fragmented\") :PID 28716)
"
    :STDERR "")
   (:STATUS :OK :MODE "coalesced" :SERVER-PID 28714 :CLIENT-PID 28717 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "coalesced"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"coalesced\") :PID 28717)
"
    :STDERR "")
   (:STATUS :OK :MODE "maximum" :SERVER-PID 28714 :CLIENT-PID 28718 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "maximum"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
    "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"maximum\") :PID 28718)
"
    :STDERR "")
   (:STATUS :OK :MODE "zero" :SERVER-PID 28714 :CLIENT-PID 28719 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "zero"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((4) BASE-CHAR . \"zero\") :PID 28719)
"
    :STDERR "")
   (:STATUS :OK :MODE "oversize" :SERVER-PID 28714 :CLIENT-PID 28720 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "oversize"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((8) BASE-CHAR . \"oversize\") :PID 28720)
"
    :STDERR "")
   (:STATUS :OK :MODE "truncated" :SERVER-PID 28714 :CLIENT-PID 28721 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "truncated"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"truncated\") :PID 28721)
"
    :STDERR "")
   (:STATUS :OK :MODE "session" :SERVER-PID 28714 :CLIENT-PID 28723 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "session"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"session\") :PID 28723)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-invalid-hello" :SERVER-PID 28714 :CLIENT-PID
    28725 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "session-invalid-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((21) BASE-CHAR . \"session-invalid-hello\") :PID 28725)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-pre-hello" :SERVER-PID 28714 :CLIENT-PID 28726
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "session-pre-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((17) BASE-CHAR . \"session-pre-hello\") :PID 28726)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-oversize-hello" :SERVER-PID 28714 :CLIENT-PID
    28727 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "session-oversize-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((22) BASE-CHAR . \"session-oversize-hello\") :PID 28727)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-id-reuse" :SERVER-PID 28714 :CLIENT-PID 28728
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "session-id-reuse"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"session-id-reuse\") :PID 28728)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-server" :SERVER-PID 28714 :CLIENT-PID 28777 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "native-server"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-server\") :PID 28777)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-client" :SERVER-PID 28714 :CLIENT-PID 28797 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "native-client"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-client\") :PID 28797)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-truncated" :SERVER-PID 28714 :CLIENT-PID 28798
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-5FARFm/ipc.sock" "native-truncated"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/"))
    :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"native-truncated\") :PID 28798)
"
    :STDERR ""))
  :NAMESPACE
  (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
   :REPLACEMENT-PRESERVED T)
  :NATIVE-SYMLINK-BIND
  (:BIND-RESULT :BOUND :LINK (16777232 1579505432 41453) :TARGET
   (16777232 1579505433 49645))
  :LIMITS
  (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
   :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
 :STDOUT "(:STATUS :OK :SPIKE :SPK-11 :FRAMING
 (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
  :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
 :SESSION
 (:STATUS :OK :CASES
  ((:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-WIRE\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-MAPS\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-NEGOTIATION\") :STATUS :OK)
   (:CASE #A((20) BASE-CHAR . \"CHECK-SESSION-CREDIT\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-CORRELATION\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-TIME\") :STATUS :OK)
   (:CASE #A((23) BASE-CHAR . \"CHECK-SESSION-ISOLATION\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-SENSITIVITY\") :STATUS :OK))
  :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
  (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
   :NO-PRODUCTION-ALLOCATION-CLAIM))
 :NATIVE-IO
 (:STATUS :OK :SCRIPTS
  (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS T
   :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
  :EMPTY-AND-CLOSED
  (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
  :SATURATION
  (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
  :ALLOCATION
  (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420889952 :SUCCESS-AFTER
   420889952 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420889952 :EMPTY-AFTER
   420889952 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
   :POSITIVE-BEFORE 420889952 :POSITIVE-MINIMUM-DETECTED 1048576
   :POSITIVE-AFTER 422943088 :POSITIVE-BYTES-CONSED 2053136
   :NATIVE-ALLOCATOR-TRACED NIL)
  :DISASSEMBLY
  ((:FUNCTION #A((16) BASE-CHAR . \"NATIVE-RECV-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x8012607D78                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; D78:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; D7C:       AA0F00F9         STR R0, [CFP, #24]
; D80:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; D84:       693F0091         ADD TMP, CSP, #15
; D88:       29ED7C92         AND TMP, TMP, #18446744073709551600
; D8C:       3B410091         ADD CSP, TMP, #16
; D90:       2C1D0091         ADD R2, TMP, #7
; D94:       AB1740F9         LDR R1, [CFP, #40]
; D98:       2B3500A9         STP R1, R3, [TMP]
; D9C:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; DA0:       20400091         ADD NL0, NL1, #16
; DA4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; DA8:       003A80D2         MOVZ NL0, #464
; DAC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; DB0:       2A0000A9         STP R0, NL0, [NL1]
; DB4:       AC6A20F8         STR R2, [THREAD, NL0]
; DB8:       AA1740F9         LDR R0, [CFP, #40]
; DBC:       41050091         ADD NL1, R0, #1
; DC0:       A01B40F9         LDR NL0, [CFP, #48]
; DC4:       00FC4193         ASR NL0, NL0, #1
; DC8:       2100008B         ADD NL1, NL1, NL0
; DCC:       AA1340F9         LDR R0, [CFP, #32]
; DD0:       AD1F40F9         LDR R3, [CFP, #56]
; DD4:       041080D2         MOVZ NL4, #128
; DD8:       40FD4193         ASR NL0, R0, #1
; DDC:       A2FD4193         ASR NL2, R3, #1
; DE0:       E30304AA         MOV NL3, NL4
; DE4:       74430091         ADD R10, CSP, #16
; DE8:       D6010010         ADR LEXENV, L0
; DEC:       7D5B00A9         STP CFP, LEXENV, [CSP]
; DF0:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; DF4:       B3F7FF58         LDR R9, #x8012607CE8            ; recv
; DF8:       60023FD6         BLR R9
; DFC:       110080D2         MOVZ R7, #0
; E00:       100080D2         MOVZ R6, #0
; E04:       0F0080D2         MOVZ R5, #0
; E08:       0E0080D2         MOVZ R4, #0
; E0C:       0D0080D2         MOVZ R3, #0
; E10:       0C0080D2         MOVZ R2, #0
; E14:       0B0080D2         MOVZ R1, #0
; E18:       0A0080D2         MOVZ R0, #0
; E1C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; E20: L0:   0C0000AB         ADDS R2, NL0, NL0
; E24:       E7010054         BVC L2
; E28:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; E2C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; E30:       2C410091         ADD R2, TMP, #16
; E34:       9F011EEB         CMP R2, LR
; E38:       C8040054         BHI L5
; E3C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; E40: L1:   2C3D0091         ADD R2, TMP, #15
; E44:       3E2280D2         MOVZ LR, #273
; E48:       3E0100A9         STP LR, NL0, [TMP]
; E4C:       BF3A03D5         DMB ISHST
; E50:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; E54:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; E58:       5E0000B4         CBZ LR, L2
; E5C:       200120D4         BRK #9                          ; Pending interrupt trap
; E60: L2:   9F0900B1         CMN R2, #2
; E64:       01030054         BNE L4
; E68:       AC2300F9         STR R2, [CFP, #64]
; E6C:       7D0300F9         STR CFP, [CSP]
; E70:       96F2FF58         LDR LEXENV, #x8012607CC0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; E74:       170080D2         MOVZ NARGS, #0
; E78:       DE9240F8         LDR LR, [LEXENV, #9]
; E7C:       FD031BAA         MOV CFP, CSP
; E80:       C0033FD6         BLR LR
; E84:       AC2340F9         LDR R2, [CFP, #64]
; E88:       EB030AAA         MOV R1, R0
; E8C: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; E90:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; E94:       AA6A20F8         STR R0, [THREAD, NL0]
; E98:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; E9C:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; EA0:       EA030CAA         MOV R0, R2
; EA4:       F9031DAA         MOV OCFP, CFP
; EA8:       3B430091         ADD CSP, OCFP, #16
; EAC:       970080D2         MOVZ NARGS, #4
; EB0:       EC031AAA         MOV R2, NULL
; EB4:       ED031AAA         MOV R3, NULL
; EB8:       FF031FEB         CMP ZR, ZR
; EBC:       BD7B40A9         LDP CFP, LR, [CFP]
; EC0:       C0035FD6         RET
; EC4: L4:   0B0080D2         MOVZ R1, #0
; EC8:       F1FFFF17         B L3
; ECC:       E00120D4         BRK #15                         ; Invalid argument count trap
; ED0: L5:   090280D2         MOVZ TMP, #16
; ED4:       ECF0FF58         LDR R2, #x8012607CF0            ; SB-VM::ALLOC-TRAMP
; ED8:       80013FD6         BLR R2
; EDC:       D9FFFF17         B L1
\")
   (:FUNCTION #A((16) BASE-CHAR . \"NATIVE-SEND-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x8012602EF8                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 2EF8:       AA0A40F9         LDR R0, [THREAD, #16]          ; binding-stack-pointer
; 2EFC:       AA0F00F9         STR R0, [CFP, #24]
; 2F00:       ADEA40F9         LDR R3, [THREAD, #464]         ; tls: SB-VM::*PINNED-OBJECTS*
; 2F04:       693F0091         ADD TMP, CSP, #15
; 2F08:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 2F0C:       3B410091         ADD CSP, TMP, #16
; 2F10:       2C1D0091         ADD R2, TMP, #7
; 2F14:       AB1740F9         LDR R1, [CFP, #40]
; 2F18:       2B3500A9         STP R1, R3, [TMP]
; 2F1C:       A10A40F9         LDR NL1, [THREAD, #16]         ; binding-stack-pointer
; 2F20:       20400091         ADD NL0, NL1, #16
; 2F24:       A00A00F9         STR NL0, [THREAD, #16]         ; binding-stack-pointer
; 2F28:       003A80D2         MOVZ NL0, #464
; 2F2C:       AAEA40F9         LDR R0, [THREAD, #464]         ; tls: SB-VM::*PINNED-OBJECTS*
; 2F30:       2A0000A9         STP R0, NL0, [NL1]
; 2F34:       AC6A20F8         STR R2, [THREAD, NL0]
; 2F38:       AA1740F9         LDR R0, [CFP, #40]
; 2F3C:       41050091         ADD NL1, R0, #1
; 2F40:       A01B40F9         LDR NL0, [CFP, #48]
; 2F44:       00FC4193         ASR NL0, NL0, #1
; 2F48:       2100008B         ADD NL1, NL1, NL0
; 2F4C:       AA1340F9         LDR R0, [CFP, #32]
; 2F50:       AD1F40F9         LDR R3, [CFP, #56]
; 2F54:       E4036DB2         MOV NL4, #524288
; 2F58:       041080F2         MOVK NL4, #128
; 2F5C:       40FD4193         ASR NL0, R0, #1
; 2F60:       A2FD4193         ASR NL2, R3, #1
; 2F64:       E30304AA         MOV NL3, NL4
; 2F68:       74430091         ADD R10, CSP, #16
; 2F6C:       D6010010         ADR LEXENV, L0
; 2F70:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 2F74:       BB5210A9         STP CSP, R10, [THREAD, #256]   ; control-frame-pointer, control-stack-pointer
; 2F78:       93F7FF58         LDR R9, #x8012602E68           ; send
; 2F7C:       60023FD6         BLR R9
; 2F80:       110080D2         MOVZ R7, #0
; 2F84:       100080D2         MOVZ R6, #0
; 2F88:       0F0080D2         MOVZ R5, #0
; 2F8C:       0E0080D2         MOVZ R4, #0
; 2F90:       0D0080D2         MOVZ R3, #0
; 2F94:       0C0080D2         MOVZ R2, #0
; 2F98:       0B0080D2         MOVZ R1, #0
; 2F9C:       0A0080D2         MOVZ R0, #0
; 2FA0:       BF8600F9         STR ZR, [THREAD, #264]         ; control-stack-pointer
; 2FA4: L0:   0C0000AB         ADDS R2, NL0, NL0
; 2FA8:       E7010054         BVC L2
; 2FAC:       BA2A00B9         STR WNULL, [THREAD, #40]       ; pseudo-atomic-bits
; 2FB0:       A97A47A9         LDP TMP, LR, [THREAD, #112]    ; mixed-tlab.{free-pointer, end-addr}
; 2FB4:       2C410091         ADD R2, TMP, #16
; 2FB8:       9F011EEB         CMP R2, LR
; 2FBC:       C8040054         BHI L5
; 2FC0:       AC3A00F9         STR R2, [THREAD, #112]         ; mixed-tlab
; 2FC4: L1:   2C3D0091         ADD R2, TMP, #15
; 2FC8:       3E2280D2         MOVZ LR, #273
; 2FCC:       3E0100A9         STP LR, NL0, [TMP]
; 2FD0:       BF3A03D5         DMB ISHST
; 2FD4:       BF2A00B9         STR WZR, [THREAD, #40]         ; pseudo-atomic-bits
; 2FD8:       BE2E40B9         LDR WLR, [THREAD, #44]         ; pseudo-atomic-bits
; 2FDC:       5E0000B4         CBZ LR, L2
; 2FE0:       200120D4         BRK #9                         ; Pending interrupt trap
; 2FE4: L2:   9F0900B1         CMN R2, #2
; 2FE8:       01030054         BNE L4
; 2FEC:       AC2300F9         STR R2, [CFP, #64]
; 2FF0:       7D0300F9         STR CFP, [CSP]
; 2FF4:       76F2FF58         LDR LEXENV, #x8012602E40       ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 2FF8:       170080D2         MOVZ NARGS, #0
; 2FFC:       DE9240F8         LDR LR, [LEXENV, #9]
; 3000:       FD031BAA         MOV CFP, CSP
; 3004:       C0033FD6         BLR LR
; 3008:       AC2340F9         LDR R2, [CFP, #64]
; 300C:       EB030AAA         MOV R1, R0
; 3010: L3:   A10A40F9         LDR NL1, [THREAD, #16]         ; binding-stack-pointer
; 3014:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 3018:       AA6A20F8         STR R0, [THREAD, NL0]
; 301C:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 3020:       A10A00F9         STR NL1, [THREAD, #16]         ; binding-stack-pointer
; 3024:       EA030CAA         MOV R0, R2
; 3028:       F9031DAA         MOV OCFP, CFP
; 302C:       3B430091         ADD CSP, OCFP, #16
; 3030:       970080D2         MOVZ NARGS, #4
; 3034:       EC031AAA         MOV R2, NULL
; 3038:       ED031AAA         MOV R3, NULL
; 303C:       FF031FEB         CMP ZR, ZR
; 3040:       BD7B40A9         LDP CFP, LR, [CFP]
; 3044:       C0035FD6         RET
; 3048: L4:   0B0080D2         MOVZ R1, #0
; 304C:       F1FFFF17         B L3
; 3050:       E00120D4         BRK #15                        ; Invalid argument count trap
; 3054: L5:   090280D2         MOVZ TMP, #16
; 3058:       CCF0FF58         LDR R2, #x8012602E70           ; SB-VM::ALLOC-TRAMP
; 305C:       80013FD6         BLR R2
; 3060:       D9FFFF17         B L1
\")
   (:FUNCTION #A((7) BASE-CHAR . \"IO-STEP\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x8012606CE0                       ; ARCDOCDB.SPK11::IO-STEP
; CE0:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; CE4:       AA0F00F9         STR R0, [CFP, #24]
; CE8:       EED146F8         LDR R4, [R5, #109]
; CEC:       EAF9FF58         LDR R0, #x8012606C28            ; :ACTIVE
; CF0:       DF010AEB         CMP R4, R0
; CF4:       C0000054         BEQ L1
; CF8:       EAD146F8         LDR R0, [R5, #109]
; CFC: L0:   FB031DAA         MOV CSP, CFP
; D00:       5F0300F1         CMP NULL, #0
; D04:       BD7B40A9         LDP CFP, LR, [CFP]
; D08:       C0035FD6         RET
; D0C: L1:   E15144F8         LDR NL1, [R5, #69]
; D10:       A01340F9         LDR NL0, [CFP, #32]
; D14:       1F0001EB         CMP NL0, NL1
; D18:       4AE30091         ADD R0, NULL, #56               ; T
; D1C:       4AB38A9A         CSEL R0, NULL, R0, LT
; D20:       AF1700F9         STR R5, [CFP, #40]
; D24:       7D0300F9         STR CFP, [CSP]
; D28:       4BF8FF58         LDR R1, #x8012606C30            ; :IO-CLOCK
; D2C:       B6F6FF58         LDR LEXENV, #x8012606C00        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; D30:       970080D2         MOVZ NARGS, #4
; D34:       DE9240F8         LDR LR, [LEXENV, #9]
; D38:       FD031BAA         MOV CFP, CSP
; D3C:       C0033FD6         BLR LR
; D40:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; D44:       AF1740F9         LDR R5, [CFP, #40]
; D48:       AB1340F9         LDR R1, [CFP, #32]
; D4C:       EB5104F8         STR R1, [R5, #69]
; D50:       E1D143F8         LDR NL1, [R5, #61]
; D54:       A01340F9         LDR NL0, [CFP, #32]
; D58:       1F0001EB         CMP NL0, NL1
; D5C:       8A090054         BGE L7
; D60:       E25143F8         LDR NL2, [R5, #53]
; D64:       E35142F8         LDR NL3, [R5, #37]
; D68:       E15145F8         LDR NL1, [R5, #85]
; D6C:       610001CB         SUB NL1, NL3, NL1
; D70:       3F0002EB         CMP NL1, NL2
; D74:       21B0829A         CSEL NL1, NL1, NL2, LT
; D78:       E20301AA         MOV NL2, NL1
; D7C:       EED144F8         LDR R4, [R5, #77]
; D80:       AE061037         TBNZ WR4, #2, L5
; D84:       F6030EAA         MOV LEXENV, R4
; D88: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; D8C:       E1D145F8         LDR NL1, [R5, #93]
; D90:       210800B1         ADDS NL1, NL1, #2
; D94:       A6080054         BVS L8
; D98:       E1D105F8         STR NL1, [R5, #93]
; D9C:       EAD140F8         LDR R0, [R5, #13]
; DA0:       EB5141F8         LDR R1, [R5, #21]
; DA4:       EC5145F8         LDR R2, [R5, #85]
; DA8:       7D0300F9         STR CFP, [CSP]
; DAC:       ED0302AA         MOV R3, NL2
; DB0:       170180D2         MOVZ NARGS, #8
; DB4:       DED25FF8         LDR LR, [LEXENV, #-3]
; DB8:       FD031BAA         MOV CFP, CSP
; DBC:       C0033FD6         BLR LR
; DC0:       4B138B9A         CSEL R1, NULL, R1, NE
; DC4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; DC8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; DCC:       F0030AAA         MOV R6, R0
; DD0:       EE030BAA         MOV R4, R1
; DD4:       F0000036         TBZ WR6, #0, L3
; DD8:       010E4092         AND NL1, R6, #15
; DDC:       3F3C00F1         CMP NL1, #15
; DE0:       C1010054         BNE L4
; DE4:       01125FF8         LDR NL1, [R6, #-15]
; DE8:       3F4404F1         CMP NL1, #273
; DEC:       61010054         BNE L4
; DF0: L3:   4E010037         TBNZ WR4, #0, L4
; DF4:       EA030FAA         MOV R0, R5
; DF8:       EB0310AA         MOV R1, R6
; DFC:       EC030EAA         MOV R2, R4
; E00:       ED0302AA         MOV R3, NL2
; E04:       36F0FF58         LDR LEXENV, #x8012606C08        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; E08:       170180D2         MOVZ NARGS, #8
; E0C:       DE9240F8         LDR LR, [LEXENV, #9]
; E10:       DE130091         ADD LR, LR, #4
; E14:       C0031FD6         BR LR
; E18: L4:   AF1700F9         STR R5, [CFP, #40]
; E1C:       EAF0FF58         LDR R0, #x8012606C38            ; :FAULTED
; E20:       E97D4BD3         UBFM TMP, R5, #11, #31
; E24:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; E28:       EAD106F8         STR R0, [R5, #109]
; E2C:       7D0300F9         STR CFP, [CSP]
; E30:       8AF0FF58         LDR R0, #x8012606C40            ; 'ARCDOCDB.SPK11::REJECTION
; E34:       ABF0FF58         LDR R1, #x8012606C48            ; :REASON
; E38:       CCF0FF58         LDR R2, #x8012606C50            ; :IO-RESULT
; E3C:       29A680D2         MOVZ TMP, #1329
; E40:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; E44:       D70080D2         MOVZ NARGS, #6
; E48:       FD031BAA         MOV CFP, CSP
; E4C:       C0033FD6         BLR LR
; E50:       AF1740F9         LDR R5, [CFP, #40]
; E54: L5:   EED142F8         LDR R4, [R5, #45]
; E58:       0AF0FF58         LDR R0, #x8012606C58            ; :INPUT
; E5C:       DF010AEB         CMP R4, R0
; E60:       C0000054         BEQ L6
; E64:       6AEDFF58         LDR R0, #x8012606C10            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; E68:       561140F8         LDR LEXENV, [R0, #1]
; E6C:       DF021AEB         CMP LEXENV, NULL
; E70:       E0010054         BEQ L9
; E74:       C5FFFF17         B L2
; E78: L6:   0AEDFF58         LDR R0, #x8012606C18            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; E7C:       561140F8         LDR LEXENV, [R0, #1]
; E80:       DF021AEB         CMP LEXENV, NULL
; E84:       60010054         BEQ L10
; E88:       C0FFFF17         B L2
; E8C: L7:   AAEEFF58         LDR R0, #x8012606C60            ; :EXPIRED
; E90:       E97D4BD3         UBFM TMP, R5, #11, #31
; E94:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; E98:       EAD106F8         STR R0, [R5, #109]
; E9C:       2AEEFF58         LDR R0, #x8012606C60            ; :EXPIRED
; EA0:       97FFFF17         B L0
; EA4:       E00120D4         BRK #15                         ; Invalid argument count trap
; EA8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; EAC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; EB0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
\")))
 :PROCESSES
 ((:STATUS :OK :MODE \"fragmented\" :SERVER-PID 28714 :CLIENT-PID 28716 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"fragmented\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 28716)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"coalesced\" :SERVER-PID 28714 :CLIENT-PID 28717 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"coalesced\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 28717)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"maximum\" :SERVER-PID 28714 :CLIENT-PID 28718 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"maximum\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
   \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 28718)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"zero\" :SERVER-PID 28714 :CLIENT-PID 28719 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"zero\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 28719)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"oversize\" :SERVER-PID 28714 :CLIENT-PID 28720 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"oversize\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 28720)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"truncated\" :SERVER-PID 28714 :CLIENT-PID 28721 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"truncated\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 28721)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session\" :SERVER-PID 28714 :CLIENT-PID 28723 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 28723)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 28714 :CLIENT-PID
   28725 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-invalid-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 28725)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 28714 :CLIENT-PID 28726
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-pre-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 28726)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 28714 :CLIENT-PID
   28727 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-oversize-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 28727)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 28714 :CLIENT-PID 28728
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-id-reuse\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 28728)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-server\" :SERVER-PID 28714 :CLIENT-PID 28777 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-server\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 28777)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-client\" :SERVER-PID 28714 :CLIENT-PID 28797 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-client\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 28797)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 28714 :CLIENT-PID 28798
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-truncated\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
   :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 28798)
\"
   :STDERR \"\"))
 :NAMESPACE
 (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
  :REPLACEMENT-PRESERVED T)
 :NATIVE-SYMLINK-BIND
 (:BIND-RESULT :BOUND :LINK (16777232 1579505432 41453) :TARGET
  (16777232 1579505433 49645))
 :LIMITS
 (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
  :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
"
 :STDERR
 "(:STATUS :OK :MODE \"fragmented\" :SERVER-PID 28714 :CLIENT-PID 28716 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"fragmented\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 28716)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"coalesced\" :SERVER-PID 28714 :CLIENT-PID 28717 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"coalesced\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 28717)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"maximum\" :SERVER-PID 28714 :CLIENT-PID 28718 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"maximum\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
 \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 28718)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"zero\" :SERVER-PID 28714 :CLIENT-PID 28719 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"zero\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 28719)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"oversize\" :SERVER-PID 28714 :CLIENT-PID 28720 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"oversize\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 28720)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"truncated\" :SERVER-PID 28714 :CLIENT-PID 28721 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"truncated\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 28721)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session\" :SERVER-PID 28714 :CLIENT-PID 28723 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 28723)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 28714 :CLIENT-PID 28725
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-invalid-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 28725)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 28714 :CLIENT-PID 28726
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-pre-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 28726)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 28714 :CLIENT-PID 28727
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-oversize-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 28727)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 28714 :CLIENT-PID 28728 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"session-id-reuse\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 1
  :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 28728)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-server\" :SERVER-PID 28714 :CLIENT-PID 28777 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-server\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 28777)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-client\" :SERVER-PID 28714 :CLIENT-PID 28797 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-client\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 28797)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 28714 :CLIENT-PID 28798 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-5FARFm/ipc.sock\" \"native-truncated\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-bSrIMB/\"))
 :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF) :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 28798)
\"
 :STDERR \"\")
")
